
create FUNCTION [dbo].[GetNextOrderNumForMmeAction](@mmeRosterId INT )
RETURNS INT
AS
BEGIN
	DECLARE @nextOrderNum INT = 1;
	DECLARE @recCount INT;
	
	SELECT
		@recCount = count(*), 
		@nextOrderNum = 
			CASE
				WHEN @recCount < 1 THEN 1
--				WHEN @recCount < 1 THEN 0 
				ELSE MAX(ORDER_) + 1
			END
	FROM MNT_MST_MME_ACTIONS 
	WHERE ROSTER_ID = @mmeRosterId
	
	RETURN @nextOrderNum;
END


go

