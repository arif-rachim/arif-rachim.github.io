CREATE PROCEDURE [dbo].[CleanTable]
	-- Add the parameters for the stored procedure here
	@tableName nvarchar(500)
AS
BEGIN
	DECLARE @sql nvarchar(100) = 'DELETE FROM ' + @tableName
	EXEC(@sql)
END
go

