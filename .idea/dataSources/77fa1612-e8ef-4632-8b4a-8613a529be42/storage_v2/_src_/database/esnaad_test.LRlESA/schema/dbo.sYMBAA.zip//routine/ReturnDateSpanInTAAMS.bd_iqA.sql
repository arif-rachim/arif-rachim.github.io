CREATE FUNCTION ReturnDateSpanInTAAMS(@fromDate DATETIME, @dateTo DATETIME) RETURNS decimal(9,1) 
AS
BEGIN
	DECLARE @return_taams_time decimal(9,1) 
	DECLARE @hourPart int 
	DECLARE @minutePart decimal(9,1)
	DECLARE @timeInMinutes decimal(9,3)
	
	SET @timeInMinutes = DATEDIFF(mi,@fromDate,@dateTo)
	
	if(@timeInMinutes >= 60) BEGIN
		SET @hourPart = @timeInMinutes / 60;
		SET @minutePart = @timeInMinutes -  (@hourPart * 60)
	END		
	ELSE BEGIN
		SET @hourPart = 0
		SET @minutePart =  @timeInMinutes
	END
	SET @return_taams_time =  @hourPart + ceiling(@minutePart/6) /10
	
	RETURN @return_taams_time
END
go

