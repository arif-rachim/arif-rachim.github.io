CREATE PROC [dbo].[STK_AddTempLocationByPercent] (
	@handle uniqueidentifier,
	@stId uniqueidentifier,
	@percent int
) AS
BEGIN
	DECLARE @totalLines int
	DECLARE @customPercentOfTotLines int

	DECLARE @paramsDef nvarchar(500)

	SELECT ST.STORE_ID st_store_id, LG.NAME_ lg_name, L.NAME_ l_name, LG.ID_ lg_id, L.ID_ l_id, C.CLS_ID_ c_cls_id, ST.L2_ID st_l2_id 
	INTO #locs
    FROM LOG_TRN_STM_STOCKTAKING2_LG STLG
    INNER JOIN LOG_TRN_STM_STOCKTAKING2 ST ON ST.ID_ = STLG.ST_ID
    INNER JOIN ADM_MST_UNIT_LOCATION_GROUP LG ON LG.ID_ = STLG.LG_ID_
    INNER JOIN LOG_TRN_STM_STOCKTAKING2_CLASS C ON C.ST_ID = ST.ID_
    INNER JOIN ADM_MST_UNIT_LOCATION L ON L.LG_ID = LG.ID_
    WHERE L.IS_ACTIVE_ = 1 AND ST.ID_ = @stId AND L.LOC_TYPE_ = 'Regular'

	SELECT @totalLines = SUM(x.LineItems) FROM (
	SELECT LgId, LocId, COUNT(UnitId) LineItems FROM (
			SELECT DISTINCT locs.lg_id LgId, locs.l_id LocId, U.ID_ UnitId
			FROM #locs locs
			INNER JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.BU_ID_ = locs.st_store_id AND IL.LOC_ID_ = locs.l_id AND (IL.OWNED_L2_ID_ = locs.st_l2_id OR locs.st_l2_id IS NULL) AND IL.TC_ID_ <> 16
			INNER JOIN ADM_MST_UNITS U ON U.ID_ = IL.UNIT_ID_
			INNER JOIN ADM_MST_ITEMS I ON I.ID_ = U.ITEM_ID AND I.CLS_ID_ = locs.c_cls_id
		) Y 
		GROUP BY LgId, LocId
	) X
	
	SET @customPercentOfTotLines = CAST(ROUND(@totalLines * (@percent / 100.0), 0) AS INT)

	INSERT LOG_TMP_STM_STOCKTAKING2_LOC_SELECTION (HANDLE_, LOC_ID, IS_PERC_, LINE_ITEMS_)
	SELECT @handle, LocId, 1, COUNT(UnitId) 
	FROM 
	(
		SELECT LgName, LocName, UnitId, LgId, LocId, Sum(ActualRow) OVER (ORDER BY RowId) AS ROW
		FROM (
			SELECT ROW_NUMBER() OVER(ORDER BY locs.lg_name,locs.l_name) RowId, locs.lg_name LgName, locs.l_name LocName,  
			U.ID_ UnitId, locs.lg_id LgId, locs.l_id LocId, (CASE WHEN U.ID_ IS NULL THEN 0 ELSE 1 END) AS ActualRow
			FROM #locs locs
			LEFT JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.BU_ID_ = locs.st_store_id AND IL.LOC_ID_ = locs.l_id AND (IL.OWNED_L2_ID_ = locs.st_l2_id OR locs.st_l2_id IS NULL)
			LEFT JOIN ADM_MST_UNITS U ON U.ID_ = IL.UNIT_ID_
			LEFT JOIN ADM_MST_ITEMS I ON I.ID_ = U.ITEM_ID
			WHERE (I.ID_ IS NULL OR (IL.TC_ID_ <> 16 AND I.CLS_ID_ = locs.c_cls_id))
			AND locs.l_id NOT IN (
				SELECT LOC_ID_ FROM dbo.STK_FindLocationReferences(@stId, 0)
			)
			AND NOT EXISTS (
				SELECT 1 FROM LOG_TRN_STM_STOCKTAKING2_LOCKED_LOC LL
				WHERE LL.LOC_ID = locs.l_id AND LL.CLS_ID = locs.c_cls_id 
			) 
			AND locs.l_id NOT IN  (
				SELECT STL.LOC_ID
				FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC AS STL 
				INNER JOIN LOG_TRN_STM_SUB_STOCKTAKING2 AS SST ON SST.ID_ = STL.SST_ID 
				WHERE SST.ST_ID = @stId
			)
			GROUP BY locs.lg_name, locs.l_name, U.ID_, locs.lg_id, locs.l_id 
		) Z
	) X
	WHERE ROW BETWEEN 0 AND @customPercentOfTotLines
	GROUP BY LgName, LocName, LgId,  LocId
END
go

