CREATE VIEW [dbo].[VW_OPS_FSD_FLEET_STRENGTH]
AS
WITH 
TOTALPILOTS (CommandId, PlatformId, Pilots)
AS (
       SELECT BAT.PRNT_ID AS CommandId, FC.PRI_PLTF_ID_ AS PlatformId, COUNT(FC.ID_) TotalPilots
       FROM OPS_MST_FLIGHT_CREWS FC
       JOIN ADM_MST_PROF_QUALIFICATIONS Q ON Q.ID_ = FC.QUALF_ID
       JOIN ADM_MST_QUALFCN_CATS QC ON QC.ID_ = Q.CAT_ID
       JOIN ADM_MST_RESTRICTIONS COY ON COY.ID_ = FC.COMPANY_ID
       JOIN ADM_MST_RESTRICTIONS BAT ON BAT.ID_ = COY.PRNT_ID
       jOIN ADM_TRN_USER_PROFILES USR on USR.ID_=FC.PERSON_ID
       WHERE QC.CODE_='P' AND FC.PRI_PLTF_ID_ IS NOT NULL and USR.IS_MILITARY_ = 1
       GROUP BY BAT.PRNT_ID, FC.PRI_PLTF_ID_
),
ACFT (CommandId, PlatformId, Platform, TailUnitId, TailNum, Status)
AS (
       SELECT BAT.PRNT_ID AS CommandId 
       , P.ID_ AS PlatformId, P.CODE_ AS Platform
       , U.ID_ AS TailUnitId, T.T_NUM_ AS TailNum
       , CASE 
              WHEN SC.COND_ID = 32 OR SC.COND_ID = 36 OR SC.COND_ID = 37 OR SC.COND_ID IS NULL THEN 'MC'
              ELSE 'NMC'
         END AS Status
       FROM ADM_MST_TAILS T
       JOIN ADM_MST_UNITS U ON T.UNIT_ID = U.ID_
       JOIN ADM_MST_PLATFORMS P ON P.ID_ = U.ITEM_ID
       JOIN ADM_MST_RESTRICTIONS BAT ON BAT.ID_ = T.BATLN_ID
       LEFT JOIN MNT_TRN_AIRCRAFT_SERVS SRV ON SRV.UNIT_ID = U.ID_
       LEFT JOIN ADM_MST_STATUS_CONDITIONS SC ON SC.ID_ = SRV.STSCND_ID
       WHERE T.END_DATE_='9999-12-31 00:00:00.000'
),
ACFTMC (CommandId, PlatformId, McAcft)
AS (
       SELECT CommandId,PlatformId,COUNT(TailUnitId) AS McAcft FROM ACFT
       WHERE Status='MC'
       GROUP BY CommandId, PlatformId
),
ACFTTOT (CommandId, PlatformId, TotAcft)
AS (
       SELECT CommandId,PlatformId,COUNT(TailUnitId) AS TotAcft FROM ACFT
       GROUP BY CommandId, PlatformId
),
PLTFCFG (CommandId, PlatformId, MinPilots)
AS (
       SELECT DISTINCT BAT.PRNT_ID AS CommandId, P.ID_ AS PlatformId, ISNULL(PC.MIN_PILOTS_ ,1) MinPilots
       FROM ADM_MST_TAILS T
       JOIN ADM_MST_UNITS U ON U.ID_ = T.UNIT_ID
       JOIN ADM_MST_PLATFORMS P ON P.ID_ = U.ITEM_ID
       JOIN ADM_MST_RESTRICTIONS BAT ON BAT.ID_ = T.BATLN_ID
       LEFT JOIN ADM_MST_PFC_PLATFORM_CONFIG PC ON PC.CMD_ID_ = BAT.PRNT_ID AND PC.PLTF_ID_ = P.ID_
       WHERE T.END_DATE_='9999-12-31 00:00:00.000'
),
COMBATREADINESS2 (CommandId,PlatformId,TotalPilots,CombatReady,CombatReadiness) 
AS (
       SELECT TP.CommandId, TP.PlatformId, TP.Pilots AS TotalPilots, ISNULL(CR.Pilots,0) AS CombatReady, ROUND(((ISNULL(CR.Pilots,0)* 100.0) /TP.Pilots),2) AS CombatReadiness
       FROM
       TOTALPILOTS TP 
       LEFT JOIN VW_FSD_COMBATREADINESS CR ON TP.CommandId = CR.CommandId AND TP.PlatformId = CR.PlatformId
),
TOTMCACFT (CommandId, PlatformId, TotAcft, McAcft, TotPilotReq, MinPilots) 
AS (
       SELECT A.CommandId, A.PlatformId, TotAcft, ISNULL(McAcft,0) AS McAcft
       , (P.MinPilots * ISNULL(McAcft,0)) AS TotPilotReq, P.MinPilots
       FROM ACFTTOT A
       LEFT JOIN ACFTMC M ON A.CommandId = M.CommandId AND A.PlatformId = M.PlatformId
       JOIN PLTFCFG P ON A.CommandId = P.CommandId AND A.PlatformId = P.PlatformId
)

SELECT CMD.ID_ AS CommandId, CMD.CODE_ AS CommandCode
, M.PlatformId, ISNULL(TotAcft,0) AS TotAcft, ISNULL(McAcft,0) AS McAcft, ISNULL(TotPilotReq,0) AS TotPilotReq
, ISNULL(TotalPilots,0) AS TotalPilots, ISNULL(MinPilots,0) AS MinPilots
,ISNULL(CombatReady,0) AS CombatReady, CAST(ISNULL(CombatReadiness, 0) AS decimal(5,2)) AS CombatReadiness
, (CASE WHEN TotPilotReq >= ISNULL(CombatReady,0) THEN ISNULL(CombatReady,0)/MinPilots ELSE ISNULL(McAcft,0) END) AS FleetStrength 
FROM 
ADM_MST_RESTRICTIONS CMD 
LEFT JOIN TOTMCACFT M ON CMD.ID_ = M.CommandId 
LEFT JOIN COMBATREADINESS2 CR2 ON CR2.CommandId = M.CommandId AND CR2.PlatformId = M.PlatformId
WHERE CMD.TYPE_NAME_='Command'
go

