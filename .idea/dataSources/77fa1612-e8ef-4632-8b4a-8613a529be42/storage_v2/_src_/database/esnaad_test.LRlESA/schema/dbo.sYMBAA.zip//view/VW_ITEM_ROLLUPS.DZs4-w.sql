CREATE VIEW dbo.VW_ITEM_ROLLUPS AS
--if are no alternate parts, then consider the same item id as primary id
SELECT	ia.ITEM_ID, ia.L2_ID, ia.ITEM_ID ROLLUP_ITEM_ID_, ia.PRIMARY_PART_ ROLLUP_IS_SET_AS_PRIMARY_
FROM	ADM_TRN_ITEM_ASSOCS ia
WHERE	ia.IN_LIEU_CODE_ is null
UNION 
--if there are alternate parts and primary part is flagged, get that part's item id
SELECT	ia.ITEM_ID, ia.L2_ID, ilia.ITEM_ID ROLLUP_ITEM_ID_, ilia.PRIMARY_PART_ ROLLUP_IS_SET_AS_PRIMARY_
FROM	ADM_TRN_ITEM_ASSOCS ia
		join ADM_TRN_ITEM_ASSOCS ilia ON ia.IN_LIEU_CODE_ = ilia.IN_LIEU_CODE_
WHERE	ia.IN_LIEU_CODE_ is not null
		and ilia.PRIMARY_PART_ = 1
UNION 
--if there are alternate parts but primary part is not flagged, get the minimum item id in the group as primary id
SELECT	ia.ITEM_ID, ia.L2_ID, min(ilia.ITEM_ID) ROLLUP_ITEM_ID_, 0 ROLLUP_IS_SET_AS_PRIMARY_
FROM	ADM_TRN_ITEM_ASSOCS ia
		join ADM_TRN_ITEM_ASSOCS ilia ON ia.IN_LIEU_CODE_ = ilia.IN_LIEU_CODE_
WHERE	ia.IN_LIEU_CODE_ is not null
		and not exists (
			SELECT	1 
			FROM	ADM_TRN_ITEM_ASSOCS ia2 
			WHERE	ia.IN_LIEU_CODE_ = ia2.IN_LIEU_CODE_ and ia2.PRIMARY_PART_ = 1
			)
GROUP	BY ia.ITEM_ID, ia.L2_ID
UNION
--there are scenarios where the item has no association with the l2 in catalog but there is inventory for such item-l2 combination
--In such scenarios, choose the same item id as rollup item id
SELECT	units.ITEM_ID, imv.OWNED_L2_ID_, units.ITEM_ID ROLLUP_ITEM_ID_, 0 ROLLUP_IS_SET_AS_PRIMARY_
FROM	ADM_TRN_IMV_ITEMS_IN_LOCATION imv
		join ADM_MST_UNITS units on imv.unit_id_ = units.id_
WHERE	not exists (
			SELECT	1
			FROM	ADM_TRN_ITEM_ASSOCS ia
			WHERE	ia.ITEM_ID = units.ITEM_ID 
					and ia.L2_ID = imv.OWNED_L2_ID_
		)
GROUP	BY units.ITEM_ID, imv.OWNED_L2_ID_
go

