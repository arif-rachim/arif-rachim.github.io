CREATE FUNCTION [dbo].[TadbeerGetItemsInRepair]
  (
    @item_id bigint,
    @cmdId bigint = 0
    )
  RETURNS bigint
  AS
  BEGIN

    DECLARE @RFCOUNT BIGINT

    SELECT @RFCOUNT = COUNT(1)
    FROM LOG_TRN_RPR_REPAIR_FILE RF
           INNER JOIN ADM_MST_BUSINESS_UNITS TFU ON TFU.ID_ = RF.TFU_ID_
    WHERE ITEM_ID = @item_id
      AND TFU.CMD_ID_ = CASE WHEN @cmdId > 0 THEN @cmdId ELSE TFU.CMD_ID_ END
      AND STATUS_ NOT IN ('RepairOrderClosed', 'Closed')

    RETURN ISNULL(@RFCOUNT, 0)

  END
go

