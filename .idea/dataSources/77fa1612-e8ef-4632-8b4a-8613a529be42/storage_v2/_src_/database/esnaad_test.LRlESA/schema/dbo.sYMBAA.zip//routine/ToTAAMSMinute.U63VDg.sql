CREATE FUNCTION [dbo].[ToTAAMSMinute](@minutes int) RETURNS int
AS
BEGIN
 DECLARE @adder int
 
 SET @adder = 0
 IF(@minutes % 6 <> 0) SET @adder = 6
 
 RETURN (@minutes / 6) * 6 + @adder
END
go

