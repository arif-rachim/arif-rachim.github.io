CREATE FUNCTION ConvertDateToDDMMMYYYY
(
	-- Add the parameters for the function here
	@date DateTime
)
RETURNS Varchar(21)
AS
BEGIN
	declare @ddmmmyyyy varchar(11) = null;

	select @ddmmmyyyy = upper(isNull(
		replace(
			convert(varchar, @date, 106)
		, ' ','-')
	, null))

	return @ddmmmyyyy

END
go

