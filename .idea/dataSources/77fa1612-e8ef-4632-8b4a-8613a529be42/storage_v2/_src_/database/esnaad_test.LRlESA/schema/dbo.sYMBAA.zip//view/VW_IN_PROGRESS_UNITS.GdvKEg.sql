CREATE view [dbo].[VW_IN_PROGRESS_UNITS] as
--in progress transactions
with cte as (
	--work orders
		select	wo.id_ TRANSACTION_ID,
				wo.WO_NO_ TRANSACTION_NUMBER,
				'WorkOrder' TRANSACTION_TYPE,
				wo.EI_UNIT_ID_ UNIT_ID
		from	MNT_TRN_WOTS_WORK_ORDER wo 
		where	wo.WO_CONDITION_ in ('Drafted', 'Active')
				and wo.EI_UNIT_ID_ is not null
		union	all
		--defect reports
		select	dr.ID_ TRANSACTION_ID,
				dr.DEFECT_NO_ TRANSACTION_NUMBER,
				'DefectReport' TRANSACTION_TYPE,
				dr.UNIT_ID_ UNIT_ID
		from	MNT_TRN_DFR_DEFECT_REPORT dr
				join WF_TRN_INSTANCE wti on dr.WF_ID = wti.ID_ AND wti.WF_DEF_ID_='DefectReportWorkflow'
		where	wti.WF_STS_ = 'Active'
				and wti.WF_STATE_ <> 'Closed'
		union	all
		--tfu awaiting reception
		select	dr.id_ TRANSACTION_ID,
				dr.DEFECT_NO_ TRANSACTION_NUMBER,
				'DefectReport' TRANSACTION_TYPE,
				tfu.UNIT_ID_ UNIT_ID
		from	LOG_TRN_TFR_TFU_RECEIVING tfu
				join MNT_TRN_DFR_DEFECT_REPORT dr on tfu.DEFECT_REPORT_NO_ = dr.DEFECT_NO_
		where	tfu.RECEIVED_DATE_ is null
		union	all
		--tfu units in progress 
		select	rf.id_ TRANSACTION_ID,
				rf.repair_file_no_ TRANSACTION_NUMBER,
				'Repair' TRANSACTION_TYPE,
				rf.UNIT_ID UNIT_ID
		from	ADM_MST_UNIT_LOCATION loc
				join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.loc_id_ = loc.id_
				join LOG_TRN_RPR_REPAIR_FILE rf on rf.unit_id = imv.unit_id_ and rf.TFU_ID_ = imv.BU_ID_
		where	loc.LOC_TYPE_ = 'Regular' 
				and loc.LOC_DISC_TYPE_ = 'Regular'
				and rf.STATUS_ not in ('Closed')
		union	all
		--tfu units sent to vendor, awaiting reception
		select	rf.id_ TRANSACTION_ID,
				rf.repair_file_no_ TRANSACTION_NUMBER,
				'Repair' TRANSACTION_TYPE,
				rf.UNIT_ID UNIT_ID
		from	ADM_MST_UNIT_LOCATION loc
				join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.loc_id_ = loc.id_
				join LOG_TRN_RPR_REPAIR_FILE rf on rf.unit_id = imv.unit_id_
		where	loc.LOC_TYPE_ = 'Virtual' 
				and loc.LOC_DISC_TYPE_ = 'Regular'
				and rf.STATUS_ not in ('Closed' , 'RepairOrderValidated')
		union	all
		--tfu unit sent to vendor, awaiting reception
		--handle RepairOrderValidated cases if they have active dues in (to tackle old issue where RepairOrderValidated was end state)
		select	rf.id_ TRANSACTION_ID,
				rf.repair_file_no_ TRANSACTION_NUMBER,
				'Repair' TRANSACTION_TYPE,
				rf.UNIT_ID UNIT_ID
		from	ADM_MST_UNIT_LOCATION loc
				join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.loc_id_ = loc.id_
				join LOG_TRN_RPR_REPAIR_FILE rf on rf.unit_id = imv.UNIT_ID_
		where	rf.STATUS_ = 'RepairOrderValidated'
				and exists (
					select	1 
					from	VW_DUES_IN_DETAILS din 
							join LOG_TRN_ROM_REPAIR_ORDER_ITEM roi on din.line_id_ = roi.id_
					where	rf.status_ = 'RepairOrderValidated'
							and din.DOC_TYPE_ = 'RepairOrder'
							and roi.repair_file_ref_ = rf.repair_file_no_
					)
		union	all
		--in transit serviceable turn ins
		select	tti.id_ TRANSACTION_ID,
				tti.turn_in_no_ TRANSACTION_NUMBER,
				'ServiceableTurnIn' TRANSACTION_TYPE,
				ti.unit_id UNIT_ID
		from	LOG_TRN_TIN_TURN_IN_ITEM ti
				join LOG_TRN_TIN_TURN_IN tti on ti.turn_in_id = tti.id_
		where	ti.STATUS_ in ('Validated', 'Created')
				and ti.unit_id is not null
		union	all
		--serviceable turn ins that are rejected but can be acted upon again
		--select	tti.id_ TRANSACTION_ID,
		--		tti.turn_in_no_ TRANSACTION_NUMBER,
		--		'ServiceableTurnIn' TRANSACTION_TYPE,
		--		ti.unit_id UNIT_ID
		--from	LOG_TRN_TIN_TURN_IN_ITEM ti
		--		join LOG_TRN_TIN_TURN_IN tti on ti.turn_in_id = tti.id_
		--where	ti.STATUS_ = 'RejectedByReceiver'
		--		and ti.unit_id is not null
		--		and not exists ( 
		--		--unless the turn-in is partially received, it can be reused
		--		--so, below check is intended to make sure turn in is not partially received
		--			select	1 
		--			from	LOG_TRN_TIN_TURN_IN_ITEM tii 
		--			where	tii.turn_in_id = ti.turn_in_id 
		--					and ti.UNIT_ID <> tii.UNIT_ID
		--					and tii.STATUS_ in ('Received')
		--			)
		--union 	all
		--asset transactions
		select	tr.id_ TRANSACTION_ID,
				tr.pbo_movement_no_ TRANSACTION_NUMBER,
				'PBO' TRANSACTION_TYPE,
				tri.unit_id UNIT_ID
		from	LOG_TRN_ASM_ASSET_TRANSACTION tr
				join LOG_TRN_ASM_ASSET_TRANSACTION_ITEM tri on tri.TR_ID = tr.ID_
		where	tr.STATUS_ in ('Approved','AwaitingApproval','Created','Validated','Assigned')
		union all
		--delivery note items not yet located
		select	dn.id_ TRANSACTION_ID,
				dn.delivery_no_ TRANSACTION_NUMBER,
				'DeliveryNote' TRANSACTION_TYPE,
				din.unit_id_ UNIT_ID
		from	LOG_TRN_REC_DELIVERY_NOTE dn
				join LOG_TRN_RCM_UNIT_DUES_IN din on din.BU_ID_ = dn.BU_ID and din.L2_ID_ = dn.L2_ID and din.DOC_REF_NO_ = dn.DELIVERY_REF_ and din.SUP_ID_ = dn.SUP_ID 
		where	1=1 
				and din.PNR_NO_ is not null
		union	all
		--transfers to be received or located
		select	trq.id_ TRANSACTION_ID,
				trq.tr_no_ TRANSACTION_NUMBER,
				'Transfer' TRANSACTION_TYPE,
				din.UNIT_ID_ UNIT_ID
		from	LOG_TRN_TRM_TRANSFER_REQUEST trq
				join LOG_TRN_RCM_UNIT_DUES_IN din on trq.RI_BU_ID_ = din.BU_ID_ and trq.RI_L2_ID_ = din.L2_ID_ and trq.TR_NO_ = din.DOC_REF_NO_
		where	trq.TR_TYPE_ in ('StoreTransfer', 'DirectTransfer')
		union	all
		--loans to be received or located
		select	el.ID_ TRANSACTION_ID,
				el.LOAN_NO_ TRANSACTION_NUMBER,
				'ExternalLoan' TRANSACTION_TYPE,
				din.UNIT_ID_ UNIT_ID
		from	LOG_TRN_ELM_EXTERNAL_LOAN el
				join LOG_TRN_RCM_UNIT_DUES_IN din on el.LOAN_NO_ = din.DOC_REF_NO_
		union 	all
		--scrap request in created status
		select	scr.id_ TRANSACTION_ID,
				scr.scrap_req_no_ TRANSACTION_NUMBER,
				'Scrap' TRANSACTION_TYPE,
				sri.unit_id UNIT_ID
		from	LOG_TRN_SCR_SCRAP_REQUEST scr
				join LOG_TRN_SCR_SCRAP_REQUEST_ITEM sri on scr.id_ = sri.sr_id 
		where	scr.STATUS_ in ('Created')
		and		sri.UNIT_ID is not null
		union 	all
		--scrap requests validated but not yet received by logistics
		select	scr.id_ TRANSACTION_ID,
				scr.scrap_req_no_ TRANSACTION_NUMBER,
				'Scrap' TRANSACTION_TYPE,
				sri.unit_id UNIT_ID
		from	LOG_TRN_SCR_SCRAP_REQUEST scr
				join LOG_TRN_SCR_SCRAP_REQUEST_ITEM sri on scr.id_ = sri.sr_id 
		where	scr.STATUS_ in ('Validated')
		and		sri.UNIT_ID is not null
		and		not exists (
					select	1
					from	LOG_TRN_SCR_SCRAP_ITEM si
					where	sri.id_ = si.SRAP_REQUEST_ITEM_ID
				)
		union 	all
		--scrap requests received and in progress 
		select	scr.id_ TRANSACTION_ID,
				scr.scrap_req_no_ TRANSACTION_NUMBER,
				'Scrap' TRANSACTION_TYPE,
				sri.unit_id UNIT_ID
		from	LOG_TRN_SCR_SCRAP_REQUEST scr
				join LOG_TRN_SCR_SCRAP_REQUEST_ITEM sri on scr.id_ = sri.sr_id 
				join LOG_TRN_SCR_SCRAP_ITEM si on sri.id_ = si.SRAP_REQUEST_ITEM_ID
		where	scr.STATUS_ in ('Validated')
		and		sri.UNIT_ID is not null
		and		not exists (
					select	1
					from	LOG_TRN_SCR_SCRAP_INSTRUCTION_FORM_ITEM ifi
							join LOG_TRN_SCR_SCRAP_DISPOSAL_DOCUMENT_ITEM ddi on ifi.id_ = ddi.SCRAP_INSTR_FORM_ITEM_ID
							join LOG_TRN_SCR_SCRAP_DISPOSAL_DOCUMENT dd on ddi.SCRAP_DISPOSAL_DOC_ID = dd.ID_
					where	ifi.SCRAP_ITEM_ID = si.ID_
					and		dd.STATUS_ = 'Disposed'
				)
			
		-- Quarantine in progress
		union all
		select qd.ID_ TRANSACTION_ID,
			qd.DOC_NO_ TRANSACTION_NUMBER,
			'Quarantine' TRANSACTION_TYPE,
			qdi.UNIT_ID UNIT_ID
		from LOG_TRN_QRM_QUARANTINE_DOCUMENT_ITEM qdi
		join LOG_TRN_QRM_QUARANTINE_DOCUMENT qd on qd.ID_ = qdi.QD_ID
		where qdi.INSP_STATUS_ = 'RequiredInspection'
			
		-- Tools
		union all
		SELECT
			REG.ID_		TRANSACTION_ID,
			null		TRANSACTION_NUMBER,
			'Tools'		TRANSACTION_TYPE,
			REG.UNIT_ID UNIT_ID

		FROM LOG_TRN_TOM_TOOLS_REGISTER AS REG 
		LEFT JOIN ADM_TRN_CAL_UNIT_CALIBRATION AS CAL ON CAL.UNIT_ID = REG.UNIT_ID
		JOIN ADM_MST_UNITS AS UNT ON REG.UNIT_ID = UNT.ID_ 
		LEFT JOIN ADM_MST_BUSINESS_UNITS AS BU ON BU.ID_ = REG.STORE_ID 
		LEFT JOIN(
			SELECT ROW_NUMBER() OVER (PARTITION BY UNIT_ID_ ORDER BY CREATED_ON_ DESC) AS ROW_NUM, *
			FROM ADM_TRN_IMV_ITEMS_IN_LOCATION
		) AS IMV ON IMV.ROW_NUM = 1 AND IMV.UNIT_ID_= UNT.ID_ 
		LEFT JOIN ADM_MST_UNIT_LOCATION AS IMVLOC ON IMV.LOC_ID_ = IMVLOC.ID_ 
		LEFT JOIN ADM_MST_UNIT_LOCATION_GROUP AS IMVLGR ON IMVLOC.LG_ID = IMVLGR.ID_ 
		LEFT JOIN ADM_MST_BUSINESS_UNITS AS IMVBU ON IMVLGR.BU_ID = IMVBU.ID_ 
		LEFT JOIN (
			SELECT DISTINCT ud.UNIT_ID_, ud.BU_ID_, 'Arriving' AS STATUS_
			FROM LOG_TRN_RCM_UNIT_DUES_IN AS ud
			INNER JOIN ADM_MST_BUSINESS_UNITS AS bu ON ud.BU_ID_ = bu.ID_ 
			WHERE 1 = 1
			AND ud.PNR_NO_ IS NULL AND ud.QTY_ > ISNULL(ud.LOC_QTY_, 0)
			AND bu.CMD_ID_ = 2
		) AS UD ON UD.UNIT_ID_ = UNT.ID_ AND UD.BU_ID_ = BU.ID_
		LEFT JOIN (
			SELECT DISTINCT DTN.UNIT_ID, TR.RI_BU_ID_, 'Arriving' AS STATUS_
			FROM LOG_TRN_TRM_TRANSFER_REQUEST_ITEM AS TRI
			INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST AS TR ON TR.ID_ = TRI.TR_ID_
			INNER JOIN LOG_TRN_TRF_TRANSFER_DATA TRD ON TR.TR_NO_ = TRD.DOC_REF_NO_ 
			INNER JOIN LOG_TRN_TRM_DIRECT_TRANSFER_UNIT AS DTN ON DTN.DTI_ID_ = TRI.ID_ 
			WHERE 1 = 1
			AND TR.TR_TYPE_ = 'DirectTransfer'
			AND TRD.RCV_DATE_ IS NULL
		) AS TRN ON TRN.UNIT_ID = UNT.ID_ AND TRN.RI_BU_ID_ = BU.ID_
		WHERE BU.CMD_ID_ = 2 
		AND REG.L2_ID_ IN(
			SELECT L2.L2_ID 
			FROM ADM_MST_SEC_L2_COMMAND AS L2 
			WHERE L2.CMD_ID = 2
		) 
		AND (
		CASE 
					
			IIF(UD.STATUS_ IS NOT NULL, UD.STATUS_, 
			IIF(TRN.STATUS_ IS NOT NULL, TRN.STATUS_, 
			IIF(LEFT(CAL.DOC_REF_, 2) = 'WO' OR LEFT(CAL.DOC_REF_, 2) = 'DR', 'InCalibration', 
			IIF(REG.STATUS_ = 'InCalibration', 'InStore', REG.STATUS_))))
					
			WHEN 'InStore' THEN IIF(BU.CODE_ = IMVBU.CODE_, 'InStore', 'OutofStore')
			WHEN 'OutofStore' THEN IIF(BU.CODE_ = IMVBU.CODE_, 'InStore', 'OutofStore')
			WHEN 'InCalibration' THEN 'In Calibration' 
			WHEN 'Arriving' THEN 'Arriving'
			ELSE REG.STATUS_ 
		END in ('InCalibration', 'InStore', 'OutofStore')
		)
			
		-- Locked location
		union all
		select distinct null TRANSACTION_ID,
			null TRANSACTION_NUMBER,
			'LocationLocked' TRANSACTION_TYPE,
			imv.UNIT_ID_ UNIT_ID
		from ADM_TRN_IMV_ITEMS_IN_LOCATION imv
		join ADM_MST_UNIT_LOCATION loc on loc.ID_ = imv.LOC_ID_
		where loc.IS_LOCKED_ = 1
)

select	tr.TRANSACTION_ID,
		tr.TRANSACTION_NUMBER,
		tr.TRANSACTION_TYPE,
		tr.UNIT_ID,
		imv.LOC_ID_ LOC_ID, --need to bring location from transactions. valid for non serialized
		1 QTY --hard coded as 1 for serialized. when non-serialized is introduced, it has to be derived from transactions
from	(
			select cte.TRANSACTION_ID, cte.TRANSACTION_NUMBER, cte.TRANSACTION_TYPE, cte.UNIT_ID
			from cte

			-- RCM
			union all
			select distinct null TRANSACTION_ID, 
				rcm.DOC_REF_NO_ TRANSACTION_NUMBER, 
				'RCM' TRANSACTION_TYPE,
				rcm.UNIT_ID_ UNIT_ID
			from LOG_TRN_RCM_UNIT_DUES_IN rcm
			join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.UNIT_ID_ = rcm.UNIT_ID_
			join ADM_MST_UNIT_LOCATION loc on loc.ID_ = imv.LOC_ID_
			join ADM_MST_BUSINESS_UNITS bu on bu.ID_ = rcm.BU_ID_
			where bu.BU_TYPE_ = 'Store'
				and rcm.DOC_REF_NO_ not in (select cte.TRANSACTION_NUMBER from cte)
		) as tr
		join ADM_MST_UNITS units on tr.UNIT_ID = units.ID_
		join ADM_MST_ITEMS items on units.ITEM_ID = items.ID_
		join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.UNIT_ID_ = tr.UNIT_ID
where	1=1
		and items.SERIALIZED_ = 1
go

