CREATE FUNCTION [dbo].[D16IsOverdue]
(
  @dueHours            real,
  @dueLandings         int,
  @dueDate             datetime,
  @currentTotalMinutes int,
  @currentLandings     int
  )
  RETURNS bit
AS
BEGIN
  IF (@dueHours IS NOT NULL AND @dueHours < isnull(dbo.ReturnTAAMSTime(@currentTotalMinutes), 0))
    RETURN 1;
  ELSE
    IF (@dueLandings IS NOT NULL AND @dueLandings < isnull(@currentLandings, 0))
      RETURN 1;
    ELSE
      IF (@dueDate IS NOT NULL AND @dueDate < convert(date, GETDATE()))
        RETURN 1;
  RETURN 0;
END;
go

