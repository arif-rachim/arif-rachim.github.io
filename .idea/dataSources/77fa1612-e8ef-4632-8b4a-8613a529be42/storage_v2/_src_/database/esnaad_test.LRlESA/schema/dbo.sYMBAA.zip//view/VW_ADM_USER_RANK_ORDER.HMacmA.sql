CREATE view [dbo].[VW_ADM_USER_RANK_ORDER]
as
select up.ID_, 
    up.USER_ID_,
	up.F_NAME_ + ISNULL(' ' + up.M_NAME_,'') + ISNULL(' ' + up.L_NAME_,'') as FULL_NAME_,
	up.MOBILE_,
    rnk.CODE_ as RANK_,
    up.ACTIVE_PERSONNEL_,
	up.IS_MILITARY_,
	up.RANK_ID as RANK_ID_,
	up.LAST_PROMOTION_DATE_,
	ROW_NUMBER() over(
		order by 
			up.IS_MILITARY_ desc,
			jrnk.JAC_RANK_ORDER desc, 
			(isnull(up.LAST_PROMOTION_DATE_, getdate())) asc,
			(CASE WHEN rnk.ID_=21 then 1 ELSE 0 END) ASC, 
			CONVERT(bigint, (CASE WHEN PATINDEX('%[0-9]%' ,up.USER_ID_)=0 THEN '999999' else SUBSTRING(up.USER_ID_, PATINDEX('%[0-9]%' ,up.USER_ID_),  LEN(up.USER_ID_)) END)) ASC,
			up.USER_ID_ ASC
	) as ORDER_
from ADM_TRN_USER_PROFILES up
inner join ADM_MST_SIMPLE_REF rnk ON up.RANK_ID = rnk.ID_
left join (
	select distinct(RANK_ID), JAC_RANK_ORDER from  BIZ_JAC_MAP_RANK
) as jrnk on jrnk.RANK_ID = up.RANK_ID
go

