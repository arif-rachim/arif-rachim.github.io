CREATE VIEW [dbo].[VW_LOG_TRN_PENDING_DUES_OUT_LIST_IN_TRF]
AS
SELECT     IIR.ID_ AS Id, I.PART_NO_ AS PartNumber, I.NOMENCLATURE_ AS Nomenclature, I.NSN_ AS Nsn, SM.REF_NUM_ AS RequisitionDoc, 
                      SM.REQ_DATE_ AS RequisitionDate, SM.PRIORITY_ AS Priority, T.T_NUM_ AS Tail, WO.WO_NUM_ AS WorkOrder, U.SERIAL_NO_ AS EndItem, 
                      IIR.REQ_QTY_ AS PendingQty, IIR.IN_LIEU_ AS InLieuAccepted, IIR.ITEM_ID AS ItemId, SM.FF_BU_ID AS RequestingBuId
FROM         dbo.LOG_TRN_STOCK_MOVEMENT AS SM INNER JOIN
                      dbo.LOG_TRN_ITEM_IN_REQUEST AS IIR ON SM.ID_ = IIR.SM_ID AND SM.SM_TYPE_ = 'REQ' AND (UPPER(SM.WF_STATE_) = 'APPROVED' OR
                      UPPER(SM.WF_STATE_) = 'PARTIALLYFULFILLED') INNER JOIN
                      dbo.ADM_MST_BUSINESS_UNITS AS BU ON SM.FF_BU_ID = BU.ID_ INNER JOIN
                      dbo.ADM_MST_ITEMS AS I ON IIR.ITEM_ID = I.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_UNITS AS U ON SM.END_ITEM_ID = U.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_TAILS AS T ON U.ID_ = T.UNIT_ID LEFT OUTER JOIN
                      dbo.MNT_TRN_WORK_ORDER AS WO ON SM.WO_ID = WO.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_ITEMS AS II ON SM.END_ITEM_ID = II.ID_
WHERE     (IIR.IN_TRF_ = 'TRUE')
go

