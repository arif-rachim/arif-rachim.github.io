CREATE VIEW [dbo].[VW_2408ForecastReportData]
AS
SELECT DISTINCT ASSCOMP.ID_                                            AS Id
              , ISNULL(nha_item.PART_NO_, COMPITEM.PART_NO_)           AS PartNo
              , ISNULL(nha_item.ID_, COMPITEM.ID_)                     AS ItemId
              , COMPSMFR.CAGE_CODE_                                    AS MFR
              , ISNULL(nha_item.NOMENCLATURE_, compitem.NOMENCLATURE_) AS Nomenclature
              , ISNULL(nha_item.PBL_, compitem.PBL_)                   AS PblItemType
              , PLATFORMS.ID_                                          AS PlatformId
              , PLATFORMS.CODE_                                        AS Platform
              , COMPTAIL.T_NUM_                                        AS Tail
              , ISNULL(nha_unit.SERIAL_NO_, COMPUNIT.SERIAL_NO_)       AS SerialNo
              , COMP.UNIT_ID_                                          AS UnitId
              , CMD.ID_                                                AS CommandId
              , CMD.CODE_                                              AS Command
              , IIF(nha.ID_ IS NOT NULL, nha_due._date, c_due._date)   AS RepDueDate
              , COMPUNIT.MANF_DATE_                                    AS ManuDate
              , MACOMP.REP_CAL_UNIT_
              , MACOMP.REP_CAL_VALUE_
              , MACOMP.TSI_VALUE_
              , ASSCOMP.INST_DATE_
              , COMPUNIT.MANF_DATE_
              , (CASE
                   WHEN (MACOMP.REP_CAL_UNIT_ = 'Months') AND (MACOMP.REP_CAL_VALUE_ >= MACOMP.TSI_VALUE_) THEN MACOMP.REP_CAL_VALUE_
                   WHEN (MACOMP.REP_CAL_UNIT_ = 'Months') AND (MACOMP.REP_CAL_VALUE_ < MACOMP.TSI_VALUE_) THEN MACOMP.TSI_VALUE_
                   WHEN (MACOMP.REP_CAL_UNIT_ = 'Months') AND (MACOMP.REP_CAL_VALUE_ >= MACOMP.TSI_VALUE_) THEN MACOMP.REP_CAL_VALUE_ * 12
                   ELSE (MACOMP.TSI_VALUE_ * 12) END)              AS RepLifeMonths
              , (SELECT ISNULL(SUM(STOCK1.QTY_), 0) AS Qty
                 FROM LOG_TRN_STOCK AS STOCK1
                        INNER JOIN
                      ADM_MST_UNIT_LOCATION ON STOCK1.LOC_ID = ADM_MST_UNIT_LOCATION.ID_
                        LEFT OUTER JOIN
                      ADM_MST_UNITS AS UNIT1 ON UNIT1.ID_ = STOCK1.UNIT_ID
                        LEFT OUTER JOIN
                      ADM_MST_ITEMS AS ITEM1 ON ITEM1.ID_ = UNIT1.ITEM_ID
                        LEFT OUTER JOIN
                      ADM_MST_MANUFACTURES AS MAN1
                      ON MAN1.ID_ = ITEM1.MNF_ID AND MAN1.CAGE_CODE_ = COMPSMFR.CAGE_CODE_
                        JOIN
                      ADM_MST_PLATFORM_L2 pl2 ON pl2.CMD_ID_ = MACOMP.CMD_ID_ AND pl2.PLTF_ID_ = MACOMP.PLTF_ID
                 WHERE (ITEM1.ID_ = COMPITEM.ID_)
                   AND (ADM_MST_UNIT_LOCATION.LOC_TYPE_ = 'REGULAR')
				   AND TAG_COLOR_COND_ID_<>16
                   AND (STOCK1.OWNED_BY_L2_ID_ = pl2.L2_ID_))          AS OnHandQty
              , 1                                                      AS Quantity
              , IIF(nha.ID_ IS NOT NULL, nha_due._date, c_due._date)   AS c_r_due_date
              , COMPITEM.NSN_										   AS Nsn
FROM MNT_TRN_D16_ASSIGNED_COMPONENT AS ASSCOMP
       INNER JOIN MNT_MST_D16_MASTER_COMPONENT AS MACOMP ON MACOMP.ID_ = ASSCOMP.MASTER_COMP_ID_
       INNER JOIN MNT_MST_D16_COMPONENT AS COMP ON COMP.ID_ = ASSCOMP.COMP_ID_
       INNER JOIN ADM_MST_UNITS AS COMPUNIT ON COMPUNIT.ID_ = COMP.UNIT_ID_
       INNER JOIN ADM_MST_ITEMS AS COMPITEM ON COMPITEM.ID_ = COMPUNIT.ITEM_ID
       INNER JOIN ADM_MST_MANUFACTURES AS COMPSMFR ON COMPSMFR.ID_ = COMPITEM.MNF_ID
       INNER JOIN ADM_MST_TAILS AS COMPTAIL ON COMPTAIL.UNIT_ID = ASSCOMP.ACFT_UNIT_ID_
       INNER JOIN ADM_MST_RESTRICTIONS AS CMD ON CMD.ID_ = MACOMP.CMD_ID_
       INNER JOIN ADM_MST_UNITS AS PUNITS ON PUNITS.ID_ = ASSCOMP.ACFT_UNIT_ID_
       INNER JOIN ADM_MST_ITEMS AS PITEMS ON PITEMS.ID_ = PUNITS.ITEM_ID
       INNER JOIN ADM_MST_PLATFORMS AS PLATFORMS ON PLATFORMS.ID_ = PITEMS.ID_
       INNER JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION AS ULOCATION ON ULOCATION.UNIT_ID_ = COMP.UNIT_ID_
       LEFT JOIN MNT_TRN_D16_ASSIGNED_COMPONENT nha ON nha.ID_ = ASSCOMP.REPLACE_NHA_ID
       LEFT JOIN MNT_MST_D16_COMPONENT nha_comp ON nha_comp.ID_ = nha.COMP_ID_
       LEFT JOIN ADM_MST_UNITS nha_unit ON nha_unit.ID_ = nha_comp.UNIT_ID_
       LEFT JOIN ADM_MST_ITEMS nha_item ON nha_item.ID_ = nha_unit.ITEM_ID
       CROSS APPLY dbo.D16GetComponentDue(nha_comp.ID_) nha_due
       CROSS APPLY dbo.D16GetComponentDue(COMP.ID_) c_due
WHERE (ASSCOMP.IS_ACTIVE_ = 1)
  AND (MACOMP.REP_CAL_VALUE_ > 0 OR MACOMP.TSI_VALUE_ > 0)
go

