CREATE PROCEDURE [dbo].[GetPlatform1352_1_Report] 
	@CommandId BIGINT,
	@PlatformId BIGINT,
	@PlatformCode varchar(200),
	@Month BIGINT,
	@Year BIGINT

AS
BEGIN	
	SET NOCOUNT ON;
	DECLARE @TailUnitId INT;
	DECLARE @TailNumber NVARCHAR(MAX);
	DECLARE @TRANSACTION_TABLES TABLE (TailUnitId INT, TailNumber NVARCHAR(MAX));

	INSERT INTO @TRANSACTION_TABLES
	SELECT T.UNIT_ID AS TailUnitId, T.T_NUM_ AS TailNumber
	FROM ADM_MST_TAILS AS T
	INNER JOIN ADM_MST_RESTRICTIONS AS BTN ON BTN.ID_ = T.BATLN_ID
	INNER JOIN ADM_MST_UNITS AS U ON U.ID_ = T.UNIT_ID
	INNER JOIN ADM_MST_ITEMS AS I ON I.ID_ = U.ITEM_ID
	INNER JOIN ADM_MST_PLATFORMS AS P ON P.ID_ = I.ID_
	LEFT JOIN ADM_MST_TAIL_VARIANT Tvariant on Tvariant.ID_ = T.UNIT_ID
	LEFT JOIN ADM_MST_PLATFORM_VARIANT PVariant on PVariant.ID_ = Tvariant.PLTF_VARIANT_ID 
	WHERE BTN.PRNT_ID = @CommandId --AND (case when PVariant.ID_ is null then P.CODE_ else PVariant.PLTF_ALIAS_CODE_ end) = @PlatformCode
	AND ( (PVariant.ID_ is null and  P.CODE_=@PlatformCode) or ( PVariant.ID_ is not null and PVariant.ID_=(select DAP.id_ from ADM_MST_PLATFORM_VARIANT DAP join
	ADM_MST_PLATFORMS  Platforms on Platforms.ID_=DAP.PLTF_ID
	where iif(Dap.PLTF_ALIAS_CODE_=Platforms.CODE_+' '+Dap.VARIANT_, Dap.PLTF_ALIAS_CODE_,Platforms.CODE_+' '+Dap.VARIANT_)=@PlatformCode )) )

	DECLARE CUR CURSOR FOR SELECT TailUnitId, TailNumber FROM @TRANSACTION_TABLES

	OPEN CUR;
	FETCH NEXT FROM CUR INTO @TailUnitId, @TailNumber
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		EXEC GetPlatform1352_1_By_TailId @Month, @Year, @TailUnitId, @TailNumber								
		FETCH NEXT FROM CUR INTO @TailUnitId, @TailNumber
	END
	CLOSE CUR
	DEALLOCATE CUR
END
go

