CREATE VIEW [dbo].[VW_PMO_PROJECT_LIST] AS (SELECT P.ID_ AS Id, P.NAME_ AS Name, P.DESC_ [Description], P.CUR_STATE_ AS ProjectStatus, SR1.DESC_ AS ProjectCategory, SR2.DESC_ AS ProjectDomain, PG.NAME_ AS Program, COUNT(C.ID_) AS NoContracts,  
                                                    UP1.PID_ as CreatedByPid,  (UP1.F_NAME_ + ' ' + UP1.L_NAME_) AS CreatedByName , P.CREATED_ON_ AS CreatedOn,  
                                                    UP2.PID_ as ModifiedByPid,  (UP2.F_NAME_ + ' ' + UP2.L_NAME_) AS ModifiedByName, P.MOD_ON_ as ModifiedOn 
                                                    , P.IS_ACTIVE_ AS IsActive, P.DEACTIVATED_DATE_ AS DeactivatedDate
                                                    FROM PMO_TRN_PROJECT P   
                                                    LEFT OUTER JOIN PMO_TRN_CONTRACT C ON C.PROJ_ID = P.ID_  
                                                    LEFT OUTER JOIN PMO_TRN_PROGRAM PG on P.PROG_ID = PG.ID_  
                                                    LEFT OUTER JOIN ADM_MST_SIMPLE_REF SR1 on P.PRJ_CAT_ID = SR1.ID_  
                                                    LEFT OUTER JOIN ADM_MST_SIMPLE_REF SR2 on P.PRJ_DOMAIN_ID = SR2.ID_  
                                                    LEFT OUTER JOIN ADM_TRN_USER_PROFILES UP1 ON P.CREATED_BY_ = UP1.USER_ID_   
                                                    LEFT OUTER JOIN ADM_TRN_USER_PROFILES UP2 ON P.MOD_BY_ = UP2.USER_ID_  
                                                    GROUP BY P.ID_, P.NAME_, P.DESC_ , P.CUR_STATE_, SR1.DESC_, SR2.DESC_, PG.NAME_, UP1.PID_, 
															 P.CREATED_ON_, UP2.PID_, P.MOD_ON_, UP1.F_NAME_, UP1.L_NAME_, UP2.F_NAME_, UP2.L_NAME_
															 ,P.IS_ACTIVE_, P.DEACTIVATED_DATE_)
go

