CREATE VIEW [dbo].[VW_MNT_FLEET_STATUS_FLIGHT] AS
SELECT
     Unit
    ,SYS.code_ AS SYSCode
    ,status.ID_ as StatusId
    ,status.code_ AS StatusCode
	,status.ORDER_ AS StatusOrder
    ,count(1) AS FCount 
FROM (
    select unit_id AS Unit, fault_info_sys_id AS FaultSys, max(adm_mst_simple_ref.order_) AS AccStatOrder,count(*) AS total 
    FROM mnt_trn_fault_units funit 
    JOIN adm_mst_simple_ref on funit.acc_sts_id = adm_mst_simple_ref.ID_ 
    WHERE fault_sts_ = 'Open' 
    GROUP BY unit_id, fault_info_sys_id 
) T 
JOIN adm_mst_simple_ref status on T.AccStatOrder = status.order_ and grp_ = 'MNT.STS' 
JOIN adm_mst_simple_ref SYS on T.FaultSys = SYS.ID_ 
JOIN (
    select unit_id, fault_info_sys_id, order_ 
    FROM mnt_trn_fault_units 
    JOIN adm_mst_simple_ref on mnt_trn_fault_units.acc_sts_id = adm_mst_simple_ref.ID_ 
    WHERE fault_sts_ = 'Open' 
) T1 on T1.unit_id = T.Unit and T1.fault_info_sys_id = T.FaultSys and T.AccStatOrder = T1.order_ 
group by Unit, SYS.code_, status.id_, status.code_, status.ORDER_
go

