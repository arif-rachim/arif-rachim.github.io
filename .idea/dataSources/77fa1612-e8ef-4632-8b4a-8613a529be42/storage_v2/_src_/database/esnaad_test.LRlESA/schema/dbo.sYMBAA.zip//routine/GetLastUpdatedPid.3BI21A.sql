CREATE FUNCTION [dbo].[GetLastUpdatedPid]
(
	-- Add the parameters for the function here
	@ModifiedUserId		nvarchar(255),
	@CreatedUserId		nvarchar(255)
)
RETURNS nvarchar(255)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @result nvarchar(255)
   
    -- Add the T-SQL statements to compute the return value here
	IF @ModifiedUserId IS NOT NULL AND @ModifiedUserId <> ''
	BEGIN
		SELECT @result = PID_ FROM ADM_TRN_USER_PROFILES WHERE USER_ID_ = @ModifiedUserId
	END
	ELSE
	BEGIN
		SELECT @result = PID_ FROM ADM_TRN_USER_PROFILES WHERE USER_ID_ = @CreatedUserId
	END
	
	-- Return the result of the function
	RETURN @result
END
go

