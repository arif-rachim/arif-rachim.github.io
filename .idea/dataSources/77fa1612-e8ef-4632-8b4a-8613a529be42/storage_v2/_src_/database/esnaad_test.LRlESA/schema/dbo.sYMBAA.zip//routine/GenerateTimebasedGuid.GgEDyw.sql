CREATE FUNCTION [dbo].[GenerateTimebasedGuid]()
RETURNS UNIQUEIDENTIFIER
AS
BEGIN
	RETURN dbo.GenerateTimeBasedGuid2(getdate())
END
go

