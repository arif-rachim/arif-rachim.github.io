CREATE FUNCTION [dbo].[D16_IsAssignmentRestrictionMarkAsValid]
(
    @unitId bigint
)
    RETURNS bit
AS
BEGIN
    DECLARE @result bit = 0;

    SELECT @result = CASE WHEN count(Id) = 0 THEN cast(1 AS bit) ELSE cast(0 AS bit) END from (
  select ac.ID_ as Id, dbo.D16_IsAssignmentRestrictionValid(ac.ID_) as isValid
    FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
             JOIN (SELECT PATH_
                   FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
                            JOIN MNT_MST_D16_COMPONENT p_c ON p_c.ID_ = ac.PARENT_COMP_ID_
                            JOIN MNT_MST_D16_COMPONENT c_c ON c_c.ID_ = ac.COMP_ID_
                   WHERE ac.IS_ACTIVE_ = 1
                     AND ac.REM_DATE_ IS NULL
                     AND (p_c.UNIT_ID_ = @unitId OR c_c.UNIT_ID_ = @unitId)) rootPath
           on ac.PATH_ = left(rootPath.PATH_, LEN(ac.PATH_))
) as levelOne
where isValid = 0
    RETURN @result
END
go

