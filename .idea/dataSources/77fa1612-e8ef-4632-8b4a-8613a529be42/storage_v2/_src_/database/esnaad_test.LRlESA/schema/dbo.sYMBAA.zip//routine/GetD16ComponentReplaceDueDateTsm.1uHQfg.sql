CREATE FUNCTION [dbo].[GetD16ComponentReplaceDueDateTsm] (@TsmValue int, @TsmUnit nvarchar(10), @ManufactureDate datetime)
RETURNS DATETIME
AS
BEGIN
    select @TsmValue = coalesce(@TsmValue, 0);

	IF (@TsmValue <= 0 OR @ManufactureDate IS NULL) 
		RETURN NULL;

	IF (@TsmUnit = 'Months')
		RETURN dateadd(month, @TsmValue, @ManufactureDate);
	ELSE
		RETURN dateadd(year, @TsmValue, @ManufactureDate);

RETURN NULL;
END
go

