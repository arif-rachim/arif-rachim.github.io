CREATE FUNCTION dbo.[SL_GetStockInfoMain](

 @givenDate datetime,
 @itemId bigint,
 @isIncludeInLieu bit, 
 @isIncludeFromSubStore bit,
 @storeId int,
 @agl2Id int
 )

RETURNS TABLE AS 
RETURN (

select  sum(imv.QTY_) as Qty from ADM_TRN_IMV_ITEMS_IN_LOCATION  FOR SYSTEM_TIME  as of @givenDate imv
 JOIN ADM_MST_UNITS FOR SYSTEM_TIME  as of @givenDate unit on imv.UNIT_ID_=unit.ID_
 JOIN ADM_MST_UNIT_LOCATION L ON L.ID_ = IMV.LOC_ID_
 JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = IMV.BU_ID_
 JOIN ADM_TRN_ASSOC_GROUPS L2 ON L2.ID_ = IMV.OWNED_L2_ID_
			JOIN (
			SELECT DISTINCT ITEM_ID, IN_LIEU_CODE_ FROM (
				SELECT IA.ITEM_ID, IA.IN_LIEU_CODE_  FROM ADM_TRN_ITEM_ASSOCS IA
				WHERE (IA.ITEM_ID = @itemId AND IA.L2_ID = @agl2Id)
				UNION ALL
				SELECT IA2.ITEM_ID, IA.IN_LIEU_CODE_  FROM ADM_TRN_ITEM_ASSOCS IA
				JOIN ADM_TRN_ITEM_ASSOCS IA2 ON IA.IN_LIEU_CODE_ = IA2.IN_LIEU_CODE_
				WHERE (@isIncludeInLieu = 1 AND IA.ITEM_ID = @itemId AND IA.L2_ID = @agl2Id AND IA.IN_LIEU_CODE_ IS NOT NULL)) ALL_ITEMS
			) IA ON IA.ITEM_ID = unit.ITEM_ID 
 WHERE BU.BU_TYPE_ = 'Store'
       AND BU.ID_ in (
	                  SELECT DISTINCT ID_ FROM ADM_MST_BUSINESS_UNITS WHERE (ID_ = @storeId)
					  UNION ALL  
					   SELECT DISTINCT ID_ FROM ADM_MST_BUSINESS_UNITS WHERE @isIncludeFromSubStore = 1 and (PARENT_STORE_ID_ in (SELECT ID_ FROM ADM_MST_BUSINESS_UNITS where  BU_TYPE_ = 'Store'
					   and PARENT_STORE_ID_ is null and CMD_ID_ = (SELECT DISTINCT CMD_ID_ FROM ADM_MST_BUSINESS_UNITS WHERE (ID_ = @storeId))))
                      )
			AND (L.LOC_TYPE_='Regular' OR L.LOC_TYPE_='Receiving') AND IMV.TC_ID_ = 1 
 AND (unit.EXP_DATE_ is null or unit.EXP_DATE_>=@givenDate)
 
 )
go

