
CREATE PROCEDURE DM_003_PUTIL_001_StartLog
	 @scriptName VARCHAR(MAX)
	,@logRecordID_OUT BIGINT OUTPUT
	,@InputCommand VARCHAR(10) = NULL
AS
BEGIN
	SET NOCOUNT ON;

	PRINT ''
	PRINT '======================================================================================================================='
	PRINT @scriptName + ' [Host: ' + HOST_NAME() + '] [DB server: ' + CAST(SERVERPROPERTY ('ServerName') AS VARCHAR(MAX)) + '] [Database: ' + DB_NAME() +'] : Started >>>>'
	PRINT ''
	IF @InputCommand IS NOT NULL
	BEGIN
		PRINT '[Command: ' + @InputCommand + ']'
	END

	DECLARE @today date = getdate();	
	PRINT '[Date: ' + CAST(YEAR(@today) AS VARCHAR) + '-' + DATENAME (MONTH, (@today)) + '-' + CAST(DAY(@today) AS VARCHAR) + ']'
	PRINT ''

	-- ######################################## DB_SERVER #######################################
	IF NOT EXISTS
	(
		SELECT *
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_NAME = N'DM_ESNAAD_ExecutionTimeLog'
		AND COLUMN_NAME = N'DB_SERVER'
	)
	BEGIN
		ALTER TABLE DM_ESNAAD_ExecutionTimeLog
		ADD DB_SERVER VARCHAR(MAX)
	END
	-- ##########################################################################################
	
	INSERT INTO DM_ESNAAD_ExecutionTimeLog
	(
		 HOST
		,DB_SERVER
		,DB
		,CMD
		,SCRIPT
		,EXECUTION_DATE
		,START_TIME
	)
	VALUES
	(
		 HOST_NAME()
		,CAST(SERVERPROPERTY ('ServerName') AS VARCHAR(MAX))
		,DB_NAME()
		,@InputCommand
		,@scriptName
		,GETDATE()
		,GETDATE()
	)
	
	SET @logRecordID_OUT = SCOPE_IDENTITY();
	
END
go

