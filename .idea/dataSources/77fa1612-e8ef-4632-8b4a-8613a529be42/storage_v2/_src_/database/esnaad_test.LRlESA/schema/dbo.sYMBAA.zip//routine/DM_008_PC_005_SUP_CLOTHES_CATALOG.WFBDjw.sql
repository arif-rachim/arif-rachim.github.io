
CREATE PROCEDURE DM_008_PC_005_SUP_CLOTHES_CATALOG
	@InputCommand VARCHAR(10)
AS
BEGIN
	-- ######################################## Time logging : start block #############################################################
	DECLARE @scriptName VARCHAR(MAX) = OBJECT_NAME(@@PROCID);
	DECLARE @startTime DATETIME = GETDATE();
	DECLARE @logRecordID BIGINT;
	EXEC DM_003_PUTIL_001_StartLog  @scriptName = @scriptName, @logRecordID_OUT = @logRecordID OUTPUT, @InputCommand = @InputCommand
	-- #################################################################################################################################

	SET NOCOUNT ON;
	SET DATEFORMAT DMY;
	
	-- ####################################### Get Data migration user info #######################################
	DECLARE	@DM_USR_FULLNAME varchar(100), @DM_USR_PID varchar(100), @DM_USR_USER_ID varchar(100);
	DECLARE @hostName VARCHAR(MAX) = HOST_NAME();
	EXEC DM_003_PUTIL_004_GetDataMigrationUserRec @DM_USR_FULLNAME OUTPUT, @DM_USR_PID OUTPUT, @DM_USR_USER_ID OUTPUT
	-- ############################################################################################################

	DECLARE @successRecCount  BIGINT = 0; 
	DECLARE @detailSRecCount  BIGINT = 0; 
	DECLARE @skippedRecCount  BIGINT = 0; 
	DECLARE @errorCount       INT = 0;
	DECLARE @duplicateError   VARCHAR(MAX) = 'Duplicate record (Hint: "Color" and "Size" are not taken)';  --Error messages are used elsewhere in the code. hence declaring as variable
	DECLARE @lineError        VARCHAR(MAX) = 'One or more lines have validation errors';
	DECLARE @ErrorMessage     VARCHAR(MAX);
	DECLARE @esnaadStatus     NVARCHAR(1);

	DECLARE @part_no_			NVARCHAR(255);
	DECLARE @description		NVARCHAR(255);
	DECLARE @mnf_id				BIGINT;
	DECLARE @esnaad_uom_id_		UNIQUEIDENTIFIER;
	DECLARE @esnaad_cls_id		BIGINT;
	DECLARE @esnaad_clo_type_id_	BIGINT;
	
	DECLARE @commandId    BIGINT = (SELECT COMMAND.ID_ FROM ADM_MST_RESTRICTIONS COMMAND WHERE COMMAND.CODE_ = @InputCommand);
	DECLARE @nextSequence VARCHAR(MAX);
	DECLARE @esnaadKey             BIGINT;
	
	DECLARE copierCursor CURSOR FOR
	SELECT
		LTRIM(RTRIM(UPPER(AADMIS.[Model Number]))) AS PartNo
		,LTRIM(RTRIM(AADMIS.Description))	      
		,AADMIS.ESNAAD_MNF_ID
		,AADMIS.ESNAAD_UOM_ID_
		,AADMIS.ESNAAD_CLO_TYPE_ID_
		,ESNAAD_CLS_ID
	  FROM AADMIS_TBL__Clothes_Catalog AADMIS
	 WHERE ESNAAD_FORCE = @InputCommand
	   AND ESNAAD_STATUS IS NULL
	   FOR UPDATE OF ESNAAD_KEY, ESNAAD_STATUS, ESNAAD_ERROR

	DECLARE errorReportingCursorForHeader CURSOR FOR
	SELECT ESNAAD_STATUS AS esnaadStatus,
	       ESNAAD_ERROR AS errorMessage,
	       COUNT(1) AS errorCount
	  FROM AADMIS_TBL__Clothes_Catalog
	 WHERE ESNAAD_FORCE = @InputCommand
	 GROUP BY ESNAAD_STATUS, ESNAAD_ERROR
	 
	 
	IF @InputCommand = 'NAG'
	BEGIN
		UPDATE AADMIS_TBL__Clothes_Catalog SET ESNAAD_FORCE = 'NAG' WHERE [Force] = 'NAVY' AND ISNULL(ESNAAD_FORCE, 'NAVY') <> 'NAG'
	END
	ELSE IF @InputCommand = 'G18'
	BEGIN
		UPDATE AADMIS_TBL__Clothes_Catalog SET ESNAAD_FORCE = 'G18' WHERE [Force] = 'SOC' AND ISNULL(ESNAAD_FORCE, 'SOC') <> 'G18'
	END
	
	ELSE IF @InputCommand = 'SARSQ'
	BEGIN
		UPDATE AADMIS_TBL__Clothes_Catalog SET ESNAAD_FORCE = 'SARSQ' WHERE [Force] = 'JSR' AND ISNULL(ESNAAD_FORCE, 'JSR') <> 'SARSQ'
	END
	
	PRINT 'Updated Force for '+ CAST(@@ROWCOUNT AS VARCHAR)+' records'
	

	UPDATE AADMIS_TBL__Clothes_Catalog 
	   SET ESNAAD_STATUS = NULL
	      ,ESNAAD_ERROR  = NULL 
	 WHERE ESNAAD_STATUS = 'E'
	   AND ESNAAD_FORCE = @InputCommand
	PRINT 'Cleared errors in AADMIS_TBL__Clothes_Catalog for '+ CAST(@@ROWCOUNT AS VARCHAR)+' records';

	-- Flag duplicate records
	WITH CTE AS (
	SELECT AADMIS.[Model Number] AS PART_NUMBER
		  ,ESNAAD_STATUS
		  ,ESNAAD_ERROR
		  ,RN = ROW_NUMBER()OVER(PARTITION BY AADMIS.[Model Number]
							         ORDER BY AADMIS.[Model Number])
	  FROM AADMIS_TBL__Clothes_Catalog AADMIS
	 WHERE ESNAAD_FORCE = @InputCommand
	 )
	UPDATE CTE SET ESNAAD_STATUS = 'E', ESNAAD_ERROR = @duplicateError
	 WHERE RN > 1;
	 
	--Derive Esnaad IDs
	UPDATE AADMIS_TBL__Clothes_Catalog
	   SET 
	       ESNAAD_MNF_ID       = (SELECT MNF.ID_ FROM ADM_MST_MANUFACTURES MNF WHERE MNF.CAGE_CODE_ = 'NOMFR')	                              
	      ,ESNAAD_UOM_ID_      = (SELECT ID_ FROM LOG_MST_UNIT_OF_MEASURE WHERE CODE_ = 'EA') --> each)
	  FROM AADMIS_TBL__Clothes_Catalog AADMIS
	 WHERE AADMIS.ESNAAD_FORCE = @InputCommand
	   AND AADMIS.ESNAAD_STATUS IS NULL
	
	UPDATE AADMIS_TBL__Clothes_Catalog
	   SET ESNAAD_STATUS = 'E'
	      ,ESNAAD_ERROR = CASE WHEN AADMIS.ESNAAD_MNF_ID IS NULL THEN 'Could not identify manufacturer'
	                           WHEN AADMIS.ESNAAD_UOM_ID_ IS NULL THEN 'Could not identify UOM'
	                      END
	  FROM AADMIS_TBL__Clothes_Catalog AADMIS
	 WHERE AADMIS.ESNAAD_FORCE = @InputCommand
	   AND AADMIS.ESNAAD_STATUS IS NULL
	   AND (AADMIS.ESNAAD_MNF_ID IS NULL OR AADMIS.ESNAAD_UOM_ID_ IS NULL)
  
	--Flag already existing records in Esnaad
	UPDATE AADMIS_TBL__Clothes_Catalog
	   SET ESNAAD_STATUS = 'E'
	      ,ESNAAD_ERROR  = 'Part already exists in Esnaad'
	  FROM AADMIS_TBL__Clothes_Catalog AADMIS
	 WHERE AADMIS.ESNAAD_FORCE = @InputCommand
	   AND AADMIS.ESNAAD_STATUS IS NULL
	   AND EXISTS (
	       SELECT 1
	         FROM ADM_MST_ITEMS ITEMS
	              JOIN ADM_MST_MANUFACTURES MNF ON ITEMS.MNF_ID = MNF.ID_
	        WHERE ITEMS.PART_NO_ = LTRIM(RTRIM(UPPER(AADMIS.[Model Number])))
	          AND MNF.CAGE_CODE_ = 'NOMFR'
	       )

	-- ################################# Insert all Cloth types to SIMPLE_REF ################################# _START
	INSERT INTO ADM_MST_SIMPLE_REF 
	(VERSION_,	CODE_,				DESC_,				GRP_,		S_DESC_,	ORDER_,	CREATED_BY_,	CREATED_ON_,	MOD_BY_,	MOD_ON_,	TERM_)
	 SELECT 1,	DATASOURCE.CODE_,	DATASOURCE.CODE_,	'CLO.TYP',	NULL,		0,      @DM_USR_USER_ID, GETDATE(),   NULL,    NULL,    HOST_NAME()
	FROM
	(
		SELECT DISTINCT UPPER(LTRIM(RTRIM([Type]))) AS CODE_ FROM AADMIS_TBL__Clothes_Catalog 
	) AS DATASOURCE
	WHERE NOT EXISTS
	(
		SELECT 1
		FROM ADM_MST_SIMPLE_REF
		WHERE GRP_ = 'CLO.TYP' AND DATASOURCE.CODE_ = ADM_MST_SIMPLE_REF.CODE_
	)
	-- ################################# Insert all Cloth types to SIMPLE_REF ################################# _END

	UPDATE AADMIS_TBL__Clothes_Catalog
	SET ESNAAD_CLO_TYPE_ID_ = REF.ID_
	FROM AADMIS_TBL__Clothes_Catalog AADMIS
	JOIN ADM_MST_SIMPLE_REF REF ON REF.CODE_ = UPPER(LTRIM(RTRIM(AADMIS.[Type]))) AND REF.GRP_ = 'CLO.TYP'	
	WHERE AADMIS.ESNAAD_STATUS IS NULL
	AND AADMIS.ESNAAD_FORCE = @InputCommand
  
  
	UPDATE AADMIS_TBL__Clothes_Catalog
	   SET ESNAAD_CLS_ID = REF.ID_ 
	  FROM AADMIS_TBL__Clothes_Catalog AADMIS
	       JOIN ADM_MST_SIMPLE_REF REF ON REF.CODE_ = 'C' AND REF.GRP_ = 'LOG.ICL'
  	 WHERE AADMIS.ESNAAD_STATUS = 'S'
  	   AND AADMIS.ESNAAD_FORCE = @InputCommand
  	   AND ISNULL(AADMIS.ESNAAD_CLS_ID, 0000000) <> REF.ID_ 
	PRINT 'Updated class id in AADMIS_TBL__Clothes_Catalog for '+ CAST(@@ROWCOUNT AS VARCHAR)+' records'
  	
  	UPDATE ADM_MST_ITEMS
  	   SET CLS_ID_ = AADMIS.ESNAAD_CLS_ID
  	  FROM ADM_MST_ITEMS ITEMS
  	       JOIN AADMIS_TBL__Clothes_Catalog AADMIS ON ITEMS.ID_ = AADMIS.ESNAAD_KEY
  	 WHERE AADMIS.ESNAAD_CLS_ID IS NOT NULL
  	   AND AADMIS.ESNAAD_FORCE = @InputCommand
  	   AND AADMIS.ESNAAD_STATUS = 'S'
  	   AND AADMIS.ESNAAD_CLS_ID <> ISNULL(ITEMS.CLS_ID_, 0000000)
	PRINT 'Updated cls id in ADM_MST_ITEMS for '+ CAST(@@ROWCOUNT AS VARCHAR)+' records'

/*
	-- ################################# Insert all Cloth types to SIMPLE_REF ################################# _START
	INSERT INTO ADM_MST_SIMPLE_REF 
	(VERSION_,	CODE_,				DESC_,				GRP_,		S_DESC_,	ORDER_,	CREATED_BY_,	CREATED_ON_,	MOD_BY_,	MOD_ON_,	TERM_)
	 SELECT 1,	DATASOURCE.CODE_,	DATASOURCE.CODE_,	'CLO.TYP',	NULL,		0,      @DM_USR_USER_ID, GETDATE(),   NULL,    NULL,    HOST_NAME()
	FROM
	(
		SELECT DISTINCT [TYPE] AS CODE_ FROM AADMIS_TBL__Clothes_Catalog 
	) AS DATASOURCE
	WHERE NOT EXISTS
	(
		SELECT 1
		FROM ADM_MST_SIMPLE_REF
		WHERE GRP_ = 'CLO.TYP' AND DATASOURCE.CODE_ = ADM_MST_SIMPLE_REF.CODE_
	)
	-- ################################# Insert all Cloth types to SIMPLE_REF ################################# _END
*/	
 
	OPEN copierCursor;
	FETCH NEXT FROM copierCursor
	INTO	@part_no_
	       ,@description
	       ,@mnf_id
	       ,@esnaad_uom_id_
	       ,@esnaad_clo_type_id_
	       ,@esnaad_cls_id
	;

	WHILE @@FETCH_STATUS = 0
	BEGIN
		BEGIN TRY
			INSERT INTO ADM_MST_ITEMS (
			    VERSION_
			   ,PART_NO_
			   ,NSN_
			   ,NOMENCLATURE_
			   ,NAME_
			   ,SERIALIZED_
			   ,CONSUMABLE_
			   ,IN_BATCH_
			   ,TRACKING_
			   ,SENSITIVE_
			   ,ASSEMBLY_
			   ,INSTALLABLE_
			   ,ITEM_STATUS_
			   ,MNF_ID
			   ,FSC_ID
			   ,CREATED_BY_, CREATED_ON_, MOD_BY_, MOD_ON_, TERM_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, PID_MOD_BY_, FULL_NAME_MOD_BY_
			   
			   ,UOM_ID_
			   ,COS_ID
			   ,SCOS_ID
			   ,IN_LIEU_CODE_
			   
			   ,CLS_ID_
			   ,IPC_ID_
			   
			   ,ITEM_GROUP_
			   ,GRP_TYPE_
			   ,CLO_SEX_TYPE_
			   ,CLO_TYPE_ID_
			)
			VALUES (
			    1				--> VERSION_
			   ,@part_no_		--> PART_NO_
			   ,NULL			--> NSN_
			   ,@description	--> NOMENCLATURE_
			   ,@description	--> NAME_
			   ,0				--> SERIALIZED_
			   ,1				--> CONSUMABLE_
			   ,0				--> IN_BATCH_
			   ,0				--> TRACKING_
			   ,0				--> SENSITIVE_
			   ,0				--> ASSEMBLY_
			   ,0				--> INSTALLABLE_
			   ,'Active'		--> ITEM_STATUS_
			   ,@mnf_id			--> MNF_ID
			   ,null			--> FSC_ID
			   ,@DM_USR_USER_ID, GETDATE(), null, null, @hostName, @DM_USR_PID, @DM_USR_FULLNAME, null, null
			   
			   ,@esnaad_uom_id_	--> UOM_ID_
			   ,NULL			--> COS_ID
			   ,NULL			--> SCOS_ID
			   ,NULL			--> IN_LIEU_CODE_
			   
			   ,@esnaad_cls_id	--> CLS_ID_
			   ,NULL			--> IPC_ID_
			   
			   ,'Clothing'		--> ITEM_GROUP_
			   ,NULL			--> GRP_TYPE_
			   ,'Male'			--> CLO_SEX_TYPE_
			   ,@esnaad_clo_type_id_	--> CLO_TYPE_ID_
			)
			-- Ref: Anvar, Fredy
			
		END TRY
		BEGIN CATCH
		
			SET @ErrorMessage = ERROR_MESSAGE()
			UPDATE AADMIS_TBL__Clothes_Catalog 
			   SET ESNAAD_STATUS = 'E', ESNAAD_ERROR = @ErrorMessage
			 WHERE CURRENT OF copierCursor
			 
			FETCH NEXT FROM copierCursor
			INTO	@part_no_
				   ,@description
				   ,@mnf_id
				   ,@esnaad_uom_id_
				   ,@esnaad_clo_type_id_
				   ,@esnaad_cls_id
			;
			
 			CONTINUE
		END CATCH
	    
	    SET @esnaadKey = SCOPE_IDENTITY();
	    
		UPDATE AADMIS_TBL__Clothes_Catalog 
		   SET ESNAAD_KEY = @esnaadKey
		      ,ESNAAD_STATUS = 'S' 
		 WHERE CURRENT OF copierCursor
		
		FETCH NEXT FROM copierCursor
		INTO	@part_no_
			   ,@description
			   ,@mnf_id
			   ,@esnaad_uom_id_
			   ,@esnaad_clo_type_id_
			   ,@esnaad_cls_id
		;
		
	END
	
	CLOSE copierCursor;
	DEALLOCATE copierCursor;

    PRINT '------------------------------------'
    PRINT '           Error report '
    PRINT '------------------------------------'
    SET @skippedRecCount = 0;
	OPEN errorReportingCursorForHeader;
	FETCH NEXT FROM errorReportingCursorForHeader
	INTO   @esnaadStatus
	      ,@ErrorMessage
	      ,@errorCount
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    IF @esnaadStatus = 'S'
			SET @successRecCount = @errorCount;
		ELSE
			BEGIN
				PRINT @ErrorMessage + ' : ' + CAST(@errorCount AS VARCHAR)
				SET @skippedRecCount = @skippedRecCount + @errorCount
			END
		FETCH NEXT FROM errorReportingCursorForHeader
		INTO   @esnaadStatus
			  ,@ErrorMessage
			  ,@errorCount
	END
	CLOSE errorReportingCursorForHeader;
	DEALLOCATE errorReportingCursorForHeader;
	
	-- Show Record count
	EXEC DM_003_PUTIL_003_ShowRecCount  @insertedRecCount = @successRecCount, @skippedRecCount = @skippedRecCount	
	      
	-- ############################################### Time logging : stop block ###############################################	
	EXEC DM_003_PUTIL_002_StopLog  @logRecordID = @logRecordID, @scriptName = @scriptName, @startTime = @startTime, @isDisplayOn = 1;
	-- #########################################################################################################################
END
go

