CREATE FUNCTION [dbo].[GetAllFcifLinkedProfessionalQualifications]
(
	--parameters for the function	
	@fcifFileId uniqueidentifier
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- return variable
	DECLARE @linkedProQualifications NVARCHAR(MAX)
		
	SELECT @linkedProQualifications = 
	CASE
	WHEN (COUNT(AllProQualifications.QualificationCode) = SUM(CASE WHEN FPQ.FileProQualId IS NULL THEN 0 ELSE 1 END)) THEN '[ALL]'
	WHEN SUM(CASE WHEN FPQ.FileProQualId IS NULL THEN 0 ELSE 1 END) = 0 THEN '[ALL]'
	ELSE (SELECT STUFF((SELECT ', ' + PQ.CODE_ FROM OPS_TRN_FCIF_FILES AS FF
		INNER JOIN OPS_TRN_FCIF_PROF_QUALIFICATIONS AS FPQ ON FF.ID_ = FPQ.FCIF_FILE_ID_
		INNER JOIN ADM_MST_PROF_QUALIFICATIONS AS PQ ON PQ.ID_ = FPQ.PRO_QUALIFICATION_ID_
		WHERE FF.ID_ = @fcifFileId for xml path('')), 1, 1, ''))	END
	FROM
	(
	SELECT PQ.ID_ AS ProQualId, PQ.CODE_ AS QualificationCode
	FROM ADM_MST_PROF_QUALIFICATIONS AS PQ
	INNER JOIN ADM_MST_QUALFCN_CATS AS CAT ON PQ.CAT_ID = CAT.ID_
	) AS AllProQualifications
	LEFT JOIN (SELECT PQ.PRO_QUALIFICATION_ID_ AS ProQualId, FF.ID_ AS FileId, PQ.ID_ AS FileProQualId
	FROM OPS_TRN_FCIF_FILES AS FF
	INNER JOIN OPS_TRN_FCIF_PROF_QUALIFICATIONS AS PQ ON FF.ID_ = PQ.FCIF_FILE_ID_) AS FPQ ON AllProQualifications.ProQualId = FPQ.ProQualId
	AND FPQ.FileId = @fcifFileId
		
	-- Returns the result of the function	
	RETURN @linkedProQualifications

END
go

