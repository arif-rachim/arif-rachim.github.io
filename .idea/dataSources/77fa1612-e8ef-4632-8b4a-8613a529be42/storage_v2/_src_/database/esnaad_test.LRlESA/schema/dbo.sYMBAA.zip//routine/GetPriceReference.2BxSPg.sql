CREATE FUNCTION [dbo].[GetPriceReference](@itemId bigint,
                                          @l2Id bigint)
    RETURNS decimal(18, 2)
AS
BEGIN
    DECLARE @result decimal(18, 2);

    select
            @result =
            case
                when IS_FMS_ = 1 then coalesce(ItemCatalogUnitPrice, AveragePrice, LastNor, LastIor)
                else coalesce(AveragePrice, ItemCatalogUnitPrice, lastNor, LastIor) end
    from (
             select
                 il2.L2_ID
               , il2.IS_FMS_
                , cast(i.UNIT_PRICE_ * c.RATE_ as decimal(18,2))               as ItemCatalogUnitPrice
               , dbo.GetAveragePrice(i.ID_)  as AveragePrice
               , (select
                  top (1)
                  cast(POI.UNIT_PRICE_VAL_ * CUR.RATE_ as decimal(18, 2))
                  FROM LOG_TRN_PRC_PURCHASE_ORDER po
                           JOIN LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi ON poi.PO_ID = po.ID_
                           JOIN LOG_TRN_PRC_PROCUREMENT_ITEM pri ON poi.PROC_ITEM_ID = pri.ID_
                           JOIN ADM_MST_MONEY_CURRENCY cur ON cur.ID_ = poi.UNIT_PRICE_CUR_ID
                  WHERE PO.STATUS_ IN ('Validated', 'PartiallyDelivered', 'Closed')
                    and PO.PRIORITY_ in ('NOR')
                    and pri.ITEM_ID = i.ID_
                  order by po.PO_DATE_ desc) as LastNor
               , (select
                  top (1)
                  cast(POI.UNIT_PRICE_VAL_ * CUR.RATE_ as decimal(18, 2))
                  FROM LOG_TRN_PRC_PURCHASE_ORDER po
                           JOIN LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi ON poi.PO_ID = po.ID_
                           JOIN LOG_TRN_PRC_PROCUREMENT_ITEM pri ON poi.PROC_ITEM_ID = pri.ID_
                           JOIN ADM_MST_MONEY_CURRENCY cur ON cur.ID_ = poi.UNIT_PRICE_CUR_ID
                  WHERE PO.STATUS_ IN ('Validated', 'PartiallyDelivered', 'Closed')
                    and PO.PRIORITY_ in ('IOR')
                    and pri.ITEM_ID = i.ID_
                  order by po.PO_DATE_ desc) as LastIor
             from ADM_MST_ITEMS i
                 join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = i.ID_ and ia.L2_ID = @l2Id
                 left join LOG_TRN_ITEM_L2_ATTRIBUTES il2 on il2.ITEM_ID = i.ID_ and il2.L2_ID = @l2Id
                 left join ADM_MST_MONEY_CURRENCY c on c.ID_ = i.UNIT_PRICE_CUR_ID
             where i.ID_ = @itemId
         ) x


    RETURN @result
END
go

