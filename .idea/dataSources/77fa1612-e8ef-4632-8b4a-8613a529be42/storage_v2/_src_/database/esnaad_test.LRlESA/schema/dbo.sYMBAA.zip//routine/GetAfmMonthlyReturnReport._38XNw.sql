CREATE PROCEDURE [dbo].[GetAfmMonthlyReturnReport] 

	@month int = 0, 
	@year int = 0,
	@user_profile_id bigint = 0,
	@selected_tail_ids nvarchar(max) = ''
	
AS
BEGIN

	SET NOCOUNT ON;

	IF (@month = 0)
		SET @month = Month(getdate())
	IF (@year = 0)
		SET @year = Year(getdate())
		
	--
	DECLARE @RED_DIAGONAL int = 30;
	DECLARE @RED_X int = 31;
	DECLARE @RED_DASH int = 38;
	DECLARE @CIRCLED_RED_X int = 39;
	DECLARE @CIRCLED_RED_B int = 41;
	DECLARE @CIRCLED_RED_C int = 42;
	DECLARE @CIRCLED_RED_N int = 43;
	
	DECLARE @start_date		SMALLDATETIME
	SET @start_date = convert(smalldatetime,(SELECT dateadd(mm, (@year - 1900) * 12 + @month - 1 , 1 - 1)),100)
	
	DECLARE @end_date       SMALLDATETIME
    SET @end_date = DATEADD(DD, -1, DATEADD(M, 1, @start_date)) 
    IF @end_date > getdate()
		SET @end_date = getdate() -- cast(convert(varchar,DATEADD(DD,-1,getdate()),101) as smalldatetime)
		
	DECLARE @end_day       int
	SET @end_day = DATEPART(day, @end_date)
	
    
	SELECT     
		R.ARCFT_ID_																									AIRCRAFT_ID,	--TESTING 
		T.ID_																										TAIL_ID,		--TESTING 
		T.T_NUM_																									TAIL_NUMBER,	--TESTING 
		@start_date																									START_DATE_,	--TESTING 
		@end_date																									END_DATE_,		--TESTING 
		@end_day																									END_DAY,		--TESTING 
		P.CODE_																										SERIES,			--
		T.T_NUM_																									SERIAL_NUM,		--
		'AGA'																										ASSG_FUNC_CODE,  
		
		--sum(D.DUR_MINS_)																						TOTAL_AC_INV_HRS,
		--((case when @end_date > getdate() then (@end_day - 1) else @end_day end) * 24) 								HRS_ONHAND,
		--(select dbo.GetAfmMonthlyReturnReportHrsForAperiod(@start_date, @end_date, R.ARCFT_ID_, 0))					AC_TOTAL_HRS,
		--(select dbo.GetAfmMonthlyReturnReportHrsForAperiod(@start_date, @end_date, R.ARCFT_ID_, @RED_DIAGONAL))		RED_DIAGONAL_HRS,
		--(select dbo.GetAfmMonthlyReturnReportHrsForAperiod(@start_date, @end_date, R.ARCFT_ID_, @RED_DASH))			RED_DASH_HRS,
		--(select dbo.GetAfmMonthlyReturnReportHrsForAperiod(@start_date, @end_date, R.ARCFT_ID_, @CIRCLED_RED_X))		CIRCLED_RED_X_HRS,
		--(select dbo.GetAfmMonthlyReturnReportHrsForAperiod(@start_date, @end_date, R.ARCFT_ID_, @RED_X))				RED_X_HRS,
		--(select dbo.GetAfmMonthlyReturnReportHrsForAperiod(@start_date, @end_date, R.ARCFT_ID_, @CIRCLED_RED_N))		CIRCLED_RED_N_HRS,
		--(select dbo.GetAfmMonthlyReturnReportHrsForAperiod(@start_date, @end_date, R.ARCFT_ID_, @CIRCLED_RED_B))		CIRCLED_RED_B_HRS,
		--(select dbo.GetAfmMonthlyReturnReportHrsForAperiod(@start_date, @end_date, R.ARCFT_ID_, @CIRCLED_RED_C))		CIRCLED_RED_C_HRS,

		0		TOTAL_AC_INV_HRS,
		0 		HRS_ONHAND,
		0		AC_TOTAL_HRS,
		0		RED_DIAGONAL_HRS,
		0		RED_DASH_HRS,
		0		CIRCLED_RED_X_HRS,
		0		RED_X_HRS,
		0		CIRCLED_RED_N_HRS,
		0		CIRCLED_RED_B_HRS,
		0		CIRCLED_RED_C_HRS,


		(select dbo.GetAircraftFlyHrsForAPeriodFromUnitUsageDetails(@start_date, @end_date, T.ID_))					HRS_FLAWN,
		(select dbo.GetAircraftLandingsForAPeriodFromUnitUsageDetails(@start_date, @end_date, T.ID_))				NUM_LANDINGS,
		0																											AUTO_ROATIONS
	FROM         
                 dbo.ADM_MST_PLATFORMS P INNER JOIN dbo.ADM_MST_ITEMS I  ON P.ID_ = I.ID_ 
									INNER JOIN dbo.ADM_MST_UNITS U ON U.ITEM_ID = i.ID_	
									INNER JOIN dbo.ADM_MST_TAILS T ON T.UNIT_ID = U.ID_	
									LEFT JOIN  dbo.MNT_TRN_MFM_AFM_MONTHLY_RECORD R ON R.ARCFT_ID_ = U.ID_
									LEFT JOIN  dbo.MNT_TRN_MFM_AFM_MONTHLY_RECORD_DETAIL D ON D.AFM_MONTHLY_ID = R.ID_
	WHERE
		T.ID_ IN  (SELECT * FROM dbo.[CSVToTable](@selected_tail_ids))
	GROUP BY 
		R.ARCFT_ID_   ,
		P.CODE_	 ,
		T.ID_ ,
		T.T_NUM_
		                  
		
END
go

