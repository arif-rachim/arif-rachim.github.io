CREATE FUNCTION [dbo].[GetD16ReplaceDueConsiderNha] (@AssignedComponentId uniqueidentifier)
  RETURNS @replaceDue TABLE
  (
    _hours    REAL,
    _landings INT,
    _cycles   INT,
    _date     DATETIME
  )
AS
BEGIN

	declare @nhaChildID uniqueidentifier;
	declare @nhaCompId uniqueidentifier;
	declare @compId uniqueidentifier;

	select @nhaChildID=ID_ from dbo.GetD16FirstNhaChild(@AssignedComponentId);

	if (@nhaChildID is not null)
		BEGIN
			select @nhaCompId = COMP_ID_ from MNT_TRN_D16_ASSIGNED_COMPONENT where ID_ = @nhaChildID

			INSERT @replaceDue
			  SELECT * from dbo.D16_GetReplaceDue(@nhaCompId)
			RETURN;
		END;

	select @compId = COMP_ID_ from MNT_TRN_D16_ASSIGNED_COMPONENT where ID_ = @AssignedComponentId

	INSERT @replaceDue
		SELECT * from dbo.D16_GetReplaceDue(@compId)
	RETURN;
END
go

