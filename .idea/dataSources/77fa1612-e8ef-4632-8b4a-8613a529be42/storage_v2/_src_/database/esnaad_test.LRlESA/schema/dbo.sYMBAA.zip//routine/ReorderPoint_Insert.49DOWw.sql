CREATE PROCEDURE [ReorderPoint_Insert]
	@pExecutionDate datetime
AS
BEGIN TRY
    BEGIN TRAN

	SET NOCOUNT ON;

	-- ######################################## Time logging : start block #############################################################
	DECLARE @scriptName VARCHAR(MAX) = OBJECT_NAME(@@PROCID);
	DECLARE @startTime DATETIME = GETDATE();
	-- #################################################################################################################################

	DECLARE @affectedRows BIGINT = @@ROWCOUNT;
	DECLARE @PRINT_MESSAGES BIT = 0;

	IF @PRINT_MESSAGES = 1
	BEGIN
		PRINT ''
		PRINT '======================================================================================================================='
		PRINT @scriptName + ' [Host: ' + HOST_NAME() + '] [DB server: ' + CAST(SERVERPROPERTY ('ServerName') AS VARCHAR(MAX)) + '] [Database: ' + DB_NAME() +'] : Started >>>>'
		PRINT ''

		DECLARE @today date = getdate();	
		PRINT '[Date: ' + CAST(YEAR(@today) AS VARCHAR) + '-' + DATENAME (MONTH, (@today)) + '-' + CAST(DAY(@today) AS VARCHAR) + ']'
		PRINT ''
	END

	DECLARE @unitPriceCurrId BIGINT = (SELECT ID_ FROM ADM_MST_MONEY_CURRENCY WHERE CODE_ = 'AED');
	
	-- create empty table
	SELECT L.* INTO #TblTempReorderLevel FROM LOG_TRN_ITEM_REORDER_LEVELS L WHERE 1=0;

    
	--get all the primary parts and their levels
	INSERT INTO #TblTempReorderLevel(
		   ITEM_ID,
		   BU_ID,
		   L2_ID,
		   MAX_LEVEL_,
		   SAFETY_LEVEL_,
		   WAR_RESERVE_,
		   CREATED_ON_
	       )
    SELECT ItemAssoc.ITEM_ID AS ItemID
	      ,StockLevels.STORE_ID AS StoreId
          ,ItemAssoc.L2_ID AS L2Id
		  ,StockLevels.MAX_ AS MaxLevel
		  ,StockLevels.SAFETY_ AS SafetyLevel
		  ,StockLevels.WAR_RESERVE_ AS WarReserve
		  ,getdate() AS CreatedOn
      FROM LOG_TRN_STOCK_LEVEL2 StockLevels
           JOIN ADM_TRN_ITEM_ASSOCS ItemAssoc ON StockLevels.ITEM_ASSOC_ID_ = ItemAssoc.ID_
		   JOIN ADM_MST_BUSINESS_UNITS Store ON StockLevels.STORE_ID = Store.ID_
     WHERE ItemAssoc.PRIMARY_PART_ = 1
	   AND Store.PARENT_STORE_ID_ IS NULL;



	--update all the values for the primary part columns
	WITH PrimaryPartStoreStock (CandidateID, Stock, NewDuesInConfirmed,  NewDuesInNotConfirmed,   DuesOut, AvgTAT, LastPrice, UnderStockTaking, ExpiredStock) AS (
				SELECT Candidates.ID_
					   --Regular and Receiving locations quantity only as per current implementation
					  ,SUM(ISNULL(QtySnapshot.TOTAL_STOCK_,0) - ISNULL(QtySnapshot.STOCK_AWAITING_RECEPTION_,0)) Stock
					  ,SUM(ISNULL(QtySnapshot.NEW_DUES_IN_CONF_,0)) NewDuesInConfirmed
					  ,SUM(ISNULL(QtySnapshot.NEW_DUES_IN_NOT_CONF_,0)) NewDuesInNotConfirmed
					  ,SUM(ISNULL(QtySnapshot.USER_DUES_OUT_QTY,0)) DuesOut
					  ,MAX(ISNULL(QtySnapshot.AVG_TAT,0)) AvgTAT --Only one row expected. Hence MAX
					  ,MAX(ISNULL(QtySnapshot.LAST_PROC_PRICE,0)) LastPrice --Only one row expected. Hence MAX
					  ,SUM(ISNULL(QtySnapshot.UNDER_STOCK_TAKING_, 0)) UnderStockTaking
					  ,SUM(ISNULL(QtySnapshot.EXPIRED_STOCK, 0)) ExpiredStock
				  FROM #TblTempReorderLevel Candidates
					   JOIN LOG_MST_RPM_CANDIDATE_CONFIG Config ON Candidates.BU_ID = Config.STORE_ID
					   JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE QtySnapshot ON Candidates.ITEM_ID = QtySnapshot.ITEM_ID_
																	  AND Candidates.BU_ID = QtySnapshot.PARENT_BU_ID_
																	  AND Candidates.L2_ID = QtySnapshot.L2_ID_
					   JOIN ADM_MST_BUSINESS_UNITS substore ON QtySnapshot.BU_ID_ = substore.ID_ 
				 WHERE Config.HAS_SUB_STORE_STOCK_ = 1
				   AND (isnull(substore.IS_DEPLOYMENT_STORE_,0) = 0) 
				 GROUP BY Candidates.ID_
         UNION ALL
				SELECT Candidates.ID_
					   --Regular and Receiving locations quantity only as per current implementation
					  ,SUM(ISNULL(QtySnapshot.TOTAL_STOCK_,0) - ISNULL(QtySnapshot.STOCK_AWAITING_RECEPTION_,0)) Stock
					  ,SUM(ISNULL(QtySnapshot.NEW_DUES_IN_CONF_,0)) NewDuesInConfirmed
					  ,SUM(ISNULL(QtySnapshot.NEW_DUES_IN_NOT_CONF_,0)) NewDuesInNotConfirmed
					  ,SUM(ISNULL(QtySnapshot.USER_DUES_OUT_QTY,0)) DuesOut
					  ,MAX(ISNULL(QtySnapshot.AVG_TAT,0)) AvgTAT --Only one row expected. Hence MAX
					  ,MAX(ISNULL(QtySnapshot.LAST_PROC_PRICE,0)) LastPrice --Only one row expected. Hence MAX
					  ,SUM(ISNULL(QtySnapshot.UNDER_STOCK_TAKING_, 0)) UnderStockTaking
					  ,SUM(ISNULL(QtySnapshot.EXPIRED_STOCK, 0)) ExpiredStock
				  FROM #TblTempReorderLevel Candidates
					   JOIN LOG_MST_RPM_CANDIDATE_CONFIG Config ON Candidates.BU_ID = Config.STORE_ID
					   JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE QtySnapshot ON Candidates.ITEM_ID = QtySnapshot.ITEM_ID_
																	  AND Candidates.BU_ID = QtySnapshot.BU_ID_
																	  AND Candidates.L2_ID = QtySnapshot.L2_ID_
					   JOIN ADM_MST_BUSINESS_UNITS substore ON QtySnapshot.BU_ID_ = substore.ID_ 
				 WHERE Config.HAS_SUB_STORE_STOCK_ = 0
				   AND (isnull(substore.IS_DEPLOYMENT_STORE_,0) = 0) 
				 GROUP BY Candidates.ID_
	) 
	UPDATE Upd
	   SET STOCK_ = PS.Stock
	      ,NEW_DUES_IN_CONFIRMED_ = PS.NewDuesInConfirmed
		  ,NEW_DUES_IN_NOT_CONFIRMED_ = PS.NewDuesInNotConfirmed
		  ,DUES_OUT_ = PS.DuesOut
		  ,AVG_LEAD_TIME_ = PS.AvgTAT
		  ,UNIT_PRICE_CURR_ID = @unitPriceCurrId
		  ,UNIT_PRICE_CURR_VAL_ = PS.LastPrice
		  ,UNDER_STOCK_TAKING_ = PS.UnderStockTaking
		  ,EXPIRED_STOCK = PS.ExpiredStock
	  FROM #TblTempReorderLevel Upd
	       JOIN PrimaryPartStoreStock PS on Upd.ID_ = PS.CandidateID;    


    --update all the values for the in liue part columns
	WITH InLieuPartStoreStock (CandidateID, Stock, NewDuesInConfirmed,  NewDuesInNotConfirmed,   DuesOut, UnderStockTaking, ExpiredStock) AS (
				SELECT Candidates.ID_
					   --Regular and Receiving locations quantity only as per current implementation
					  ,SUM(ISNULL(QtySnapshot.TOTAL_STOCK_,0) - ISNULL(QtySnapshot.STOCK_AWAITING_RECEPTION_,0)) Stock
					  ,SUM(ISNULL(QtySnapshot.NEW_DUES_IN_CONF_,0)) NewDuesInConfirmed
					  ,SUM(ISNULL(QtySnapshot.NEW_DUES_IN_NOT_CONF_,0)) NewDuesInNotConfirmed
					  ,SUM(ISNULL(QtySnapshot.USER_DUES_OUT_QTY,0)) DuesOut
					  ,SUM(ISNULL(QtySnapshot.UNDER_STOCK_TAKING_, 0)) UnderStockTaking
					  ,SUM(ISNULL(QtySnapshot.EXPIRED_STOCK, 0)) ExpiredStock
				  FROM #TblTempReorderLevel Candidates
					   JOIN LOG_MST_RPM_CANDIDATE_CONFIG Config ON Candidates.BU_ID = Config.STORE_ID
					   JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE QtySnapshot ON Candidates.ITEM_ID = QtySnapshot.PRIMARY_PART_ITEM_ID_
																	  AND QtySnapshot.ITEM_ID_ <> QtySnapshot.PRIMARY_PART_ITEM_ID_ --do not double count primary part values
																	  AND Candidates.BU_ID = QtySnapshot.PARENT_BU_ID_
																	  AND Candidates.L2_ID = QtySnapshot.L2_ID_
					   JOIN ADM_MST_BUSINESS_UNITS substore ON QtySnapshot.BU_ID_ = substore.ID_ 
				 WHERE Config.HAS_SUB_STORE_STOCK_ = 1
				   AND (isnull(substore.IS_DEPLOYMENT_STORE_,0) = 0) 
				 GROUP BY Candidates.ID_
         UNION ALL
		SELECT Candidates.ID_
		       --Regular and Receiving locations quantity only as per current implementation
			  ,SUM(ISNULL(QtySnapshot.TOTAL_STOCK_,0) - ISNULL(QtySnapshot.STOCK_AWAITING_RECEPTION_,0)) Stock
			  ,SUM(ISNULL(QtySnapshot.NEW_DUES_IN_CONF_,0)) NewDuesInConfirmed
			  ,SUM(ISNULL(QtySnapshot.NEW_DUES_IN_NOT_CONF_,0)) NewDuesInNotConfirmed
			  ,SUM(ISNULL(QtySnapshot.USER_DUES_OUT_QTY,0)) DuesOut
			  ,SUM(ISNULL(QtySnapshot.UNDER_STOCK_TAKING_, 0)) UnderStockTaking
			  ,SUM(ISNULL(QtySnapshot.EXPIRED_STOCK, 0)) ExpiredStock
		  FROM #TblTempReorderLevel Candidates
               JOIN LOG_MST_RPM_CANDIDATE_CONFIG Config ON Candidates.BU_ID = Config.STORE_ID
		       JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE QtySnapshot ON Candidates.ITEM_ID = QtySnapshot.PRIMARY_PART_ITEM_ID_
                                                              AND QtySnapshot.ITEM_ID_ <> QtySnapshot.PRIMARY_PART_ITEM_ID_ --do not double count primary part values
			                                                  AND Candidates.BU_ID = QtySnapshot.BU_ID_
															  AND Candidates.L2_ID = QtySnapshot.L2_ID_
               JOIN ADM_MST_BUSINESS_UNITS substore ON QtySnapshot.BU_ID_ = substore.ID_ 
         WHERE Config.HAS_SUB_STORE_STOCK_ = 0
           AND (isnull(substore.IS_DEPLOYMENT_STORE_,0) = 0) 
		 GROUP BY Candidates.ID_
	) 
	UPDATE Upd
	   SET IN_LIEU_STOCK_ = IPS.Stock
	      ,NEW_IN_LIEU_DUES_IN_CONFIRMED_ = IPS.NewDuesInConfirmed
		  ,NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_ = IPS.NewDuesInNotConfirmed
		  ,IN_LIEU_DUES_OUT_ = IPS.DuesOut
		  ,IN_LIEU_UNDER_STOCK_TAKING_ = IPS.UnderStockTaking
		  ,IN_LIEU_EXPIRED_STOCK = IPS.ExpiredStock
	  FROM #TblTempReorderLevel Upd
	       JOIN InLieuPartStoreStock IPS on Upd.ID_ = IPS.CandidateID;

 --update Repair Dues In 
	WITH RepairPartStoreStock (CandidateID, RprDuesInConfirmed, RprDuesInNotConfirmed) AS (
			SELECT        Candidates.ID_, SUM(ISNULL(QtySnapshot.RPR_DUES_IN_CONF_, 0)) AS RprDuesInConfirmed, SUM(ISNULL(QtySnapshot.RPR_DUES_IN_NOT_CONF_, 0)) AS RprDuesInNotConfirmed
			FROM            [#TblTempReorderLevel] AS Candidates 
														INNER JOIN LOG_MST_RPM_CANDIDATE_CONFIG AS Config ON Candidates.BU_ID = Config.STORE_ID 
														INNER JOIN ADM_MST_STORE_TFU_BUSINESS_UNIT AS TU_BU ON TU_BU.STORE_ID = Candidates.BU_ID 
														INNER JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE AS QtySnapshot ON Candidates.ITEM_ID = QtySnapshot.PRIMARY_PART_ITEM_ID_
																													AND QtySnapshot.ITEM_ID_ <> QtySnapshot.PRIMARY_PART_ITEM_ID_ 
																													AND TU_BU.TFU_ID = QtySnapshot.BU_ID_ AND Candidates.L2_ID = QtySnapshot.L2_ID_ 
														INNER JOIN ADM_MST_BUSINESS_UNITS AS substore ON QtySnapshot.BU_ID_ = substore.ID_
			WHERE      --  (Config.HAS_SUB_STORE_STOCK_ = 1)  AND 
								(isnull(substore.IS_DEPLOYMENT_STORE_,0) = 0) 
								AND (TU_BU.STORE_ID IN
															 (SELECT        ID_
															   FROM            ADM_MST_BUSINESS_UNITS AS BU
															   WHERE        (CMD_ID_ = Config.CMD_ID) AND (BU_TYPE_ = 'Store')))
			GROUP BY Candidates.ID_
	) 
	UPDATE Upd
	 SET    RPR_IN_LIEU_DUES_IN_CONFIRMED_ = PS.RprDuesInConfirmed
				,RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_ = PS.RprDuesInNotConfirmed
	
	  FROM #TblTempReorderLevel Upd
	       JOIN RepairPartStoreStock PS on Upd.ID_ = PS.CandidateID;

		   
 --update In-Lieu Repair Dues In
	WITH RepairPartStoreStock (CandidateID, RprDuesInConfirmed, RprDuesInNotConfirmed) AS (
			SELECT        Candidates.ID_, SUM(ISNULL(QtySnapshot.RPR_DUES_IN_CONF_, 0)) AS RprDuesInConfirmed, SUM(ISNULL(QtySnapshot.RPR_DUES_IN_NOT_CONF_, 0)) AS RprDuesInNotConfirmed
			FROM            [#TblTempReorderLevel] AS Candidates 
														INNER JOIN LOG_MST_RPM_CANDIDATE_CONFIG AS Config ON Candidates.BU_ID = Config.STORE_ID 
														INNER JOIN ADM_MST_STORE_TFU_BUSINESS_UNIT AS TU_BU ON TU_BU.STORE_ID = Candidates.BU_ID 
														INNER JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE AS QtySnapshot ON Candidates.ITEM_ID = QtySnapshot.ITEM_ID_ 
																													AND TU_BU.TFU_ID = QtySnapshot.BU_ID_ AND Candidates.L2_ID = QtySnapshot.L2_ID_ 
														INNER JOIN ADM_MST_BUSINESS_UNITS AS substore ON QtySnapshot.BU_ID_ = substore.ID_
			WHERE     --   (Config.HAS_SUB_STORE_STOCK_ = 1)  AND 
							   (isnull(substore.IS_DEPLOYMENT_STORE_,0) = 0) 
								AND (TU_BU.STORE_ID IN
															 (SELECT        ID_
															   FROM            ADM_MST_BUSINESS_UNITS AS BU
															   WHERE        (CMD_ID_ = Config.CMD_ID) AND (BU_TYPE_ = 'Store')))
			GROUP BY Candidates.ID_
	) 

	UPDATE Upd
	   SET    RPR_DUES_IN_CONFIRMED_ = PS.RprDuesInConfirmed
				,RPR_DUES_IN_NOT_CONFIRMED_ = PS.RprDuesInNotConfirmed	   
	  FROM #TblTempReorderLevel Upd
	       JOIN RepairPartStoreStock PS on Upd.ID_ = PS.CandidateID;
	
	-- Audit log: Insert only modified records + new records
	INSERT INTO LOG_TRN_RPM_REORDER_POINT_JOB_LOG
	(   ID_,
	    VERSION_,
	    DATE_,
		ITEM_ID,
		BU_ID_,
		L2_ID_,
		STOCK_,
		NEW_DUES_IN_CONFIRMED_,
		NEW_DUES_IN_NOT_CONFIRMED_,
		DUES_OUT_,
		IN_LIEU_STOCK_,
		NEW_IN_LIEU_DUES_IN_CONFIRMED_,
		NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_,
		IN_LIEU_DUES_OUT_,
		MAX_LEVEL_,
		SAFETY_LEVEL_,
		WAR_RESERVE_,
		AVG_LEAD_TIME_,
		UNIT_PRICE_CURR_ID,
		UNIT_PRICE_CURR_VAL_,
		EXE_STATUS_,
		RPR_DUES_IN_CONFIRMED_,
		RPR_DUES_IN_NOT_CONFIRMED_,
		RPR_IN_LIEU_DUES_IN_CONFIRMED_,
		RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_
	)
	SELECT 
	(select NEWID())
		 ,1
		,@pExecutionDate
		,TempReorderLevel.ITEM_ID
		,TempReorderLevel.BU_ID
		,TempReorderLevel.L2_ID
		,TempReorderLevel.STOCK_
		,TempReorderLevel.NEW_DUES_IN_CONFIRMED_
		,TempReorderLevel.NEW_DUES_IN_NOT_CONFIRMED_
		,TempReorderLevel.DUES_OUT_
		,TempReorderLevel.IN_LIEU_STOCK_
		,TempReorderLevel.NEW_IN_LIEU_DUES_IN_CONFIRMED_
		,TempReorderLevel.NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_
		,TempReorderLevel.IN_LIEU_DUES_OUT_
		,TempReorderLevel.MAX_LEVEL_
		,TempReorderLevel.SAFETY_LEVEL_
		,TempReorderLevel.WAR_RESERVE_
		,TempReorderLevel.AVG_LEAD_TIME_
		,TempReorderLevel.UNIT_PRICE_CURR_ID
		,ISNULL(TempReorderLevel.UNIT_PRICE_CURR_VAL_,0)
		,'Success'
		,TempReorderLevel.RPR_DUES_IN_CONFIRMED_
		,TempReorderLevel.RPR_DUES_IN_NOT_CONFIRMED_
		,TempReorderLevel.RPR_IN_LIEU_DUES_IN_CONFIRMED_
		,TempReorderLevel.RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_
		FROM #TblTempReorderLevel as TempReorderLevel
		left JOIN
		LOG_TRN_ITEM_REORDER_LEVELS TblReorderLevel ON 	
		TempReorderLevel.BU_ID = TblReorderLevel.BU_ID AND
		TempReorderLevel.L2_ID = TblReorderLevel.L2_ID AND
		TempReorderLevel.ITEM_ID = TblReorderLevel.ITEM_ID
	WHERE
	(
		(
			TempReorderLevel.ITEM_ID = TblReorderLevel.ITEM_ID
			AND
			(
				TempReorderLevel.STOCK_<> TblReorderLevel.STOCK_
				OR TempReorderLevel.NEW_DUES_IN_CONFIRMED_ <> TblReorderLevel.NEW_DUES_IN_CONFIRMED_
				OR TempReorderLevel.NEW_DUES_IN_NOT_CONFIRMED_ <> TblReorderLevel.NEW_DUES_IN_NOT_CONFIRMED_
				OR TempReorderLevel.DUES_OUT_ <> TblReorderLevel.DUES_OUT_
				OR TempReorderLevel.UNDER_STOCK_TAKING_ <> TblReorderLevel.UNDER_STOCK_TAKING_
				OR TempReorderLevel.EXPIRED_STOCK <> TblReorderLevel.EXPIRED_STOCK
				OR TempReorderLevel.IN_LIEU_STOCK_ <> TblReorderLevel.IN_LIEU_STOCK_
				OR TempReorderLevel.NEW_IN_LIEU_DUES_IN_CONFIRMED_ <> TblReorderLevel.NEW_IN_LIEU_DUES_IN_CONFIRMED_
				OR TempReorderLevel.NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_ <> TblReorderLevel.NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_
				OR TempReorderLevel.IN_LIEU_DUES_OUT_ <> TblReorderLevel.IN_LIEU_DUES_OUT_
				OR TempReorderLevel.IN_LIEU_UNDER_STOCK_TAKING_ <> TblReorderLevel.IN_LIEU_UNDER_STOCK_TAKING_
				OR TempReorderLevel.IN_LIEU_EXPIRED_STOCK <> TblReorderLevel.IN_LIEU_EXPIRED_STOCK
				OR TempReorderLevel.MAX_LEVEL_ <> TblReorderLevel.MAX_LEVEL_
				OR TempReorderLevel.SAFETY_LEVEL_ <> TblReorderLevel.SAFETY_LEVEL_
				OR TempReorderLevel.WAR_RESERVE_ <> TblReorderLevel.WAR_RESERVE_
				OR TempReorderLevel.AVG_LEAD_TIME_ <> TblReorderLevel.AVG_LEAD_TIME_
				OR TempReorderLevel.UNIT_PRICE_CURR_ID <> TblReorderLevel.UNIT_PRICE_CURR_ID
				OR TempReorderLevel.UNIT_PRICE_CURR_VAL_ <> TblReorderLevel.UNIT_PRICE_CURR_VAL_
				OR TempReorderLevel.RPR_DUES_IN_CONFIRMED_ <> TblReorderLevel.RPR_DUES_IN_CONFIRMED_
				OR TempReorderLevel.RPR_DUES_IN_NOT_CONFIRMED_ <> TblReorderLevel.RPR_DUES_IN_NOT_CONFIRMED_
				OR TempReorderLevel.RPR_IN_LIEU_DUES_IN_CONFIRMED_ <> TblReorderLevel.RPR_IN_LIEU_DUES_IN_CONFIRMED_
				OR TempReorderLevel.RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_ <> TblReorderLevel.RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_
			)
		)
		
		OR
		
		(TblReorderLevel.ITEM_ID IS NULL)
	)
	
	
	-- Clear all existing data
	BEGIN TRY
		TRUNCATE TABLE LOG_TRN_ITEM_REORDER_LEVELS;
		SET @affectedRows = @@ROWCOUNT;		
		
		IF @PRINT_MESSAGES = 1
		BEGIN
			PRINT 'Truncated table: LOG_TRN_ITEM_REORDER_LEVELS';
		END
	END TRY
	BEGIN CATCH
		IF @PRINT_MESSAGES = 1
		BEGIN
			PRINT ''
			PRINT 'Please run the script to create table: LOG_TRN_ITEM_REORDER_LEVELS'
			PRINT 'Execution stopped!'
		END
		
		RETURN;
		
	END CATCH
	
	-- Dump temporary table to history
	INSERT INTO LOG_TRN_ITEM_REORDER_LEVELS
	(
		ITEM_ID,
		BU_ID,
		L2_ID,
		STOCK_,
		NEW_DUES_IN_CONFIRMED_,
		NEW_DUES_IN_NOT_CONFIRMED_,
		DUES_OUT_,
		UNDER_STOCK_TAKING_,
		EXPIRED_STOCK,
		IN_LIEU_STOCK_,
		NEW_IN_LIEU_DUES_IN_CONFIRMED_,
		NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_,
		IN_LIEU_DUES_OUT_,
		IN_LIEU_UNDER_STOCK_TAKING_,
		IN_LIEU_EXPIRED_STOCK,
		MAX_LEVEL_,
		SAFETY_LEVEL_,
		WAR_RESERVE_,
		AVG_LEAD_TIME_,
		UNIT_PRICE_CURR_ID,
		UNIT_PRICE_CURR_VAL_,
		CREATED_ON_,
		RPR_DUES_IN_CONFIRMED_,
		RPR_DUES_IN_NOT_CONFIRMED_,
		RPR_IN_LIEU_DUES_IN_CONFIRMED_,
		RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_
	)
	SELECT
		 TempReorderLevel.ITEM_ID
		,TempReorderLevel.BU_ID
		,TempReorderLevel.L2_ID
		,ISNULL(TempReorderLevel.STOCK_,0)
		,ISNULL(TempReorderLevel.NEW_DUES_IN_CONFIRMED_,0)
		,ISNULL(TempReorderLevel.NEW_DUES_IN_NOT_CONFIRMED_,0)
		,ISNULL(TempReorderLevel.DUES_OUT_,0)
		,ISNULL(TempReorderLevel.UNDER_STOCK_TAKING_,0)
		,ISNULL(TempReorderLevel.EXPIRED_STOCK,0)
		,ISNULL(TempReorderLevel.IN_LIEU_STOCK_,0)
		,ISNULL(TempReorderLevel.NEW_IN_LIEU_DUES_IN_CONFIRMED_,0)
		,ISNULL(TempReorderLevel.NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_,0)
		,ISNULL(TempReorderLevel.IN_LIEU_DUES_OUT_,0)
		,ISNULL(TempReorderLevel.IN_LIEU_UNDER_STOCK_TAKING_,0)
		,ISNULL(TempReorderLevel.IN_LIEU_EXPIRED_STOCK,0)
		,TempReorderLevel.MAX_LEVEL_
		,TempReorderLevel.SAFETY_LEVEL_
		,TempReorderLevel.WAR_RESERVE_
		,ISNULL(TempReorderLevel.AVG_LEAD_TIME_,0)
		,TempReorderLevel.UNIT_PRICE_CURR_ID
		,ISNULL(TempReorderLevel.UNIT_PRICE_CURR_VAL_,0)
		,TempReorderLevel.CREATED_ON_
		,ISNULL(TempReorderLevel.RPR_DUES_IN_CONFIRMED_,0)
		,ISNULL(TempReorderLevel.RPR_DUES_IN_NOT_CONFIRMED_,0)
		,ISNULL(TempReorderLevel.RPR_IN_LIEU_DUES_IN_CONFIRMED_,0)
		,ISNULL(TempReorderLevel.RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_,0)
		
	FROM #TblTempReorderLevel as TempReorderLevel
	
	SET @affectedRows = @@ROWCOUNT;
		
	DROP TABLE #TblTempReorderLevel;
	-- ------------------------------------------------------------------------------------------------

	----------------------AUTO GENERATE REORDER POINT----------------------
	EXEC Generate_Reorder_Point_Automatically
	----------------------------------------------------------------------
	
	IF @PRINT_MESSAGES = 1
	BEGIN
		PRINT ''
		PRINT 'Records inserted in table LOG_TRN_ITEM_REORDER_LEVELS: ' + CONVERT(VARCHAR(510), @affectedRows);
		PRINT ''
	END

	DECLARE @stopTime DATETIME;
	DECLARE @timeTakenInSeconds BIGINT;
	DECLARE @timeTakenInMilliseconds BIGINT;
	DECLARE @timeSpentStr VARCHAR(MAX);
	DECLARE @description VARCHAR(MAX);
	
	SET @stopTime = GETDATE();
	SET @timeTakenInSeconds = DATEDIFF("s", @startTime, @stopTime)
	SET @timeTakenInMilliseconds = DATEDIFF("ms", @startTime, @stopTime)
	
	SET @timeSpentStr = dbo.ConvertMinutesToHourMinSecString(@timeTakenInSeconds);
	SET @description = 'Execution time: ' + dbo.ConvertMinutesToHourMinSecString(@timeTakenInSeconds) + ' (started: ' + CONVERT(VARCHAR(100), @startTime, 126) + ', stopped: ' + CONVERT(VARCHAR(100), @stopTime, 126) + ')';

	IF @PRINT_MESSAGES = 1
	BEGIN
		PRINT ''
		PRINT @scriptName + ': Ended <<<<<<<<<<<<<'
		PRINT @description
		PRINT '======================================================================================================================='
	END

    COMMIT;

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
      ROLLBACK TRAN;

    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;
    SELECT @ErrorMessage = ERROR_MESSAGE()
          ,@ErrorSeverity = ERROR_SEVERITY()
          ,@ErrorState = ERROR_STATE();
    RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

END CATCH;
go

