CREATE FUNCTION [GetPhaseHistory]
(
  @CmdId      bigint,
  @PlatformIds  nvarchar(max),
  @TailIds    nvarchar(max),
  @InspectionIds  nvarchar(max),
  @IncludeRma   bit = 0,
  @FromDate   date,
  @ToDate     date
)
RETURNS TABLE
AS
RETURN
(
  WITH CTE_BASE AS (
    SELECT PE.ID_ AS PeId, PED.ID_ AS PedId, PLTFM.CODE_ AS Platform, T.T_NUM_ AS TailNo, IAM.INSP_NUMBER_ AS InspNumber, IA.ID_ AS InspectionAssignmentId, P.NAME_ AS PhaseName, AREA.NAME_ AS AreaName, PED.IDX_ AS InspOrdr, 
    UPPER(PED.DESCRIPTION_) AS InspDescription, UPPER(PUSR.F_NAME_ + ' ' + PUSR.L_NAME_) AS PerformedBy, PED.PERFORMED_ON_ As PerformedOn, PED.PERFORMED_MMH_ AS PerformedMmh
    FROM MNT_TRN_PIM_PHASE_EXECUTION PE
    INNER JOIN MNT_TRN_PIM_PHASE P ON P.ID_ = PE.PHASE_ID
    INNER JOIN ADM_MST_TAILS T ON T.ID_ = PE.TAIL_ID
    INNER JOIN ADM_MST_UNITS TU ON TU.ID_ = T.UNIT_ID
    --INNER JOIN ADM_MST_ITEMS TUI ON TUI.ID_ = TU.ITEM_ID
    INNER JOIN MNT_TRN_INSPECTION_MASTERS IAM ON IAM.ID_ = P.INSP_MST_ID
    INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS IA ON IA.INSP_MST_ID = IAM.ID_ AND IA.UNIT_ID = TU.ID_
    INNER JOIN ADM_MST_PLATFORMS PLTFM ON PLTFM.ID_ = TU.ITEM_ID
    INNER JOIN MNT_TRN_PIM_PHASE_EXECUTION_DETAIL PED ON PED.PHASE_EXEC_ID = PE.ID_
    INNER JOIN MNT_MST_PIM_PLATFORM_AREA AREA ON AREA.ID_ = PED.AREA_ID
    INNER JOIN ADM_MST_RESTRICTIONS BTLN ON BTLN.ID_ = T.BATLN_ID
    INNER JOIN dbo.SplitInts(@PlatformIds, ',') PLT ON PLT.Item = TU.ITEM_ID
    INNER JOIN dbo.SplitInts(@TailIds, ',') TL ON TL.Item = T.ID_
    LEFT JOIN ADM_TRN_USER_PROFILES PUSR ON PUSR.ID_ = PED.PERFORMED_BY_ID
    WHERE BTLN.PRNT_ID = @CmdId AND PE.STATUS_ <> 'InProgress'
    --and TUI.ID_ in (@PlatformIds)
  --  and T.ID_ in (@TailIds)
    --AND ('0' = ISNULL(@PlatformIds, '0') OR TUI.ID_ IN (SELECT Item from dbo.SplitInts(@PlatformIds, ',')))
  --  AND ('0' = ISNULL(@TailIds, '0') OR T.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',')))
    --AND ('0' = ISNULL(@InspectionIds, '0') OR P.ID_ IN (SELECT Item from dbo.SplitGuids(@InspectionIds, ',')))
    AND ('0' = ISNULL(@InspectionIds, '0') OR P.ID_ IN (SELECT Item from dbo.SplitGuids((CASE WHEN @InspectionIds = '0' THEN NULL ELSE @InspectionIds END), ',')))
    -- DATE CONDITION ADD
    AND PE.START_DATE_ >= @FromDate AND PE.START_DATE_ <= @ToDate
  ),
  CTE AS (
    SELECT CTE_BASE.PeId, CTE_BASE.PedId, CTE_BASE.Platform, CTE_BASE.TailNo, CTE_BASE.InspNumber, CTE_BASE.InspectionAssignmentId, CTE_BASE.PhaseName, CTE_BASE.AreaName, CTE_BASE.InspOrdr, 
    CTE_BASE.InspDescription, CTE_BASE.PerformedBy, CTE_BASE.PerformedOn, CTE_BASE.PerformedMmh,
    ISNULL(RMA.CNT, 0) AS RmaCount, ISNULL(CTE_BASE.PerformedMmh, 0) + ISNULL(RMA.DUR, 0) AS Duration
    FROM CTE_BASE
    outer apply (
      SELECT ACT.PHASE_EXEC_DET_ID, COUNT(1) AS CNT, SUM(ISNULL(ACT.PERFORMED_MMH_, 0) + ISNULL(ACT.TI_MMH_, 0)) AS DUR
      FROM MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS ACT
      where ACT.PHASE_EXEC_DET_ID = CTE_BASE.PedId
      GROUP BY ACT.PHASE_EXEC_DET_ID
    ) RMA 
  )
  SELECT RANK() OVER (ORDER BY PeId, InspOrdr ASC)  AS Idx, * FROM (
  SELECT DETAILS.PeId, DETAILS.PedId, DETAILS.Platform AS Platform, DETAILS.TailNo AS TailNo, DETAILS.InspNumber, DETAILS.InspectionAssignmentId, DETAILS.PhaseName AS PhaseName, DETAILS.AreaName AS AreaName, DETAILS.InspOrdr AS InspOrdr, 
  DETAILS.InspDescription AS InspDescription, DETAILS.RmaCount AS RmaCount,
     FaultsAp.faults AS Faults,
  NULL AS RmaOrdr, NULL As RmaStatusId, NULL AS RmaAction, NULL AS RmaPerformedAction, DETAILS.PerformedBy AS PerformedBy, DETAILS.PerformedOn AS PerformedOn, NULL AS TiBy,NULL AS TiOn, DETAILS.Duration AS Duration
  FROM CTE AS DETAILS
  outer apply(
   SELECT STRING_AGG( CONCAT(F.FAULT_NO_, ' ',FREF.CODE_ ),',') as    faults
        FROM MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_FAULTS PEDF 
        INNER JOIN MNT_TRN_FAULT_UNITS F ON F.ID_ = PEDF.FAULT_ID
        INNER JOIN ADM_MST_SIMPLE_REF FREF ON FREF.ID_= F.FAULT_INFO_STS_ID
        WHERE PEDF.PHASE_EXEC_DET_ID =DETAILS.PedId
        group by PEDF.PHASE_EXEC_DET_ID ) AS FaultsAp

  --outer apply
  --  (select STUFF
  --  (
  --    (
  --      SELECT ', ' + CAST(F.FAULT_NO_ AS VARCHAR) + ' ' + FREF.CODE_
  --      FROM MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_FAULTS PEDF 
  --      INNER JOIN MNT_TRN_FAULT_UNITS F ON F.ID_ = PEDF.FAULT_ID
  --      INNER JOIN ADM_MST_SIMPLE_REF FREF ON FREF.ID_= F.FAULT_INFO_STS_ID
  --      WHERE PEDF.PHASE_EXEC_DET_ID = DETAILS.PedId
  --      FOR XML PATH('')
  --    ) 
  --  ,1 ,2 , '') as   faults) AS FaultsAp
  UNION ALL 

  SELECT DETAILS.PeId, DETAILS.PedId, DETAILS.Platform AS Platform, DETAILS.TailNo AS TailNo, DETAILS.InspNumber, DETAILS.InspectionAssignmentId, DETAILS.PhaseName AS PhaseName, DETAILS.AreaName AS AreaName, DETAILS.InspOrdr AS InspOrdr, 
  DETAILS.InspDescription AS InspDescription, -1 AS RmaCount, NULL AS Faults, 
  (PEDA.IDX_ + 1) AS RmaOrdr, PEDA.STATUS_ID As RmaStatusId, PEDA.ACTION_ AS RmaAction,  PEDA.PERFORMED_ACTION_ AS RmaPerformedAction,
  UPPER(USR.F_NAME_ + ' ' + USR.L_NAME_) AS PerformedBy, PEDA.PERFORMED_ON_ AS PerformedOn,
  UPPER(TIUSR.F_NAME_ + ' ' + TIUSR.L_NAME_) AS TiBy, NULL AS TiOn,
  ISNULL(PEDA.PERFORMED_MMH_, 0) + ISNULL(PEDA.TI_MMH_, 0) AS Duration
  FROM CTE AS DETAILS
  INNER JOIN MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS PEDA ON PEDA.PHASE_EXEC_DET_ID = DETAILS.PedId
  LEFT JOIN ADM_TRN_USER_PROFILES USR ON USR.ID_ = PEDA.PERFORMED_BY_ID
  LEFT JOIN ADM_TRN_USER_PROFILES TIUSR ON TIUSR.ID_ = PEDA.TI_VALIDATION_BY_ID
  WHERE @IncludeRma = 1 AND DETAILS.RmaCount > 0
  ) RESULT
  --ORDER BY Platform, TailNo, InspNumber, InspOrdr, RmaOrdr
)
go

