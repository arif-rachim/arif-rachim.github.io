CREATE FUNCTION [dbo].[GetDash16ForecastReport]
( 
	@command		BIGINT, 
	@platformIds	nvarchar(max),
	@months			BIGINT
)
RETURNS TABLE 
AS
RETURN 
(
	WITH CTE AS(
		SELECT 
			PartNo,			ItemId,			MFR,Nsn,		Nomenclature,
			PblItemType,	PlatformId,		Platform,		Tail,
			SerialNo,		UnitId,			CommandId,		RepDueDate,
			ManuDate,		RepLifeMonths,
			CASE WHEN REP_CAL_VALUE_ = 0 THEN 0 
				 ELSE ((DATEDIFF(MONTH, CASE WHEN TSI_VALUE_ > 0 THEN INST_DATE_ ELSE MANF_DATE_ END, DATEADD(MONTH, @months, getdate()))) / 
						(CASE WHEN (REP_CAL_UNIT_ = 'Months') THEN REP_CAL_VALUE_ ELSE (REP_CAL_VALUE_ * 12) END)) END AS TimesReplace
						, DATEADD(MONTH, @months, getdate()) AS EndDate, 
			OnHandQty, SUM(Quantity) AS Quantity
		FROM VW_2408ForecastReportData 
		WHERE	RepLifeMonths IS NOT NULL 
				AND (c_r_due_date < DATEADD(MONTH, @months, getdate())) 
				AND CommandId = @command 
				AND PlatformId IN (SELECT Item from dbo.SplitInts(@platformIds, ',')) 
		GROUP BY PartNo,		ItemId,			MFR,			Nsn, 
				 Nomenclature,  PblItemType,	PlatformId,		Platform, 
				 Tail,			SerialNo,		UnitId,			CommandId,
				 RepDueDate,	ManuDate,		RepLifeMonths,	OnHandQty, 
				 Quantity,		REP_CAL_VALUE_, TSI_VALUE_,		INST_DATE_, 
				 MANF_DATE_,	REP_CAL_UNIT_
	),
	CTE2 AS 
	(
		SELECT PartNo,ItemId,MFR,Nsn,Nomenclature,PblItemType,PlatformId,Platform,Tail,SerialNo,UnitId,CommandId,RepDueDate,ManuDate,
			(CASE WHEN RepLifeMonths = 0 THEN NULL ELSE RepLifeMonths END) RepLifeMonths,
			TimesReplace, EndDate, OnHandQty, Quantity
		FROM CTE 
		UNION ALL
		SELECT	 PartNo,		ItemId,			MFR,			Nsn,
				 Nomenclature,  PblItemType,	PlatformId,		Platform,
				 Tail,			SerialNo,		UnitId,			CommandId, 
				 DATEADD(MONTH, ISNULL(CTE2.RepLifeMonths, 0), RepDueDate) RepDueDate, 
				 ManuDate,		RepLifeMonths,	TimesReplace,	EndDate, 
				 OnHandQty,		Quantity
		FROM CTE2
		WHERE CTE2.RepLifeMonths IS NOT NULL AND DATEADD(MONTH, CTE2.RepLifeMonths, CTE2.RepDueDate) <= DATEADD(MONTH, @months, GETDATE())
	),
	CTE3 AS 
	(
		SELECT	 PartNo,		ItemId,			MFR,			Nsn, 
				 Nomenclature,  SUM(Quantity)	Quantity,		OnHandQty  
		FROM	 CTE2
		GROUP BY PartNo, ItemId, MFR, Nsn, Nomenclature, OnHandQty
	)
	SELECT		ItemId,			PartNo,			MFR,			Nsn,
				Nomenclature,	Platform,		Tail,			SerialNo,
				RepDueDate,		RepLifeMonths,	Quantity,		OnHandQty, 
				Diff,			HEAD_,			DATEADD(MONTH, @months, getdate()) EndDate 
	FROM
	(
		SELECT  PartNo,			 ItemId,				MFR,				Nsn,
				Nomenclature,	 NULL PblItemType,	NULL PlatformId,	NULL Platform, 
				NULL Tail,		 NULL SerialNo,		NULL UnitId,		NULL CommandId,
				NULL RepDueDate, NULL ManuDate,		NULL RepLifeMonths,	NULL TimesReplace,
				NULL  EndDate,	 OnHandQty,			Quantity,			(OnHandQty - Quantity) Diff,
		1 AS HEAD_ FROM CTE3
		UNION ALL
		SELECT  PartNo,			 ItemId,			MFR,				Nsn,
				Nomenclature,	 PblItemType,		PlatformId,			Platform,
				Tail,			 SerialNo,			UnitId,				CommandId,
				RepDueDate,		 ManuDate,			RepLifeMonths,		TimesReplace, 
				EndDate,		 OnHandQty,			Quantity,			NULL Diff,
		0 AS HEAD_ 
		FROM CTE2
			INNER JOIN ADM_MST_ITEMS I ON I.ID_ = CTE2.ItemId
	)
	AS D
)
go

