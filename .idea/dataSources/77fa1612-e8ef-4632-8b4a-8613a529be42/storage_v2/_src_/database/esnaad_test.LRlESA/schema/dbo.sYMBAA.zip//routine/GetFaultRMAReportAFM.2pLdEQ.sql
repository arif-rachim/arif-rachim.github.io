CREATE PROC [dbo].[GetFaultRMAReportAFM]
      @TailIds    varchar(max)
AS
BEGIN
SELECT  DISTINCT
      FAULTUNIT.ID_                       As FaultId,
      TAILS.T_NUM_                        As TailNo,
      FAULTUNIT.FAULT_NO_                 As FaultNo,
      FAULTUNIT.FAULT_INFO_DATE_  As FaultDate,
      FAULTUNIT.FAULT_INFO_STS_ID As FaultStatus,
      dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_SYS_ID, 'code') As FaultSystem,
      FAULTUNIT.FAULT_INFO_REMARKS_ As FaultRemarks
FROM  
      ADM_MST_TAILS TAILS INNER JOIN ADM_MST_UNITS UNITS                      ON TAILS.UNIT_ID = UNITS.ID_
                                    INNER JOIN MNT_TRN_FAULT_UNITS FAULTUNIT  ON UNITS.ID_ =       FAULTUNIT.UNIT_ID
                                    INNER JOIN MNT_TRN_FAULT_CORRECTS CORRECTS      ON FAULTUNIT.ID_ = CORRECTS.FAULT_UNIT_ID
                                    INNER JOIN MNT_TRN_FAULT_CORRECTING_ITEMS CORRECTITEMS ON CORRECTS.ID_ = CORRECTITEMS.FLT_CORR_ID AND CORRECTITEMS.STS_ID IS NOT NULL
                                    INNER JOIN ADM_MST_SIMPLE_REF SREF ON CORRECTITEMS.STS_ID = SREF.ID_
WHERE
      TAILS.UNIT_ID IN (SELECT Item from dbo.SplitInts(@TailIds, ',')   )
      AND FAULTUNIT.CLOSE_DATE_ IS NULL AND FAULT_STS_ = 'Open'
ORDER BY 
      FAULTUNIT.ID_

SELECT
      CORRECTS.FAULT_UNIT_ID              As  FaultId,
      CORRECTITEMS.STS_ID                       As    StatusId,
      CORRECTITEMS.REL_ACT_               As    RMARemarks,
      CORRECTITEMS.ACT_                   As    [Action],
      dbo.ReturnPID(CORRECTITEMS.USR_ID)  As PID,
      dbo.ReturnDisplyStringForSimpleRef(CORRECTITEMS.CAT_ID, 'code') As Category, 
      CORRECTITEMS.MNT_MAIN_HRS ManHours,
	  UPPER(LEFT(UP.L_NAME_, 1)) As Initial
FROM
      ADM_MST_TAILS TAILS     INNER JOIN ADM_MST_UNITS UNITS                                          ON    TAILS.UNIT_ID = UNITS.ID_
                                    INNER JOIN MNT_TRN_FAULT_UNITS FAULTUNIT                    ON    UNITS.ID_ =       FAULTUNIT.UNIT_ID
                                    INNER JOIN MNT_TRN_FAULT_CORRECTS CORRECTS                        ON    FAULTUNIT.ID_ = CORRECTS.FAULT_UNIT_ID 
                                    INNER JOIN MNT_TRN_FAULT_CORRECTING_ITEMS CORRECTITEMS      ON CORRECTS.ID_   = CORRECTITEMS.FLT_CORR_ID 
                                    INNER JOIN ADM_MST_SIMPLE_REF SREF ON CORRECTITEMS.STS_ID = SREF.ID_
									LEFT JOIN ADM_TRN_USER_PROFILES UP ON UP.ID_ = CORRECTITEMS.TI_USR_ID
WHERE
      TAILS.UNIT_ID IN (SELECT Item from dbo.SplitInts(@TailIds, ',')   )
      AND FAULTUNIT.CLOSE_DATE_ IS NULL AND FAULT_STS_ = 'Open'
SELECT * FROM dbo.ReturnTailHeader(@TailIds)
END
go

