CREATE PROC [dbo].[GetFaultRMAReport]
       @DateFrom     Datetime,
       @DateTo              DateTime,
       @TailIds      varchar(max)
AS

DECLARE @TailIdsTable TABLE (TAIL_ID BIGINT);

INSERT @TailIdsTable
SELECT Item 
  FROM dbo.SplitInts(@TailIds, ',');

SELECT  DISTINCT
       FAULTUNIT.ID_                     As FaultId,
       TAILS.T_NUM_                      As TailNo,
       FAULTUNIT.FAULT_NO_               As FaultNo,
       FAULTUNIT.FAULT_INFO_DATE_  As FaultDate,
       FAULTUNIT.FAULT_INFO_STS_ID As FaultStatus,
       dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_SYS_ID, 'code') As FaultSystem,
       FAULTUNIT.FAULT_INFO_REMARKS_ As FaultRemarks
FROM   @TailIdsTable AS TailsTable 
                           INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                        INNER JOIN ADM_MST_UNITS UNITS                     ON TAILS.UNIT_ID = UNITS.ID_
                                         INNER JOIN MNT_TRN_FAULT_UNITS FAULTUNIT ON UNITS.ID_ =        FAULTUNIT.UNIT_ID
                                         INNER JOIN MNT_TRN_FAULT_CORRECTS CORRECTS      ON FAULTUNIT.ID_ = CORRECTS.FAULT_UNIT_ID
                                         INNER JOIN MNT_TRN_FAULT_CORRECTING_ITEMS CORRECTITEMS ON CORRECTS.ID_ = CORRECTITEMS.FLT_CORR_ID AND CORRECTITEMS.STS_ID IS NOT NULL
WHERE
CORRECTITEMS.STS_ID IS NOT NULL   
       --AND TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',')    )
       AND FAULTUNIT.FAULT_INFO_DATE_ < @DateTo
       AND (FAULTUNIT.CLOSE_DATE_ IS NULL OR FAULTUNIT.CLOSE_DATE_ > @DateFrom)
       AND (CORRECTS.DATE_ IS NULL  OR (CORRECTS.DATE_ BETWEEN @DateFrom AND @DateTo))
ORDER BY 
       FAULTUNIT.ID_
    OPTION (FORCE ORDER);

SELECT
       CORRECTS.FAULT_UNIT_ID                   As  FaultId,
       CORRECTITEMS.STS_ID                      As     StatusId,
       CORRECTITEMS.REL_ACT_                    As     RMARemarks,
       CASE WHEN CORRECTITEMS.TI_USR_ID IS NULL THEN CORRECTITEMS.ACT_
       ELSE CORRECTITEMS.ACT_ + ' (INSP. OK BY: ' + UP.USER_ID_      + ')' END As [Action],
       dbo.ReturnPID(CORRECTITEMS.USR_ID) As PID,
       dbo.ReturnDisplyStringForSimpleRef(CORRECTITEMS.CAT_ID, 'code') As Category, 
       CORRECTITEMS.MNT_MAIN_HRS As ManHours,
	   UPPER(LEFT(UP.L_NAME_, 1)) As Initial
FROM @TailIdsTable AS TailsTable 
                           INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                        INNER JOIN ADM_MST_UNITS UNITS                                          ON       TAILS.UNIT_ID = UNITS.ID_
                                         INNER JOIN MNT_TRN_FAULT_UNITS FAULTUNIT                      ON       UNITS.ID_ =   FAULTUNIT.UNIT_ID
                                         INNER JOIN MNT_TRN_FAULT_CORRECTS CORRECTS                           ON     FAULTUNIT.ID_ = CORRECTS.FAULT_UNIT_ID 
                                         INNER JOIN MNT_TRN_FAULT_CORRECTING_ITEMS CORRECTITEMS ON CORRECTS.ID_  = CORRECTITEMS.FLT_CORR_ID
                                         LEFT JOIN ADM_TRN_USER_PROFILES AS UP ON UP.ID_ = CORRECTITEMS.TI_USR_ID
WHERE
       CORRECTITEMS.STS_ID IS NOT NULL   
       --AND TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',')    )
       AND FAULTUNIT.FAULT_INFO_DATE_ < @DateTo
       AND (FAULTUNIT.CLOSE_DATE_ IS NULL OR FAULTUNIT.CLOSE_DATE_ > @DateFrom)
       AND (CORRECTS.DATE_ IS NULL  OR (CORRECTS.DATE_ BETWEEN @DateFrom AND @DateTo))
ORDER BY CORRECTITEMS.IDX_
OPTION (FORCE ORDER);
       
SELECT * FROM dbo.ReturnTailHeader(@TailIds)
go

