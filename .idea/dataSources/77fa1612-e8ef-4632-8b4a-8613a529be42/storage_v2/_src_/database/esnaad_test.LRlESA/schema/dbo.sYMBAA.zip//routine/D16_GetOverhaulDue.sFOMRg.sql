CREATE FUNCTION [dbo].[D16_GetOverhaulDue] (@compId as uniqueIdentifier)
RETURNS @overhaulDue TABLE
(
      _hours real,
      _landings int,
      _cycles int,
      _date datetime
)
AS
BEGIN
DECLARE
		@due_hours numeric(10,2),
		@due_landings int,
		@due_cycles int,
		@due_date datetime

		SELECT
			@due_hours = (CASE WHEN mc.OVR_HRS_ > 0 THEN mc.OVR_HRS_ - ((SELECT Hours FROM dbo.D16_GetComponentUsage(c.ID_)) - L_OVR_HRS_) + round(isnull(uu.TOT_FLIGHT_MINS_, 0) / 60.0,2) ELSE null END + case when mspu.MSPU_FLAG_ = 1 then ISNULL(mc.MSPU_OVR_HRS_, 0) else 0 end),
			@due_landings = (CASE WHEN mc.OVR_LDGS_ > 0 THEN mc.OVR_LDGS_ - ((select Landings from dbo.D16_GetComponentUsage(c.ID_)) - L_OVR_LDGS_) + isnull(uu.LANDINGS_, 0) ELSE null END),
			@due_cycles = (CASE WHEN mc.OVR_CYCLES_ > 0 THEN mc.OVR_CYCLES_ - ((select Cycles from dbo.D16_GetComponentUsage(c.ID_)) - L_OVR_CYCS_) + isnull(e.OPERATING_HRS_, 0) ELSE null END),
			@due_date = (CASE WHEN (mc.OVR_CAL_VALUE_ > 0 and ac.L_OVR_DATE_ is not null)  THEN CASE WHEN (mc.OVR_CAL_UNIT_ = 'Months') then  case when (mc.OVR_CAL_VALUE_ > 95000) then '31-Dec-9999' else  dateadd(month, mc.OVR_CAL_VALUE_ , ac.L_OVR_DATE_) end else dateadd(year,  case when (mc.OVR_CAL_VALUE_ + DATEPART(YEAR, ac.L_OVR_DATE_) > 9999) then '31-Dec-9999' else mc.OVR_CAL_VALUE_ end, ac.L_OVR_DATE_) END ELSE null END)
		FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
			INNER JOIN MNT_MST_D16_COMPONENT c ON c.id_ = ac.COMP_ID_
			INNER JOIN MNT_MST_D16_MASTER_COMPONENT mc ON mc.ID_ = ac.MASTER_COMP_ID_
			INNER JOIN ADM_TRN_UNIT_USAGE uu ON uu.UNIT_ID_ = ac.ACFT_UNIT_ID_
			INNER JOIN ADM_MST_TAILS t on t.UNIT_ID = ac.ACFT_UNIT_ID_
		    LEFT JOIN MNT_MST_D16_MSPU_TAIL_CONFIG mspu ON mspu.ID_ = t.ID_
            LEFT JOIN (
                SELECT
                TOP (1)
                    rg.ENG_UNIT_ID, rd.OPERATING_HRS_
                FROM MNT_D193_ENGINE_READINGS rd
                         JOIN MNT_D193_ENGINE_REGISTER rg ON rg.ID_ = rd.ENGINE_ID
                         JOIN MNT_TRN_D16_ASSIGNED_COMPONENT ac_2 on ac_2.ENGINE_UNIT_ID = rg.ENG_UNIT_ID
                         JOIN MNT_MST_D16_COMPONENT c_2 ON c_2.ID_ = ac_2.COMP_ID_
                 WHERE ac_2.IS_ACTIVE_ = 1 and c_2.ID_ = @compId
                ORDER BY READING_DATE_ DESC) e ON e.ENG_UNIT_ID = ac.ENGINE_UNIT_ID
	    	WHERE ac.COMP_ID_ = @compId AND ac.IS_ACTIVE_ = 1 AND ac.REM_DATE_ is null

      INSERT @overhaulDue
      SELECT @due_hours, @due_landings, @due_cycles, @due_date;
      RETURN;
END
go

