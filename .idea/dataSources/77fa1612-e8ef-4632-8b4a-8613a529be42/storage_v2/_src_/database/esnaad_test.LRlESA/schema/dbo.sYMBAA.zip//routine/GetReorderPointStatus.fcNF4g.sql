CREATE FUNCTION [dbo].[GetReorderPointStatus]
(
	@reorderPointId uniqueidentifier
)
RETURNS nvarchar(50)
AS
BEGIN
	DECLARE @total int, @created int, @validated int, @indentcreated int, @reorderStatus nvarchar(50)

	SELECT @reorderStatus = STATUS_ FROM LOG_TRN_RPM_REORDER_POINT WHERE ID_ = @reorderPointId;
	
	IF NOT EXISTS(SELECT 1 FROM LOG_TRN_RPM_REORDER_POINT_ITEM WHERE ROP_ID = @reorderPointId)
	BEGIN
		RETURN 'Created'
	END
	ELSE IF @reorderStatus = 'Closed'
	BEGIN
		RETURN 'Closed'
	END
	ELSE IF NOT EXISTS(SELECT 1 FROM LOG_TRN_RPM_REORDER_POINT_ITEM WHERE ROP_ID = @reorderPointId AND STATUS_ <> 'Cancelled')
	BEGIN
		RETURN 'Cancelled'
	END

	SELECT @created = [Created], @validated = [Validated], @indentcreated = [IndentCreated]
	,@total = [Created] + [Validated] + [IndentCreated]
	FROM
	(SELECT ROP_ID, STATUS_
	FROM LOG_TRN_RPM_REORDER_POINT_ITEM 
	WHERE ROP_ID = @reorderPointId
	AND STATUS_ <> 'Cancelled') p
	PIVOT
	(
		COUNT(STATUS_)
		FOR STATUS_ IN 
		([Created], [Validated], [IndentCreated]) 
	) AS pvt

	IF @validated = @total
	BEGIN
		RETURN 'Validated'
	END
	ELSE IF @indentcreated = @total
	BEGIN
		RETURN 'Closed'
	END
	ELSE IF @indentcreated > 0
	BEGIN
		RETURN 'PartiallyProcessed'
	END
	ELSE IF @validated > 0
	BEGIN
		RETURN 'PartiallyValidated'
	END
	ELSE IF @created = @total
	BEGIN
		RETURN 'Created'
	END

	RETURN ''
END
go

