CREATE   FUNCTION dbo.adm_getstockcardinfo 
(
	@itemid bigint = 1, 
	@buid	bigint = 1,
	@agl2id bigint = 1
)
RETURNS 
@ResultTable TABLE
( 
	MainStore			VARCHAR(50), 
	AgL2				VARCHAR(50), 
	PartNo				VARCHAR(250), 
	MfrCode				VARCHAR(50), 
	Uom					VARCHAR(50), 
	Stock				INT,  
	NonIssuableStock	INT,  
	DuesInConfirmed		INT, 
	DuesInNotConfirmed	INT, 
	DuesOutUser			INT, 
	DuesOutStore		INT, 
	ShippedOutside		INT,
	StockDate			DATETIME
)
AS
BEGIN
	declare @mstoreid bigint
	declare @MainStore VARCHAR(50)
	declare @AGL2 VARCHAR(50)
	declare @PartNo VARCHAR(50)
	declare @MfrCode VARCHAR(50)
	declare @Uom VARCHAR(50)
	declare @Stock int  
	declare @NonIssuableStock int  
	declare @DuesInConfirmed int 
	declare @DuesInNotConfirmed int 
	declare @DuesOutUser int 
	declare @DuesOutStore int 
	declare @ShippedOutside int
	declare @StockDate DATETIME

	-- prepare table data
	set @StockDate = getdate();
	--mainstore
	select 
		@mstoreid = cmdbu.ID_ , @MainStore = cmdbu.CODE_ 
	from 
		ADM_MST_BUSINESS_UNITS bu join
		ADM_MST_BUSINESS_UNITS cmdbu on cmdbu.CMD_ID_ = bu.CMD_ID_
	where 
		bu.id_ = @buid and cmdbu.BU_TYPE_ ='Store' and cmdbu.PARENT_STORE_ID_ IS NULL and cmdbu.IS_UNIFORM_STORE_ = 0
	--agl2
	select @AGL2 = CODE_ from ADM_TRN_ASSOC_GROUPS where ID_ = @agl2id
	--uom
	SELECT 
		@Uom = UOM.CODE_ , @PartNo = i.PART_NO_, @MfrCode = mfr.CAGE_CODE_
	FROM 
		ADM_MST_ITEMS I 
		JOIN ADM_MST_MANUFACTURES mfr ON mfr.ID_ = I.MNF_ID
		JOIN LOG_MST_UNIT_OF_MEASURE UOM ON UOM.ID_ = I.UOM_ID_
	WHERE 
	I.ID_ = @itemid

	--qIssuable
	SELECT 
		@stock = ISNULL(SUM(S.QTY_) ,0)
	FROM 
		LOG_TRN_STOCK S
		JOIN ADM_MST_UNITS U ON S.UNIT_ID = U.ID_
		JOIN ADM_MST_ITEMS I ON I.ID_ = U.ITEM_ID
		JOIN ADM_MST_UNIT_LOCATION L ON S.LOC_ID = L.ID_
		JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = S.STORE_ID
	WHERE 
	U.ITEM_ID = @itemid
	AND S.STORE_ID = @mstoreid
	AND S.OWNED_BY_L2_ID_= @agl2id
	AND (L.LOC_TYPE_='Regular' OR L.LOC_TYPE_='Receiving') 
	AND s.TAG_COLOR_COND_ID_ = 1 AND (u.EXP_DATE_ is null or u.EXP_DATE_ >= GETDATE())



	--qNonIssuable
	SELECT 
		@NonIssuableStock = ISNULL(SUM((CASE WHEN IL.TC_ID_ = 5 AND QD.DOC_NO_ IS NOT NULL THEN QD.QUARANTINE_QTY_ ELSE IL.QTY_ END)),0) 
	FROM 
		ADM_TRN_IMV_ITEMS_IN_LOCATION IL 
        JOIN ADM_MST_UNITS U ON U.ID_ = IL.UNIT_ID_
        JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = IL.BU_ID_
        JOIN ADM_MST_UNIT_LOCATION L ON IL.LOC_ID_ = L.ID_
        JOIN ADM_MST_UNIT_LOCATION_GROUP LG ON LG.ID_ = L.LG_ID
        LEFT JOIN LOG_TRN_SCR_SCRAP_REQUEST_ITEM SRI ON SRI.UNIT_ID = U.ID_ AND IL.TC_ID_ IN (4,9,12,15)
        LEFT JOIN LOG_TRN_SCR_SCRAP_REQUEST SR ON SR.ID_ = SRI.SR_ID AND SR.STATUS_ <> 'Rejected'
		LEFT JOIN LOG_TRN_SCR_SCRAP_ITEM SCI ON SCI.SRAP_REQUEST_ITEM_ID = SRI.ID_
		LEFT JOIN LOG_TRN_SCR_SCRAP_INSTRUCTION_FORM_ITEM SII ON SII.SCRAP_ITEM_ID = SCI.ID_
		LEFT JOIN LOG_TRN_SCR_SCRAP_INSTRUCTION_FORM SI ON SI.ID_ = SII.SCRAP_INSTRUCTION_FORM_ID
		LEFT JOIN LOG_TRN_SCR_SCRAP_DISPOSAL_DOCUMENT_ITEM SDI ON SDI.SCRAP_INSTR_FORM_ITEM_ID = SII.ID_
		LEFT JOIN LOG_TRN_SCR_SCRAP_DISPOSAL_DOCUMENT SD ON SDI.SCRAP_DISPOSAL_DOC_ID = SD.ID_
		LEFT JOIN (
			SELECT L2_ID, DOC_NO_, UNIT_ID, QUARANTINE_LOC_ID, SUM(QUARANTINE_QTY_) QUARANTINE_QTY_
			FROM 
			(
				SELECT QD_.L2_ID, QD_.DOC_NO_, QDI_.UNIT_ID, QDI_.QUARANTINE_LOC_ID, QDI_.QUARANTINE_QTY_ - (CASE 
				WHEN COUNT(QDIE_.QD_ITEM_ID) = 0 THEN 0
				WHEN COUNT(QDIE_.QD_ITEM_ID) > 0 AND QDI_.INSP_ACTION_ = 'GenerateWorkOrder' THEN COUNT(QDIE_.QD_ITEM_ID)
				ELSE QDI_.QUARANTINE_QTY_
				END) AS QUARANTINE_QTY_
				FROM LOG_TRN_QRM_QUARANTINE_DOCUMENT QD_
				INNER JOIN LOG_TRN_QRM_QUARANTINE_DOCUMENT_ITEM QDI_ ON QDI_.QD_ID = QD_.ID_
				INNER JOIN ADM_MST_UNITS U ON U.ID_ = QDI_.UNIT_ID
				LEFT JOIN LOG_TRN_QRM_QUARANTINE_DOCUMENT_ITEM_EXT_INFO QDIE_ ON QDIE_.QD_ITEM_ID = QDI_.ID_ AND QDIE_.IS_ACTIVE_ = 1
				WHERE U.ITEM_ID = @itemId AND QD_.STATUS_ NOT IN ('Completed', 'Rejected')
				GROUP BY QD_.L2_ID, QD_.DOC_NO_, QDI_.UNIT_ID, QDI_.QUARANTINE_QTY_, QDI_.QUARANTINE_LOC_ID, QDI_.INSP_ACTION_
			) QDD GROUP BY L2_ID, DOC_NO_, UNIT_ID, QUARANTINE_LOC_ID
		) QD ON QD.UNIT_ID = IL.UNIT_ID_ AND QD.QUARANTINE_LOC_ID = IL.LOC_ID_ AND QD.L2_ID = IL.OWNED_L2_ID_ AND IL.TC_ID_ = 5 AND QD.QUARANTINE_QTY_ > 0
				
    WHERE 
		U.ITEM_ID = @itemId 
		AND BU.ID_ = @mstoreid AND BU.BU_TYPE_ = 'Store'
		AND IL.OWNED_L2_ID_ = @agl2id
		AND IL.TYPE_='Logistic' AND ISNULL(U.DEACTIVATED_TS_,0) = 0 AND IL.TC_ID_ <> 16
		AND (L.LOC_TYPE_ = 'Receiving' OR L.LOC_TYPE_ = 'Regular' OR L.LOC_TYPE_ = 'Virtual'  OR L.LOC_TYPE_ = 'InTransit' OR (L.LOC_TYPE_='ScrapInTransit' AND SR.ID_ IS NOT NULL))
		AND (IL.TC_ID_ <> 1 OR (IL.TC_ID_ = 1 AND L.LOC_TYPE_ = 'InTransit') OR BU.BU_TYPE_ <> 'Store' OR U.EXP_DATE_ IS NOT NULL AND U.EXP_DATE_ < GETDATE())
	

	--qDuesIn
	SELECT 
		@DuesInConfirmed  = ISNULL((SUM(NEW_DUES_IN_CONF_) + SUM(RPR_DUES_IN_CONF_)),0), 
		@DuesInNotConfirmed  = ISNULL((SUM(NEW_DUES_IN_NOT_CONF_) + SUM(RPR_DUES_IN_NOT_CONF_ )),0)
	FROM 
		VW_DUES_IN_SUMMARY di
	WHERE 
		ITEM_ID_= @itemid
		AND DI.BU_ID_ = @mstoreid
		AND DI.L2_ID_ = @agl2id

	--qDuesOut user
	SELECT 
		@DuesOutUser = ISNULL(SUM(QTY_) ,0)
	FROM 
		VW_DUES_OUT do
	WHERE 
		ITEM_ID_= @itemid
		AND do.FF_BU_ID_= @mstoreid
		AND do.FF_L2_ID_ = @agl2id
		AND do.DUES_OUT_TO_ = 'User'

	--qDuesOut store
	SELECT 
		@DuesOutStore = ISNULL(SUM(QTY_) ,0)
	FROM 
		VW_DUES_OUT do
	WHERE 
		ITEM_ID_= @itemid
		AND do.FF_BU_ID_= @mstoreid
		AND do.FF_L2_ID_ = @agl2id
		AND do.DUES_OUT_TO_ = 'Store'
	

	--shipped outside
	SELECT 
		@ShippedOutside  = ISNULL((SUM(NEW_DUES_IN_CONF_) + SUM(RPR_DUES_IN_CONF_)),0) 
	FROM 
		VW_DUES_IN_SUMMARY di
	WHERE 
		ITEM_ID_= @itemid
		AND DI.BU_ID_ = @buid
		AND DI.L2_ID_ = @agl2id


	-- Fill the table variable with the rows for your result set
	INSERT INTO @ResultTable
		SELECT
			@MainStore , 
			@AGL2 , 
			@PartNo ,
			@MfrCode,
			@Uom , 
			@Stock ,  
			@NonIssuableStock ,  
			@DuesInConfirmed , 
			@DuesInNotConfirmed , 
			@DuesOutUser , 
			@DuesOutStore , 
			@ShippedOutside ,
			@StockDate 
	
	RETURN 
END
go

