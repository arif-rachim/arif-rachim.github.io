CREATE FUNCTION [dbo].[GetAircraftInvReportHrsForMonths] 
(
	-- Add the parameters for the function here
	@months		varchar(255),
	@year		int,
	@aircraft_id	bigint,
	@condition_id	bigint
)
RETURNS DECIMAL(5,1)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @AC_TOTAL_HRS DECIMAL(5,1)

	DECLARE @NRT int = 234  

	-- Get total aircraft hrs
	IF(@condition_id = 0 )
	BEGIN
		SELECT @AC_TOTAL_HRS = (SUM(HOURS_)) FROM dbo.MNT_TRN_AIRCRAFT_INVENTORIES
		WHERE 
			MONTH(DATE_)  in (select * from  dbo.SplitInts(@months,',')) and YEAR(DATE_)=@year
			AND AIRCRAFT_ID = @aircraft_id
			AND COND_ID <> @NRT
	END
	-- Get total aircraft hrs for a condition
	ELSE
	BEGIN
		SELECT @AC_TOTAL_HRS = (SUM(HOURS_)) FROM dbo.MNT_TRN_AIRCRAFT_INVENTORIES
		WHERE 
			MONTH(DATE_) in (select * from  dbo.SplitInts(@months,',')) and YEAR(DATE_)=@year
			AND COND_ID = @condition_id
			AND AIRCRAFT_ID = @aircraft_id
	END
	-- Return the result of the function
	RETURN ISNULL(@AC_TOTAL_HRS ,0)

END
go

