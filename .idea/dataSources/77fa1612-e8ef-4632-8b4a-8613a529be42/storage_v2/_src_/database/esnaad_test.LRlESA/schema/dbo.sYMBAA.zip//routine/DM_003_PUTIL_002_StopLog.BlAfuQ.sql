
CREATE PROCEDURE DM_003_PUTIL_002_StopLog
	  @logRecordID BIGINT
	, @scriptName VARCHAR(MAX)
	, @startTime DATETIME
	, @isDisplayOn BIT
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @stopTime DATETIME;
	DECLARE @timeTakenInSeconds BIGINT;
	DECLARE @timeTakenInMilliseconds BIGINT;
	DECLARE @timeSpentStr VARCHAR(MAX);
	DECLARE @description VARCHAR(MAX);
	
	SET @stopTime = GETDATE();
	SET @timeTakenInSeconds = DATEDIFF("s", @startTime, @stopTime)
	SET @timeTakenInMilliseconds = DATEDIFF("ms", @startTime, @stopTime)
	
	SET @timeSpentStr = dbo.ConvertMinutesToHourMinSecString(@timeTakenInSeconds);
	SET @description = 'Execution time: ' + dbo.ConvertMinutesToHourMinSecString(@timeTakenInSeconds) + ' (started: ' + CONVERT(VARCHAR(100), @startTime, 126) + ', stopped: ' + CONVERT(VARCHAR(100), @stopTime, 126) + ')';
	
	IF @isDisplayOn = 1
	BEGIN
		PRINT ''
		PRINT @scriptName + ': Ended <<<<<<<<<<<<<'
		PRINT @description
		PRINT '======================================================================================================================='
	END
	
	UPDATE DM_ESNAAD_ExecutionTimeLog
	SET
		  END_TIME =  GETDATE()
		, TIME_SPENT_SECONDS = @timeTakenInSeconds
		, TIME_SPENT_MILLISECONDS = @timeTakenInMilliseconds
		, TIME_SPENT_STR = @timeSpentStr
		, DESCRIPTION = @description
	WHERE
		ID_ = @logRecordID
END
go

