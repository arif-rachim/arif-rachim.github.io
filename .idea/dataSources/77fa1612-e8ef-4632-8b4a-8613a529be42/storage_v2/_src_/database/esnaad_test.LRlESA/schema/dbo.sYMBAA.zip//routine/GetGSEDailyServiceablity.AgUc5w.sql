CREATE FUNCTION  [dbo].[GetGSEDailyServiceablity]
(
	-- Add the parameters for the function here
	@recordDate datetime,
	@userId bigint,
	@commandId bigint,
	@displayNonUpdated bit
)
RETURNS INT
AS
BEGIN
	-- Declare the return variable here
	DECLARE @condition varchar(max);
	DECLARE @conditionCount INT;
	DECLARE @total INT = 0;
	DECLARE @fmc int = 0;
	DECLARE @pmc int = 0;
	DECLARE @depot int = 0;
	DECLARE @nmcs int = 0;
	DECLARE @nullValues int = 0;
	DECLARE @denominator int = 0;
	DECLARE @dailyServPer  decimal(18,2) = 0;

	-- Add the T-SQL statements to compute the return value here
	DECLARE db_cursor CURSOR FOR

SELECT  
	                        Condition, COUNT(*) AS ConditionCount
                        FROM
	                        (
		                        SELECT 
			                        (CASE WHEN (ConfigValidityDate < cast(@recordDate as date)) THEN 'NMCM' ELSE Condition END) AS Condition, SrvDate
		                        FROM 
			                        (
				                        SELECT  SRV.DATE_ AS SrvDate,
					                        COND.CODE_ AS Condition, 
					                        ISNULL(SRV.VALID_TILL_DATE_, CONVERT(DATE, DATEADD(DAY, (ISNULL(SC.VALIDITY_DAYS_, 1)),ISNULL(SRV.CREATED_ON_, @recordDate)), 105))  AS ConfigValidityDate
				                        FROM 
                                            MNT_TRN_GSE_SERV AS SRV
							join
							(
								select 
									lsrv.UNIT_ID_ As UNIT_ID_, max(lsrv.DATE_) As LATESTSRVCDATE, max(lsrv.CREATED_ON_) As LATESTSRVCCREATEDON
								from
									MNT_TRN_GSE_SERV AS lsrv
								where
									lsrv.DATE_ <= @recordDate
								group by
									UNIT_ID_
							) AS LATESTSRVC ON LATESTSRVC.UNIT_ID_ = SRV.UNIT_ID_ AND LATESTSRVC.LATESTSRVCDATE = SRV.DATE_ AND LATESTSRVC.LATESTSRVCCREATEDON = SRV.CREATED_ON_
							RIGHT JOIN MNT_MST_GSE_SERV srunit on SRV.UNIT_ID_ = srunit.UNIT_ID_
                            LEFT JOIN ADM_MST_SIMPLE_REF AS COND ON COND.ID_ = SRV.CONDITION_ID_
                            LEFT JOIN MNT_MST_GSE_SERVS_CONFIG AS SC ON SC.COMMAND_ID_ = SRV.COMMAND_ID_
                            LEFT JOIN ADM_MST_RESTRICTIONS AS CCMD ON CCMD.ID_ = SRV.CURRENT_COMMAND_ID_ 
							LEFT JOIN 
							(
								SELECT 
									distinct dacl.TYPE_ID_ as TYPE_ID_
								FROM 
									ADM_TRN_SEC_ROLE_ACL_DETAIL dacl 
									INNER JOIN ADM_TRN_SEC_ROLE_ACL roleacl on dacl.ROLE_ACL_ID = roleacl.id_ AND roleacl.MDL_ID = 'MNT.003.00.00.00'
									INNER JOIN dbo.ADM_TRN_SEC_ROLE role on roleacl.ROLE_ID = role.id_ 
									INNER JOIN ADM_TRN_SEC_ROLE_ASSIGNMENT roleassignment on roleassignment.ROLE_ID = role.id_ and roleassignment.USR_PRF_ID = @userId
									INNER JOIN ADM_MST_RESTRICTIONS As r1 ON dacl.TYPE_ID_ = r1.ID_
								WHERE 
									dacl.type_ = 'MilitaryUnit' and r1.TYPE_NAME_ = 'Command'
							) As cmdres ON cmdres.TYPE_ID_ = CCMD.ID_
                            WHERE 
							(SRV.ID_ IS NULL OR CONVERT(DATE, SRV.DATE_, 105) <= CONVERT(DATE, @recordDate, 105)) 
							AND (@recordDate >= cast(srunit.CREATED_ON_ as date))
							AND (srunit.IS_DELETED_ != 1 OR  (SRV.ID_ IS NOT NULL AND SRV.DATE_ = @recordDate))     
  AND	(@commandId = 0 OR srunit.COMMAND_ID_ IN (@commandId)) 
  AND (@displayNonUpdated <> 0 OR SRV.ID_ IS NOT NULL)					 
					-- AND (SRV.ID_ IS NOT NULL)   
                                    ) AS SRC WHERE 1 = 1
                                ) AS CNT 
                                GROUP BY Condition, SrvDate 


OPEN db_cursor;

FETCH NEXT FROM db_cursor INTO @condition,@conditionCount

WHILE @@FETCH_STATUS = 0
begin
 SET @total = @total + @conditionCount;
--print @condition;
--print @conditionCount;


IF @condition = 'FMC' 
BEGIN
 SET @fmc = @fmc + @conditionCount;
END
ELSE IF @condition = 'PMCM' 
BEGIN
SET @pmc = @pmc + @conditionCount;
END
ELSE IF @condition = 'PMCS' 
BEGIN
SET @pmc = @pmc + @conditionCount;
END
ELSE IF @condition = 'DEPOT' 
BEGIN
SET @depot = @depot + @conditionCount;
END
ELSE IF @condition = 'NMCS' 
BEGIN
SET @nmcs = @nmcs + @conditionCount;
END
ELSE 
BEGIN
SET  @nullValues = @conditionCount;
END

FETCH NEXT FROM db_cursor INTO @condition,@conditionCount

end

SET  @denominator = @total - (@depot + @nmcs);

--print 'denominatoir'
--print @denominator;
--print '----@fmc'
--print @fmc
--print '----@pmc'
--print @pmc

            --SET @dailyServPer = 0;
            if (@denominator > 0)
            BEGIN
                --DECLARE  @dailyServ decimal(18,2) = 0;
                SET @dailyServPer = CONVERT(decimal(18,2), @fmc + @pmc) / @denominator * 100;
				--print '@dailyServ'
				--print Ceiling(@dailyServ)
            END

			
			--PRINT @dailyServPer
close db_cursor

DEALLOCATE db_cursor;
	-- Return the result of the function
	RETURN Ceiling(@dailyServPer);
	--RETURN (@dailyServPer);

END
go

