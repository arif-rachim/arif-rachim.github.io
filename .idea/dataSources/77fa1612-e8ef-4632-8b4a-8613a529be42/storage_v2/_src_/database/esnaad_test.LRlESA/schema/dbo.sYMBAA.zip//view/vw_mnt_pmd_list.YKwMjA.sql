CREATE VIEW [dbo].[vw_mnt_pmd_list]
AS
SELECT     dbo.MNT_TRN_PMD_PART_MAINTENANCE.ID_ AS Id, dbo.MNT_TRN_PMD_PART_MAINTENANCE.PMD_NUM_ AS Pmd, 
                      dbo.MNT_TRN_PMD_PART_MAINTENANCE.CREATED_ON_ AS CreatedDate, dbo.ADM_MST_ITEMS.PART_NO_ AS ItemPn, 
                      dbo.ADM_MST_ITEMS.NOMENCLATURE_ AS Nomenclature, dbo.ADM_MST_UNITS.SERIAL_NO_ AS ItemSn, 
                      dbo.ADM_MST_TAG_COLOR_CONDITION.CONDITION_ AS Condition, CASE ISNULL(dbo.ADM_TRN_WARRANTY.IS_APPLICABLE_, 0) 
                      WHEN 0 THEN 'NO' ELSE 'YES' END AS Warranty, dbo.WF_TRN_INSTANCE.WF_STATE_ AS Status, 
                      dbo.MNT_TRN_PMD_PART_MAINTENANCE.CREATED_ON_ AS CreatedOn, dbo.MNT_TRN_PMD_PART_MAINTENANCE.PID_CREATED_BY_ AS CreatedPid, 
                      dbo.MNT_TRN_PMD_PART_MAINTENANCE.FULL_NAME_CREATED_BY_ AS CreatedUserName, dbo.MNT_TRN_PMD_PART_MAINTENANCE.MOD_ON_ AS ModifiedOn,
                       dbo.MNT_TRN_PMD_PART_MAINTENANCE.PID_MOD_BY_ AS ModifiedPid, dbo.MNT_TRN_PMD_PART_MAINTENANCE.FULL_NAME_MOD_BY_ AS ModifiedName, 
                      dbo.MNT_TRN_PMD_PART_MAINTENANCE.CREATED_BY_,
                          (SELECT     TOP (1) dbo.ADM_MST_SIMPLE_REF.CODE_ + ' - ' + dbo.ADM_MST_SIMPLE_REF.DESC_ AS PRIORITY_
                            FROM          dbo.MNT_TRN_WORK_ORDER INNER JOIN
                                                   dbo.ADM_MST_SIMPLE_REF ON dbo.MNT_TRN_WORK_ORDER.PRI_ID = dbo.ADM_MST_SIMPLE_REF.ID_
                            WHERE      (dbo.MNT_TRN_WORK_ORDER.PMD_ID = dbo.MNT_TRN_PMD_PART_MAINTENANCE.ID_)
                            ORDER BY dbo.MNT_TRN_WORK_ORDER.ID_ DESC) AS Priority,
                          (SELECT     TOP (1) SHOP_BU_ID AS SHOP_
                            FROM          dbo.MNT_TRN_WORK_ORDER AS MNT_TRN_WORK_ORDER_1
                            WHERE      (PMD_ID = dbo.MNT_TRN_PMD_PART_MAINTENANCE.ID_)
                            ORDER BY ID_ DESC) AS SHOP_BU_ID, dbo.MNT_TRN_PMD_PART_MAINTENANCE.BU_ID, dbo.ADM_TRN_WARRANTY.ID_
FROM         dbo.WF_TRN_INSTANCE INNER JOIN
                      dbo.MNT_TRN_PMD_PART_MAINTENANCE INNER JOIN
                      dbo.LOG_TRN_STOCK ON dbo.MNT_TRN_PMD_PART_MAINTENANCE.STOCK_ID = dbo.LOG_TRN_STOCK.ID_ INNER JOIN
                      dbo.ADM_MST_UNITS ON dbo.LOG_TRN_STOCK.UNIT_ID = dbo.ADM_MST_UNITS.ID_ INNER JOIN
                      dbo.ADM_MST_ITEMS ON dbo.ADM_MST_UNITS.ITEM_ID = dbo.ADM_MST_ITEMS.ID_ ON 
                      dbo.WF_TRN_INSTANCE.ID_ = dbo.MNT_TRN_PMD_PART_MAINTENANCE.WF_ID LEFT OUTER JOIN
                      dbo.ADM_MST_TAG_COLOR_CONDITION INNER JOIN
                      dbo.MNT_TRN_PMD_ACTION ON dbo.ADM_MST_TAG_COLOR_CONDITION.ID_ = dbo.MNT_TRN_PMD_ACTION.TAG_ID_ ON 
                      dbo.MNT_TRN_PMD_PART_MAINTENANCE.ACT_ID = dbo.MNT_TRN_PMD_ACTION.ID_ LEFT OUTER JOIN
                      dbo.ADM_TRN_WARRANTY ON dbo.ADM_MST_UNITS.ID_ = dbo.ADM_TRN_WARRANTY.UNIT_ID_
go

