CREATE FUNCTION [dbo].[ReturnYesNo](@boolval bit) RETURNS varchar(100)
BEGIN
	DECLARE @retValue varchar(100)
	SELECT @retValue = (CASE WHEN @boolval = 1 THEN 'YES' ELSE 'NO' END)
	RETURN @retValue
END
go

