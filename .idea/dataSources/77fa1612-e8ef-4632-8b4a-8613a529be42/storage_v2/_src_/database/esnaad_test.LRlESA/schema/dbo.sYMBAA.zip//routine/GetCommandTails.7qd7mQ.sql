
-- =============================================
-- Author:		gal2723
-- Create date: 23-MAR-2015
-- Description:	Returns all platforms of a command
-- =============================================

/*
Ex: SELECT * FROM GetCommandTails('NAG')
*/

CREATE FUNCTION [dbo].GetCommandTails(@commandCode VARCHAR(MAX))
RETURNS TABLE
AS
RETURN
(
	SELECT DISTINCT 
		  BAT.ID_ AS BatID
		, BAT.NAME_ AS BatName
		, BAT.CODE_ AS BatCode
		, CMD.NAME_ AS cmdName
		, CMD.CODE_ AS CmdCode
		, dbo.ADM_MST_TAILS.T_NUM_
	FROM
		dbo.ADM_MST_RESTRICTIONS AS BAT INNER JOIN
		dbo.ADM_MST_RESTRICTIONS AS CMD ON BAT.PRNT_ID = CMD.ID_ INNER JOIN
		dbo.ADM_MST_TAILS ON BAT.ID_ = dbo.ADM_MST_TAILS.BATLN_ID
	WHERE
		CMD.CODE_ = @commandCode
)
go

