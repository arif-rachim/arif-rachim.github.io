CREATE FUNCTION [dbo].[GetIssueableStockQtyForUserItem]
(
  @ItemId     bigint,
  @UserId bigint
)
RETURNS int
AS
BEGIN
  DECLARE @result int

  SELECT @result = ISNULL(SUM(CASE AMUL.LOC_TYPE_ WHEN 'Regular' THEN LTS.QTY_ ELSE 0 END),0)
    FROM LOG_TRN_STOCK AS LTS 
           INNER JOIN ADM_MST_UNITS AS AMU ON LTS.UNIT_ID = AMU.ID_ AND AMU.DEACTIVATED_TS_ = 0 
           INNER JOIN ADM_MST_TAG_COLOR_CONDITION AS AMTCC ON LTS.TAG_COLOR_COND_ID_ = AMTCC.ID_ 
           INNER JOIN ADM_MST_UNIT_LOCATION AS AMUL ON LTS.LOC_ID = AMUL.ID_ 
           INNER JOIN ADM_MST_BUSINESS_UNITS BU ON LTS.STORE_ID = BU.ID_
     WHERE AMTCC.CONDITION_ = 'Serviceable'
       AND AMUL.LOC_TYPE_ IN ('Regular', 'Receiving') 
       AND AMU.ITEM_ID = @ItemId  
       AND ISNULL(AMUL.IS_LOCKED_, 0) = 0
	   AND (ISNULL(AMU.EXP_DATE_, GETDATE() + 1) >= REPLACE(CONVERT(VARCHAR, GETDATE(), 106), ' ', '-'))
       AND EXISTS (
           SELECT 1
             FROM ADM_TRN_SEC_ROLE_ASSIGNMENT ra
                  JOIN ADM_TRN_SEC_ROLE_ACL roleacl on ra.ROLE_ID = roleacl.ROLE_ID and roleacl.MDL_ID = 'LOG.001.00.00.00' 
                  JOIN ADM_TRN_SEC_ROLE_ACL_DETAIL AS dacl_ag on dacl_ag.ROLE_ACL_ID = roleacl.ID_ and dacl_ag.TYPE_ = 'AssociationGroup' and dacl_ag.TYPE_ID_ = LTS.OWNED_BY_L2_ID_
                  JOIN ADM_TRN_SEC_ROLE_ACL_DETAIL AS dacl_bu on dacl_bu.ROLE_ACL_ID = roleacl.ID_ and dacl_bu.TYPE_ = 'BusinessUnit' and dacl_bu.TYPE_ID_ = LTS.STORE_ID
                  JOIN ADM_TRN_SEC_ROLE_ACL_DETAIL AS dacl_mu on dacl_mu.ROLE_ACL_ID = roleacl.ID_ and dacl_mu.TYPE_ = 'MilitaryUnit' and dacl_mu.TYPE_ID_ = BU.CMD_ID_
            WHERE ra.USR_PRF_ID = @UserId
           )

  RETURN @result

END
go

