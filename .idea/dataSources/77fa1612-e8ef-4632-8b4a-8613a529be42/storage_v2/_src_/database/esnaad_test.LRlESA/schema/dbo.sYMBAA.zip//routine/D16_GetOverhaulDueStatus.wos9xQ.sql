create function [dbo].[D16_GetOverhaulDueStatus](@assignmentId uniqueidentifier,
                                                 @currentHours real,
                                                 @currentLandings bigint,
                                                 @currentCycles bigint,
                                                 @currentDate datetime)
    returns int
as
begin

        DECLARE @overhaulDueStatus int;

        select @overhaulDueStatus =
            case
                when @currentHours > DueMaxHours or @currentLandings > DueMaxLandings or @currentCycles > DueCycles or @currentDate > DueMaxDate then 2
                when @currentHours >= DueMinHours or @currentLandings > DueMinLandings or @currentCycles > DueMinLandings or @currentDate > DueMinDate then 1
                else 0 end
        from (
                 select due._hours - iif(tw.ID_ is null or m.ENABLE_TW_ = 0 or tw.OVR_BFR_DUE_ = 0, 0, tw.OVR_ACFT_HRS_)                as DueMinHours
                      , due._hours + iif(tw.ID_ is null or m.ENABLE_TW_ = 0 or tw.OVR_AFT_DUE_ = 0, 0, tw.OVR_ACFT_HRS_)                as DueMaxHours
                      , due._landings - iif(tw.ID_ is null or m.ENABLE_TW_ = 0 or tw.OVR_BFR_DUE_ = 0 , 0, tw.OVR_LDG_)                  as DueMinLandings
                      , due._landings + iif(tw.ID_ is null or m.ENABLE_TW_ = 0 or tw.OVR_AFT_DUE_ = 0, 0, tw.OVR_LDG_)                  as DueMaxLandings
                      , due._cycles                                                                                 as DueCycles
                      , dateadd(day, iif(tw.ID_ is null or m.ENABLE_TW_ = 0 or tw.OVR_BFR_DUE_ = 0, 0, tw.OVR_CAL_ * -1), due._date)    as DueMinDate
                      , dateadd(day, iif(tw.ID_ is null or m.ENABLE_TW_ = 0 or tw.OVR_BFR_DUE_ = 0, 0, tw.OVR_CAL_), due._date)         as DueMaxDate
                 from MNT_TRN_D16_ASSIGNED_COMPONENT a
                          join MNT_MST_D16_MASTER_COMPONENT m on m.ID_ = a.MASTER_COMP_ID_ and m.PART_TYPE_ != 'CC'
                          left join MNT_MST_D16_TOLERANCE_WINDOW tw on tw.CMD_ID_ = m.CMD_ID_ and tw.PLTF_ID_ = m.PLTF_ID
                          cross apply dbo.D16_GetOverhaulDue(a.COMP_ID_) due
                 where a.ID_ = @assignmentId) as root

    return @overhaulDueStatus

end
go

