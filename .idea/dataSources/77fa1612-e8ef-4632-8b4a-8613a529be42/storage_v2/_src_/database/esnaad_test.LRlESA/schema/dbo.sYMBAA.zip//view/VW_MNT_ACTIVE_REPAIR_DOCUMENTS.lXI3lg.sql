CREATE VIEW [dbo].[VW_MNT_ACTIVE_REPAIR_DOCUMENTS] AS

select
	REPAIR_DOCS_.DocumentId, 
	REPAIR_DOCS_.DocumentType, 
	REPAIR_DOCS_.RepairDocument, 
	REPAIR_DOCS_.OpenedDate,
	REPAIR_DOCS_.DocumentStatus, 
	REPAIR_DOCS_.DefectDesc, 
	REPAIR_DOCS_.UnitId, 
	itm.ID_ AS ItemId,
	unt.SERIAL_NO_ AS SerialOrBatchNo, 
	itm.SERIALIZED_ AS IsSerialized, 
	IIF(REPAIR_DOCS_.RemovalDate IS NOT NULL, REPAIR_DOCS_.RemovalDate, fu.FAULT_INFO_DATE_) AS RemovalDate,  
	fu.ID_ as FaultId, 
	fu.FAULT_NO_ as FaultNumber, 
	t.T_NUM_ as TailNumber,
	p.ID_ PlatformId,
	rc.ID_ as CommandId,
	REPAIR_DOCS_.AGL2_ID_ As AgL2Id,
	COUNT(att.ID_) AS AttachmentCount
FROM
(
	select 
		wo.ID_ AS DocumentId,
		'WorkOrder' AS DocumentType, 
		'MNT.003.02.01.00' AS AttachmentResourceId, 
		wo.WO_NO_ AS RepairDocument, 
		(CASE WFINST.WF_STATE_ WHEN 'AwaitingApproval' then WO.CREATED_ON_ else WO.APPROVED_DATE_ END) AS OpenedDate,
		(
			case when WO.WO_CONDITION_ IN ('ACTIVE') OR WO.WO_STS_CODE_  = 'NR1'then 'OPEN'
							when  ((WO.WO_CONDITION_ IN ('ACTIVE')) AND WO.WO_STS_CODE_ IN ('IM', 'IMC')) then 'OPEN - AWAITING ITEM MOVEMENT'
							when (WO.WO_STS_CODE_ IN ('NR1')) then 'COMPLETED - AWAITING NRTS VALIDATION'
							when (WO.WO_CONDITION_ IN ('COMPLETED')  AND WO.WO_STS_CODE_  != 'NR1') then 'COMPLETED'
							when ( WO.WO_CONDITION_ IN ('COMPLETED')  AND WO.WO_STS_CODE_  in ('IM', 'IMC')) then 'COMPLETED - AWAITING ITEM MOVEMENT'
							when (WO.WO_CONDITION_ IN ('COMPLETED')   AND WO.WO_STS_CODE_  in ('S', 'NR2')) then 'COMPLETED - AWAITING CLOSURE'
							when WO.WO_CONDITION_ IN('CLOSED','CANCELLED') then 'CLOSED'	
							ELSE UPPER(WFINST.WF_STATE_)
			end				
		) AS DocumentStatus,
		wo.DESC_ AS DefectDesc, 
		wo.EI_UNIT_ID_ AS UnitId, 
		NULL AS RemovalDate,
		wo.REF_NO_ AS WO_REF_NO,
		wo.ACFT_TAIL_ID_ AS TAIL_UNIT_ID,
		wo.AGL2_ID_ As AGL2_ID_
	from 
		MNT_TRN_WOTS_WORK_ORDER WO 
		inner join WF_TRN_INSTANCE AS WFINST ON wo.WF_ID = WFINST.ID_ AND WFINST.WF_DEF_ID_='WOWorkflow'
		inner join ADM_MST_UNITS unit on WO.EI_UNIT_ID_ = unit.ID_
	where 
		WO_CONDITION_ = 'Active' OR (WO_CONDITION_ = 'Completed' AND wo.IS_NRTS_ = 1 AND wo.DEFECT_REPORT_NO_ IS NULL)
		--AND  
		--WFINST.WF_STATE_ NOT IN ('AwaitingApproval','Awaiting2NdApproval','Rejected','Rejected2Nd') AND ISNULL(WO.REQUESTED_ITEM_ID,0) = 0 



	UNION ALL

	select 
		dfr.ID_ AS DocumentId, 
		'DefectReport' AS DocumentType, 
		'MNT.003.00.00.00' AS AttachmentResourceId, 
		dfr.DEFECT_NO_ AS RepairDocument, 
		dfr.CREATED_ON_ AS OpenedDate,
		(CASE WHEN (WFINST.WF_STATE_ ='NeedCorrection' ) 
                                THEN  
								CASE 
								WHEN DFR.PREVIOUS_STATE_ = 'Approved' then 'NEED CORRECTION BY APPROVER' 
								WHEN DFR.PREVIOUS_STATE_ = 'Validated' then 'NEED CORRECTION BY VALIDATOR' 
								WHEN DFR.PREVIOUS_STATE_ = 'Submitted' then 'NEED CORRECTION BY SUBMITTER' 								
								END								
								ELSE UPPER(WFINST.WF_STATE_) END) AS DocumentStatus, 
		dfr.DESCRIPTION_ AS DefectDesc, 
		dfr.UNIT_ID_ AS UnitId, 
		dfr.REMOVAL_DATE_ AS RemovalDate,
		wo.REF_NO_ AS WO_REF_NO,
		dfr.ACFT_ID_ AS TAIL_UNIT_ID,
		dfr.AGL2_ID_ As AGL2_ID_
	from 
		MNT_TRN_DFR_DEFECT_REPORT DFR 
		inner join WF_TRN_INSTANCE AS WFINST ON DFR.WF_ID = WFINST.ID_ AND WFINST.WF_DEF_ID_='DefectReportWorkflow'
		left join MNT_TRN_WOTS_WORK_ORDER wo ON dfr.DEFECT_NO_ = wo.DEFECT_REPORT_NO_
		left join LOG_TRN_RPR_REPAIR_FILE rf on rf.DEFECT_REPORT_NO_ = dfr.DEFECT_NO_
	where  
		WFINST.WF_STATE_  in ('NeedCorrection', 'Approved', 'Validated', 'Submitted', 'Created'  )
		and rf.DEFECT_REPORT_NO_ IS NULL

	UNION ALL


	select 
		rf.ID_ AS DocumentId, 
		'RepairFile' AS DocumentType, 
		'LOG.003.06.00.00' AS AttachmentResourceId, 
		rf.REPAIR_FILE_NO_ AS RepairDocument, 
		rf.CREATED_ON_ AS OpenedDate,
		CASE RF.STATUS_ 
                        WHEN 'RepairFileCreated' THEN 'REPAIR FILE CREATED' 
                        WHEN 'RFQCreated' THEN 'RFQ CREATED' 
                        WHEN 'RFQValidated' THEN 'RFQ VALIDATED' 
                        WHEN 'RFQDeleted' THEN 'RFQ DELETED' 
                        WHEN 'BidAnalysisCreated' THEN 'BID ANALYSIS CREATED' 
                        WHEN 'BidAnalysisAwaitingEvaluation' THEN 'BID ANALYSIS AWAITING EVALUATION' 
                        WHEN 'BidAnalysisEvaluated' THEN 'BID ANALYSIS EVALUATED' 
                        WHEN 'BidAnalysisValidated' THEN 'BID ANALYSIS VALIDATED' 
                        WHEN 'BidAnalysisDeleted' THEN 'BID ANALYSIS DELETED' 
                        WHEN 'BidAnalysisSignCancelled' THEN 'CANCEL BID ANALYSIS SIGN' 
                        WHEN 'BidAnalysisEvaluateCancelled' THEN 'CANCEL BID ANALYSIS EVALUATION' 
                        WHEN 'BidAnalysisValidateCancelled' THEN 'CANCEL BID ANALYSIS VALIDATION' 
                        WHEN 'BidAnalysisExcluded' THEN 'EXCLUDED FROM BID ANALYSIS' 
                        WHEN 'ShipmentRequestApproved' THEN 'SHIPMENT REQUEST APPROVED' 
                        WHEN 'BER' THEN 'MARKED AS BEYOND ECONOMICAL REPAIR' 
                        WHEN 'CaseCreated' THEN 'CASE CREATED' 
                        WHEN 'CaseDeleted' THEN 'CASE DELETED' 
                        WHEN 'ShipmentPrepared' THEN 'SHIPMENT PREPARED' 
                        WHEN 'ShipmentApproved' THEN 'SHIPMENT APPROVED' 
                        WHEN 'FinalQuoteUpdated' THEN 'FINAL QUOTE UPDATED' 
                        WHEN 'FinalQuoteRejected' THEN 'FINAL QUOTE REJECTED' 
                        WHEN 'FinalQuoteAwaiting' THEN 'FINAL QUOTE AWAITING' 
                        WHEN 'FinalQuoteAccepted' THEN 'FINAL QUOTE APPROVED' 
                        WHEN 'RepairLetterReferenceCreated' THEN 'REPAIR LETTER REFERENCE CREATED' 
                        WHEN 'RepairLetterReferenceDeleted' THEN 'REPAIR LETTER REFERENCE DELETED' 
                        WHEN 'RepairLetterReferenceCanceled' THEN 'REPAIR LETTER REFERENCE CANCELED' 
                        WHEN 'RepairOrderCreated' THEN 'REPAIR ORDER CREATED' 
                        WHEN 'RepairOrderValidated' THEN 'REPAIR ORDER VALIDATED' 
                        WHEN 'RepairOrderDeleted' THEN 'REPAIR ORDER DELETED' 
                        WHEN 'RepairOrderCancelled' THEN 'REPAIR ORDER CANCELED' 
                        WHEN 'RepairOrderClosed' THEN 'REPAIR ORDER CLOSED' 
                        WHEN 'FMSDocumentCreated' THEN 'FMS DOCUMENT CREATED' 
                        WHEN 'FMSDocumentRequested' THEN 'FMS DOCUMENT REQUESTED' 
                        WHEN 'FMSDocumentReleased' THEN 'FMS DOCUMENT RELEASED' 
                        WHEN 'ScrapRequestCreated' THEN 'SCRAP REQUEST CREATED' 
                        ELSE UPPER(RF.STATUS_) 
                    END AS DocumentStatus, 
		rf.DEFECT_DESC_ AS DefectDesc, 
		rf.UNIT_ID AS UnitId, 
		dfr.REMOVAL_DATE_ AS RemovalDate,
		wo.REF_NO_ AS WO_REF_NO,
		dfr.ACFT_ID_ AS TAIL_UNIT_ID,
		rf.L2_ID_ As AGL2_ID_
	 from 
		LOG_TRN_RPR_REPAIR_FILE rf 
		inner join MNT_TRN_DFR_DEFECT_REPORT dfr ON dfr.DEFECT_NO_ = rf.DEFECT_REPORT_NO_
		left join MNT_TRN_WOTS_WORK_ORDER wo ON dfr.DEFECT_NO_ = wo.DEFECT_REPORT_NO_
	where 
		rf.STATUS_ != 'Closed'


) AS REPAIR_DOCS_
		inner join ADM_MST_UNITS unt on unt.ID_ = REPAIR_DOCS_.UnitId
		inner join ADM_MST_ITEMS itm ON itm.ID_ = unt.ITEM_ID
		inner join ADM_MST_UNITS tu on tu.ID_ = REPAIR_DOCS_.TAIL_UNIT_ID
		inner join ADM_MST_TAILS t on t.UNIT_ID = tu.ID_
		inner join ADM_MST_RESTRICTIONS rb on rb.ID_ = t.BATLN_ID
		inner join ADM_MST_RESTRICTIONS rc on rc.ID_ = rb.PRNT_ID
		inner join ADM_MST_PLATFORMS p on p.ID_ = tu.ITEM_ID
		left join MNT_TRN_FAULT_UNITS fu ON fu.FAULT_NO_ = REPAIR_DOCS_.WO_REF_NO
		left join ADM_TRN_ATTACHMENTS_EXT_INFO att ON att.FUNCTION_ID = REPAIR_DOCS_.AttachmentResourceId and att.REFERENCE_ID = REPAIR_DOCS_.DocumentId

GROUP BY
	REPAIR_DOCS_.DocumentId, 
	REPAIR_DOCS_.DocumentType, 
	REPAIR_DOCS_.RepairDocument, 
	REPAIR_DOCS_.OpenedDate,
	REPAIR_DOCS_.DocumentStatus, 
	REPAIR_DOCS_.DefectDesc, 
	REPAIR_DOCS_.UnitId, 
	unt.SERIAL_NO_, 
	itm.ID_,
	itm.SERIALIZED_, 
	IIF(REPAIR_DOCS_.RemovalDate IS NOT NULL, REPAIR_DOCS_.RemovalDate, fu.FAULT_INFO_DATE_) ,  
	fu.ID_,
	fu.FAULT_NO_, 
	t.T_NUM_ ,
	p.ID_,
	rc.ID_,
	REPAIR_DOCS_.AGL2_ID_
go

