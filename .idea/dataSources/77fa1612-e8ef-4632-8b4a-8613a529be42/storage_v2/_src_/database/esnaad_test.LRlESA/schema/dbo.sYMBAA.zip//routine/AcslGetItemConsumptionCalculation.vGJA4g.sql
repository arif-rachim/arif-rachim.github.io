CREATE FUNCTION [dbo].[AcslGetItemConsumptionCalculation](
	@refId uniqueidentifier, 
	@consumptionOnly bit = 0
)
RETURNS @acslItems TABLE
                     (
                       ItemId                           bigint,
					   MaxConsumption					int,
					   MinConsumption					int,
					   AvgLeadTime						decimal(10, 3), 
					   LongLeadTime						decimal(10, 3),
					   ExpiryFactor						decimal(10, 2),
					   MinLevel							int,
					   SafetyLevel						int,
					   MaxLevel							int,
					   WarLevel							int
                     )
AS
 begin
    -- 2024-09-05 : Bug #90726 : None Min and Max Consumption should be displayed -
	-- 2024-08-01 : BUG #90291 :
	--				- expiry factor is set to 1 when (item expiry date - delivery date) > 270
	--				- expiry factor is set to 1 if null item expiry found on the latest delivery
	--				- use staging table for calculation
	-- 2024-07-31 : BUG #90139 : considering turn-in on consumption calculation

	if @consumptionOnly = 1 
	begin
		insert into @acslItems (ItemId) select ItemId from LOG_TRN_SLM_STAGING_CONSUM_HST where RefId = @refId group by ItemId		
		return;
	end

	-- populate result table
	insert into @acslItems
	select ti.ItemId, 
		tma.MaxConsumption  as MaxConsumption, 
		tmi.MinConsumption as MinConsumption, 
		isnull(tli.AvgLeadTime, 0) as AvgLeadTime,
		isnull(tli.LongLeadTime, 0) as LongLeadTime,
		isnull(ef.ExpiryFactor, 0) as ExpiryFactor,
		round((isnull(tmi.MinConsumption, 0) * isnull(tli.AvgLeadTime, 0)) * isnull(ef.ExpiryFactor, 1), 0) as MinLevel,
		round((isnull(tma.MaxConsumption, 0) * isnull(tli.LongLeadTime, 0)) * isnull(ef.ExpiryFactor, 1), 0) as SafetyLevel,	
		round((isnull(tma.MaxConsumption, 0) * isnull(tli.LongLeadTime, 0)) * isnull(ef.ExpiryFactor, 1), 0) * 2 as MaxLevel,
		round((isnull(tma.MaxConsumption, 0) * isnull(tli.LongLeadTime, 0)) * isnull(ef.ExpiryFactor, 1), 0) * 2 * 0.2 as WarLevel
	--from @t_item ti
	from (
			select ItemId from LOG_TRN_SLM_STAGING_CONSUM_HST where RefId = @refId group by ItemId
		) ti
	left join LOG_TRN_SLM_STAGING_CONSUM_MAX tma on tma.ItemId = ti.ItemId and tma.RefId=@refId 
	left join LOG_TRN_SLM_STAGING_CONSUM_MIN tmi on tmi.ItemId = ti.ItemId and tmi.RefId=@refId
	left join LOG_TRN_SLM_STAGING_LEAD_TIME tli on tli.ItemId = ti.ItemId and tli.RefId=@refId
	left join LOG_TRN_SLM_STAGING_EXPIRY_FACTOR ef on ef.ItemId = ti.ItemId and ef.RefId=@refId

	return;
end;
go

