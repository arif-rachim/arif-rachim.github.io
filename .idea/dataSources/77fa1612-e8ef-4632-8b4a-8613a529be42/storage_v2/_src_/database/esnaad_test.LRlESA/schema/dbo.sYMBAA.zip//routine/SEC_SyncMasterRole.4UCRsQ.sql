CREATE PROCEDURE [dbo].[SEC_SyncMasterRole]
	-- master role id
	@m_role_id uniqueidentifier
AS 
BEGIN
	-- repopulate all linked roles 

	declare @child_role_id uniqueidentifier;

	declare c_cursor cursor
		for select distinct ID_ from ADM_TRN_SEC_ROLE where MASTER_ID_=@m_role_id

	open c_cursor 

	fetch next from c_cursor into @child_role_id
	while @@FETCH_STATUS = 0
	begin
		exec dbo.[SEC_RepopulateLinkedRoles] @m_role_id, @child_role_id
		fetch next from c_cursor into @child_role_id
	end

	close c_cursor
	deallocate c_cursor
END
go

