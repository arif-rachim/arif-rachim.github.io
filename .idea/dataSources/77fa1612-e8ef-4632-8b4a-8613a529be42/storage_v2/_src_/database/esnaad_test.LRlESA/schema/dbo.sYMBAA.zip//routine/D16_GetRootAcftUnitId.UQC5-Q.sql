CREATE FUNCTION [dbo].[D16_GetRootAcftUnitId] (@assignedComponentId uniqueidentifier)
RETURNS bigint
AS
begin
    DECLARE @result bigint = null;

    with cte as (
        select leaf.PARENT_COMP_ID_
        from MNT_TRN_D16_ASSIGNED_COMPONENT leaf
        where leaf.ID_ = @assignedComponentId
        union all
        select parent.PARENT_COMP_ID_
        from MNT_TRN_D16_ASSIGNED_COMPONENT as parent
                    inner join cte as child
                            on parent.COMP_ID_ = child.PARENT_COMP_ID_ and parent.IS_ACTIVE_ = 1
    )
    select @result = t.UNIT_ID
    from cte as cte
    join MNT_MST_D16_COMPONENT c on c.ID_ = cte.PARENT_COMP_ID_
    join ADM_MST_TAILS t on t.UNIT_ID = c.UNIT_ID_

    RETURN @result
end
go

