create view dbo.VW_ALL_TAILS as
select tails.ID_ TAIL_ID_
      ,tails.T_NUM_ TAIL_NUMBER
      ,platforms.CODE_ PLATFORM_
      ,btln.CODE_ BATTALION_
      ,cmnd.CODE_ COMMAND_
	  ,pvr.VARIANT_ PLATFORM_VARIANT_
	  ,pvr.DESCRIPTION_ VARIANT_DESCRIPTION_
	  ,case when tvr.READY_ = 1 then 'Yes' when tvr.READY_ = 0 then 'No' else null end VARIANT_READY_
	  ,case when tvr.EQUIPPED_ = 1 then 'Yes' when tvr.EQUIPPED_ = 0 then 'No' else null end VARIANT_EQUIPPED_
	  ,pvr.PLTF_ALIAS_CODE_ PLATFORM_ALIAS_CODE_
	  ,usages.CYCLES_ TOTAL_CYCLES_
	  ,usages.LANDINGS_ TOTAL_LANDINGS_
	  ,(ISNULL(usages.TOT_FLIGHT_MINS_, 0))/60.0 TOTAL_FLIGHT_HOURS_
      ,cmnd.id_ COMMAND_ID_
      ,platforms.id_ PLATFORM_ID_
	  ,tails.UNIT_ID TAIL_UNIT_ID_
	  ,tails.BEGIN_DATE_ TAIL_BEGIN_DATE_
	  ,tails.END_DATE_ TAIL_END_DATE_
  from ADM_MST_TAILS tails
       join ADM_MST_UNITS units on tails.UNIT_ID = units.ID_
       join ADM_MST_PLATFORMS platforms on units.ITEM_ID = platforms.ID_
       join ADM_MST_RESTRICTIONS btln on tails.BATLN_ID = btln.ID_
       join ADM_MST_RESTRICTIONS cmnd on btln.PRNT_ID = cmnd.ID_
	   left outer join ADM_TRN_UNIT_USAGE usages on tails.UNIT_ID = usages.UNIT_ID_
	   left outer join ADM_MST_TAIL_VARIANT tvr on tvr.ID_ = tails.UNIT_ID
	   left outer join ADM_MST_PLATFORM_VARIANT pvr on pvr.ID_ = tvr.PLTF_VARIANT_ID

go

