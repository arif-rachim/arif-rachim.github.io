
CREATE PROCEDURE DM_US63126_5_D1__INSERT_MWO
	 @ID_  uniqueidentifier 
    ,@MWO_NO_  nvarchar(500) 
    ,@MWO_PUB_DATE_  datetime 
    ,@MAT_CHG_NO_  nvarchar(500) 
    ,@MWO_TITLE_  nvarchar(max) 
    ,@SW_VER_  nvarchar(500) 
    ,@MWO_PRI_ID  bigint 
    ,@MNT_LVL_ID  bigint 
    ,@MWO_STS_ID  bigint 
    ,@SUP_BY_MWO_ID  uniqueidentifier 
    ,@SUP_MWO_ID  uniqueidentifier 
    ,@IS_PCW_  bit 
    ,@IS_SUP_MWO_CANCELLED_  bit 
    ,@CREATED_BY_  nvarchar(255) 
    ,@PID_CREATED_BY_  nvarchar(255) 
    ,@FULL_NAME_CREATED_BY_  nvarchar(255) 
    ,@CREATED_ON_  datetime 
    ,@MOD_BY_  nvarchar(255) 
    ,@PID_MOD_BY_  nvarchar(255) 
    ,@FULL_NAME_MOD_BY_  nvarchar(255) 
    ,@MOD_ON_  datetime 
    ,@TERM_  nvarchar(255) 
    ,@CMD_ID  bigint AS
BEGIN

	INSERT INTO [dbo].[MNT_TRN_D5_1_MWO_MASTER]
           ([ID_]
           ,[VERSION_]
           ,[MWO_NO_]
           ,[MWO_PUB_DATE_]
           ,[MAT_CHG_NO_]
           ,[MWO_TITLE_]
           ,[SW_VER_]
           ,[MWO_PRI_ID]
           ,[MNT_LVL_ID]
           ,[MWO_STS_ID]
           ,[SUP_BY_MWO_ID]
           ,[SUP_MWO_ID]
           ,[IS_PCW_]
           ,[IS_SUP_MWO_CANCELLED_]
           ,[CREATED_BY_]
           ,[PID_CREATED_BY_]
           ,[FULL_NAME_CREATED_BY_]
           ,[CREATED_ON_]
           ,[MOD_BY_]
           ,[PID_MOD_BY_]
           ,[FULL_NAME_MOD_BY_]
           ,[MOD_ON_]
           ,[TERM_]
           ,[CMD_ID])
     VALUES
           (@ID_
           ,1
           ,@MWO_NO_
           ,@MWO_PUB_DATE_
           ,@MAT_CHG_NO_
           ,@MWO_TITLE_
           ,@SW_VER_
           ,@MWO_PRI_ID
           ,@MNT_LVL_ID
           ,@MWO_STS_ID
           ,@SUP_BY_MWO_ID
           ,@SUP_MWO_ID
           ,@IS_PCW_
           ,@IS_SUP_MWO_CANCELLED_
           ,@CREATED_BY_
           ,@PID_CREATED_BY_
           ,@FULL_NAME_CREATED_BY_
           ,@CREATED_ON_
           ,@MOD_BY_
           ,@PID_MOD_BY_
           ,@FULL_NAME_MOD_BY_
           ,@MOD_ON_
           ,@TERM_
           ,@CMD_ID)
END



go

