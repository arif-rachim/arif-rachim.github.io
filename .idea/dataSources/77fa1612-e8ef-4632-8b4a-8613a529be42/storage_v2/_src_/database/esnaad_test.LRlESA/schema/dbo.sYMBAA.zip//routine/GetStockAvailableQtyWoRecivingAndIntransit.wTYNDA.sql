CREATE FUNCTION [dbo].[GetStockAvailableQtyWoRecivingAndIntransit]
(
	@ItemId				int,
	@FulfillingBuId		int,
	@AGLevel2Id			int
)
RETURNS int
AS
BEGIN
	DECLARE @result int
    
	SELECT @result = ISNULL(SUM(S.QTY_),0)
				 FROM LOG_TRN_STOCK S
					  INNER JOIN ADM_MST_UNIT_LOCATION UL ON S.LOC_ID = UL.ID_ 
					  INNER JOIN ADM_MST_UNIT_LOCATION_GROUP ULG ON UL.LG_ID = ULG.ID_ 
					  INNER JOIN ADM_MST_BUSINESS_UNITS BU ON ULG.BU_ID = BU.ID_ AND BU.ID_ = @FulfillingBuId
					  INNER JOIN ADM_MST_UNITS U ON S.UNIT_ID = U.ID_ 
					  RIGHT OUTER JOIN ADM_MST_ITEMS I ON U.ITEM_ID = I.ID_ AND I.ID_ = @ItemId
				 WHERE I.ID_ IN (
							SELECT ITEM_ID 
							FROM ADM_TRN_ITEM_ASSOCS 
							WHERE ASSOC_ID IN (
											SELECT AG_ID 
											FROM ADM_XRF_ADM_MST_BUSINESS_GROUP_ADM_TRN_ASSOC_GROUPS 
												WHERE BUG_ID = BU.BUG_ID)) 
				 AND      (UL.LOC_TYPE_ <> N'Receiving' AND UL.LOC_TYPE_ <> N'InTransit')
				 AND ULG.L2_ID_ = @AGLevel2Id

	RETURN @result
END
go

