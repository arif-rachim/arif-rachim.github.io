
-- ==========================================================================================
-- Author:		GAL24913
-- Create date: 10-APR-2016
-- Description:	Generate next sequence number from reference. Example RFQ/IDNT2016000058/A
-- ==========================================================================================

CREATE PROCEDURE DM_003_PUTIL_008_GenerateNextSequenceFromReference
	 @sequenceCode VARCHAR(255)
	,@referenceNumber VARCHAR(255)
	,@nextSequence VARCHAR(1024) OUTPUT
AS
BEGIN

	DECLARE @postFix CHAR = '';
	
	IF (@sequenceCode = 'RFQ')
	BEGIN
		SELECT @postFix = CHAR(ASCII(COUNT(1))+17) --Ascii valu of A is 65, 0 is 48. 65 - 48 = 17 is used to determine the postfix value
		  FROM LOG_TRN_QM_REQUEST_FOR_QUOTATION RFQ
			   JOIN LOG_TRN_IDM_PURCHASING_INDENT IDNT ON RFQ.INDENT_ID_ = IDNT.ID_
		 WHERE IDNT.INDENT_NO_ = @referenceNumber
		SET @nextSequence = 'RFQ/'+@referenceNumber+'/'+@postFix;
	END

	IF (@sequenceCode = 'BA')
	BEGIN
		SELECT @postFix = CHAR(ASCII(COUNT(1))+17) --Ascii valu of A is 65, 0 is 48. 65 - 48 = 17 is used to determine the postfix value
		  FROM LOG_TRN_BAM_BID_ANALYSIS BA
		       JOIN LOG_TRN_QM_REQUEST_FOR_QUOTATION RFQ ON BA.RFQ_NO_ = RFQ.RFQ_NO_
			   JOIN LOG_TRN_IDM_PURCHASING_INDENT IDNT ON RFQ.INDENT_ID_ = IDNT.ID_
		 WHERE IDNT.INDENT_NO_ = @referenceNumber
		SET @nextSequence = 'BA/'+@referenceNumber+'/'+@postFix;
	END
	
END

/*

EXEC DM_003_PUTIL_008_GenerateNextSequenceFromReference @sequenceCode = 'RFQ' @referenceNumber = 'IDNT2016000058'
	
*/
go

