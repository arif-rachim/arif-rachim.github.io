CREATE FUNCTION [dbo].[ASSY_GetParentItemnsInLocation] (@unitId AS bigint)
  RETURNS @imv TABLE
  (
    _id    uniqueidentifier,
	_command nvarchar(100),
	_agL2 nvarchar(100),
	_businessUnit nvarchar(100),
	_locationAndGroup nvarchar(max)
  )
AS
  BEGIN
    
	;with  N (ID_, UNIT_ID, PRNT_UNIT_ID, LEVEL_) as
	(
		   select asu.ID_,
						 asu.UNIT_ID,
						 asu.PRNT_UNIT_ID,
						 1 LEVEL_
		   from   ADM_TRN_AUM_ASSY_UNIT asu
						 join ADM_MST_UNITS units on asu.UNIT_ID = units.ID_
		   where  units.ID_ = @unitId
						 and asu.INST_DATE_ is not null
		   union all
		   select NPLUS1.ID_,
						 NPLUS1.UNIT_ID,
						 NPLUS1.PRNT_UNIT_ID,
						 N.LEVEL_ + 1 LEVEL_
		   from   ADM_TRN_AUM_ASSY_UNIT NPLUS1
						 join N on N.PRNT_UNIT_ID = NPLUS1.UNIT_ID
						 join ADM_MST_UNITS units on NPLUS1.UNIT_ID = units.ID_
		   where  N.PRNT_UNIT_ID = NPLUS1.UNIT_ID
	)

    INSERT @imv
		select
			imv.ID_,
			PCMD.CODE_,
			PAGL.CODE_,
			PBU.CODE_,
			(PLOC.NAME_ + ' (' + PLGR.NAME_+')')
		from	N
				inner join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on n.PRNT_UNIT_ID = imv.UNIT_ID_
				inner join ADM_MST_BUSINESS_UNITS AS PBU ON PBU.ID_ = imv.BU_ID_
				inner join ADM_MST_RESTRICTIONS AS PCMD ON PCMD.ID_ = imv.CMD_ID_
				inner join ADM_TRN_ASSOC_GROUPS AS PAGL ON PAGL.ID_ = imv.OWNED_L2_ID_
				inner join ADM_MST_UNIT_LOCATION AS PLOC ON PLOC.ID_ = imv.LOC_ID_
				inner join ADM_MST_UNIT_LOCATION_GROUP AS PLGR ON PLOC.LG_ID = PLGR.ID_;
    RETURN;
  END;
go

