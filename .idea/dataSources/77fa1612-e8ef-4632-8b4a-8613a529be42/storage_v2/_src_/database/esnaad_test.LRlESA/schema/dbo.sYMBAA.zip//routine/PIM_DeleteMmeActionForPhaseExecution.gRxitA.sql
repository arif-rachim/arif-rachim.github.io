CREATE Proc [dbo].[PIM_DeleteMmeActionForPhaseExecution](
 @mmeRosterId bigint,
 @mmeAction nvarchar(max),
 @mmeActionStatusId bigint
 )
AS
BEGIN
 
		select distinct PHASE_EXEC_DET_ID into #InspectionsphaseExec_delete 
		from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS execAction
		join MNT_TRN_PIM_PHASE_EXECUTION_DETAIL execDetail on execDetail.ID_ = execAction.PHASE_EXEC_DET_ID
		where MME_ROSTER_ID_ =@mmeRosterId and execDetail.STATUS_ in ('NotCompleted','PendingAction')
		group by PHASE_EXEC_DET_ID
 		having max(execAction.MOD_ON_) is null

		alter table #InspectionsphaseExec_delete 
		add mmeIndex int


	   Begin tran
		
			update CTE set CTE.mmeIndex=act.IDX_ from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS act join
			#InspectionsphaseExec_delete CTE  on CTE.PHASE_EXEC_DET_ID=act.PHASE_EXEC_DET_ID
			where act.ACTION_=@mmeAction and act.MME_ROSTER_ID_=@mmeRosterId;

			Delete tmp from ( select  act.*, (ROW_NUMBER() over ( partition by act.PHASE_EXEC_DET_ID,act.STATUS_ID,act.ACTION_ order by act.IDX_)) rownum
			from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS act 
			where  act.PHASE_EXEC_DET_ID in (select PHASE_EXEC_DET_ID from  #InspectionsphaseExec_delete CTE)
			AND act.ACTION_=@mmeAction and act.STATUS_ID=@mmeActionStatusId and act.MME_ROSTER_ID_=@mmeRosterId
			) tmp where tmp.rownum=1

			update act set act.IDX_= iif(act.IDX_>CTE.mmeIndex,act.IDX_-1,act.IDX_)
			from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS act join
			#InspectionsphaseExec_delete CTE  on CTE.PHASE_EXEC_DET_ID=act.PHASE_EXEC_DET_ID

			update execDetail
			set INSP_ACTIONS_COUNT_=(select count(*) from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS where PHASE_EXEC_DET_ID=execDetail.ID_) 
			from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL execDetail inner join
			#InspectionsphaseExec_delete CTE on CTE.PHASE_EXEC_DET_ID=execDetail.ID_

	  commit

	  drop table if exists #InspectionsphaseExec_delete
		
END
go

