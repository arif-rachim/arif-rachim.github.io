CREATE FUNCTION [dbo].[D16_GetComponentUsage]
(
    @compId AS uniqueIdentifier
)
    RETURNS @usage table
                   (
                       ComponentId uniqueidentifier,
                       Hours       real,
                       Landings    int,
                       Cycles      int
                   )
AS
BEGIN
    DECLARE
        @comp_id uniqueidentifier,
        @comp_h_usage numeric(10, 2),
        @comp_l_usage numeric(10, 2),
        @comp_c_usage numeric(10, 2),
        @total_flight_mins numeric(10, 2),
        @stop_flag_h bit,
        @stop_flag_l bit,
        @stop_flag_c bit;

    SELECT @comp_h_usage = 0, @comp_l_usage = 0, @comp_c_usage = 0, @comp_id = @compId, @total_flight_mins = NULL;
    SELECT @stop_flag_h = 0, @stop_flag_l = 0, @stop_flag_c = 0;

    WHILE @total_flight_mins IS NULL
        BEGIN
            SELECT
            TOP (1)
            @comp_id = ac.parent_comp_id_
            ,
            @total_flight_mins = CASE WHEN ac.REM_DATE_ IS NULL THEN uu.TOT_FLIGHT_MINS_ ELSE isnull(ac.REM_C_HRS_ * 60, 0) END
            ,
            @comp_h_usage = CASE
                                WHEN (ac.REM_DATE_ IS NULL AND @stop_flag_h = 0) THEN
                                            @comp_h_usage + coalesce(round((uu.tot_flight_mins_ / 60.0), 2), 0) -
                                            ac.inst_p_hrs_ + ac.inst_c_hrs_ + coalesce(ac.PEN_HRS_, 0)
                                WHEN (ac.REM_DATE_ IS NULL AND @stop_flag_h = 1) THEN
                                    @comp_h_usage  + coalesce(round((uu.tot_flight_mins_ / 60.0), 2), 0)
                                ELSE @comp_h_usage + ac.REM_C_HRS_ END
            ,
            @comp_l_usage = CASE
                                WHEN (ac.REM_DATE_ IS NULL AND @stop_flag_l = 0) THEN
                                        @comp_l_usage + coalesce(uu.landings_, 0) - ac.inst_p_ldgs_ +
                                        ac.inst_c_ldgs_ +
                                        coalesce(ac.PEN_LDGS_, 0)
                                WHEN (ac.REM_DATE_ IS NULL AND @stop_flag_l = 1) THEN
                                    @comp_l_usage + coalesce(uu.landings_, 0)
                                ELSE @comp_l_usage + ac.REM_C_LDGS_ END
            ,
            @comp_c_usage = CASE
                                WHEN (ac.REM_DATE_ IS NULL AND @stop_flag_c = 0 AND mc.LEVEL_ = 0) THEN
                                        @comp_c_usage + coalesce(e.OPERATING_HRS_, 0)
                                WHEN (ac.REM_DATE_ IS NULL AND @stop_flag_c = 0 AND mc.LEVEL_ > 0) THEN
                                        @comp_c_usage + coalesce(e.OPERATING_HRS_, 0) - ac.inst_p_cycs_ + ac.inst_c_cycs_
                                WHEN (ac.REM_DATE_ IS NULL AND @stop_flag_c = 1) THEN
                                    @comp_c_usage + coalesce(e.OPERATING_HRS_, 0)
                                ELSE @comp_c_usage + ac.REM_C_CYCS_ END
            ,
            @stop_flag_h = CASE WHEN (@stop_flag_h = 1 OR mc.TREF_HRS_ != 'Parent') THEN 1 ELSE 0 END
            ,
            @stop_flag_l = CASE WHEN (@stop_flag_l = 1 OR mc.TREF_LDGS_ != 'Parent') THEN 1 ELSE 0 END
            ,
            @stop_flag_c = CASE WHEN (@stop_flag_c = 1 OR mc.TREF_CYCL_ != 'Parent') THEN 1 ELSE 0 END
            FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
                     JOIN MNT_MST_D16_MASTER_COMPONENT mc ON mc.ID_ = ac.MASTER_COMP_ID_
                     JOIN MNT_MST_D16_COMPONENT c ON c.id_ = ac.parent_comp_id_
                     JOIN MNT_MST_D16_COMPONENT child_comp ON child_comp.ID_ = ac.COMP_ID_
                     LEFT JOIN ADM_TRN_UNIT_USAGE uu ON uu.unit_id_ = c.unit_id_
                     AND exists(SELECT ID_ FROM ADM_MST_TAILS WHERE UNIT_ID = uu.UNIT_ID_)
                     LEFT JOIN (
                        SELECT
                        TOP (1)
                            rg.ENG_UNIT_ID, rd.OPERATING_HRS_
                        FROM MNT_D193_ENGINE_READINGS rd
                                 JOIN MNT_D193_ENGINE_REGISTER rg ON rg.ID_ = rd.ENGINE_ID
                                 JOIN MNT_MST_D16_COMPONENT ec ON ec.UNIT_ID_ = rg.ENG_UNIT_ID
                        WHERE ec.ID_ = @comp_id
                        ORDER BY READING_DATE_ DESC) e ON e.ENG_UNIT_ID = child_comp.UNIT_ID_
            WHERE ac.comp_id_ = @comp_id
            ORDER BY ac.INST_DATE_ DESC, ac.IS_ACTIVE_ DESC

            IF @@rowcount <= 0 BREAK;
        END;

    INSERT @usage
    SELECT @compId, @comp_h_usage, @comp_l_usage, @comp_c_usage;
    RETURN;
END
go

