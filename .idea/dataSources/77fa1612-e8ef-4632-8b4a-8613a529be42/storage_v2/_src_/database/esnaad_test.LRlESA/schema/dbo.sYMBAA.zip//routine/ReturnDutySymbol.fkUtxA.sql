CREATE FUNCTION ReturnDutySymbol(@Id int) RETURNS varchar(100)
BEGIN
	DECLARE @retValue varchar(100)
	SELECT 	@retValue = CODE_ FROM OPS_MST_DUTY_SYMBOL WHERE ID_ = @Id
	RETURN @retValue
END
go

