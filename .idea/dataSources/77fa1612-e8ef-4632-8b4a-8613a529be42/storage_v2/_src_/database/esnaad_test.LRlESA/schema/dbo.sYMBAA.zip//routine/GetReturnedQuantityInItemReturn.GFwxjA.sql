CREATE FUNCTION [dbo].[GetReturnedQuantityInItemReturn]
(
	-- Add the parameters for the function here
	@unitId		int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @quantity int
   
    -- Add the T-SQL statements to compute the return value here
	SELECT @quantity =  ISNULL((SELECT SUM(LOG_TRN_ITEM_RETURN.RET_QTY_) AS Expr1 
						FROM LOG_TRN_ITEM_RETURN  
						INNER JOIN WF_TRN_INSTANCE ON LOG_TRN_ITEM_RETURN.WF_ID = WF_TRN_INSTANCE.ID_ 
						WHERE (LOG_TRN_ITEM_RETURN.UNIT_ID_ = @unitId) 						
						AND (WF_TRN_INSTANCE.WF_STATE_ <> 'Rejected')),0)
	
	-- Return the result of the function
	RETURN @quantity
END
go

