
CREATE PROCEDURE DM_US63126_5_D1__INSERT_COMPONENT
              @ID_  uniqueidentifier 
            ,@CMD_ID  bigint 
            ,@UNIT_ID  bigint 
            ,@CREATED_BY_  nvarchar(255) 
            ,@PID_CREATED_BY_  nvarchar(255) 
            ,@FULL_NAME_CREATED_BY_  nvarchar(255) 
            ,@CREATED_ON_  datetime 
            ,@MOD_BY_  nvarchar(255) 
            ,@PID_MOD_BY_  nvarchar(255) 
            ,@FULL_NAME_MOD_BY_  nvarchar(255) 
            ,@MOD_ON_  datetime 
            ,@TERM_  nvarchar(255)
AS
BEGIN

	INSERT INTO [dbo].[MNT_TRN_D5_1_COMPONENT]
           ([ID_]
           ,[VERSION_]
           ,[CMD_ID]
           ,[UNIT_ID]
           ,[CREATED_BY_]
           ,[PID_CREATED_BY_]
           ,[FULL_NAME_CREATED_BY_]
           ,[CREATED_ON_]
           ,[MOD_BY_]
           ,[PID_MOD_BY_]
           ,[FULL_NAME_MOD_BY_]
           ,[MOD_ON_]
           ,[TERM_])
     VALUES
           (@ID_ 
           ,1
           ,@CMD_ID 
           ,@UNIT_ID 
           ,@CREATED_BY_ 
           ,@PID_CREATED_BY_ 
           ,@FULL_NAME_CREATED_BY_ 
           ,@CREATED_ON_ 
           ,@MOD_BY_ 
           ,@PID_MOD_BY_ 
           ,@FULL_NAME_MOD_BY_ 
           ,@MOD_ON_ 
           ,@TERM_ )
END
go

