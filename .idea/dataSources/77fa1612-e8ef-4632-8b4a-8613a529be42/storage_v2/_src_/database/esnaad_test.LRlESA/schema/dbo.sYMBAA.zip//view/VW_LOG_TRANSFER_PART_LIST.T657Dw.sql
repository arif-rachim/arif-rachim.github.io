CREATE VIEW [dbo].[VW_LOG_TRANSFER_PART_LIST]
AS
SELECT     I.ID_ AS PartId, I.PART_NO_ AS PartNo, I.NOMENCLATURE_ AS Nomenclature, I.CAGE_CODE_ AS CageCode, I.NSN_ AS Nsn, I.SERIALIZED_ AS Serialized, 
                      SR.S_DESC_ AS Ui, dbo.GetStockAvailableQty(I.ID_, BU.ID_, 0) AS AvailableQty, IIR.REQ_QTY_ AS TransferRequestedQty, IIR.ISSUED_QTY_ AS ProcessedQty, 
                      IIR.REQ_QTY_ - IIR.ISSUED_QTY_ AS RemainingQty, IIR.IN_LIEU_ AS InLieuAccepted, SM.ID_ AS RequestId
FROM         dbo.LOG_TRN_STOCK_MOVEMENT AS SM INNER JOIN
                      dbo.ADM_MST_BUSINESS_UNITS AS BU ON BU.ID_ = SM.FF_BU_ID INNER JOIN
                      dbo.LOG_TRN_ITEM_IN_REQUEST AS IIR ON SM.ID_ = IIR.SM_ID INNER JOIN
                      dbo.ADM_MST_ITEMS AS I ON IIR.ITEM_ID = I.ID_ INNER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS SR ON SR.ID_ = I.UI_ID
go

