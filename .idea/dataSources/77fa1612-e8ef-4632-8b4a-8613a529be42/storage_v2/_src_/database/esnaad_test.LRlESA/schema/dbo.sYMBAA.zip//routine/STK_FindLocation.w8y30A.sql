CREATE FUNCTION [dbo].[STK_FindLocation](
	@handle uniqueidentifier,
	@stId uniqueidentifier, 
	@sstId uniqueidentifier = null, 
	@includeClassA bit = 1,
	@includeClassB bit = 1,
	@includeClassC bit = 1,
	@includedInOtherSst bit =  0,
	@lgId bigint = 0)

RETURNS @locations TABLE (
	Handle uniqueidentifier,
	LgId bigint, 
	LgName nvarchar(255), 
	LocId bigint, 
	LocName nvarchar(255), 
	LocDesc nvarchar(max)
) AS
BEGIN
	DECLARE	@itemClasses STK_TYPE_ItemClass
	DECLARE @itemClasses2 STK_TYPE_ItemClass

	IF @includeClassA = 1 INSERT @itemClasses values (560)
	IF @includeClassB = 1 INSERT @itemClasses values (561)
	IF @includeClassC = 1 INSERT @itemClasses values (562)

	INSERT @itemClasses2 
	SELECT SC.CLS_ID_ 
	FROM LOG_TRN_STM_STOCKTAKING2_CLASS SC
	JOIN @itemClasses IC ON SC.CLS_ID_ = IC.ClassId
	WHERE SC.ST_ID = @stId

	INSERT @locations
	SELECT DISTINCT
	@handle HANDLE_,LG.ID_ LG_ID_,LG.NAME_ LG_NAME_, L.ID_ LOC_ID, L.NAME_ LOC_NAME_,L.DESC_ LOC_DESC_
	FROM LOG_TRN_STM_STOCKTAKING2 ST
	JOIN ADM_MST_UNIT_LOCATION_GROUP LG ON LG.BU_ID = ST.STORE_ID  
	JOIN LOG_TRN_STM_STOCKTAKING2_LG STLG ON STLG.LG_ID_ = LG.ID_ AND STLG.ST_ID = ST.ID_
	JOIN ADM_MST_UNIT_LOCATION L ON L.LG_ID = LG.ID_
	JOIN ADM_MST_BUSINESS_UNITS_L2 BL2 ON BL2.BU_ID_ = ST.STORE_ID
	WHERE ST.ID_ = @stId
	AND L.LOC_TYPE_ = 'Regular' AND L.IS_ACTIVE_ = 1
	AND (LG.ID_ = @lgId OR @lgId = 0)
	AND ((LG.L2_ID_ IS NOT NULL AND LG.L2_ID_=BL2.L2_ID_) OR (LG.L2_ID_ IS NULL))
	AND ((ST.L2_ID IS NOT NULL AND ST.L2_ID = BL2.L2_ID_) OR (ST.L2_ID IS NULL))
	AND NOT EXISTS (
		SELECT 1 FROM LOG_TMP_STM_STOCKTAKING2_LOC_SELECTION TLS2
		WHERE TLS2.HANDLE_ = @handle AND TLS2.LOC_ID = L.ID_
	)
	AND (
			(
				@includedInOtherSst = 0 
				AND NOT EXISTS (
					SELECT LL.LOC_ID FROM LOG_TRN_STM_STOCKTAKING2_LOCKED_LOC LL
					JOIN @itemClasses2 IC ON LL.CLS_ID = IC.ClassId
					WHERE LL.LOC_ID = L.ID_
				)
				AND NOT EXISTS (
						SELECT SL.LOC_ID FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC SL
						JOIN LOG_TRN_STM_SUB_STOCKTAKING2 SST ON SST.ID_ = SL.SST_ID AND SST.ST_ID = ST.ID_  AND (@sstId IS NULL OR SST.ID_ <> @sstId)
						WHERE L.ID_ = SL.LOC_ID
				)
			)
			OR @includedInOtherSst = 1
	)
	AND (
		EXISTS (
			SELECT IL.ID_
			FROM ADM_TRN_IMV_ITEMS_IN_LOCATION IL 
			JOIN ADM_MST_UNITS U ON U.ID_ = IL.UNIT_ID_
			JOIN ADM_MST_ITEMS I ON I.ID_ = U.ITEM_ID
			JOIN @itemClasses2 IC ON I.CLS_ID_ = IC.ClassId
			WHERE IL.LOC_ID_ = L.ID_
			AND IL.TC_ID_ <> 16
		)
		OR NOT EXISTS (
			SELECT IL.ID_
			FROM ADM_TRN_IMV_ITEMS_IN_LOCATION IL 
			WHERE IL.LOC_ID_ = L.ID_
		)
	)
RETURN;
END
go

