CREATE VIEW [dbo].[VW_MNT_AFM_MONTHLY_RETURN] AS

select * from 
(
	select s.id_ as status_id, s.code_, s.order_, dbo.[ReturnTAAMSTime](d.DUR_MINS_) as MINS_, 'Hours' as Type_,
	datepart(day, d.BEGIN_ON_) day_,
	datepart(month, d.BEGIN_ON_) month_,
	left(datename(month, d.BEGIN_ON_),3) month_text_,
	year(d.BEGIN_ON_) year_,
	--r.ARCFT_ID_ as tail_id,
	t.id_ as tail_id
	FROM 
	adm_mst_simple_ref s LEFT OUTER JOIN 
	mnt_trn_mfm_afm_monthly_record_detail d ON s.id_ = d.FAULT_STS_ID_  INNER JOIN 
	mnt_trn_mfm_afm_monthly_record r ON r.ID_ = d.AFM_MONTHLY_ID inner join
	adm_mst_units u  ON u.ID_ = r.ARCFT_ID_ inner join
	adm_mst_tails t ON t.UNIT_ID = u.ID_ 
	WHERE s.grp_ = 'MNT.STS' 
) as src
PIVOT
(
	sum(MINS_)
	for day_ in ([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15], [16], [17], [18], [19], [20], [21], [22], [23], [24], [25], [26], [27], [28], [29], [30], [31])
) as pivots 
go

