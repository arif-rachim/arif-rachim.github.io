CREATE PROCEDURE [dbo].[BIZ_UpdateFitnessData]  
AS  
BEGIN  
	-- SET NOCOUNT ON added to prevent extra result sets from  
	-- interfering with SELECT statements.  
	SET NOCOUNT ON;  
  
    -- update  
	update BIZ_MEDICAL_FITNESS  
	set MED_PLUS_TRANSACTION_ID_ = up.MedPlusTransactionId,  
		DAILY_FITNESS_ = up.DailyFitness,  
		MED_CODE_ = up.MedCode,  
		LIMITATIONS_ = up.Limitation,
		MED_LAST_UPDATE_ = up.MedTimestamp,   
		LAST_UPDATE_ = up.BizTimeStatmp  
	from BIZ_MEDICAL_FITNESS f  
	inner join (  
		select ltrim(rtrim(MILITARY_ID)) as MilitaryId, TRANSACTION_ID as MedPlusTransactionId,  
			c.STATUS_ as DailyFitness,  
			c.CODE_ as MedCode,
			t.LIMITATIONS as Limitation,
			t.MED_TIMESTAMP as MedTimestamp,
			getdate() as BizTimeStatmp
		from BIZ_MEDPLUS_TRANSACTION  t
		inner join BIZ_MED_CHECK_CODE c on ltrim(rtrim(t.RESULT_CODE)) = c.CODE_
		where t.TRANSACTION_ID in (  
			select max(TRANSACTION_ID)   
			from BIZ_MEDPLUS_TRANSACTION   
			where (ltrim(rtrim(RESULT_CODE)) in (select CODE_ from BIZ_MED_CHECK_CODE))  
			group by ltrim(rtrim(MILITARY_ID))  
		)  
		and LTRIM(RTRIM(MILITARY_ID)) in (select MILITARY_ID from BIZ_MEDICAL_FITNESS) 
	) up on f.MILITARY_ID_ = up.MilitaryId  
	where MILITARY_ID_ in (select MILITARY_ID_ from BIZ_MEDICAL_FITNESS)

	-- insert  
	insert into BIZ_MEDICAL_FITNESS  
	select ltrim(rtrim(MILITARY_ID)), 
		TRANSACTION_ID,  
		c.STATUS_,  
		c.CODE_,  
		getdate(),
		t.LIMITATIONS,
		t.MED_TIMESTAMP
	from BIZ_MEDPLUS_TRANSACTION t
	inner join BIZ_MED_CHECK_CODE c on ltrim(rtrim(t.RESULT_CODE)) = c.CODE_
	where t.TRANSACTION_ID in (  
	  select max(TRANSACTION_ID)   
	  from BIZ_MEDPLUS_TRANSACTION   
	  where (ltrim(rtrim(RESULT_CODE)) in (select CODE_ from BIZ_MED_CHECK_CODE))  
	  group by ltrim(rtrim(MILITARY_ID))  
	)  
	 and LTRIM(RTRIM(MILITARY_ID)) not in (select MILITARY_ID_ from BIZ_MEDICAL_FITNESS)  
END
go

