CREATE view [dbo].[VW_MEDICAL_FITNESS] as
select f.MILITARY_ID_,
	case when cfg.Config = 'Automated' then f.DAILY_FITNESS_ else null end as DAILY_FITNESS_, 
	f.LAST_UPDATE_ as LAST_UPDATE_
from BIZ_MEDICAL_FITNESS f
left join (
	select usr.USER_ID_ as MilitaryId, bat.PRNT_ID as CommandId, cfg.ANNUAL_RENEWAL_TYPE_ as Config
	from OPS_MST_FLIGHT_CREWS fc
	inner join ADM_TRN_USER_PROFILES usr on usr.ID_ = fc.PERSON_ID
	inner join ADM_MST_RESTRICTIONS cmp on cmp.ID_ = fc.COMPANY_ID
	inner join ADM_MST_RESTRICTIONS bat on cmp.PRNT_ID = bat.ID_
	inner join OPS_TRN_MEDICAL_CURRENCY_CONFIG cfg on cfg.COMMAND_ID = bat.PRNT_ID
) cfg on cfg.MilitaryId = f.MILITARY_ID_
go

