CREATE PROC [dbo].[STK_OnSubStocktakingApproved2](
        @subStocktakingId uniqueidentifier,
        @userProfileId bigint,
        @remarks nvarchar(max),
        @terminal nvarchar(255)
) AS
BEGIN
        SET XACT_ABORT ON
        -- Skip if there are no records to process
        IF NOT EXISTS (
                SELECT LI.ID_ FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
                JOIN LOG_TRN_STM_SUB_STOCKTAKING2_LOC L ON L.ID_ = LI.SST_LOC_ID AND L.SST_ID = @subStocktakingId
                WHERE ISNULL(LI.STOCK_ADJ_STATUS_,0) <> 1       
        )
        BEGIN
                RETURN
        END
        -- Check if all locations is locked
        IF(EXISTS
                (
                        SELECT L.ID_ FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC L
                        LEFT JOIN ADM_MST_UNIT_LOCATION LOC ON LOC.ID_ = L.LOC_ID AND LOC.IS_ACTIVE_ = 1 AND LOC.IS_LOCKED_ = 1
                        WHERE L.SST_ID=@subStocktakingId AND LOC.ID_ IS NULL
                )
        )
        BEGIN
                RAISERROR('Not all locations specified in Stocktaking are locked',16,1)
                RETURN -1
        END
        
		DECLARE @buId bigint
		SELECT @buId = ST.STORE_ID
        FROM LOG_TRN_STM_STOCKTAKING2 ST
		INNER JOIN LOG_TRN_STM_SUB_STOCKTAKING2 SST ON SST.ST_ID = ST.ID_
        WHERE SST.ID_ = @subStocktakingId

        DECLARE @userId nvarchar(255), @userPid nvarchar(255), @userFullName nvarchar(765)
        
        SELECT @userId = USER_ID_, @userPid = PID_, @userFullName = F_NAME_ + ' ' + ISNULL(L_NAME_, '')
        FROM ADM_TRN_USER_PROFILES 
        WHERE ID_ = @userProfileId

        DECLARE @handle uniqueidentifier
        SELECT @handle = dbo.GenerateTimebasedGuid()

        INSERT INTO LOG_TMP_SUB_STOCKTAKING2_DISCR
        SELECT @handle, L.SST_ID,  LI.SST_LOC_ID, LI.ID_ SST_LOC_ITEM_ID, LI.ACT_COC_, LI.ACT_EXP_, LI.ACT_LOG_
        , LI.UNIT_ID
        , CASE WHEN (LI.SYS_COC_ <> LI.ACT_COC_ 
			OR ISNULL(LI.SYS_EXP_,'9999-12-31') <> ISNULL(LI.ACT_EXP_ ,'9999-12-31')
			OR LI.SYS_LOG_ <> LI.ACT_LOG_
			OR (LI.UNIT_ID IS NOT NULL AND LI.NEW_SERIAL_NO_ IS NOT NULL) 
			OR LI.NEW_ITEM_ID_ IS NOT NULL) THEN 1 ELSE 0 
		END IS_DISCR_UNIT_
        , CASE WHEN LI.SYS_QTY_ <> LI.ACT_QTY_ AND LI.ACT_QTY_ <> 0 AND LI.UNIT_ID IS NOT NULL THEN 1 ELSE 0 END IS_DISCR_QTY_
        , LI.ACT_QTY_, LI.NEW_SERIAL_NO_, LI.ITEM_ID, L.LOC_ID, SST.SST_NO_
        , CASE WHEN LI.SYS_QTY_ <> 0 AND LI.ACT_QTY_ <= 0 THEN 1 ELSE 0 END IS_TO_DELETE_
        , ST.STOCKTAKING_NO_
        , CASE WHEN LI.SYS_QTY_=0 AND LI.UNIT_ID IS NULL THEN 1 ELSE 0 END IS_NEW_STOCK_
        , LI.TC_ID, LI.MNF_DATE_
        , LI.L2_ID, ST.STORE_ID, LI.REMARKS_, ST.REMARKS_, LOC.LG_ID
        , BU.CMD_ID_, BU.CODE_, CMD.CODE_, L2.CODE_
        , LOC.NAME_, LOC.LOC_TYPE_
        , I.PART_NO_, I.NOMENCLATURE_, MNF.CAGE_CODE_, I.SERIALIZED_
        , ST.ID_
        , LI.SYS_QTY_
        , UOM.CODE_
        , LI.OVERRIDE_UNIT_INFO_
        , NULL, NULL
		, CASE WHEN LI.NEW_ITEM_ID_ IS NOT NULL THEN 1 ELSE 0 END IS_DISCR_PART_
		, CASE WHEN LI.UNIT_ID IS NOT NULL AND LI.NEW_SERIAL_NO_ IS NOT NULL THEN 1 ELSE 0 END IS_DISCR_BATCH_SERIAL_NO_
		, LI.NEW_ITEM_ID_
        --INTO LOG_TMP_SUB_STOCKTAKING2_UNIT_DISC
        FROM 
        LOG_TRN_STM_SUB_STOCKTAKING2_LOC L 
        JOIN LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI ON L.ID_ = LI.SST_LOC_ID 
        JOIN LOG_TRN_STM_SUB_STOCKTAKING2 SST ON L.SST_ID = SST.ID_
        JOIN LOG_TRN_STM_STOCKTAKING2 ST ON ST.ID_ = SST.ST_ID
        JOIN ADM_MST_UNIT_LOCATION LOC ON LOC.ID_ = L.LOC_ID
        JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = ST.STORE_ID
        JOIN ADM_MST_RESTRICTIONS CMD ON CMD.ID_ = BU.CMD_ID_
        JOIN ADM_TRN_ASSOC_GROUPS L2 ON LI.L2_ID = L2.ID_
        JOIN ADM_MST_ITEMS I ON I.ID_ = LI.ITEM_ID
        JOIN ADM_MST_MANUFACTURES MNF ON I.MNF_ID = MNF.ID_
        JOIN LOG_MST_UNIT_OF_MEASURE UOM ON UOM.ID_ = I.UOM_ID_
        WHERE L.SST_ID = @subStocktakingId
		AND LI.DISC_LEVEL_ <> 'Nil'
        AND ISNULL(LI.STOCK_ADJ_STATUS_,0) <> 1 

		-- Check if Item Unit used in Asset/PBO and its Qty is still >= adjusted qty
		--IF EXISTS (
		--	SELECT 1 FROM (
		--		SELECT UNIT_ID_,SUM(QTY_) PboQty
		--		FROM LOG_TRN_ASM_PBO pbo
		--		GROUP BY pbo.UNIT_ID_
		--	) PBO
		--	JOIN (
		--		SELECT UNIT_ID UNIT_ID_, SUM(st.ACT_QTY_) StQty
		--		FROM LOG_TMP_SUB_STOCKTAKING2_DISCR st
		--		WHERE HANDLE = @handle AND IS_DISCR_QTY_ = 1
		--		GROUP  BY st.UNIT_ID
		--	) ST ON pbo.UNIT_ID_ = ST.UNIT_ID_
		--	WHERE PBO.PboQty > StQty
		--)
		--BEGIN
		--	RAISERROR('Cannot change the Quantity less than specified in Asset/PBO',16,1)
  --          RETURN -1
		--END
        --

		-- Check if Item Unit used in Asset/PBO and its Qty is still >= adjusted qty
		IF EXISTS (
					  SELECT 1 FROM (
							SELECT CMD_ID_, UNIT_ID_,SUM(QTY_) PboQty
							FROM LOG_TRN_ASM_PBO pbo
							WHERE ACTIVE_=1 and EXISTS(
							 select top 1 st.UNIT_ID  from LOG_TMP_SUB_STOCKTAKING2_DISCR ST 
							 where  st.UNIT_ID=pbo.UNIT_ID_ 
							 AND  HANDLE = @handle AND IS_DISCR_QTY_ = 1 
							)
							GROUP BY CMD_ID_,pbo.UNIT_ID_
						) PBO
						JOIN (
							select imv.CMD_ID_,imv.UNIT_ID_,(sum(imv.QTY_)-max(ST.StQty)) InvQty 
							from ADM_TRN_IMV_ITEMS_IN_LOCATION imv 
							JOIN (
								SELECT UNIT_ID UNIT_ID_, SUM(st.SYS_QTY_-st.ACT_QTY_) StQty
								FROM LOG_TMP_SUB_STOCKTAKING2_DISCR st
								WHERE HANDLE = @handle AND IS_DISCR_QTY_ = 1
								GROUP  BY st.UNIT_ID
							) ST ON imv.UNIT_ID_ = ST.UNIT_ID_
							Group By imv.CMD_ID_,imv.UNIT_ID_
						) IMV ON pbo.CMD_ID_=IMV.CMD_ID_ AND  pbo.UNIT_ID_ = IMV.UNIT_ID_
						WHERE PBO.PboQty > InvQty
				)
		BEGIN
				RAISERROR('Cannot change the Quantity less than specified in Asset/PBO',16,1)
				RETURN -1
		END
		


		-- Add Serialized Stock Validation
		DECLARE @addSerializedCount INT
		SELECT @addSerializedCount = COUNT(1) FROM LOG_TMP_SUB_STOCKTAKING2_DISCR
		WHERE IS_NEW_STOCK_ = 1
		
		IF @addSerializedCount > 0 AND EXISTS (
			SELECT U.ID_
			FROM ADM_MST_UNITS U
			JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON D.ITEM_ID = U.ITEM_ID AND U.SERIAL_NO_ = D.NEW_SERIAL_NO_ 
			JOIN ADM_MST_ITEMS I ON I.ID_ = U.ITEM_ID
			JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.UNIT_ID_ = U.ID_
			WHERE D.HANDLE = @handle AND I.SERIALIZED_ = 1 AND D.IS_NEW_STOCK_ = 1
		)
		BEGIN
			RAISERROR('Cannot add new serialized stock as combination exists',16,1)
            RETURN -1
		END
		-- Add Serialized Stock Validation

		-- Change Serial / Batch Validation
		DECLARE @changeBatchSerialCount INT
		SELECT @changeBatchSerialCount = COUNT(1) FROM LOG_TMP_SUB_STOCKTAKING2_DISCR
		WHERE IS_DISCR_BATCH_SERIAL_NO_ = 1
		
		IF @changeBatchSerialCount > 0 AND EXISTS (
			SELECT U.ID_
			FROM ADM_MST_UNITS U
			JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON D.ITEM_ID = U.ITEM_ID AND U.SERIAL_NO_ = D.NEW_SERIAL_NO_ 
			WHERE D.HANDLE = @handle AND D.IS_DISCR_BATCH_SERIAL_NO_ = 1
		)
		BEGIN
			RAISERROR('Cannot change batch / serial number as combination exists',16,1)
            RETURN -1
		END
		-- Change Serial / Batch Validation

		-- Change Part Validation
		DECLARE @changePartCount INT
		SELECT @changePartCount = COUNT(1) FROM LOG_TMP_SUB_STOCKTAKING2_DISCR
		WHERE IS_DISCR_PART_ = 1
		IF @changePartCount > 0
		BEGIN
			DECLARE @inStoreInvalidCount int = 0, @d16InvalidCount int = 0, @unitInLockedCount int = 0;

			SELECT @unitInLockedCount = COUNT(1)
			FROM ADM_TRN_IMV_ITEMS_IN_LOCATION IL
			INNER JOIN ADM_MST_UNIT_LOCATION L ON L.ID_ = IL.LOC_ID_
			INNER JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON D.UNIT_ID = IL.UNIT_ID_ AND L.ID_ <> D.LOC_ID
			INNER JOIN ADM_MST_UNITS U ON U.ID_ = D.UNIT_ID
			INNER JOIN ADM_MST_ITEMS I ON I.ID_ = U.ITEM_ID
			WHERE I.SERIALIZED_ = 0 AND D.HANDLE = @handle AND (D.IS_DISCR_PART_ = 1 OR D.IS_DISCR_BATCH_SERIAL_NO_ = 1)
			AND L.IS_LOCKED_ = 1

			IF @unitInLockedCount > 0
			BEGIN
				RAISERROR('Cannot change part number / batch number as stock existing in locked locations',16,1)
            RETURN -1
			END

			SELECT @inStoreInvalidCount = COUNT(1)
			FROM LOG_TRN_SII_INSTORE_UNIT_INSPECTION INU
			INNER JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON D.UNIT_ID = INU.UNIT_ID
			INNER JOIN ADM_MST_UNITS U ON U.ID_ = D.UNIT_ID
			INNER JOIN ADM_MST_ITEMS I ON I.ID_ = U.ITEM_ID
			WHERE I.SERIALIZED_ = 1 AND D.HANDLE = @handle AND D.IS_DISCR_PART_ = 1

			SELECT @d16InvalidCount = COUNT(1) 
			FROM MNT_TRN_D16_ASSIGNED_COMPONENT C
			INNER JOIN MNT_MST_D16_COMPONENT MC ON MC.ID_ = C.COMP_ID_
			INNER JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON D.UNIT_ID = MC.UNIT_ID_
			WHERE D.HANDLE = @handle AND D.IS_DISCR_PART_ = 1 AND C.IS_ACTIVE_ = 1 and C.REM_DATE_ IS NULL

			IF @inStoreInvalidCount > 0 OR @d16InvalidCount > 0
			BEGIN
				RAISERROR('Cannot change part number as related transactions in IN-STORE / -16 exist',16,1)
            RETURN -1
			END
		END
		-- Change Part Validation


		-- Set adjustment status to Success for all items with no discrepancy
        UPDATE LI
        SET STOCK_ADJ_STATUS_ = 1
        FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
        JOIN LOG_TRN_STM_SUB_STOCKTAKING2_LOC L ON LI.SST_LOC_ID = L.ID_ AND L.SST_ID = @subStocktakingId AND ISNULL(LI.STOCK_ADJ_STATUS_,0) <> 1       
        WHERE NOT EXISTS (
                SELECT D.SST_LOC_ID FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D       
                WHERE D.SST_LOC_ITEM_ID = LI.ID_
                AND HANDLE = @handle
        )
        --

        -- Skip process if no discrepancy exists
        IF NOT EXISTS (
                SELECT D.SST_LOC_ID FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D       
                WHERE HANDLE = @handle
        ) 
        BEGIN
                -- Only unlock all locations if stock adjustment process for all items success  
                EXEC dbo.STK_UnlockLocationIfRequired @subStocktakingId
                --

                -- Clear temp data
                DELETE LOG_TMP_SUB_STOCKTAKING2_DISCR WHERE HANDLE = @handle
                --
                RETURN;
        END
        --

		--Update Stock and IMV Qty
        UPDATE IL
        SET IL.QTY_ = D.ACT_QTY_
        , VERSION_ = IL.VERSION_ + 1
        , MOD_BY_ = @userId, PID_MOD_BY_ = @userPid, FULL_NAME_MOD_BY_ = @userFullName, MOD_ON_ = GETDATE()
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID_ = D.UNIT_ID AND IL.LOC_ID_ = D.LOC_ID AND IL.TC_ID_ = D.TC_ID AND IL.OWNED_L2_ID_ = D.L2_ID
        WHERE HANDLE=@handle AND IS_DISCR_QTY_=1

        UPDATE IL
        SET QTY_ = D.ACT_QTY_
        , VERSION_ = IL.VERSION_ + 1
        , MOD_BY_ = @userId, PID_MOD_BY_ = @userPid, FULL_NAME_MOD_BY_ = @userFullName, MOD_ON_ = GETDATE()
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN LOG_TRN_STOCK IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID=D.UNIT_ID AND IL.LOC_ID = D.LOC_ID AND IL.TAG_COLOR_COND_ID_ = D.TC_ID AND IL.STORE_ID = D.STORE_ID AND IL.OWNED_BY_L2_ID_ = D.L2_ID
        WHERE HANDLE=@handle AND IS_DISCR_QTY_=1


        -- Delete Stock and IMV
        DELETE ADM_TRN_IMV_ITEMS_IN_LOCATION 
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        WHERE HANDLE=@handle AND IS_TO_DELETE_ = 1
        AND TYPE_='Logistic' AND UNIT_ID_ = D.UNIT_ID AND LOC_ID_ = D.LOC_ID AND TC_ID_ = D.TC_ID AND OWNED_L2_ID_ = D.L2_ID

        DELETE LOG_TRN_STOCK 
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        WHERE HANDLE=@handle AND IS_TO_DELETE_ = 1
        AND TYPE_='Logistic' AND LOG_TRN_STOCK.UNIT_ID=D.UNIT_ID AND LOG_TRN_STOCK.LOC_ID = D.LOC_ID AND TAG_COLOR_COND_ID_ = D.TC_ID AND LOG_TRN_STOCK.STORE_ID = D.STORE_ID AND OWNED_BY_L2_ID_ = D.L2_ID

        -- Record ItemHistory due to Stock Deletion (StockManagementEventHandler.StockDeleted)
        INSERT LOG_HST_STM_ITEM_HISTORY(ID_, VERSION_, ITEM_ID_, LOC_ID_, L2_ID_, ADJ_TYPE_, QTY_, BASE_UOM_CODE_, SERIAL_NO_, REMARKS_, DOC_REF_NO_
        , CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
        SELECT NEWID(), 1, I.ID_, D.LOC_ID, D.L2_ID, 'Delete', D.ACT_QTY_, UOM.CODE_, D.NEW_SERIAL_NO_, D.LI_REMARKS_, D.STOCKTAKING_NO_
        , @userId, @userPid, @userFullName, GETDATE(), @terminal
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN ADM_MST_UNITS U ON U.ID_ = D.UNIT_ID
        JOIN ADM_MST_ITEMS I ON I.ID_ = U.ITEM_ID
        JOIN LOG_MST_UNIT_OF_MEASURE UOM ON I.UOM_ID_ = UOM.ID_
        WHERE HANDLE=@handle AND IS_TO_DELETE_ = 1


        -- Record UnitHistory due to Stock Deletion (UnitHistoryEventHandler.StockDeleted)
        INSERT LOG_HST_STM_UNIT(ID_, VERSION_, UNIT_ID_, FIELD_, OLD_, NEW_, PROC_, RES1_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
        SELECT NEWID(), 1, D.UNIT_ID, NULL, NULL, NULL, 'STK', D.STOCKTAKING_NO_, @userId, @userPid, @userFullName, GETDATE(), @terminal
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        WHERE HANDLE= @handle AND IS_TO_DELETE_ = 1


        -- Create new unit and stock (StockInternalService.CreateStock)
        -- Check first if Item Unit has previously been created
        IF EXISTS (
                SELECT U.ID_
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                LEFT JOIN ADM_MST_UNITS U ON U.ITEM_ID = D.ITEM_ID AND U.SERIAL_NO_ = D.NEW_SERIAL_NO_
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND U.ID_ IS NULL
                )
        BEGIN
                INSERT ADM_MST_UNITS (VERSION_, SERIAL_NO_, MANF_DATE_, TYPE_, EXP_DATE_, CODE_TYPE_, DOC_REF_, ITEM_ID, UNIT_TYPE_, IS_COC_, IS_LOG_, IS_LOCKED_, DEACTIVATED_TS_, CREATED_BY_, CREATED_ON_, TERM_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_)
                SELECT DISTINCT 1, NEW_SERIAL_NO_, MNF_DATE_, 'NonAircraft', ACT_EXP_,  'Initialize', D.STOCKTAKING_NO_, D.ITEM_ID, 'Unit', ACT_COC_, ACT_LOG_, 0, 0, @userId, GETDATE(), @terminal, @userPid, @userFullName
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                LEFT JOIN ADM_MST_UNITS U ON U.ITEM_ID = D.ITEM_ID AND U.SERIAL_NO_ = D.NEW_SERIAL_NO_
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND U.ID_ IS NULL

        END

        --Override unit info should it marked to do so
        UPDATE U
        SET U.VERSION_ = U.VERSION_ + 1, U.MANF_DATE_ = D.MNF_DATE_, U.EXP_DATE_ = D.ACT_EXP_, U.IS_COC_ = D.ACT_COC_, U.IS_LOG_ = D.ACT_LOG_
        FROM ADM_MST_UNITS U
        JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON D.ITEM_ID = U.ITEM_ID AND U.SERIAL_NO_ = D.NEW_SERIAL_NO_ 
        WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND D.OVERRIDE_UNIT_INFO_ = 1

        -- Update new unit id
        UPDATE D
        SET UNIT_ID = U.ID_
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN ADM_MST_UNITS U ON U.ITEM_ID = D.ITEM_ID AND U.SERIAL_NO_ = D.NEW_SERIAL_NO_
        WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle

        -- End of new unit creation

        -- Check if IMV has been previously created
        IF NOT EXISTS (
                SELECT IL.ID_
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID_ = D.UNIT_ID AND IL.LOC_ID_ = D.LOC_ID AND IL.TC_ID_ = ISNULL(D.TC_ID, 1) AND IL.OWNED_L2_ID_ = D.L2_ID
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle
        )
        BEGIN
                INSERT ADM_TRN_IMV_ITEMS_IN_LOCATION(ID_, VERSION_, BU_ID_, UNIT_ID_, QTY_, LG_ID_, LOC_ID_, OWNED_L2_ID_, TC_ID_, CMD_ID_, TYPE_
                , CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_
                )
                SELECT dbo.GenerateTimebasedGuid(),1, D.STORE_ID, D.UNIT_ID, D.ACT_QTY_, D.LG_ID, D.LOC_ID, D.L2_ID, 1, D.CMD_ID, 'Logistic'
                ,@userId, @userPid, @userFullName, GETDATE(), @terminal
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle

                --Remove IMV with same serial number and 0 qty
                DELETE IL
                FROM ADM_TRN_IMV_ITEMS_IN_LOCATION IL
                JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON IL.UNIT_ID_ = D.UNIT_ID AND D.SERIALIZED_ = 1 
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND IL.QTY_ = 0
        END
        ELSE
        BEGIN
                -- Keep old imv qty in temp table
                UPDATE D
                SET D.OUT_OLD_IMV_QTY_ = IL.QTY_
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID_ = D.UNIT_ID AND IL.LOC_ID_ = D.LOC_ID AND IL.TC_ID_ = D.TC_ID AND IL.OWNED_L2_ID_ = D.L2_ID
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND D.SERIALIZED_ = 0

                -- Add up QTY only for non serialized
                UPDATE IL
                SET IL.QTY_ = IL.QTY_ + D.ACT_QTY_
                , VERSION_ = IL.VERSION_ + 1
                , MOD_BY_ = @userId, PID_MOD_BY_ = @userPid, FULL_NAME_MOD_BY_ = @userFullName, MOD_ON_ = GETDATE()
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID_ = D.UNIT_ID AND IL.LOC_ID_ = D.LOC_ID AND IL.TC_ID_ = D.TC_ID AND IL.OWNED_L2_ID_ = D.L2_ID
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND D.SERIALIZED_ = 0

                -- Override QTY for serialized
                UPDATE IL
                SET IL.QTY_ = D.ACT_QTY_
                , VERSION_ = IL.VERSION_ + 1
                , MOD_BY_ = @userId, PID_MOD_BY_ = @userPid, FULL_NAME_MOD_BY_ = @userFullName, MOD_ON_ = GETDATE()
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID_ = D.UNIT_ID AND IL.LOC_ID_ = D.LOC_ID AND IL.TC_ID_ = D.TC_ID AND IL.OWNED_L2_ID_ = D.L2_ID
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND D.SERIALIZED_ = 1
        END

        -- Check if Stock has been previously created
        IF NOT EXISTS (
                SELECT IL.ID_
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                JOIN LOG_TRN_STOCK IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID = D.UNIT_ID AND IL.LOC_ID = D.LOC_ID AND IL.TAG_COLOR_COND_ID_ = ISNULL(D.TC_ID, 1) AND IL.STORE_ID = D.STORE_ID AND IL.OWNED_BY_L2_ID_ = D.L2_ID
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle
        )
        BEGIN
                INSERT LOG_TRN_STOCK(ID_, VERSION_, STORE_ID, UNIT_ID, QTY_, LOC_ID, OWNED_BY_L2_ID_, UOM_ID_, TAG_COLOR_COND_ID_, TYPE_
                , CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_
                )
                SELECT dbo.GenerateTimebasedGuid(),1, D.STORE_ID, D.UNIT_ID, D.ACT_QTY_,D.LOC_ID, D.L2_ID, I.UOM_ID_,  1, 'Logistic'
                , @userId, @userPid, @userFullName, GETDATE(), @terminal
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                JOIN ADM_MST_ITEMS I ON D.ITEM_ID = I.ID_
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle

                --Remove stock with same serial number and 0 qty
                DELETE IL
                FROM LOG_TRN_STOCK IL
                JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON IL.UNIT_ID = D.UNIT_ID AND D.SERIALIZED_ = 1 
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND IL.QTY_ = 0
        END
        ELSE
        BEGIN
                -- Keep old stock qty in temp table
                UPDATE D
                SET D.OUT_OLD_STOCK_QTY_ = IL.QTY_
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                JOIN LOG_TRN_STOCK IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID=D.UNIT_ID AND IL.LOC_ID = D.LOC_ID AND IL.TAG_COLOR_COND_ID_ = D.TC_ID AND IL.STORE_ID = D.STORE_ID AND IL.OWNED_BY_L2_ID_ = D.L2_ID
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND D.SERIALIZED_ = 0

                -- Add up QTY only for non serialized
                UPDATE IL
                SET QTY_ = IL.QTY_ + D.ACT_QTY_
                , VERSION_ = IL.VERSION_ + 1
                , MOD_BY_ = @userId, PID_MOD_BY_ = @userPid, FULL_NAME_MOD_BY_ = @userFullName, MOD_ON_ = GETDATE()
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                JOIN LOG_TRN_STOCK IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID=D.UNIT_ID AND IL.LOC_ID = D.LOC_ID AND IL.TAG_COLOR_COND_ID_ = D.TC_ID AND IL.STORE_ID = D.STORE_ID AND IL.OWNED_BY_L2_ID_ = D.L2_ID
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND D.SERIALIZED_ = 0

                -- Override QTY for serialized
                UPDATE IL
                SET IL.QTY_ = D.ACT_QTY_
                , VERSION_ = IL.VERSION_ + 1
                , MOD_BY_ = @userId, PID_MOD_BY_ = @userPid, FULL_NAME_MOD_BY_ = @userFullName, MOD_ON_ = GETDATE()
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
                JOIN LOG_TRN_STOCK IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID = D.UNIT_ID AND IL.LOC_ID = D.LOC_ID AND IL.TAG_COLOR_COND_ID_ = D.TC_ID AND IL.OWNED_BY_L2_ID_ = D.L2_ID
                WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle AND D.SERIALIZED_ = 1
        END

        -- Record UnitMovementHistory (ItemMovementEventHandler.StockInitialized)
        INSERT ADM_HST_IMV_UNIT_MOVEMENT(ID_, VERSION_, UNIT_ID_, NEW_LOC_ID_, NEW_LOC_NAME_, NEW_LOC_TYPE_, NEW_BU_, NEW_CMD_, NEW_L2_CODE_, PROC_, REF_NO_, NEW_QTY_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
        SELECT 
        NEWID(),1, D.UNIT_ID, D.LOC_ID, D.LOC_NAME_, D.LOC_TYPE_, D.BU_CODE_, D.CMD_CODE_, D.L2_CODE_, 'STK', D.STOCKTAKING_NO_, D.ACT_QTY_, @userId, @userPid, @userFullName, GETDATE(), @terminal
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        WHERE IS_NEW_STOCK_ = 1 AND D.HANDLE = @handle

        -- Record ItemTransactionHistory (ItemTransactionHistoryEventHandler.StockInitialized)
        INSERT ADM_HST_ITEM_TX(ID_, VERSION_, ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, IS_SERIALIZED_, MOV_TYPE_, QTY_, BU_ID_, COND_ID_, DOC_REF_, L2_ID_
        , REMARKS_, PROC_, LOC_ID_, DOC_ID_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, PERF_USER_PROFILE_ID_, PERF_USER_ID_, PERF_PID_, PERF_FULL_NAME_, PERF_ON_)
        SELECT 
        NEWID(),1, D.ITEM_ID, D.PART_NO_, D.CAGE_CODE_, NOMENCLATURE_, U.SERIAL_NO_, SERIALIZED_, 'STKADJI', ACT_QTY_, D.STORE_ID, 1, D.SST_NO_, D.L2_ID
        , isnull(D.LI_REMARKS_,D.ST_REMARKS_), 'STK', D.LOC_ID, D.ST_ID, @userId, @userPid, @userFullName, GETDATE(), @terminal, @userProfileId, @userId, @userPid, @userFullName, GETDATE()
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN ADM_MST_UNITS U ON D.UNIT_ID = U.ID_
        WHERE D.HANDLE = @handle AND D.SYS_QTY_ < D.ACT_QTY_

        INSERT ADM_HST_ITEM_TX(ID_, VERSION_, ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, IS_SERIALIZED_, MOV_TYPE_, QTY_, BU_ID_, COND_ID_, DOC_REF_, L2_ID_
        , REMARKS_, PROC_, LOC_ID_, DOC_ID_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, PERF_USER_PROFILE_ID_, PERF_USER_ID_, PERF_PID_, PERF_FULL_NAME_, PERF_ON_)
        SELECT 
        NEWID(),1, D.ITEM_ID, D.PART_NO_, D.CAGE_CODE_, NOMENCLATURE_, U.SERIAL_NO_, SERIALIZED_, 'SSTKADJD', ACT_QTY_, D.STORE_ID, 1, D.SST_NO_, D.L2_ID
        , isnull(D.LI_REMARKS_,D.ST_REMARKS_), 'STK', D.LOC_ID, D.ST_ID, @userId, @userPid, @userFullName, GETDATE(), @terminal, @userProfileId, @userId, @userPid, @userFullName, GETDATE()
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN ADM_MST_UNITS U ON D.UNIT_ID = U.ID_
        WHERE D.HANDLE = @handle AND D.SYS_QTY_ > D.ACT_QTY_


        -- Record history that SSTK has been approved
        INSERT ADM_HST_ITEM_TX(ID_, VERSION_, ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, IS_SERIALIZED_, MOV_TYPE_, QTY_, BU_ID_, COND_ID_, DOC_REF_, L2_ID_
        , REMARKS_, PROC_, LOC_ID_, DOC_ID_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, PERF_USER_PROFILE_ID_, PERF_USER_ID_, PERF_PID_, PERF_FULL_NAME_, PERF_ON_)
        SELECT 
        NEWID(),1, D.ITEM_ID, D.PART_NO_, D.CAGE_CODE_, NOMENCLATURE_, U.SERIAL_NO_, SERIALIZED_, 'SSTKA', ACT_QTY_, D.STORE_ID, 1, D.SST_NO_, D.L2_ID
        , isnull(D.LI_REMARKS_,D.ST_REMARKS_), 'STK', D.LOC_ID, D.ST_ID, @userId, @userPid, @userFullName, GETDATE(), @terminal, @userProfileId, @userId, @userPid, @userFullName, GETDATE()
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN ADM_MST_UNITS U ON D.UNIT_ID = U.ID_
        WHERE D.HANDLE = @handle


        -- Record new Item Created
        INSERT ADM_HST_ITEM_TX(ID_, VERSION_, ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, IS_SERIALIZED_, MOV_TYPE_, QTY_, BU_ID_, COND_ID_, DOC_REF_, L2_ID_
        , REMARKS_, PROC_, LOC_ID_, DOC_ID_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, PERF_USER_PROFILE_ID_, PERF_USER_ID_, PERF_PID_, PERF_FULL_NAME_, PERF_ON_)
        SELECT 
        NEWID(),1, D.ITEM_ID, D.PART_NO_, D.CAGE_CODE_, NOMENCLATURE_, U.SERIAL_NO_, SERIALIZED_, 'ICSSTK', ACT_QTY_, D.STORE_ID, 1, D.SST_NO_, D.L2_ID
        , isnull(D.LI_REMARKS_,D.ST_REMARKS_), 'STK', D.LOC_ID, D.ST_ID, @userId, @userPid, @userFullName, GETDATE(), @terminal, @userProfileId, @userId, @userPid, @userFullName, GETDATE()
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN ADM_MST_UNITS U ON D.UNIT_ID = U.ID_
        WHERE D.HANDLE = @handle AND D.IS_NEW_STOCK_ = 1

        -- Record Item Deleted 
        INSERT ADM_HST_ITEM_TX(ID_, VERSION_, ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, IS_SERIALIZED_, MOV_TYPE_, QTY_, BU_ID_, COND_ID_, DOC_REF_, L2_ID_
        , REMARKS_, PROC_, LOC_ID_, DOC_ID_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, PERF_USER_PROFILE_ID_, PERF_USER_ID_, PERF_PID_, PERF_FULL_NAME_, PERF_ON_)
        SELECT 
        NEWID(),1, D.ITEM_ID, D.PART_NO_, D.CAGE_CODE_, NOMENCLATURE_, U.SERIAL_NO_, SERIALIZED_, 'IDSSTK', ACT_QTY_, D.STORE_ID, 1, D.SST_NO_, D.L2_ID
        , isnull(D.LI_REMARKS_,D.ST_REMARKS_), 'STK', D.LOC_ID, D.ST_ID, @userId, @userPid, @userFullName, GETDATE(), @terminal, @userProfileId, @userId, @userPid, @userFullName, GETDATE()
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN ADM_MST_UNITS U ON D.UNIT_ID = U.ID_
        WHERE D.HANDLE = @handle AND D.IS_TO_DELETE_ = 1

		-- Record Item Change Part No 
        INSERT ADM_HST_ITEM_TX(ID_, VERSION_, ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, IS_SERIALIZED_, MOV_TYPE_, QTY_, BU_ID_, COND_ID_, DOC_REF_, L2_ID_
        , REMARKS_, PROC_, LOC_ID_, DOC_ID_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, PERF_USER_PROFILE_ID_, PERF_USER_ID_, PERF_PID_, PERF_FULL_NAME_, PERF_ON_)
        SELECT 
        NEWID(),1, D.ITEM_ID, D.PART_NO_, D.CAGE_CODE_, D.NOMENCLATURE_, U.SERIAL_NO_, D.SERIALIZED_, 'SSTKCP', ACT_QTY_, D.STORE_ID, 1, D.SST_NO_, D.L2_ID
        , ISNULL(isnull(D.LI_REMARKS_,D.ST_REMARKS_), '') + ' (NEW PART NO: ' + NI.PART_NO_ + ', NEW MNF CODE: ' + NIM.CAGE_CODE_ + ')', 
		'STK', D.LOC_ID, D.ST_ID, @userId, @userPid, @userFullName, GETDATE(), @terminal, @userProfileId, @userId, @userPid, @userFullName, GETDATE()
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        JOIN ADM_MST_UNITS U ON D.UNIT_ID = U.ID_
		JOIN ADM_MST_ITEMS NI ON NI.ID_ = D.NEW_ITEM_ID
		JOIN ADM_MST_MANUFACTURES NIM ON NIM.ID_ = NI.MNF_ID
        WHERE D.HANDLE = @handle AND D.IS_DISCR_PART_ = 1

        -- Record ItemUnitManagementHistory (ItemUnitManagementEventHandler.StockInitialized)
        INSERT LOG_HST_IUM_ITEM_UNIT_MANAGEMENT
        (ID_, VERSION_, UNIT_ID_, ACTION_, FROM_, TO_, REMARKS_, REFERENCE_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
        SELECT dbo.GenerateTimebasedGuid(), 1, D.UNIT_ID, 'Stocktaking', '', '', D.ST_REMARKS_, D.STOCKTAKING_NO_,
        @userId, @userPid, @userFullName, GETDATE(), @terminal
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D
        WHERE D.HANDLE = @handle AND D.IS_NEW_STOCK_ = 1

        -- Record ItemHistory (StockManagementEventHandler.StockInitialized)
        INSERT LOG_HST_STM_ITEM_HISTORY(ID_, VERSION_, ITEM_ID_, LOC_ID_, L2_ID_, ADJ_TYPE_, QTY_, BASE_UOM_CODE_, SERIAL_NO_, REMARKS_, DOC_REF_NO_
        , CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
        SELECT NEWID(), 1, D.ITEM_ID, D.LOC_ID, D.L2_ID, 'Add', D.ACT_QTY_, D.UOM_CODE_, D.NEW_SERIAL_NO_, D.ST_REMARKS_, D.STOCKTAKING_NO_
        , @userId, @userPid, @userFullName, GETDATE(), @terminal
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D   
        WHERE D.HANDLE = @handle AND D.IS_NEW_STOCK_ = 1

        -- Record UnitHistory (UnitHistoryEventHandler.StockInitialized)
        -- Record Qty
        INSERT LOG_HST_STM_UNIT(ID_, VERSION_, UNIT_ID_, FIELD_, OLD_, NEW_, PROC_, RES1_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
        SELECT NEWID(), 1, D.UNIT_ID, 'Quantity', NULL, ACT_QTY_, 'STK', D.UOM_CODE_, @userId, @userPid, @userFullName, GETDATE(), @terminal
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D   
        WHERE D.HANDLE = @handle AND D.IS_NEW_STOCK_ = 1

        -- Record SerialNo
        INSERT LOG_HST_STM_UNIT(ID_, VERSION_, UNIT_ID_, FIELD_, OLD_, NEW_, PROC_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
        SELECT NEWID(), 1, D.UNIT_ID, 'SerialNo', NULL, NEW_SERIAL_NO_, 'STK', @userId, @userPid, @userFullName, GETDATE(), @terminal
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D   
        WHERE D.HANDLE = @handle AND D.IS_NEW_STOCK_ = 1

		-- If an unit(stock) part number is changed to existing unit and which dosn'nt have any stock, then change target unit as duplicate and write history (bug#97833)
		-- This will help to control existing serial error message which is not visible to user.
		 if Exists(
				 select U.id_ 
				 FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D   
						JOIN ADM_MST_UNITS U ON U.SERIAL_NO_ = D.NEW_SERIAL_NO_ and u.ITEM_ID=D.NEW_ITEM_ID
						WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1 AND D.IS_NEW_STOCK_ = 0 and U.ID_<>D.UNIT_ID
						and not Exists(select top 1 * from ADM_TRN_IMV_ITEMS_IN_LOCATION imv where imv.UNIT_ID_=U.id_)
						)
				Begin 
				  --begin tran
				       
						 select D.SST_NO_,D.LOC_ID,D.STORE_ID,D.TC_ID,D.ACT_QTY_, D.UNIT_ID as UnitID_ ,u.ID_ as newUnitId,D.HANDLE as Handle  into #Duplicate
						 FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D   
						JOIN ADM_MST_UNITS U ON U.SERIAL_NO_ = D.NEW_SERIAL_NO_ and u.ITEM_ID=D.NEW_ITEM_ID
						WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1 AND D.IS_NEW_STOCK_ = 0 and U.ID_<>D.UNIT_ID
						and not Exists(select top 1 * from ADM_TRN_IMV_ITEMS_IN_LOCATION imv where imv.UNIT_ID_=U.id_)
		
		                 insert into ADM_HST_ITEM_TX 
						select newid(),1,D.NEW_ITEM_ID,itm.PART_NO_,mnf.CAGE_CODE_,itm.NOMENCLATURE_,D.NEW_SERIAL_NO_,1,'STKADJI',d.ACT_QTY_
						,null,@userId,@userId,@userFullName,getdate(),null,null,null,null,null,null,D.SST_NO_,null,isnull(D.LI_REMARKS_, 'Stock moved Using ' + D.SST_NO_ +'- old Part No'+ D.PART_NO_ +' old Serial No ' +Uold.SERIAL_NO_)
						,@userProfileId,@userId,@userId,@userFullName,getdate(),null,null,null,null,null,null
						FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D   
						JOIN ADM_MST_UNITS U ON U.SERIAL_NO_ = D.NEW_SERIAL_NO_ and u.ITEM_ID=D.NEW_ITEM_ID
						JOIN ADM_MST_UNITS Uold ON Uold.ID_ = D.UNIT_ID 
						join ADM_MST_ITEMS itm on itm.ID_=U.ITEM_ID 
						join ADM_MST_MANUFACTURES mnf on mnf.ID_=itm.MNF_ID
						WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1 AND D.IS_NEW_STOCK_ = 0 and U.ID_<>D.UNIT_ID
						and not Exists(select top 1 * from ADM_TRN_IMV_ITEMS_IN_LOCATION imv where imv.UNIT_ID_=U.id_)

		  
						INSERT INTO LOG_TRN_STOCK( ID_	,VERSION_,STORE_ID,UNIT_ID,QTY_,LOC_ID,OWNED_BY_L2_ID_,TAG_COLOR_COND_ID_,TYPE_	,CREATED_BY_,PID_CREATED_BY_
															  ,FULL_NAME_CREATED_BY_,CREATED_ON_,UOM_ID_)
						select (SELECT CAST(CAST(NEWID() AS BINARY(10)) + CAST(GETDATE() AS BINARY(6)) AS UNIQUEIDENTIFIER)),
						   1, D.STORE_ID,U.ID_,D.ACT_QTY_,D.LOC_ID,
						   D.L2_ID,D.TC_ID,'Logistic',@userId,@userId,@userFullName,getdate(),(select top 1 ID_ from LOG_MST_UNIT_OF_MEASURE where CODE_=D.UOM_CODE_)
							FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D   
						JOIN ADM_MST_UNITS U ON U.SERIAL_NO_ = D.NEW_SERIAL_NO_ and u.ITEM_ID=D.NEW_ITEM_ID
						WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1 AND D.IS_NEW_STOCK_ = 0 and U.ID_<>D.UNIT_ID
						and not Exists(select top 1 * from ADM_TRN_IMV_ITEMS_IN_LOCATION imv where imv.UNIT_ID_=U.id_)

						INSERT INTO ADM_TRN_IMV_ITEMS_IN_LOCATION ( ID_	,VERSION_,BU_ID_,UNIT_ID_,QTY_,LG_ID_,LOC_ID_,OWNED_L2_ID_,TC_ID_,CMD_ID_,TYPE_	,CREATED_BY_,PID_CREATED_BY_
															  ,FULL_NAME_CREATED_BY_,CREATED_ON_)
						select (SELECT CAST(CAST(NEWID() AS BINARY(10)) + CAST(GETDATE() AS BINARY(6)) AS UNIQUEIDENTIFIER)),
						   1, D.STORE_ID,U.ID_,D.ACT_QTY_,D.LG_ID,D.LOC_ID,
						   D.L2_ID,D.TC_ID,D.CMD_ID,'Logistic',@userId,@userId,@userFullName,getdate()
							FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D   
						JOIN ADM_MST_UNITS U ON U.SERIAL_NO_ = D.NEW_SERIAL_NO_ and u.ITEM_ID=D.NEW_ITEM_ID
						WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1 AND D.IS_NEW_STOCK_ = 0 and U.ID_<>D.UNIT_ID
						and not Exists(select top 1 * from ADM_TRN_IMV_ITEMS_IN_LOCATION imv where imv.UNIT_ID_=U.id_)

		  

						insert into ADM_HST_ITEM_TX 
						select newid(),1,U.ITEM_ID,itm.PART_NO_,mnf.CAGE_CODE_,itm.NOMENCLATURE_,U.SERIAL_NO_,1,'STDEL',d.ACT_QTY_
						,null,@userId,@userId,@userFullName,getdate(),null,null,null,null,null,null,D.SST_NO_,null, 'Stock moved Using ' + D.SST_NO_ +'- new Part No'+ newItm.PART_NO_ +' new Serial No ' +newU.SERIAL_NO_
						,@userProfileId,@userId,@userId,@userFullName,getdate(),null,null,null,null,null,null
						FROM #Duplicate D   
						JOIN ADM_MST_UNITS U ON U.ID_ = D.UnitID_ 
						join ADM_MST_ITEMS itm on itm.ID_=U.ITEM_ID 
						join ADM_MST_MANUFACTURES mnf on mnf.ID_=itm.MNF_ID
						JOIN ADM_MST_UNITS newU ON newU.ID_ = D.newUnitId 
						JOIN ADM_MST_ITEMS newItm ON newItm.ID_ = newU.ITEM_ID

						delete imv from ADM_TRN_IMV_ITEMS_IN_LOCATION imv where  exists (
						 select top 1 * from  #Duplicate dup where imv.UNIT_ID_=dup.UnitID_ and imv.BU_ID_=dup.STORE_ID and imv.LOC_ID_=dup.LOC_ID and imv.TC_ID_=dup.TC_ID and imv.QTY_=dup.ACT_QTY_
						)

						delete imv from LOG_TRN_STOCK imv where  exists (
						 select top 1 * from  #Duplicate dup where imv.UNIT_ID=dup.UnitID_ and imv.STORE_ID=dup.STORE_ID and imv.LOC_ID=dup.LOC_ID and imv.TAG_COLOR_COND_ID_=dup.TC_ID and imv.QTY_=dup.ACT_QTY_
						)

						
						   UPDATE LI
                           SET STOCK_ADJ_STATUS_ = 1
                           FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
                           JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON LI.ID_ = D.SST_LOC_ITEM_ID AND ISNULL(LI.STOCK_ADJ_STATUS_,0) <> 1     
                           JOIN #Duplicate U ON U.UnitID_ = D.UNIT_ID  and d.HANDLE=U.Handle
						   WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1 AND D.IS_NEW_STOCK_ = 0 
  
						 DELETE D from LOG_TMP_SUB_STOCKTAKING2_DISCR D JOIN #Duplicate U ON U.UnitID_ = D.UNIT_ID  and d.HANDLE=U.Handle
						 WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1 AND D.IS_NEW_STOCK_ = 0 

						 select * from LOG_TMP_SUB_STOCKTAKING2_DISCR D  WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1 AND D.IS_NEW_STOCK_ = 0 

						drop table #Duplicate
				--	commit

		
				end


        -- Modify Unit Info
        UPDATE U
        SET VERSION_ = U.VERSION_+1, IS_COC_ = D.ACT_COC_, EXP_DATE_ = D.ACT_EXP_, IS_LOG_ = D.ACT_LOG_, 
		SERIAL_NO_ = (CASE WHEN D.IS_DISCR_BATCH_SERIAL_NO_ = 1 THEN D.NEW_SERIAL_NO_ ELSE U.SERIAL_NO_ END), 
		ITEM_ID = (CASE WHEN D.IS_DISCR_PART_ = 1 THEN D.NEW_ITEM_ID ELSE U.ITEM_ID END)
        , MOD_BY_ = @userId, PID_MOD_BY_ = @userPid, FULL_NAME_MOD_BY_ = @userFullName, MOD_ON_ = GETDATE()
        FROM LOG_TMP_SUB_STOCKTAKING2_DISCR D   
        JOIN ADM_MST_UNITS U ON U.ID_ = D.UNIT_ID
        WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1 AND D.IS_NEW_STOCK_ = 0

        -- Record Stock Adjustment status
        -- Update status for deleted Stock/ItemsInLocation
        UPDATE LI
        SET STOCK_ADJ_STATUS_ = 1
        FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
        JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON LI.ID_ = D.SST_LOC_ITEM_ID AND ISNULL(LI.STOCK_ADJ_STATUS_,0) <> 1                
        WHERE D.HANDLE = @handle AND D.IS_TO_DELETE_ = 1
        AND NOT EXISTS (
                SELECT ID_ FROM ADM_TRN_IMV_ITEMS_IN_LOCATION LI
                WHERE LI.UNIT_ID_ = D.UNIT_ID
                AND LI.TYPE_='Logistic' AND LI.UNIT_ID_ = D.UNIT_ID AND LI.LOC_ID_ = D.LOC_ID AND LI.OWNED_L2_ID_ = D.L2_ID 
				--Tag color checking added due to the fact of non serialized item might split with different tag color
				AND LI.TC_ID_ = D.TC_ID
        )

        -- Update status for Unit Discrepancy
        UPDATE LI
        SET STOCK_ADJ_STATUS_ = 1
        FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
        JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON LI.ID_ = D.SST_LOC_ITEM_ID AND ISNULL(LI.STOCK_ADJ_STATUS_,0) <> 1     
        WHERE D.HANDLE = @handle AND D.IS_DISCR_UNIT_ = 1

        -- Update status for item having discrepancy in qty
        UPDATE LI
        SET STOCK_ADJ_STATUS_ = 1
        FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
        JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON LI.ID_ = D.SST_LOC_ITEM_ID AND ISNULL(LI.STOCK_ADJ_STATUS_,0) <> 1     
        JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID_ = D.UNIT_ID AND IL.LOC_ID_ = D.LOC_ID AND IL.OWNED_L2_ID_ = D.L2_ID AND D.ACT_QTY_ = IL.QTY_ -- Must exclude TC in comparison since tag color might be changed by other function, so we ignore it for now
        WHERE D.HANDLE = @handle
        AND D.IS_DISCR_QTY_ = 1

        -- Update status for newly created Stock and Unit
        UPDATE LI
        SET STOCK_ADJ_STATUS_ = 1
        FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
        JOIN LOG_TMP_SUB_STOCKTAKING2_DISCR D ON LI.ID_ = D.SST_LOC_ITEM_ID AND ISNULL(LI.STOCK_ADJ_STATUS_,0) <> 1     
        JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID_ = D.UNIT_ID AND IL.LOC_ID_ = D.LOC_ID AND IL.TC_ID_ = ISNULL(D.TC_ID, 1) AND IL.OWNED_L2_ID_ = D.L2_ID AND D.ACT_QTY_ + ISNULL(D.OUT_OLD_IMV_QTY_,0) = IL.QTY_ 
        WHERE D.HANDLE = @handle
        AND D.IS_NEW_STOCK_ = 1

        -- Update status for non serialized with added up qty
        UPDATE LI
        SET STOCK_ADJ_STATUS_ = 1
        FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
        JOIN (
                SELECT HANDLE, SST_LOC_ID, UNIT_ID, LOC_ID, L2_ID, SUM(ACT_QTY_) ACT_QTY_
                FROM LOG_TMP_SUB_STOCKTAKING2_DISCR
                WHERE HANDLE = @handle and SERIALIZED_ = 0
                GROUP BY HANDLE, SST_LOC_ID, UNIT_ID, LOC_ID, L2_ID
        ) AS D
        ON LI.SST_LOC_ID = D.SST_LOC_ID AND LI.UNIT_ID = D.UNIT_ID AND ISNULL(LI.STOCK_ADJ_STATUS_,0) <> 1      
        JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.TYPE_='Logistic' AND IL.UNIT_ID_ = D.UNIT_ID AND IL.LOC_ID_ = D.LOC_ID AND IL.OWNED_L2_ID_ = D.L2_ID AND D.ACT_QTY_ = IL.QTY_ 
        WHERE D.HANDLE = @handle


        -- Only unlock all locations if stock adjustment process for all items success
        EXEC dbo.STK_UnlockLocationIfRequired @subStocktakingId 
        --

        -- Clear temp data
        DELETE LOG_TMP_SUB_STOCKTAKING2_DISCR WHERE HANDLE = @handle
        --
END
go

