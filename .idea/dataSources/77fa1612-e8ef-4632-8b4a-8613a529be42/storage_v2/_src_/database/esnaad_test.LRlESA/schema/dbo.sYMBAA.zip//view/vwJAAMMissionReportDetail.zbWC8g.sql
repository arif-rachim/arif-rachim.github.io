CREATE view vwJAAMMissionReportDetail
as
with t (FlightDate, Command, Battalion, Platform, SupportTo
		--,MissionHours
		,MissionMinutes
		, MissionId
		, Pid)
as (
	select DATEADD("Minute", bd.GMT_DIFF_, rec.RTD_) AS FlightDate, cmd.CODE_ as Command, bat.CODE_ as Battalion, pltf.CODE_ as Platform, ext.NAME_ as SupportTo
		--, rec.FLIGHT_MINS_ as MissionHours
		, rec.FLIGHT_MINS_ as MissionMinutes
		, mis.ID_ as MissionId
		, usr.PID_ as Pid
	from OPS_TRN_MISSIONS mis
	inner join OPS_MST_EXTERNAL ext on mis.EXTERNAL_ID = ext.ID_
	inner join OPS_TRN_FLIGHTS fli on fli.MISSION_ID = mis.ID_
	inner join dbo.OPS_TRN_TAIL_FLIGHT tailf on tailf.FLIGHT_ID = fli.ID_
	inner join dbo.OPS_TRN_TAIL_FLIGHT_RECORD rec on rec.TAIL_FLIGHT_ID = tailf.ID_
	inner join ADM_MST_AIR_BASES bd on bd.ID_ = tailf.ACTUAL_BASE_FROM_ID
	inner join ADM_MST_AIR_BASES ba on ba.ID_ = tailf.ACTUAL_BASE_TO_ID
	inner join OPS_TRN_TAIL_CREWS tailc on tailf.TAIL_CREW_ID = tailc.ID_ 
	inner join OPS_TRN_WINGS wing on tailc.WING_ID = wing.ID_ and wing.MISSION_ID = mis.ID_
	inner join ADM_MST_RESTRICTIONS coy on wing.COY_ID = coy.ID_ 
	inner join ADM_MST_PLATFORMS pltf on wing.PLTF_ID = pltf.ID_ 
	inner join ADM_MST_TAILS tail on tailc.TAIL_ID = tail.ID_ 
	inner join ADM_MST_RESTRICTIONS bat on tail.BATLN_ID = bat.ID_ 
	inner join ADM_MST_RESTRICTIONS cmd on cmd.ID_ = bat.PRNT_ID 
	inner join ADM_TRN_USER_RESTRICION_DETAILS urd on urd.DT_REST_ID = tail.BATLN_ID and urd.LVL_NAME_ = 'Battalion'
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.ID_ = urd.USR_REST_ID and ur.MODULE_ID='EIS.002.00.00.00'
	inner join ADM_TRN_USER_PROFILES usr on usr.ID_ = ur.USER_PROFILE_ID	
	where mis.EXTERNAL_ID is not null
	and convert(varchar(7), DATEADD("Minute", bd.GMT_DIFF_, rec.RTD_), 120) = convert(varchar(7), getdate(), 120)
	and cmd.ID_ in (
		select cmd.ID_
			from CIS_EXCLUDE_COMMAND exc
			inner join CIS_NG_COMMAND_MAP map on exc.CIS_COMMAND_ = map.CIS_COMMAND_
			inner join ADM_MST_RESTRICTIONS cmd on cmd.CODE_ = map.NG_COMMAND_
	)
)  
	select CIS_IMP_JAAM_COMMAND.COMMAND_ CISCommand
		, CIS_NG_COMMAND_MAP.ng_COMMAND_ NGCommand
		, 'UNIT' AS [Type]
		, CIS_IMP_JAAM_COMMAND_FLIGHT.FLIGHT_ Data 
		, CIS_IMP_JAAM_COMMAND_FLIGHT.TOTAL_HOURS_ [Hours]
		, CIS_IMP_JAAM_COMMAND_FLIGHT.TOTAL_SORTIES_ AS Missions
		, CONVERT(int, left(TOTAL_HOURS_, charindex( ':', TOTAL_HOURS_) -1 )) AS HourNumber
		, CONVERT(int, substring(TOTAL_HOURS_, charindex( ':', TOTAL_HOURS_) + 1, len(TOTAL_HOURS_)) ) AS MinuteNumber
		, dbo.GetSumOfNumberOfMissions('CIS_IMP_JAAM_COMMAND_FLIGHT', ng_COMMAND_) AS TotalMissions
		, dbo.GetSumOfHours('CIS_IMP_JAAM_COMMAND_FLIGHT', ng_COMMAND_) AS TotalHours
		, usr.PID_ as Pid
	from CIS_IMP_JAAM_COMMAND	
	inner join CIS_NG_COMMAND_MAP ON  CIS_IMP_JAAM_COMMAND.COMMAND_ =  CIS_NG_COMMAND_MAP.CIS_COMMAND_
	inner join CIS_IMP_JAAM_COMMAND_FLIGHT ON CIS_IMP_JAAM_COMMAND_FLIGHT.COMMAND_ID = CIS_IMP_JAAM_COMMAND.ID_ 
	inner join ADM_MST_RESTRICTIONS com on com.CODE_ = CIS_NG_COMMAND_MAP.NG_COMMAND_
	inner join ADM_MST_RESTRICTIONS bat on bat.PRNT_ID= com.ID_
	inner join ADM_TRN_USER_RESTRICION_DETAILS urd on urd.DT_REST_ID  = bat.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.ID_ = urd.USR_REST_ID and ur.MODULE_ID='EIS.002.00.00.00' and urd.LVL_NAME_ = 'Battalion'
	inner join ADM_TRN_USER_PROFILES usr on usr.ID_ = ur.USER_PROFILE_ID	
	where CIS_IMP_JAAM_COMMAND_FLIGHT.TOTAL_SORTIES_ <> 0
			AND CIS_IMP_JAAM_COMMAND.COMMAND_ NOT IN (SELECT CIS_COMMAND_ FROM CIS_EXCLUDE_COMMAND)
	group by CIS_IMP_JAAM_COMMAND.COMMAND_, usr.PID_,CIS_NG_COMMAND_MAP.ng_COMMAND_, CIS_IMP_JAAM_COMMAND_FLIGHT.FLIGHT_
		, CIS_IMP_JAAM_COMMAND_FLIGHT.TOTAL_HOURS_, CIS_IMP_JAAM_COMMAND_FLIGHT.TOTAL_SORTIES_

union all
	select CIS_IMP_JAAM_COMMAND.COMMAND_ CISCommand
		, CIS_NG_COMMAND_MAP.ng_COMMAND_ NGCommand
		, 'SUPPORT TO' AS [Type]
		, CIS_IMP_JAAM_COMMAND_SUPPORT_TO.SUPPORT_TO_ Data 
		, CIS_IMP_JAAM_COMMAND_SUPPORT_TO.HOURS_ [Hours]
		, CIS_IMP_JAAM_COMMAND_SUPPORT_TO.SORTIES AS Missions
		, convert(int, left(HOURS_, charindex( ':', HOURS_) -1 )) AS HourNumber
		, convert(int, substring(HOURS_, charindex( ':', HOURS_) + 1, len(HOURS_) )) AS MinuteNumber
		, dbo.GetSumOfNumberOfMissions('CIS_IMP_JAAM_COMMAND_SUPPORT_TO', ng_COMMAND_) AS TotalMissions
		, dbo.GetSumOfHours('CIS_IMP_JAAM_COMMAND_SUPPORT_TO', ng_COMMAND_) AS TotalHours
		, usr.PID_ as Pid
	from CIS_IMP_JAAM_COMMAND	
	inner join CIS_NG_COMMAND_MAP ON  CIS_IMP_JAAM_COMMAND.COMMAND_ =  CIS_NG_COMMAND_MAP.CIS_COMMAND_
	inner join CIS_IMP_JAAM_COMMAND_SUPPORT_TO ON CIS_IMP_JAAM_COMMAND_SUPPORT_TO.COMMAND_ID = CIS_IMP_JAAM_COMMAND.ID_ 
	inner join ADM_MST_RESTRICTIONS com on com.CODE_ = CIS_NG_COMMAND_MAP.NG_COMMAND_
	inner join ADM_MST_RESTRICTIONS bat on bat.PRNT_ID= com.ID_
	inner join ADM_TRN_USER_RESTRICION_DETAILS urd on urd.DT_REST_ID  = bat.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.ID_ = urd.USR_REST_ID and ur.MODULE_ID='EIS.002.00.00.00' and urd.LVL_NAME_ = 'Battalion'
	inner join ADM_TRN_USER_PROFILES usr on usr.ID_ = ur.USER_PROFILE_ID	
	where
		CIS_IMP_JAAM_COMMAND_SUPPORT_TO.SORTIES <> 0
		AND CIS_IMP_JAAM_COMMAND.COMMAND_ NOT IN (SELECT CIS_COMMAND_ FROM CIS_EXCLUDE_COMMAND)
	group by CIS_IMP_JAAM_COMMAND.COMMAND_, usr.PID_,CIS_NG_COMMAND_MAP.ng_COMMAND_, CIS_IMP_JAAM_COMMAND_SUPPORT_TO.SUPPORT_TO_
		, CIS_IMP_JAAM_COMMAND_SUPPORT_TO.HOURS_, CIS_IMP_JAAM_COMMAND_SUPPORT_TO.SORTIES 

union all		
	select CIS_IMP_JAAM_COMMAND.COMMAND_ CISCommand
		, CIS_NG_COMMAND_MAP.ng_COMMAND_ NGCommand
		, 'AIRCRAFT TYPE' AS [Type]
		, CIS_IMP_JAAM_COMMAND_PLATFORM.PLATFORM_ Data
		, CIS_IMP_JAAM_COMMAND_PLATFORM.HOURS_ [Hours]
		, CIS_IMP_JAAM_COMMAND_PLATFORM.SORTIES AS Missions
		, convert(int, left(HOURS_, charindex( ':', HOURS_) -1 )) AS HourNumber
		, convert(int, substring(HOURS_, charindex( ':', HOURS_) + 1, len(HOURS_)) ) AS MinuteNumber
		, dbo.GetSumOfNumberOfMissions('CIS_IMP_JAAM_COMMAND_PLATFORM', ng_COMMAND_) AS TotalMissions
		, dbo.GetSumOfHours('CIS_IMP_JAAM_COMMAND_PLATFORM', ng_COMMAND_) AS TotalHours
		, usr.PID_ as Pid
	from CIS_IMP_JAAM_COMMAND
	inner join CIS_NG_COMMAND_MAP on  CIS_IMP_JAAM_COMMAND.COMMAND_ =  CIS_NG_COMMAND_MAP.CIS_COMMAND_
	inner join CIS_IMP_JAAM_COMMAND_PLATFORM on CIS_IMP_JAAM_COMMAND_PLATFORM.COMMAND_ID = CIS_IMP_JAAM_COMMAND.ID_ 
	inner join ADM_MST_RESTRICTIONS com on com.CODE_ = CIS_NG_COMMAND_MAP.NG_COMMAND_
	inner join ADM_MST_RESTRICTIONS bat on bat.PRNT_ID= com.ID_
	inner join ADM_TRN_USER_RESTRICION_DETAILS urd on urd.DT_REST_ID  = bat.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.ID_ = urd.USR_REST_ID and ur.MODULE_ID='EIS.002.00.00.00' and urd.LVL_NAME_ = 'Battalion'
	inner join ADM_TRN_USER_PROFILES usr on usr.ID_ = ur.USER_PROFILE_ID	
	where
		CIS_IMP_JAAM_COMMAND_PLATFORM.SORTIES <> 0
		AND CIS_IMP_JAAM_COMMAND.COMMAND_ NOT IN (SELECT CIS_COMMAND_ FROM CIS_EXCLUDE_COMMAND)
	group by CIS_IMP_JAAM_COMMAND.COMMAND_, usr.PID_,CIS_NG_COMMAND_MAP.ng_COMMAND_, CIS_IMP_JAAM_COMMAND_PLATFORM.PLATFORM_
		, CIS_IMP_JAAM_COMMAND_PLATFORM.HOURS_, CIS_IMP_JAAM_COMMAND_PLATFORM.SORTIES 	
union all		

select t.Command as CISCommand, t.Command as NGCommand, 'UNIT' as [Type], t.Battalion as Data
	--, replace(cast(cast(dbo.ReturnTAAMSTime(sum(t.MissionHours)) as decimal(10,2)) as varchar), '.', ':') as [Hours]
	, cast (sum(t.MissionMinutes)/60 as varchar) + ':' 
		+
	  case 
	  when sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) < 10
	  then '0' + cast (sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as varchar)
	  else cast (sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as varchar)
	  end as [Hours]
	, count(t.MissionId) as Missions
	, sum(t.MissionMinutes)/60  as HourNumber
	, sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as MinuteNumber
	, '-' as TotalMissions
	, '-' as TotalHours
	, t.Pid
from t	
group by t.Command, t.Battalion, t.Pid

union all

select t.Command as CISCommand, t.Command as NGCommand, 'SUPPORT TO' as Type, t.SupportTo as Data
	--, replace(cast(cast(dbo.ReturnTAAMSTime(sum(t.MissionHours)) as decimal(10,2)) as varchar), '.', ':') as [Hours]
	, cast (sum(t.MissionMinutes)/60 as varchar) + ':' 
		+
	  case 
	  when sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) < 10
	  then '0' + cast (sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as varchar)
	  else cast (sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as varchar)
	  end as [Hours]
	, count(t.MissionId) as Missions
	, sum(t.MissionMinutes)/60  as HourNumber
	, sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as MinuteNumber
	, '-' as TotalMissions
	, '-' as TotalHours
	, t.Pid
from t	
group by t.Command, t.SupportTo, t.Pid

union all

select t.Command as CISCommand, t.Command as NGCommand, 'AIRCRAFT TYPE' as Type, t.Platform as Data
	--, replace(cast(cast(dbo.ReturnTAAMSTime(sum(t.MissionHours)) as decimal(10,2)) as varchar), '.', ':') as [Hours]
	, cast (sum(t.MissionMinutes)/60 as varchar) + ':' 
		+
	  case 
	  when sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) < 10
	  then '0' + cast (sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as varchar)
	  else cast (sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as varchar)
	  end as [Hours]
	, count(t.MissionId) as Missions
	, sum(t.MissionMinutes)/60  as HourNumber
	, sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as MinuteNumber
	, '-' as TotalMissions
	, '-' as TotalHours
	, t.Pid
from t	
group by t.Command, t.Platform, t.Pid
go

