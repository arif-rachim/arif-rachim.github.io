CREATE FUNCTION [dbo].[GetDatePeriod]
(
	@startdate varchar(8),	--yyyymmdd, ex. 20220101
	@enddate varchar(8)		--yyyymmdd, ex. 20221201
)
RETURNS TABLE
AS
RETURN
(
	WITH cte AS (
	    SELECT CAST(@startdate AS DATETIME) as DatePeriod
	    UNION ALL
	    SELECT DATEADD(MONTH, 1, DatePeriod)
	    FROM cte
	    WHERE DatePeriod < CAST(@enddate AS DATETIME)
    )
	SELECT DatePeriod FROM cte
)
go

