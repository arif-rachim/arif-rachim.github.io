
CREATE VIEW VW_JAC_MOD_ASVC_FORCE_CONFIG AS 
(
	select 1 as ForceId, 1 as IsActive, 'JAC' as Description
)
go

