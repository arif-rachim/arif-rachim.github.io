
CREATE PROCEDURE DM_US20180_MNT_REQUESTED_WO_ITEM_CONDITION_MIGRATION
	 @userid	bigint	
AS
BEGIN

	SET NOCOUNT ON;
	SET DATEFORMAT DMY;

	DECLARE @errormsg nvarchar(max);
	
	-- Esnaad vars
	declare @wfinstid uniqueidentifier 
	DECLARE @workOrderId UNIQUEIDENTIFIER
	DECLARE @workOrderNo nvarchar(255);
	DECLARE @partNo nvarchar(255);
	DECLARE @cageCode nvarchar(255);
	DECLARE @serialNoOrBatchNo nvarchar(255);
	DECLARE @unittId BIGINT;
	DECLARE @partTagcolor BIGINT;
	DECLARE @changeToTagcolor BIGINT;
	DECLARE @orgBuid BIGINT;
	DECLARE @agL2Id BIGINT;
	DECLARE @wfState nvarchar(255);
	DECLARE @locationId BIGINT;

	DECLARE @TagcolorIdWorkOrderCreated BIGINT = 11;

/*
	DECLARE @backupTablename nvarchar(250) = ''
	DECLARE @backupTimePart nvarchar(250) = ''
	--select @backupTimePart = datepart(year, getdate())+''+ datepart(month, getdate())+''+ datepart(day, getdate())+''+  datepart(hour, getdate())+''+ datepart(minute, getdate())
	select @backupTimePart = convert(nvarchar(8), getdate(), 112) +  cast(datepart(hour, getdate()) as nvarchar(2)) + cast(datepart(minute, getdate()) as nvarchar(2))
	set @backupTablename = 'BKP_US20180_WO_' + @backupTimePart


	---
	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(@backupTablename + '_REQUESTED_ADM_TRN_IMV_ITEMS_IN_LOCATION') AND type in (N'U'))
	BEGIN
	  exec('SELECT top 1 imv.* INTO ' + @backupTablename + '_REQUESTED_ADM_TRN_IMV_ITEMS_IN_LOCATION FROM MNT_TRN_WOTS_WORK_ORDER wo  join  WF_TRN_INSTANCE wf on wf.ID_ = wo.WF_ID and wf.WF_STATE_ in (''AwaitingApproval'') join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.UNIT_ID_ = wo.EI_UNIT_ID_ and imv.BU_ID_ = wo.ORG_BU_ID_ and imv.OWNED_L2_ID_ = wo.AGL2_ID_  and imv.TC_ID_  != 11 WHERE  wo.EI_UNIT_ID_ is not null ') 
	END
	IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(@backupTablename + '_REQUESTED_MNT_TRN_WOTS_WORK_ORDER') AND type in (N'U'))
	BEGIN
	  exec('SELECT top 1 wo.* INTO ' + @backupTablename + '_REQUESTED_MNT_TRN_WOTS_WORK_ORDER FROM MNT_TRN_WOTS_WORK_ORDER wo  join  WF_TRN_INSTANCE wf on wf.ID_ = wo.WF_ID and wf.WF_STATE_ in (''AwaitingApproval'') WHERE  wo.EI_UNIT_ID_ is not null') 
	END
	---
*/

	DECLARE copierCursor CURSOR FOR
	SELECT 
		 wo.ID_
		,wf.WF_STATE_
		,wo.WO_NO_
		,wo.ORG_BU_ID_
		,wo.AGL2_ID_
		,wo.EI_PART_NO_
		,wo.EI_MNF_CODE_
		,wo.EI_SERIAL_NO_
		,wo.EI_UNIT_ID_
		,wo.TAG_COLOR_ID_
		,wo.WO_CMPL_TAG_COLOR_ID_
		,wo.EI_LOC_ID_
	FROM
		MNT_TRN_WOTS_WORK_ORDER wo  join 
		WF_TRN_INSTANCE wf on wf.ID_ = wo.WF_ID and wf.WF_STATE_ in ('AwaitingApproval') join
		ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.UNIT_ID_ = wo.EI_UNIT_ID_ and imv.BU_ID_ = wo.ORG_BU_ID_ and imv.OWNED_L2_ID_ = wo.AGL2_ID_  and imv.TC_ID_ <> @TagcolorIdWorkOrderCreated
	WHERE 
		wo.EI_UNIT_ID_ is not null 
		and imv.TC_ID_ not in ( 8,9,10,11)
		and imv.TC_ID_ = wo.TAG_COLOR_ID_
		and (wo.EI_LOC_ID_ is null or wo.EI_LOC_ID_ = imv.LOC_ID_)
		and US20180_WO_TC_ is null
	FOR UPDATE OF US20180_WO_TC_



	OPEN copierCursor
	
	FETCH NEXT FROM copierCursor
	INTO
		 @workOrderId
		,@wfState
		,@workOrderNo
		,@orgBuid
		,@agL2Id
		,@partNo
		,@cageCode
		,@serialNoOrBatchNo
		,@unittId
		,@partTagcolor
		,@changeToTagcolor
		,@locationId
	;
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
	
		
			BEGIN TRY
				BEGIN	
					print @workOrderNo
					if(@wfState = 'AwaitingApproval')
					begin
						print 'AwaitingApproval'
						EXEC DM_US20180_UPDATE_CONDITION @buid = @orgBuid, @esnaad_unit_id_ = @unittId, @tagcolor = @partTagcolor, @agl2 = @agL2Id, @createduserid = @userid, @changetotagcolor = @TagcolorIdWorkOrderCreated;

						UPDATE MNT_TRN_WOTS_WORK_ORDER SET US20180_WO_TC_ = '11'
						WHERE CURRENT OF copierCursor

					end

				END
			END TRY
			BEGIN CATCH
				SELECT @errormsg = ERROR_MESSAGE();
				print 'Error: ' + @errormsg + ' in ' + @workOrderNo

				
				FETCH NEXT FROM copierCursor
				INTO
					 @workOrderId
					,@wfState
					,@workOrderNo
					,@orgBuid
					,@agL2Id
					,@partNo
					,@cageCode
					,@serialNoOrBatchNo
					,@unittId
					,@partTagcolor
					,@changeToTagcolor
					,@locationId
				;			
			END CATCH


		FETCH NEXT FROM copierCursor
		INTO
			 @workOrderId
			,@wfState
			,@workOrderNo
			,@orgBuid
			,@agL2Id
			,@partNo
			,@cageCode
			,@serialNoOrBatchNo
			,@unittId
			,@partTagcolor
			,@changeToTagcolor
			,@locationId
				;			
	
	END
	
	CLOSE copierCursor
	DEALLOCATE copierCursor


	print '=> end of exec'
END



go

