CREATE FUNCTION [dbo].[GetClosestComponentTBOHour]
(
@hcode		nvarchar(1000)
)
RETURNS int
AS
BEGIN

    DECLARE @minHour bigint

   select @minHour=
    min(case when isnull((mc.OVERHAUL_ + ISNULL(cc.LAST_OH_,0)) - cc.CUR_OP_HRS_,0)> isnull( mc.REPLACE_ - cc.CUR_OP_HRS_ ,0) 
   then isnull( mc.REPLACE_ - cc.CUR_OP_HRS_ ,0) else isnull((mc.OVERHAUL_ + ISNULL(cc.LAST_OH_,0)) - cc.CUR_OP_HRS_,0) end )
									    
		                            FROM MNT_TRN_D16_1_ASSIGNMENT cc
                            JOIN ADM_MST_UNITS cu ON cu.ID_ = cc.COMP_UNIT_ID
                            JOIN ADM_MST_ITEMS ci ON ci.ID_ = cu.ITEM_ID
                            JOIN ADM_MST_MANUFACTURES cm ON cm.ID_ = ci.MNF_ID
                            JOIN ADM_MST_SIMPLE_REF sr ON sr.ID_ = ci.CLS_ID_
                            JOIN MNT_TRN_D16_1_MASTER mc ON mc.ID_ = cc.MASTER_ID
                            LEFT JOIN ADM_MST_TAILS t ON t.UNIT_ID = cc.END_ACFT_UNIT_ID
							where  cc.H_CODE_ like '%'+@hcode +'%'
								
   Return @minHour

end
go

