CREATE VIEW [dbo].[VW_OPS_CREW_FLYING_RECORD_LIST]
AS
SELECT ActualMissionDate, MissionDateGmt, MissionDate, MissionNo, CompanyId, Company, PlatformId, Platform, Tail, DutySymbol, MissionTypeId, MissionType, MissionSubTypeId, MissionSubType, CrewId, FlightRecordId, IfrActual, IfrSimulated, Seat, 
                         MissionTypeSymbol, EnvMountainMins, EnvWaterMins                        
                         , SUM(CASE WHEN (FlightSymbol = 'D' OR
                         FlightSymbol = 'DS' OR
                         FlightSymbol = 'H') THEN FlyingMinutes ELSE 0 END) AS DayHours, SUM(CASE WHEN (FlightSymbol = 'D') THEN FlyingMinutes ELSE 0 END) AS D, SUM(CASE WHEN (FlightSymbol = 'DS') THEN FlyingMinutes ELSE 0 END) 
                         AS DS, SUM(CASE WHEN (FlightSymbol = 'N' OR
                         FlightSymbol = 'NG' OR
                         FlightSymbol = 'NS') THEN FlyingMinutes ELSE 0 END) AS NightHours, SUM(CASE WHEN (FlightSymbol = 'N') THEN FlyingMinutes ELSE 0 END) AS N, SUM(CASE WHEN (FlightSymbol = 'NG') THEN FlyingMinutes ELSE 0 END) 
                         AS Nvg, SUM(CASE WHEN (FlightSymbol = 'NS') THEN FlyingMinutes ELSE 0 END) AS Nvs, SUM(FlyingMinutes) AS Total,
						 IsCourseTraining
FROM            dbo.VW_OPS_CREW_FLYING_RECORD
GROUP BY ActualMissionDate, MissionDateGmt, MissionDate, MissionNo,CompanyId, Company, PlatformId, Platform, Tail, DutySymbol, 
	MissionTypeId, MissionType, MissionSubTypeId, MissionSubType, CrewId, FlightRecordId, IfrActual, 
	IfrSimulated, Seat, MissionTypeSymbol, EnvMountainMins, EnvWaterMins, IsCourseTraining
go

