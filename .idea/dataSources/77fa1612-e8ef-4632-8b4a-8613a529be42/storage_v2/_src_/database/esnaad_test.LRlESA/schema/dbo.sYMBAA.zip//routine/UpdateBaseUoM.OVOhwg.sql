CREATE PROCEDURE dbo.UpdateBaseUoM(@itemId bigint, @baseUoMId uniqueidentifier) AS

BEGIN
-- Stock Management
UPDATE stock
SET stock.UOM_ID_ = @baseUoMId, stock.VERSION_ = stock.VERSION_ + 1
FROM dbo.LOG_TRN_STOCK stock
  JOIN ADM_MST_UNITS unit ON stock.UNIT_ID = unit.ID_
WHERE stock.TYPE_ = 'Logistic' AND unit.ITEM_ID = @itemId

UPDATE h
SET h.BASE_UOM_CODE_ = uom.CODE_, h.VERSION_ = h.VERSION_ + 1
FROM dbo.LOG_HST_STM_ITEM_HISTORY h
  JOIN dbo.LOG_MST_UNIT_OF_MEASURE uom ON h.BASE_UOM_CODE_ = uom.CODE_
WHERE uom.ID_ = @baseUoMId AND h.ITEM_ID_ = @itemId 

-- Transfer Management 
UPDATE dbo.LOG_TRN_TRM_TRANSFER_REQUEST_ITEM SET UOM_ID_ = @baseUoMId, VERSION_ = VERSION_ + 1
WHERE ITEM_ID = @itemId

UPDATE ti
SET ti.UNIT_MEASURE_CODE_ = uom.CODE_
FROM dbo.LOG_TRN_TIN_TURN_IN_ITEM ti
  JOIN dbo.LOG_MST_UNIT_OF_MEASURE uom ON uom.CODE_ = ti.UNIT_MEASURE_CODE_
WHERE uom.ID_ = @baseUoMId AND ti.ITEM_ID = @itemId 

-- Transfer Engine
UPDATE tdata
SET tdata.UOM_ID_ = @baseUoMId, tdata.VERSION_ = tdata.VERSION_ + 1
FROM dbo.LOG_TRN_TRF_TRANSFER_DATA_ITEM tdata
  JOIN dbo.ADM_MST_UNITS unit ON tdata.UNIT_ID_ = unit.ID_
WHERE unit.ITEM_ID = @itemId

--Procurement
UPDATE dbo.LOG_TRN_PRC_INDENT_ITEM
SET UOM_ID = @baseUoMId, VERSION_ = VERSION_ + 1
WHERE ITEM_ID = @itemId

UPDATE poi
SET poi.UOM_ID = @baseUoMId, poi.VERSION_ = poi.VERSION_ + 1
FROM LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi
  JOIN LOG_TRN_PRC_PROCUREMENT_ITEM pitem ON poi.PROC_ITEM_ID = pitem.ID_
WHERE pitem.ITEM_ID = @itemId

-- Stocktaking
UPDATE LOG_TRN_STM_STOCKTAKING_ITEM
SET UOM_ID_ = @baseUoMId, VERSION_ = VERSION_ + 1
WHERE ITEM_ID_ = @itemId

END
go

