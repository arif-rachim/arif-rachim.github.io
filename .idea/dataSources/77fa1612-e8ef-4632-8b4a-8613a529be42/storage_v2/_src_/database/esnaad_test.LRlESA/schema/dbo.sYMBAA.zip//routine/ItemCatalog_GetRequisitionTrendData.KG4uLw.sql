CREATE FUNCTION [dbo].[ItemCatalog_GetRequisitionTrendData]
(
	 @cmdId bigint, @itemId bigint, @start date, @end date
)
RETURNS TABLE
AS
RETURN
(
	WITH dates AS (
	select @start as DateOn
	union all
	select dateadd(d, 1, DateOn) as date
	from dates
	where dateon < getdate()
	),
	REQ AS (
	    select tr.TR_DATE_ as TR_DATE, count(tri.REQ_QTY_) as QTY
            from LOG_TRN_TRM_TRANSFER_REQUEST tr
                     join LOG_TRN_TRM_TRANSFER_REQUEST_ITEM tri on tri.TR_ID_ = tr.ID_
            where tri.ITEM_ID = @itemId
              and tr.RI_CMD_ID_ = @cmdId
              and tr.TR_DATE_ >= @start
            and tri.REQ_ITEM_STATUS_ = 'Fulfilled'
                GROUP BY tr.TR_DATE_
	)
	SELECT d.DateOn AS DateOn, isnull(r.QTY, (select top(1) QTY from REQ where REQ.TR_DATE < DateOn  order by REQ.TR_DATE)) as Qty
	from dates d
	left join REQ r on CAST(r.TR_DATE AS DATE) = CAST(d.DateOn AS DATE)
)
go

