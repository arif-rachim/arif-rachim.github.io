CREATE PROC [dbo].[MNT_INV_RecordLocateItemHistory] @handle uniqueidentifier, @userProfileId bigint, @terminal nvarchar(255) 
AS
BEGIN
	DECLARE @userId nvarchar(255), @fullname nvarchar(1000), @pid nvarchar(255)
	declare @createdOn datetime = getdate()
	
	SELECT @userId = UserId, @fullname=FullName, @pid=Pid FROM dbo.GetUserInfo(@userProfileId)

	-- insert item transaction history
	INSERT ADM_HST_ITEM_TX(ID_, VERSION_, ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, IS_SERIALIZED_, MOV_TYPE_, QTY_, BU_ID_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, COND_ID_, DOC_REF_, L2_ID_, PERF_USER_PROFILE_ID_, PERF_USER_ID_, PERF_PID_, PERF_FULL_NAME_, PERF_ON_, BASE_UOM)
	SELECT dbo.GenerateTimebasedGuid() AS ID_, 1 AS VERSION_,  U.ITEM_ID AS ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, SERIALIZED_ AS IS_SERIALIZED_,'MI_LOC' AS MOV_TYPE_, QTY_, TI.DST_BU_ID_
	, @userId AS CREATED_BY_, @pid AS PID_CREATED_BY_, @fullname AS  FULL_NAME_CREATED_BY_, @createdOn AS CREATED_ON_, @terminal
	, TI.DST_TAG_COLOR_ID_, NULL, TI.DST_L2_ID_, @userProfileId, @userId, @pid AS PERF_PID_, @fullname AS PERF_FULL_NAME_, @createdOn AS PERF_ON_, UOM.CODE_
	FROM 
	--ADM_TRN_IMV_ITEMS_IN_LOCATION IMV
	TMP_TRANSFER_ITEM TI
	--JOIN @imvIds IDS ON IDS.imvId = IMV.ID_
	JOIN ADM_MST_UNITS U ON U.ID_ = TI.UNIT_ID_
	JOIN ADM_MST_ITEMS I ON U.ITEM_ID = I.ID_
	JOIN ADM_MST_MANUFACTURES MNF ON I.MNF_ID = MNF.ID_
	JOIN LOG_MST_UNIT_OF_MEASURE UOM ON UOM.ID_ = I.UOM_ID_
	WHERE TI.HANDLE_ = @handle

END
go

