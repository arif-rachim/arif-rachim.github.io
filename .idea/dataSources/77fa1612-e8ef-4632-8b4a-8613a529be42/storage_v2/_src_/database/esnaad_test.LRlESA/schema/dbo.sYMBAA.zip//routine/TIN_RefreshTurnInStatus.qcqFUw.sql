CREATE proc [dbo].[TIN_RefreshTurnInStatus] @turnInId uniqueidentifier
as
begin 
	declare @threshold dbo.TIN_Type_StatusThreshold

	INSERT @threshold
	SELECT TN.ID_ AS TurnInId
	, COUNT(1) * 1000 AS thReceived
	, COUNT(1) * 100 AS thValidated
	, COUNT(1) * 10 AS thCreated
	FROM LOG_TRN_TIN_TURN_IN TN 
	JOIN LOG_TRN_TIN_TURN_IN_ITEM TNI ON TNI.TURN_IN_ID = TN.ID_ 
	WHERE TN.ID_ = @turnInId
	GROUP BY TN.ID_

	UPDATE TN
	SET TN.STATUS_ = TIS.TurnInStatus
	FROM LOG_TRN_TIN_TURN_IN TN
	JOIN (
		SELECT 
		x.TURN_IN_ID_,TURN_IN_NO_
		,CASE 
			WHEN StatusVal = thReceived THEN 'Received'
			WHEN StatusVal < thReceived AND StatusVal > thValidated THEN 'PartiallyReceived'
			WHEN StatusVal = thValidated THEN 'Validated'
			WHEN StatusVal < thValidated AND StatusVal > thCreated THEN 'PartiallyRejected'
			WHEN StatusVal = thCreated THEN 'Created'
			ELSE 'Rejected'
		END AS TurnInStatus
		FROM (
			SELECT TN.ID_ AS TURN_IN_ID_, TN.TURN_IN_NO_, SUM(CASE TNI.STATUS_
				WHEN 'Created' THEN 10
				WHEN 'RejectedByReceiver' THEN 10
				WHEN 'Validated' THEN 100
				WHEN 'Received' THEN 1000
				ELSE 0
			END ) AS StatusVal	
			FROM LOG_TRN_TIN_TURN_IN TN 
			JOIN LOG_TRN_TIN_TURN_IN_ITEM TNI ON TNI.TURN_IN_ID = TN.ID_ 
			WHERE TN.ID_ = @turnInId
			GROUP BY TN.ID_, TN.TURN_IN_NO_
		) X
		JOIN @threshold TH ON TH.TurnInId = X.TURN_IN_ID_
	) TIS ON TN.ID_ = TIS.TURN_IN_ID_

end
go

