--drop view VW_WF_TRN_TRACKING_LATEST_ENTRY

--select @@VERSION

create view VW_WF_TRN_TRACKING_LATEST_ENTRY AS
select t4.ID_, 
       t4.WF_INST_ID, 
	   t4.REMARKS_, 
	   t4.ST_FROM_, 
	   t4.ST_CURR_, 
	   t4.TRANS_, 
	   t4.PROC_ON, 
	   t4.PROC_BY_, 
	   t4.PROC_BY_PID_, 
	   t4.PROC_BY_FNAME_, 
	   t4.RESVD_, 
	   t4.ACC_CODE_, 
	   t4.VERSION_
  from (select t2.WF_INST_ID, 
               convert(uniqueidentifier,max(convert(varchar,t2.ID_))) as ID_ 
		  from (select t.WF_INST_ID, 
		               MAX(t.PROC_ON) proc_on_ 
				  from WF_TRN_TRACKING t 
				 group by t.WF_INST_ID
			   ) as t1 
			   join WF_TRN_TRACKING t2 on t1.WF_INST_ID = t2.WF_INST_ID 
							          and t1.proc_on_ = t2.PROC_ON
         group by t2.WF_INST_ID
	   ) as t3 
	   join WF_TRN_TRACKING t4 on t3.ID_ = t4.ID_ 


go

