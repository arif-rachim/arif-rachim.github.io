CREATE VIEW [dbo].[VW_DAS_EPM_CONTRACT_OVERDUE] AS
SELECT ID_ AS ContractId, CONTRACT_NO AS ContractNumber,CONT_SUB_TYPE_ID AS ContractSubTypeId, CONT_TYPE_ID AS ContractTypeId, isnull(TAS.taskcnt,0) AS TasksOverdue,
 isnull(DEL.delcnt,0) AS DeliverableOverdue, isnull(MIL.milcnt, 0) AS MilestoneOverdue FROM  PMO_TRN_CONTRACT 
                        LEFT JOIN (SELECT  contractid,count(*) AS taskcnt FROM dbo.VW_DAS_EPM_CONTRACT_TASK_OVERDUE group by contractid) AS TAS ON PMO_TRN_CONTRACT.ID_ = TAS.contractid
                        LEFT JOIN (SELECT contractid, count(*) as delcnt FROM  dbo.VW_DAS_EPM_CONTRACT_DELIVERABLE_OVERDUE group by contractid) AS DEL ON PMO_TRN_CONTRACT.ID_ = DEL.contractid
                        LEFT JOIN (SELECT contractid, count(*) as milcnt FROM dbo.VW_DAS_EPM_CONTRACT_MILESTONE_OVERDUE group by contractid) AS MIL ON PMO_TRN_CONTRACT.ID_ = MIL.contractid
                        WHERE (taskcnt > 0 OR delcnt > 0 OR milcnt > 0) AND PMO_TRN_CONTRACT.STATUS_ID_ <> 359

go

