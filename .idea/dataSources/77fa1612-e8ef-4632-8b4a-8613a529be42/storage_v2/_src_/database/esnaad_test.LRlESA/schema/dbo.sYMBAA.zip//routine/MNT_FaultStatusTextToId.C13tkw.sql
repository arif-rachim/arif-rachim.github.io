CREATE FUNCTION [dbo].[MNT_FaultStatusTextToId] (@status varchar(50)) RETURNS int
AS
BEGIN
 declare @result bigint = 0
 SELECT @result = CASE 
					WHEN @status IN ('CIRCLED RED N','(N)') THEN 43
					WHEN @status IN ('CIRCLED RED X','(X)') THEN 39
					WHEN @status IN ('CIRCLED RED B','(B)') THEN 41
					WHEN @status = 'CIRCLED RED C' THEN 42
					WHEN @status IN ('RED DASH','-') THEN 38
					WHEN @status IN ('RED X','X') THEN 31
					WHEN @status IN ('RED DIAGONAL','/') THEN 30
				END

 return @result
END
go

