
CREATE view [dbo].[vSOC_EmployeeProfile]
as (
	select * from tSOC_EmployeeProfile
)
go

