CREATE FUNCTION [dbo].[AveragePhaseCompletion]
(
      @StartDate	date,
      @EndDate	date,
      @PlatformIds	nvarchar(max)
)
RETURNS int
AS
BEGIN
	DECLARE @sum int
	DECLARE @count int
	DECLARE @result int

	set @sum = 0
	set @count = 0
	set @result = 0

	BEGIN
		SELECT @sum =  SUM( 
			CASE 
				WHEN START_DATE_ < @StartDate AND ACTUAL_COMPLETION_ <= @EndDate THEN  DATEDIFF(day,  @StartDate, ACTUAL_COMPLETION_) + 1
				WHEN START_DATE_ < @StartDate AND (ACTUAL_COMPLETION_ > @EndDate OR ACTUAL_COMPLETION_ IS NULL) THEN DATEDIFF(day,  @StartDate, @EndDate) + 1
				WHEN START_DATE_ >= @StartDate AND ACTUAL_COMPLETION_ <= @EndDate THEN DATEDIFF(day,  START_DATE_, ACTUAL_COMPLETION_) + 1
				WHEN START_DATE_ >= @StartDate AND (ACTUAL_COMPLETION_ > @EndDate OR ACTUAL_COMPLETION_ IS NULL) THEN DATEDIFF(day,  START_DATE_, @EndDate) + 1
			END)
		FROM MNT_TRN_PIM_PHASE_EXECUTION PE
			INNER JOIN ADM_MST_UNITS AS U ON U.ID_ = PE.TAIL_ID 
			INNER JOIN ADM_MST_ITEMS AS I ON I.ID_ = U.ITEM_ID 
			INNER JOIN ADM_MST_PLATFORMS AS P ON P.ID_ = I.ID_ 
		WHERE  START_DATE_ <=  @EndDate AND (ACTUAL_COMPLETION_ IS NULL OR ACTUAL_COMPLETION_ >= @StartDate) AND P.ID_ IN (SELECT Item from dbo.SplitInts(@PlatformIds, ','))
	END
	BEGIN
		SELECT @count = COUNT(*) FROM MNT_TRN_PIM_PHASE_EXECUTION PE
			INNER JOIN ADM_MST_UNITS AS U ON U.ID_ = PE.TAIL_ID 
			INNER JOIN ADM_MST_ITEMS AS I ON I.ID_ = U.ITEM_ID 
			INNER JOIN ADM_MST_PLATFORMS AS P ON P.ID_ = I.ID_ 
		WHERE  START_DATE_ <=  @EndDate AND (ACTUAL_COMPLETION_ IS NULL OR ACTUAL_COMPLETION_ >= @StartDate) AND P.ID_ IN (SELECT Item from dbo.SplitInts(@PlatformIds, ','))
	END

	BEGIN
		IF (@sum > 0 AND @count > 0)
			   SELECT @result = @sum/@count;		
	END

	RETURN @result;
END
go

