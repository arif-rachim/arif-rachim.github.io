CREATE VIEW [dbo].[VW_MNT_FLEET_STATUS_FAULT_AUDIT] AS
            SELECT fu.MOD_BY_
            ,fu.MOD_ON_
            ,fu.FULL_NAME_MOD_BY_
            ,fu.CREATED_BY_
            ,fu.CREATED_ON_
            ,fu.FULL_NAME_CREATED_BY_
            ,fu.UNIT_ID as UnitId
            ,COUNT(1) over (partition by fu.UNIT_ID) as Tcount
            ,ROW_NUMBER() over (partition by fu.UNIT_ID order by acSts.ORDER_ desc) as maxAcSts 
            FROM MNT_TRN_FAULT_UNITS fu 
            JOIN ADM_MST_SIMPLE_REF refSys on refSys.ID_ = fu.FAULT_INFO_SYS_ID 
            JOIN ADM_MST_SIMPLE_REF acSts on acSts.ID_ = fu.ACC_STS_ID WHERE FAULT_STS_ = 'Open' and refSys.CODE_='A'
go

