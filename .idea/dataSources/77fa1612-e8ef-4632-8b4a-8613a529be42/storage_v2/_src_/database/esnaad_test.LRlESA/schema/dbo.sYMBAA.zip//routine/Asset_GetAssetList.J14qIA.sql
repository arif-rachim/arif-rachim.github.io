CREATE FUNCTION [dbo].[Asset_GetAssetList] (@userProfileId bigint)
RETURNS TABLE AS
RETURN
(
        select 
            pbo.ID_                                                                                                                                                  as pboId
          , pbo.VERSION_                                                                                                                                             as Version
          , pbo.CMD_ID_                                                                                                                                              as pboCommandId
          , cmd.CODE_                                                                                                                                                as pboCommand
          , pbo.ACTIVE_                                                                                                                                              as IsActive
		      , case when ael.STATUS_ = 'Closed' then 0 else pbo.QTY_ end                                                                                                as Qty
          , pbo.REMARKS_                                                                                                                                             as Remarks
          , (case
                 when pbo.pbo_HR_USR_PRF_ID_ is not null or pbo.pbo_SR_USR_PRF_ID_ is not null then 'ASSIGNED'
                 else 'UNASSIGNED' end)                                                                                                                              as pboStatus
          , (case when pbo.DEPLOYMNT_ = 1 then 'YES' else 'NO' end)                                                                                                  as OnDeployment
          , u.ID_                                                                                                                                                    as UnitId
          , u.SERIAL_NO_                                                                                                                                             as SerialNo
          , unid.IDENTIFIER_                                                                                                                                         as AssetNo
          , i.ID_                                                                                                                                                    as ItemId
          , i.PART_NO_                                                                                                                                                as PartNo
          , i.NSN_                                                                                                                                                   as Nsn
          , i.NOMENCLATURE_                                                                                                                                          as Nomenclature
		  , i.DESCRIPTION_																																			 as Description
          , i.SERIALIZED_                                                                                                                                            as IsSerialized
          , (case when i.SERIALIZED_ = 1 then 'YES' else 'NO' end)                                                                                                   as IsSerializedString
		  , CASE WHEN (i.CAT_ID_ = 2806 AND (i.IS_INSP_REQ_ = 1)) THEN 'YES' WHEN (i.CAT_ID_ = 2806 AND (i.IS_INSP_REQ_ IS NULL OR  i.IS_INSP_REQ_ = 0)) THEN 'NO' ELSE NULL  END   as IsInspectionRequired
          , case when i.ITAR_ = 1 then 'YES' else 'NO' end                                                                                                           as IsItarControlled
          , m.CAGE_CODE_                                                                                                                                             as CageCode
          , uom.CODE_                                                                                                                                                as Uom
          , uom.NAME_                                                                                                                                                as UomDescription
          , cls.CODE_                                                                                                                                                as ClassCode
          , sref.CODE_                                                                                                                                               as Category
          , sref.DESC_                                                                                                                                               as CategoryDescription
          , (case when sref.ID_ = 2802 then TOCAT.CODE_ else SBCAT.CODE_ end)                                                                                        as SubCategory
          , (case when sref.ID_ = 2802 then UPPER(TOCAT.DESC_) else UPPER(SBCAT.DESC_) end)                                                                          as SubCategoryDescription
          , asgbu.ID_                                                                                                                                                as AssetOwnerId
          , asgbu.CODE_                                                                                                                                              as AssignedBu
          , cast(asgbu.IS_ASSET_MGMT_ as bit)                                                                                                                        as IsAssetMgmtBu
          , cast((case
                      when asgbu.CODE_ is not null and asgbu.IS_ASSET_MGMT_ = 1 then 1
                      else 0 end) as bit)                                                                                                                            as IsAssetMgmtBuSet
          , mhr.ID_                                                                                                                                                  as MasterHandReceiptId
          , mhr.USER_ID_                                                                                                                                             as MasterHandReceipt
          , (mhr.F_NAME_ + ' ' + mhr.L_NAME_)                                                                                                                        as MasterHandReceiptName
          , w.SHOW_MISSING_ASSET_OWNER_                                                                                                                              as ShowMissingAssetOwnerWarningIndicator
          , w.SHOW_MISSING_ASSET_AUTH_QTY_                                                                                                                           as ShowMissingAssetAuthQty
          , ascls.AUTHZ_QTY_                                                                                                                                         as AuthorizedQty
          , cg.ASSET_GROUP_                                                                                                                                          as AssetGroup
          , pbo.CREATED_ON_                                                                                                                                          as CreatedOn
          , pbo.CREATED_BY_                                                                                                                                          as CreatedBy
          , pbo.FULL_NAME_CREATED_BY_                                                                                                                                as FullNameCreatedBy
          , pbo.MOD_ON_                                                                                                                                              as ModifiedOn
          , pbo.MOD_BY_                                                                                                                                              as ModifiedBy
          , pbo.FULL_NAME_MOD_BY_                                                                                                                                    as FullNameModifiedBy
          , iif(cg.ASSET_GROUP_ = 'C4ITC', cast(iif(upper(ai.SOURCE_) = 'MILITARY', 1, 0) as bit), cast(0 as bit))                                                   as SourceIsMilitary
          , iif(cg.ASSET_GROUP_ = 'C4ITC', cast(iif(upper(ai.SOURCE_) = 'CONTRACTOR', 1, 0) as bit), cast(0 as bit))                                                 as SourceIsContractor
          , iif(cg.ASSET_GROUP_ = 'C4ITC', ai.DEVICE_NAME_, null)                                                                                                    as DeviceName
          , iif(cg.ASSET_GROUP_ = 'C4ITC', ai.MAC_, null)                                                                                                            as Mac
          , aus.ID_                                                                          as SourceId
          , aus.VERSION_                                                                                         as SourceVersion 
          , aus.NAME_                                                                            as Source
          , aus.DESCRIPTION_                                                                         as SourceDescription
          , aus.IS_ACTIVE_                                                                       as SourceIsActive
          , cast(iif(aus.ID_ is null, 0, 1) as bit)                                                          as SourceIsUsedInAsset
          , ai.SOURCE_REMARKS_                                                                       as SourceRemarks 
          , SerilizedLocationInfo.ItemCondition                                                                                                                      as ItemCondition
          , SerilizedLocationInfo.Command                                                                                                                            as Command
          , SerilizedLocationInfo.BusinessUnit                                                                                                                       as BusinessUnit
          , SerilizedLocationInfo.LocationGroup                                                                                                                      as LocationGroup
          , SerilizedLocationInfo.[Location]                                                                                                                         as [Location]
          , SerilizedLocationInfo.LocationId                                                                                                                         as LocationId
          , SerilizedLocationInfo.Agl2                                                                                                                               as Agl2
          , SerilizedLocationInfo.NonserializedMultipleImv                                                                                                           as NonserializedMultipleImv
          --, iif(cg.ASSET_GROUP_ = 'C4ITC' and (pbo.pbo_HR_USR_PRF_ID_ IS NOT NULL OR pbo.pbo_SR_USR_PRF_ID_ IS NOT NULL), AssetTran.IsInternet, cast(0 as bit))      as ConnectivityIsInternet
          --, iif(cg.ASSET_GROUP_ = 'C4ITC' and (pbo.pbo_HR_USR_PRF_ID_ IS NOT NULL OR pbo.pbo_SR_USR_PRF_ID_ IS NOT NULL), AssetTran.IsIntranet, cast(0 as bit))      as ConnectivityIsIntranet
          , (
                case AssetTran.Connectivity
                    when 'VtcZagil' then 'VTC-ZAGIL'
                    when 'C4IDcc' then 'C4I - DCC'
                    when 'EadgeT' then 'EADGE-T'
                    when 'FileShare' then 'FILE SHARE'
                    when 'ImdadArSystem' then 'IMDAD-AR SYSTEM'
                    when 'AlarmSystemHdhd' then 'ALARM SYSTEM-HDHD'
                    when 'FalconView' then 'FALCON VIEW'                    
                    else upper(AssetTran.Connectivity)
                end         
            )                                                                                                                                                        as Connectivity
          , iif(cg.ASSET_GROUP_ = 'C4ITC' and (pbo.pbo_HR_USR_PRF_ID_ IS NOT NULL OR pbo.pbo_SR_USR_PRF_ID_ IS NOT NULL), AssetTran.WallPort, null)                  as WallPort
          , iif(cg.ASSET_GROUP_ = 'C4ITC' and (pbo.pbo_HR_USR_PRF_ID_ IS NOT NULL OR pbo.pbo_SR_USR_PRF_ID_ IS NOT NULL), AssetTran.SwitchPort, null)                as SwitchPort
          , AssetTran.TransactionId                                                                                                                                  as MovementId
          , AssetTran.TransactionNo                                                                                                                                  as MovementNo
          , AssetTran.AttachmentId                                                                                                                                   as MovementDocumentId
          , AssetTran.UseDigitalSign                                                                                                                                 as MovementUseDigitalSign
          , case when act_tx.MovementType = 'AssignAsset' or act_tx.MovementType = 'AssetTransfer' then act_tx.hrUserProfileId else HR.ID_ end                       as HandReceiptId
          , case when act_tx.MovementType = 'AssignAsset' or act_tx.MovementType = 'AssetTransfer' then act_tx.hrUserId else HR.USER_ID_ end                         as HandReceipt
          , case when act_tx.MovementType = 'AssignAsset' or act_tx.MovementType = 'AssetTransfer' then act_tx.hrFullName else (HR.F_NAME_ + ' ' + HR.L_NAME_) end   as HandReceiptName
          , case when act_tx.MovementType = 'AssignAsset' or act_tx.MovementType = 'AssetTransfer' then act_tx.srUserProfileId else SHR.ID_ end                      as EndUserId
          , case when act_tx.MovementType = 'AssignAsset' or act_tx.MovementType = 'AssetTransfer' then act_tx.srUserId else SHR.USER_ID_ end                        as EndUser
          , case when act_tx.MovementType = 'AssignAsset' or act_tx.MovementType = 'AssetTransfer' then act_tx.srFullName else (SHR.F_NAME_ + ' ' + SHR.L_NAME_) end as EndUserName
          , act_tx.Id                                                                                                                                                as ActiveTransactionId
          , act_tx.IsActive                                                                                                                                          as HasActiveTransaction
          , case act_tx.MovementType when 'AssignAsset' then 'Assignment' when 'AssetTransfer' then 'Transfer' when 'AssetReturn' then 'Return' end                  as ActiveTransactionType
          , act_tx.UseDigitalSign                                                                                                                                    as ActiveTransactionUseDigitalSign
          , ai.IS_RESERVED_                                                                                                                                          as IsReserved
          , ai.RESERVATION_RMKS_                                                                                                                                     as ReservationRemarks
          , ai.RESERVED_BY_USER_PROFILE_ID_                                                                                                                          as ReservedByUserProfileId
          , rsvBy.USER_ID_ + ' - ' + rsvBy.F_NAME_ + ' ' + rsvBy.L_NAME_                                                                                             as ReservedBy
          , (case 
                when i.SERIALIZE_TYPE_ = 'ByManufacturer' then 'YES (BY MANUFACTURER)'
                when i.SERIALIZE_TYPE_ = 'ByJac' then 'YES (BY JAC)' else 'NO' end)                                                                                  as Serialized        
          , psc.PrinterSubcategory                                                                                                                                   as PrinterSubcategory
          , cp.ColorProfile                                                                                                                                          as ColorProfile
          , case when ai.ASSET_EXT_LOAN_ID is not null then 'YES' else 'NO' end                                                                                      as IsExternalLoan
          , aels.NAME_                                                                                                                                               as LoanedFrom
          , aels.DESCRIPTION_                                                                                                                                        as LoanedFromDescription
        from LOG_TRN_ASM_PBO as pbo
                 left join ADM_MST_BUSINESS_UNITS own on own.ID_ = pbo.ASSIGNED_TO_BU_
                 left join ADM_TRN_USER_PROFILES as hr on pbo.PBO_HR_USR_PRF_ID_ = hr.ID_
                 left join ADM_TRN_USER_PROFILES as shr on pbo.PBO_SR_USR_PRF_ID_ = shr.ID_
                 left join ADM_TRN_USER_PROFILES as mhr on mhr.ID_ = own.MASTER_HAND_RECEIPT_ID_
                 left join ADM_MST_BUSINESS_UNITS as asgbu on pbo.ASSIGNED_TO_BU_ = asgbu.ID_
                 left join LOG_MST_ASM_WARNING_INDICATOR w on w.CMD_ID = pbo.CMD_ID_
                 join ADM_MST_RESTRICTIONS as cmd on PBO.CMD_ID_ = cmd.ID_
                 join ADM_MST_UNITS as u on PBO.UNIT_ID_ = u.ID_
                 left join ADM_MST_UNITS_ASSET_INFO as ai on ai.ID_ = u.ID_
                 left join LOG_TRN_ASM_EXTERNAL_LOANS ael on ael.ID_ = ai.ASSET_EXT_LOAN_ID
                 left join LOG_MST_ASM_UNIT_SOURCE aels on aels.ID_ = ael.UNIT_SOURCE_ID
                 left join LOG_MST_ASM_UNIT_SOURCE as aus on aus.ID_ = ai.SOURCE_ID
                 left join LOG_TRN_UNIT_ID_MANAGEMENT as unid on unid.UNIT_ID = u.ID_
                 join ADM_MST_ITEMS as i on u.ITEM_ID = i.ID_

                 left join (
                    select i.ID_ as ItemId, attv.VALUE_ as PrinterSubcategory 
                    from ADM_MST_ITEMS as i
                    inner join ADM_XRF_ITEM_SPECIFICATION_ATTRIBUTE as iatt on iatt.ITEM_SPEC_ID = i.ID_
                    inner join ADM_MST_SPECIFICATION_ATTRIBUTES as patt on patt.ID_ = iatt.ATTR_ID
                    inner join ADM_MST_SPECIFICATION_ATTRIBUTES as attv on attv.ID_ = iatt.VALUE_ID
                    where patt.PARENT_ID is null and patt.VALUE_ = 'Printer Sub-Category') as psc on psc.ItemId = i.ID_

                left join(
                    select i.ID_ as ItemId, attv.VALUE_ as ColorProfile 
                    from ADM_MST_ITEMS as i
                    inner join ADM_XRF_ITEM_SPECIFICATION_ATTRIBUTE as iatt on iatt.ITEM_SPEC_ID = i.ID_
                    inner join ADM_MST_SPECIFICATION_ATTRIBUTES as patt on patt.ID_ = iatt.ATTR_ID
                    inner join ADM_MST_SPECIFICATION_ATTRIBUTES as attv on attv.ID_ = iatt.VALUE_ID
                    where patt.PARENT_ID is null and patt.VALUE_ = 'Color Profile' 
                ) as cp on cp.ItemId = i.ID_

                 left join LOG_TRN_ASM_ASSET_CLASSIFICATION ascls on ascls.CMD_ID_ = pbo.CMD_ID_ and ascls.ITEM_ID_ = i.ID_
                 join ADM_MST_MANUFACTURES as m on i.MNF_ID = m.ID_
                 join LOG_MST_UNIT_OF_MEASURE as uom on uom.ID_ = i.UOM_ID_
                 join ADM_MST_SIMPLE_REF as cls on cls.ID_ = i.CLS_ID_
                 left join ADM_MST_SIMPLE_REF as sref on i.CAT_ID_ = sref.ID_ and sref.GRP_ = 'LOG.CAT'
                 left join ADM_MST_SIMPLE_REF as sbcat on i.SUB_CAT_ID_ = sbcat.ID_
                 left join ADM_MST_SIMPLE_REF as tocat on i.TOOL_TYPE_ID_ = tocat.ID_
                 left join ADM_MST_ITEM_CATEGORY_GROUP cg on cg.CAT_ID = i.CAT_ID_
                 left join ADM_TRN_USER_PROFILES rsvBy on rsvBy.ID_ = ai.RESERVED_BY_USER_PROFILE_ID_
                 outer apply (select top(1)
                                  UnitId
                                , BusinessUnitId
                                , ItemCondition
                                , Command
                                , BusinessUnit
                                , LocationGroup
                                , [Location]
                                , LocationId
                                , Agl2
                                , case when totalRow > 1 then 'Multiple' else 'Single' end as NonserializedMultipleImv
                              from (select
                                        count(unt.ID_) over ()                                                      as totalRow
                                      , unt.ID_                                                                     as UnitId
                                      , mbu.ID_                                                                     as BusinessUnitId
                                      , tag.CONDITION_                                                              as ItemCondition
                                      , res.CODE_                                                                   as Command
                                      , case when cmdres.TYPE_ID_ is null then '' else mbu.CODE_ end                as BusinessUnit
                                      , case
                                            when cmdres.TYPE_ID_ is null then ''
                                            else (case ulo.LOC_TYPE_ when 'Regular' then ulg.NAME_ else '' end) end as LocationGroup
                                      , case
                                            when cmdres.TYPE_ID_ is null then ''
                                            else (case ulo.LOC_TYPE_ when 'Regular' then ulo.NAME_ else '' end) end as [Location]
                                      , case
                                            when cmdres.TYPE_ID_ is null then ''
                                            else (case ulo.LOC_TYPE_ when 'Regular' then ulo.ID_ else '' end) end   as LocationId
                                      , ag.CODE_                                                                    as Agl2
                                    from ADM_TRN_IMV_ITEMS_IN_LOCATION imv
                                             join ADM_MST_TAG_COLOR_CONDITION as tag on tag.ID_ = imv.TC_ID_
                                             join adm_mst_units unt on imv.unit_id_ = unt.id_
                                             join adm_mst_items itm on unt.item_id = itm.id_ and itm.SERIALIZED_ = 1
                                             join ADM_MST_UNIT_LOCATION as ulo on imv.LOC_ID_ = ulo.ID_
                                             join ADM_MST_UNIT_LOCATION_GROUP as ulg on ulo.LG_ID = ulg.ID_
                                             join ADM_MST_BUSINESS_UNITS as mbu on ulg.BU_ID = mbu.ID_
                                             join ADM_MST_RESTRICTIONS as res on mbu.CMD_ID_ = res.ID_
                                             join ADM_TRN_ASSOC_GROUPS ag on ag.ID_ = imv.OWNED_L2_ID_

                                             outer apply
                                         (select distinct dacl.TYPE_ID_ as TYPE_ID_
                                          from ADM_TRN_SEC_ROLE_ACL_DETAIL dacl
                                                   inner join ADM_TRN_SEC_ROLE_ACL roleacl
                                                              on dacl.ROLE_ACL_ID = roleacl.id_ and roleacl.MDL_ID = 'LOG.004.00.00.00'
                                                   inner join dbo.ADM_TRN_SEC_ROLE role on roleacl.ROLE_ID = role.id_
                                                   inner join ADM_TRN_SEC_ROLE_ASSIGNMENT roleassignment
                                                              on roleassignment.ROLE_ID = role.id_ and
                                                                 roleassignment.USR_PRF_ID = @userProfileId
                                                   inner join ADM_MST_RESTRICTIONS as r1 on dacl.TYPE_ID_ = r1.ID_
                                          where dacl.type_ = 'MilitaryUnit'
                                            and r1.TYPE_NAME_ = 'Command'
                                            and dacl.TYPE_ID_ = res.ID_
                                         ) as cmdres
                                    where unt.ID_ = u.ID_) x
                    ) as SerilizedLocationInfo
                 outer apply(select top(1)
                                 tx.ID_               as TransactionId
                               , tx.PBO_MOVEMENT_NO_  as TransactionNo
                               , tx.PBO_DOCUMENT_ID_  as AttachmentId
                               , tx.USE_DIGITAL_SIGN_ as UseDigitalSign
                               , txi.IS_INTERNET_     as IsInternet
                               , txi.IS_INTRANET_     as IsIntranet
                               , txi.WALL_PORT_       as WallPort
                               , txi.SWITCH_PORT_     as SwitchPort
                               , txi.CONNECTIVITY_    as Connectivity
                             from LOG_TRN_ASM_ASSET_TRANSACTION tx
                                      join
                                  LOG_TRN_ASM_ASSET_TRANSACTION_ITEM txi on txi.TR_ID = tx.ID_
                             where txi.UNIT_ID = u.ID_
                             group by txi.UNIT_ID, tx.ID_
                                    , tx.PBO_MOVEMENT_NO_, tx.PBO_DOCUMENT_ID_, tx.USE_DIGITAL_SIGN_
                                    , txi.IS_INTERNET_, txi.IS_INTRANET_, txi.WALL_PORT_, txi.SWITCH_PORT_
                                    , tx.STATUS_, tx.DATE_, tx.CREATED_ON_, txi.CONNECTIVITY_
                             having tx.STATUS_ = 'Closed'
                                and txi.UNIT_ID is not null
                                and tx.DATE_ = max(tx.DATE_)
                             order by tx.CREATED_ON_ desc
                    ) as AssetTran
                 outer apply (select distinct top(1)
                                  tx.ID_                                                                          as Id
                                , txi.UNIT_ID                                                                     as UnitId
                                , (case when txi.UNIT_ID is not null then cast(1 as bit) else cast(0 as bit) end) as IsActive
                                , tx.PBO_MOVEMENT_TYPE_                                                           as MovementType
                                , hr.ID_                                                                          as hrUserProfileId
                                , hr.USER_ID_                                                                     as hrUserId
                                , (hr.F_NAME_ + ' ' + hr.L_NAME_)                                                 as hrFullName
                                , shr.ID_                                                                         as srUserProfileId
                                , shr.USER_ID_                                                                    as srUserId
                                , (shr.F_NAME_ + ' ' + shr.L_NAME_)                                               as srFullName
                                , tx.USE_DIGITAL_SIGN_                                                            as UseDigitalSign
                              from LOG_TRN_ASM_ASSET_TRANSACTION_ITEM txi
                                       join LOG_TRN_ASM_ASSET_TRANSACTION tx on tx.ID_ = txi.TR_ID
                                       left join ADM_TRN_USER_PROFILES hr on hr.ID_ = tx.TO_HR_
                                       left join ADM_TRN_USER_PROFILES shr on shr.ID_ = isnull(tx.TO_EU_, txi.TO_SHR_ID_)
                              where tx.STATUS_ not in ('Closed', 'Rejected')
                                --and txi.UNIT_ID = pbo.UNIT_ID_
                                and txi.PBO_ID_ = pbo.ID_
                                and tx.PBO_MOVEMENT_TYPE_ in ('AssignAsset', 'AssetTransfer', 'AssetReturn')) as act_tx
                 where pbo.QTY_ > 0              
)
go

