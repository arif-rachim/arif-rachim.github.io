CREATE PROCEDURE ConsumptionHistory_BuildIndex 
AS
BEGIN
	--rebuild indexes since heavy batch operations are done
    --the scheduled maintenance plan actions will be overwritten by this procedure when it runs every night and do the heavy operations
    alter index all on [dbo].[LOG_TRN_ITEM_CATALOG_PRICE_SNAPSHOT] rebuild;
    alter index all on [dbo].[LOG_TRN_ITEM_QUANTITY_SNAPSHOT] rebuild;
    alter index all on [dbo].[LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE] rebuild;
    alter index all on [dbo].[LOG_TRN_ITEM_CONSUMPTION_HISTORY] rebuild;
    alter index all on [dbo].[LOG_TRN_ITEM_CONSUMPTION_HISTORY_ROLLUP] rebuild;
    alter index all on [dbo].[LOG_TRN_RPT_CONSUMPTION_HISTORY_LOG] rebuild;
    alter index all on [dbo].[LOG_TRN_ITEM_REF_PRICE_SNAPSHOT] rebuild;
	
END
go

