CREATE FUNCTION dbo.GetSupAddress(@SupAddress NVARCHAR(MAX), @LineNumber INT) RETURNS VARCHAR(MAX)
BEGIN
	IF @SupAddress IS NULL OR @LineNumber < 1 RETURN NULL;
	DECLARE @retValue VARCHAR(MAX) = NULL;
	DECLARE @sep CHAR = CHAR(10);
	DECLARE @cnt INT = 0;
	DECLARE @idx INT = 0;
	DECLARE @start INT = 1;
	WHILE @cnt < @LineNumber
	BEGIN
		SET @cnt = @cnt + 1;
		SET @start = @idx + 1;
		SET @idx = CHARINDEX(@sep, @SupAddress, @start);
		IF @idx = 0
		BEGIN
			BREAK
		END
	END
	IF @cnt < @LineNumber RETURN NULL
	DECLARE @len INT = LEN(@SupAddress) - @start + 1;
	IF @idx > 0
	BEGIN
		SET @len = @idx - @start;
	END
	IF @len < 1 RETURN '';
	RETURN SUBSTRING(@SupAddress, @start, @len);
END
go

