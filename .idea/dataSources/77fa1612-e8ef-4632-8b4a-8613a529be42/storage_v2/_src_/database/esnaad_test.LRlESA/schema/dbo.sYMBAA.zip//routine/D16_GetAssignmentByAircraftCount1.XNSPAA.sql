CREATE    FUNCTION [dbo].[D16_GetAssignmentByAircraftCount1](@masterComponentId uniqueidentifier,
                                                         @aircraftUnitId bigint)
    RETURNS int
AS
BEGIN
    DECLARE @result int = 0;
       DECLARE @master_comp_id uniqueidentifier;
       DECLARE @aircraft_unit_id bigint;

       set @master_comp_id = @masterComponentId;
       set @aircraft_unit_id = @aircraftUnitId;


    SELECT @result = count(ac.ID_)
    FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
             join MNT_MST_D16_MASTER_COMPONENT m on m.ID_ = ac.MASTER_COMP_ID_
    WHERE ac.IS_ACTIVE_ = 1
      AND ac.REM_DATE_ IS NULL
      AND ac.ACFT_UNIT_ID_ = @aircraft_unit_id
--      AND (ac.MASTER_COMP_ID_ =@master_comp_id or ac.MASTER_COMP_ID_ in (
      AND (exists (
        select @master_comp_id where @master_comp_id=ac.MASTER_COMP_ID_ 
              union all
              select m2.ID_
        from MNT_MST_D16_MASTER_COMPONENT m1
                 join MNT_MST_D16_MASTER_COMPONENT m2 on m1.CMD_ID_ = m2.CMD_ID_ and m1.PLTF_ID = m2.PLTF_ID and
                                                         m1.MAJOR_END_ITEM_ID_ = m2.MAJOR_END_ITEM_ID_ and
                                                         (m1.PRNT_WUC_ID_ = m2.PRNT_WUC_ID_ or
                                                          (m1.PRNT_WUC_ID_ is null and m2.PRNT_WUC_ID_ is null)) and
                                                         m1.WUC_ID_ = m2.WUC_ID_ and
                                                         m1.ASSIGNMENT_ALLOWED_ = m2.ASSIGNMENT_ALLOWED_ and
                                                         m1.ASSIGNMENT_REQUIRED_ = m2.ASSIGNMENT_REQUIRED_
                 --join ADM_MST_ITEMS i on i.ID_ = m2.COMP_ITEM_ID_
                 join ADM_MST_PLATFORM_L2 pl2 on pl2.CMD_ID_ = m2.CMD_ID_ and pl2.PLTF_ID_ = m2.PLTF_ID
                 join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = m2.COMP_ITEM_ID_ and ia.L2_ID = pl2.L2_ID_
         --join ADM_MST_PLATFORM_L2 pl2_m1 on pl2_m1.CMD_ID_ = m1.CMD_ID_ and pl2_m1.PLTF_ID_ = m1.PLTF_ID
         --join ADM_TRN_ITEM_ASSOCS ia_m1 on ia_m1.ITEM_ID = m1.COMP_ITEM_ID_ and ia_m1.L2_ID = pl2_m1.L2_ID_
         join ADM_TRN_ITEM_ASSOCS ia_m1 on ia_m1.ITEM_ID = m1.COMP_ITEM_ID_ and ia_m1.L2_ID = pl2.L2_ID_
        where m1.ID_ = @master_comp_id
          --and ia.IN_LIEU_CODE_ is not null
          --and ia.IN_LIEU_CODE_ = (select ia_2.IN_LIEU_CODE_
          --                from ADM_TRN_ITEM_ASSOCS ia_2
          --                where ia_2.ITEM_ID = m1.COMP_ITEM_ID_
          --                  and ia_2.L2_ID = ia_m1.L2_ID)
          and ia.IN_LIEU_CODE_ = ia_m1.IN_LIEU_CODE_
		  and @master_comp_id=ac.MASTER_COMP_ID_
    ))

    RETURN @result
END
go

