CREATE VIEW [dbo].[VW_LOG_TRN_ITEM_CONSUMPTION_HISTORY_ROLLUP]
AS

SELECT	itemAssoc.PRIMARY_ITEM_ID AS ITEM_ID, 
		consumption.ParamCmdId AS CMD_ID, 
		consumption.ParamBu AS BU_ID_, 
		consumption.ParamAgl2 AS L2_ID_, 
		consumption.ConsYear AS YEAR, 
        consumption.ConsMonth AS MONTH_, 
		consumption.ConsFirstDay AS FIRST_DAY_, 
		SUM(consumption.TotIssue) AS TOTAL_ISSUE_, 
		SUM(consumption.TotRegularizedQty) AS REGULARIZED_QTY_, 
		SUM(consumption.TotTurnIn) AS TOTAL_TURN_IN_, 
		consumption.ParamPlatform AS PLTF_ID_, 
        SUM(consumption.TotScheduleIssue) AS TOTAL_SCHEDULE_ISSUE_
FROM	(
			SELECT	CH.ITEM_ID AS ItemId, 
					CH.CMD_ID AS ParamCmdId, 
					ISNULL(BU.PARENT_STORE_ID_, CH.BU_ID_) AS ParamBu, 
					CH.L2_ID_ AS ParamAgl2, 
					CH.YEAR AS ConsYear, 
					CH.MONTH_ AS ConsMonth, 
                       CH.FIRST_DAY_ AS ConsFirstDay, 
					ISNULL(SUM(CH.TOTAL_ISSUE_),0) AS TotIssue,  
					ISNULL(SUM(CH.REGULARIZED_QTY_),0)  AS TotRegularizedQty, 
					ISNULL(SUM(CH.TOTAL_TURN_IN_),0)  AS TotTurnIn, 
					CH.PLTF_ID_ AS ParamPlatform, 
					ISNULL(SUM(CH.TOTAL_SCHEDULE_ISSUE_),0)  AS TotScheduleIssue
			FROM	(select * from dbo.LOG_TRN_ITEM_CONSUMPTION_HISTORY union all select * from dbo.LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE) AS CH 
					INNER JOIN dbo.ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_
			WHERE	(BU.BU_TYPE_ = 'Store')
			GROUP	BY CH.ITEM_ID, CH.CMD_ID, CH.BU_ID_, BU.PARENT_STORE_ID_, CH.L2_ID_, CH.PLTF_ID_, CH.YEAR, CH.MONTH_, CH.FIRST_DAY_
		) AS consumption 
		INNER JOIN
		(
		SELECT	ITEM_ID, 
				L2_ID, ITEM_ID AS PRIMARY_ITEM_ID
		FROM	dbo.ADM_TRN_ITEM_ASSOCS AS itemAssoc
		WHERE	(IN_LIEU_CODE_ IS NULL) 
				AND (PRIMARY_PART_ = 1)
		UNION ALL
		SELECT	itemAssoc.ITEM_ID, 
				itemAssoc.L2_ID,
                ilItemAssoc.ITEM_ID AS PRIMARY_ITEM_ID
		FROM	dbo.ADM_TRN_ITEM_ASSOCS AS itemAssoc
				join dbo.ADM_TRN_ITEM_ASSOCS AS ilItemAssoc on itemAssoc.IN_LIEU_CODE_ = ilItemAssoc.IN_LIEU_CODE_
		WHERE	(itemAssoc.IN_LIEU_CODE_ IS NOT NULL) 
				AND ilItemAssoc.PRIMARY_PART_ = 1
		) AS itemAssoc ON itemAssoc.ITEM_ID = consumption.ItemId 
					AND	itemAssoc.L2_ID = consumption.ParamAgl2
GROUP BY itemAssoc.PRIMARY_ITEM_ID, consumption.ParamCmdId, consumption.ParamBu, consumption.ParamAgl2, consumption.ConsYear, consumption.ConsMonth, consumption.ConsFirstDay, consumption.ParamPlatform
go

