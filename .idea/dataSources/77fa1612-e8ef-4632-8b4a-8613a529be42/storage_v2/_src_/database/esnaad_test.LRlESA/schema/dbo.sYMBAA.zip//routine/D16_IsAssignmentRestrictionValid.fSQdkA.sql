CREATE FUNCTION [dbo].[D16_IsAssignmentRestrictionValid]
(
    @assignedComponentId uniqueidentifier
)
    RETURNS bit
AS
BEGIN
    DECLARE @result bit = 0;
	declare @_assignedComponentId uniqueidentifier
	set @_assignedComponentId=@assignedComponentId
    SELECT @result =
           (CASE WHEN IsRemoved = 1 OR Assignment >= Required AND Assignment <= Allowed THEN cast(1 AS bit) ELSE cast(0 AS bit) END)
    FROM (
             SELECT mc.ASSIGNMENT_ALLOWED_                                         AS Allowed
                  , mc.ASSIGNMENT_REQUIRED_                                        AS Required
                  , dbo.D16_GetAssignmentByAircraftCount1(mc.ID_, ac.ACFT_UNIT_ID_) AS Assignment
                  , CASE WHEN ac.IS_ACTIVE_ = 0 or ac.REM_DATE_ is not null or ac.ACFT_UNIT_ID_ is null
                      THEN 1 ELSE 0 END                                            AS IsRemoved
             FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
                      JOIN MNT_MST_D16_MASTER_COMPONENT mc ON ac.MASTER_COMP_ID_ = mc.ID_
             WHERE ac.ID_ = @assignedComponentId) AS AssignmentRestriction

    RETURN @result
END
go

