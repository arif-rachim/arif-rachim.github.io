CREATE FUNCTION [dbo].[GetAchievedRequirementHours]
(
	@crewId bigint,
	@platformId bigint,
	@month int,
	@year int,
	@includeExtraHours bit
)
RETURNS int
AS
BEGIN
	DECLARE @result int
	SELECT @result = SUM(IIF(@includeExtraHours=0, dbo.Min(isnull(RequiredHours,0), isnull(AchievedHours,0)), isnull(AchievedHours,0)) * 60)
					from(
							select  cmpr.REQUIREMENT_ID  as RequirementId,req.Code_ as  RequirementCode ,
								sum(requirments.RequiredHours) as RequiredHours
							from OPS_TRN_CTP_CREW_MONTHLY_PLAN cmp
								inner join OPS_TRN_CTP_CREW_MONTHLY_PLAN_REQUIREMENT cmpr on cmpr.CREW_MONTHLY_PLAN_ID = cmp.ID_
								inner join OPS_TRN_CTP_MONTHLY_PLAN mpl on mpl.ID_=cmp.MONTHLY_PLAN_ID
								inner join OPS_TRN_CTP_REQUIREMENT_SNAP req on req.id_=cmpr.REQUIREMENT_ID
								outer apply (					
									select   sum(icmpr.MINUTES_) as RequiredHours
									from  OPS_TRN_CTP_CREW_MONTHLY_PLAN_REQUIREMENT icmpr 
									where    icmpr.ID_=cmpr.ID_
									group by icmpr.REQUIREMENT_ID
								) requirments 
							where mpl.PLTF_ID_ = @platformId and mpl.MONTH_ = @month and mpl.YEAR_ = @year and cmp.CREW_ID = @crewId and mpl.STATUS_ = 'APPROVED'
							group by  cmpr.REQUIREMENT_ID,	req.Code_
						)req outer Apply
						(   SELECT sum(isnull(HoursInMins,0)) as AchievedHours
							FROM (
								SELECT DISTINCT   PR.ID_ AS Id,  V.CompanyId AS CompanyId,V.PlatformId as PlatformId,
										PR.HOURS_IN_MINS_ AS HoursInMins
								FROM OPS_TRN_CREW_PERFORMED_REQUIREMENTS PR
									JOIN OPS_TRN_CTP_CREW_MONTHLY_PLAN_REQUIREMENT MPR ON MPR.ID_ = PR.RECORDED_PLANNED_REQ_ID AND MPR.MINUTES_>0 
									JOIN OPS_TRN_CTP_CREW_MONTHLY_PLAN cmp on  cmp.ID_=MPR.CREW_MONTHLY_PLAN_ID
									JOIN OPS_TRN_CTP_MONTHLY_PLAN mpl on mpl.ID_=cmp.MONTHLY_PLAN_ID
									JOIN OPS_TRN_FLIGHTS F ON F.ID_ = PR.FLIGHT_ID 
									JOIN OPS_TRN_MISSIONS M ON M.ID_ = F.MISSION_ID
									JOIN OPS_MST_MISSION_SUB_TYPES MST ON MST.ID_ = M.MISS_SUB_TYPE_ID
									JOIN OPS_MST_MISSION_TYPES MT ON MT.ID_ = MST.MISS_TYPE_ID
									JOIN OPS_MST_MISSION_SYMBOL MS ON MS.ID_ = MT.MISS_SYMBOL_ID
									JOIN OPS_TRN_TAIL_FLIGHT TF ON TF.FLIGHT_ID = PR.FLIGHT_ID
									JOIN OPS_TRN_TAIL_FLIGHT_RECORD TFR ON TFR.TAIL_FLIGHT_ID = TF.ID_
									JOIN VW_OPS_CREW_FLYING_RECORD_LIST V ON V.FlightRecordId = TFR.ID_
									JOIN WF_TRN_INSTANCE WF ON WF.ID_ = M.WF_ID AND WF.WF_DEF_ID_='MissionWorkflow'
								WHERE MPR.REQUIREMENT_ID = req.RequirementId
									AND MT.IS_COURSE_TRAINING_ = 0 AND MS.CODE_='T' AND PR.CREW_ID = cmp.CREW_ID
									AND WF.WF_STATE_ IN ('Accomplished','InCorrection','Verified','Debriefed')
									AND mpl.PLTF_ID_ = @platformId AND mpl.MONTH_ = @month and mpl.YEAR_= @year and cmp.CREW_ID  = @crewId
							) AS X
						) Achieved
	RETURN @result 
END
go

