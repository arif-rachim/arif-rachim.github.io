CREATE FUNCTION [dbo].[D161GetForecastReportByTail]
  (
    @commandId int,
    @platformId int,
    @battalionId int,
    @tailId bigint,
    @itemId bigint,
    @nomenclature varchar(250),
    @hrs real,
    @landing int,
    @cValueMonth int,
    @cValueYear int
    )
  RETURNS TABLE
    AS
    RETURN
    WITH cte AS (
		SELECT 
			TAILS.T_NUM_                                                              AS TailNo
			,dbo.ReturnTAAMSTime(USAGE.TOT_FLIGHT_MINS_)                              AS Hrs
           ,USAGE.LANDINGS_                                                           AS Landing
           ,ISNULL(nha_item.NOMENCLATURE_, compitem.NOMENCLATURE_)                    AS Part_Desc
           ,ISNULL(nha_item.PART_NO_, COMPITEM.PART_NO_)                              AS Part_No
		   ,ISNULL(nha_mnf.CAGE_CODE_, COMPITEM_MNF.CAGE_CODE_)                       AS MFR
           ,ISNULL(nha_unit.SERIAL_NO_, COMPUNIT.SERIAL_NO_)                          AS Unit_Serial_No
           ,COMPITEM.ID_                                                              AS Item_Id
		   , 0																		  AS FltHours
		   ,COMNPONENT.INST_DATE_													  AS caldate1
		   ,0																		  AS FltLdgs
           ,PL2.L2_ID_                                                                AS L2Id                                                  
		   ,'OverDue'																  AS DueStatus
		   , mc.REPLACE_ - COMNPONENT.CUR_OP_HRS_                                     AS ReplaceRemaining
       FROM  MNT_TRN_D16_1_ASSIGNMENT COMNPONENT
	   INNER JOIN MNT_TRN_D16_1_MASTER mc ON mc.ID_ = COMNPONENT.MASTER_ID
			
            INNER JOIN ADM_MST_UNITS AS COMPUNIT ON COMPUNIT.ID_ = COMNPONENT.COMP_UNIT_ID
            INNER JOIN ADM_MST_ITEMS AS COMPITEM ON COMPITEM.ID_ = COMPUNIT.ITEM_ID
			LEFT JOIN ADM_MST_MANUFACTURES COMPITEM_MNF on COMPITEM_MNF.ID_=COMPITEM.MNF_ID
            INNER JOIN ADM_MST_MANUFACTURES AS COMPSMFR ON COMPSMFR.ID_ = COMPITEM.MNF_ID
            INNER JOIN ADM_MST_TAILS AS TAILS ON TAILS.UNIT_ID = COMNPONENT.END_ACFT_UNIT_ID
			INNER JOIN ADM_MST_RESTRICTIONS AS b ON b.ID_ = TAILS.BATLN_ID
            INNER JOIN ADM_MST_RESTRICTIONS AS RST ON RST.ID_ = TAILS.BATLN_ID
            INNER JOIN ADM_MST_RESTRICTIONS AS CMD ON RST.PRNT_ID = CMD.ID_
            INNER JOIN ADM_MST_UNITS AS units1 ON units1.ID_ = TAILS.UNIT_ID
            INNER JOIN ADM_MST_ITEMS AS items1 ON items1.ID_ = units1.ITEM_ID
            INNER JOIN ADM_MST_PLATFORMS AS PLATFORMS ON items1.ID_ = PLATFORMS.ID_
            INNER JOIN ADM_MST_PLATFORM_L2 AS PL2 ON PL2.CMD_ID_ = mc.CMD_ID AND PL2.PLTF_ID_ = PLATFORMS.ID_
            LEFT JOIN ADM_TRN_UNIT_USAGE AS USAGE ON USAGE.UNIT_ID_ = units1.ID_            
            LEFT JOIN ADM_MST_UNITS nha_unit ON nha_unit.ID_ = COMNPONENT.COMP_UNIT_ID
            LEFT JOIN ADM_MST_ITEMS nha_item ON nha_item.ID_ = nha_unit.ITEM_ID 
			LEFT JOIN ADM_MST_MANUFACTURES nha_mnf on nha_mnf.ID_=nha_item.MNF_ID
			WHERE cmd.ID_ = @commandId                   
                   AND TAILS.ID_ = (CASE WHEN @tailId > 0 THEN @tailId ELSE TAILS.ID_ END)
                   AND (@battalionId = 0 OR TAILS.UNIT_ID IN (SELECT ADM_MST_TAILS.UNIT_ID
                                                          FROM ADM_MST_TAILS
                                                          WHERE ADM_MST_TAILS.BATLN_ID = b.ID_))
                   AND (@platformId = 0 OR TAILS.UNIT_ID IN (SELECT ADM_MST_TAILS.UNIT_ID
                                                         FROM ADM_MST_TAILS
                                                                INNER JOIN
                                                              ADM_MST_RESTRICTIONS
                                                              ON ADM_MST_TAILS.BATLN_ID = ADM_MST_RESTRICTIONS.ID_
                                                                INNER JOIN
                                                              ADM_MST_UNITS AS ADM_MST_UNITS_1
                                                              ON ADM_MST_TAILS.UNIT_ID = ADM_MST_UNITS_1.ID_
                                                                INNER JOIN
                                                              ADM_MST_ITEMS AS ADM_MST_ITEMS_1
                                                              ON ADM_MST_UNITS_1.ITEM_ID = ADM_MST_ITEMS_1.ID_
                                                         WHERE (ADM_MST_RESTRICTIONS.PRNT_ID = cmd.ID_)
                                                           AND (ADM_MST_ITEMS_1.ID_ = PLATFORMS.ID_))
                   )
                
				AND RST.ID_ = (CASE WHEN @battalionId > 0 THEN @battalionId  ELSE RST.ID_ END)
			    AND PLATFORMs.ID_ = (CASE WHEN @platformId > 0 THEN @platformId ELSE PLATFORMs.ID_ END)
			    AND (   ISNULL(nha_item.ID_, COMPITEM.ID_) = (CASE WHEN @itemId > 0 THEN @itemId ELSE ISNULL(nha_item.ID_, COMPITEM.ID_) END) 
                OR COMPITEM.ID_ = (CASE WHEN @itemId > 0 THEN @itemId ELSE COMPITEM.ID_ END))
                AND ISNULL(nha_item.NOMENCLATURE_, compitem.NOMENCLATURE_) LIKE
                (CASE WHEN @nomenclature IS NOT NULL THEN ('%' + @nomenclature + '%') ELSE ISNULL(nha_item.NOMENCLATURE_, compitem.NOMENCLATURE_) END)
       )
	   SELECT cte.TailNo
           ,cte.Hrs
           ,cte.Landing
		   ,cte.MFR
		   ,cte.Part_Desc AS OverDueDescription
           ,cte.Part_No   AS OverDuePartNo
           ,cte.Unit_Serial_No  AS OverDueSerialBatchNo
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN NULL
                 WHEN (cte.FltHours < cte.Hrs AND cte.FltHours IS NOT NULL) THEN cte.FltHours
                 ELSE NULL 
             END AS OverDueDueOnHrs
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN NULL
                 WHEN (cte.caldate1 < convert(date, GETDATE()) AND cte.caldate1 IS NOT NULL) THEN cte.caldate1
                 ELSE NULL 
             END AS OverDueDueOnCalender
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN NULL
                 WHEN (cte.FltLdgs < cte.Landing AND cte.FltLdgs IS NOT NULL) THEN cte.FltLdgs
                 ELSE NULL 
             END AS OverDueDueOnLanding
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN cte.Part_Desc      ELSE NULL END AS DueNextDescription
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN cte.Part_No        ELSE NULL END AS DueNextPartNo
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN cte.Unit_Serial_No ELSE NULL END AS DueNextSerialBatchNo
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(cte.FltHours) END AS DueNextDueOnHrs
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(cte.caldate1) END AS DueNextDueOnCalender
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(cte.FltLdgs)  END AS DueNextDueOnLanding
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(round((cte.FltHours - cte.Hrs), 1)) END AS DueNextRemainingHrs
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(DATEDIFF(DAY, GETDATE(), caldate1)) END AS DueNextRemainingDays
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(cte.FltLdgs - cte.Landing)          END AS DueNextRemainingLandings
		   ,cte.ReplaceRemaining
           ,(SELECT STUFF((SELECT ',' + TRNREQUEST1.TR_NO_
               FROM dbo.ADM_MST_TAILS AS TAILS1
                    INNER JOIN dbo.LOG_TRN_TRM_TRANSFER_REQUEST AS TRNREQUEST1 ON TRNREQUEST1.END_ITEM_UNIT_ID_ = TAILS1.UNIT_ID
                    INNER JOIN dbo.LOG_TRN_TRM_TRANSFER_REQUEST_ITEM AS RequestItem1 ON RequestItem1.TR_ID_ = TRNREQUEST1.ID_
              WHERE (TAILS1.T_NUM_ = cte.TailNo)
                AND RequestItem1.ITEM_ID = cte.Item_Id
                AND RequestItem1.FF_STATUS_ IN ('NotFulfilled', 'PartiallyFulfilled')
              ORDER BY TRNREQUEST1.TR_NO_ FOR XML PATH ('')), 1, 1, '')) AS RequestNo
           ,(SELECT ISNULL(SUM(STOCK1.QTY_), 0) AS Qty
               FROM LOG_TRN_STOCK AS STOCK1
                    INNER JOIN ADM_MST_UNIT_LOCATION ON STOCK1.LOC_ID = ADM_MST_UNIT_LOCATION.ID_
                    LEFT OUTER JOIN ADM_MST_UNITS AS UNIT1 ON UNIT1.ID_ = STOCK1.UNIT_ID
              WHERE (UNIT1.ITEM_ID = cte.Item_Id)
                AND (ADM_MST_UNIT_LOCATION.LOC_TYPE_ = 'REGULAR')
                AND STOCK1.OWNED_BY_L2_ID_ = cte.L2Id)                   AS OnHandQty
       FROM cte
      WHERE cte.DueStatus = 'Overdue'
         OR (    (1 <> 1 OR (@hrs > 0 OR @cValueYear > 0 OR @cValueMonth > 0 OR @landing > 0))
             AND ((@hrs > 0 AND cte.FltHours - cte.Hrs <= @hrs) OR
                  (@landing > 0 AND cte.FltLdgs - cte.Landing <= @landing) OR
                  (@cValueYear > 0 AND
                   (DATEADD(YEAR, @cValueYear, convert(date, GETDATE())) >= cte.caldate1)) OR
                  (@cValueMonth > 0 AND
                   (DATEADD(MONTH, @cValueMonth, convert(date, GETDATE())) >= cte.caldate1))
                 )
            )
   GROUP BY cte.TailNo
        ,cte.Hrs
        ,cte.Landing
        ,cte.DueStatus
        ,cte.Part_Desc
        ,cte.Part_No
	,cte.MFR
        ,cte.Item_Id
        ,cte.Unit_Serial_No
        ,cte.FltHours
        ,cte.caldate1
        ,cte.FltLdgs
        ,cte.L2Id
	,cte.ReplaceRemaining
go

