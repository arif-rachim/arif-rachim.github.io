CREATE PROCEDURE [MergeUnit] @fromUnitId bigint, @toUnitId bigInt
AS
BEGIN
	SET NOCOUNT ON;	
	DECLARE @stmt nvarchar(MAX)
	
	DECLARE curStmt CURSOR FOR 
	--select 'SELECT ' + COLUMN_NAME  + ' FROM ' + TABLE_NAME + ' WHERE ' + COLUMN_NAME + ' = ' + cast(@fromUnitId as nvarchar(MAX)) from INFORMATION_SCHEMA.COLUMNS
	--where COLUMN_NAME like 'UNIT_ID%' and TABLE_NAME not like '%_HST_%' and TABLE_SCHEMA='dbo'
	select 'UPDATE ' + TABLE_NAME + ' SET ' + COLUMN_NAME + ' = ' + cast(@toUnitId as nvarchar(MAX)) + ' WHERE ' + COLUMN_NAME + ' = ' + cast(@fromUnitId as nvarchar(MAX)) from INFORMATION_SCHEMA.COLUMNS
	where (COLUMN_NAME like 'UNIT_ID%' or  COLUMN_NAME in ('UNIT_ID_','EI_UNIT_ID_','COMP_UNIT_ID','END_UNIT_ID','ISSUED_UNIT_ID','RETURN_UNIT_ID_','LCF_1_UNIT_ID','LCF_2_UNIT_ID',
	'RECORDER_UNIT_ID','IDN_UNIT_ID_','NHA_UNIT_ID_',    'IDN_UNIT_ID_','NHA_UNIT_ID_','ENGINE_UNIT_ID','ENGINE_UNIT_ID_')) 
	and (TABLE_NAME not like 'VW_%' AND TABLE_NAME not like '%_HST_%' AND TABLE_NAME NOT LIKE 'AMO_%' AND TABLE_NAME not like '%bug%' AND TABLE_NAME not like '%backup%'
	AND TABLE_NAME not like '%ops%' AND TABLE_NAME not like '%temp%' AND TABLE_NAME NOT IN ('ADM_MST_TAILS','LOG_TRN_STOCK','ADM_TRN_IMV_ITEMS_IN_LOCATION','ADM_TRN_IMV_ITEMS_IN_LOCATION_SYSTEM_HISTORY'))
	and TABLE_SCHEMA='dbo'
	
	OPEN curStmt
	FETCH NEXT FROM curStmt INTO @stmt
	
	BEGIN TRAN 
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		PRINT @stmt	
		EXEC sp_sqlexec @stmt
		FETCH NEXT FROM curStmt INTO @stmt
	END
	
	IF @@ERROR <> 0 ROLLBACK TRAN ELSE COMMIT TRAN
	
	CLOSE curStmt
	DEALLOCATE curStmt
	--EXEC sp_sqlexec @stmt
	--SELECT * FROM ADM_MST_UNITS
END
go

