CREATE FUNCTION [dbo].[D161_GetMasterParentHCodeByLevel](@masterId bigint, @level int) RETURNS nvarchar(900) AS
BEGIN
	DECLARE @hCode nvarchar(900)
	DECLARE @parentHCode nvarchar(900)
	DECLARE @tmpLevel int

	SELECT @tmpLevel = LEVEL_, @hCode = H_CODE_ FROM MNT_TRN_D16_1_MASTER 	
	WHERE ID_ = @masterId
	
	IF(@tmpLevel = @level) RETURN @hCode

	WHILE (@tmpLevel > @level)
	BEGIN
		SET @parentHCode=dbo.D161_GetParentHCode(@hCode)
		SET @tmpLevel = @tmpLevel - 1
		SET @hCode = @parentHCode
	END
	RETURN @parentHCode
END
go

