-- =============================================
-- Author:		Subhash
-- Create date: 26-Nov-2014
-- Description:	Get AFM Monthly return Report Total Hours of a status For a period
-- =============================================
CREATE FUNCTION [dbo].[GetAfmMonthlyReturnReportHrsForAperiod] 
(
	@start_date smalldatetime,
	@end_date smalldatetime,
	@aircraft_id bigint,
	@status_id bigint
)
RETURNS DECIMAL(5,1)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @AC_TOTAL_HRS DECIMAL(5,1)

	-- Get total aircraft hrs
	IF(@status_id = 0 )
	BEGIN
		SELECT @AC_TOTAL_HRS = (dbo.ReturnTAAMSTime(SUM(d.DUR_MINS_))) FROM dbo.MNT_TRN_MFM_AFM_MONTHLY_RECORD_DETAIL d
		INNER JOIN MNT_TRN_MFM_AFM_MONTHLY_RECORD r ON r.ID_ = d.AFM_MONTHLY_ID
		WHERE 
			convert(smalldatetime,d.BEGIN_ON_,100) BETWEEN @start_date AND @end_date
			AND r.ARCFT_ID_ = @aircraft_id 
	END
	-- Get total aircraft hrs for a condition
	ELSE
	BEGIN
		SELECT @AC_TOTAL_HRS = (dbo.ReturnTAAMSTime(SUM(DUR_MINS_))) FROM dbo.MNT_TRN_MFM_AFM_MONTHLY_RECORD_DETAIL d
		INNER JOIN MNT_TRN_MFM_AFM_MONTHLY_RECORD r ON r.ID_ = d.AFM_MONTHLY_ID
		WHERE 
			convert(smalldatetime,DATE_,100) BETWEEN @start_date AND @end_date
			AND d.FAULT_STS_ID_ = @status_id
			AND r.ARCFT_ID_ = @aircraft_id 
	END
	-- Return the result of the function
	RETURN ISNULL(@AC_TOTAL_HRS ,0)

END
go

