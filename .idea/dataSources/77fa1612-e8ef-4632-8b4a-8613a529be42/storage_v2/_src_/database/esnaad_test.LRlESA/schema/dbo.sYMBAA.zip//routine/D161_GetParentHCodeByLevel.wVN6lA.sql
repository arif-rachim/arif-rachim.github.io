CREATE FUNCTION [dbo].[D161_GetParentHCodeByLevel](@assignmentId bigint, @level int) RETURNS nvarchar(900) AS
BEGIN
	DECLARE @hCode nvarchar(900)
	DECLARE @parentHCode nvarchar(900)
	DECLARE @tmpLevel int

	SELECT @tmpLevel = M.LEVEL_, @hCode = A.H_CODE_ FROM MNT_TRN_D16_1_ASSIGNMENT A 
	JOIN MNT_TRN_D16_1_MASTER M ON M.ID_ = A.MASTER_ID
	WHERE A.ID_ = @assignmentId
	
	IF(@tmpLevel = @level) RETURN @hCode

	WHILE (@tmpLevel > @level)
	BEGIN
		SET @parentHCode=dbo.D161_GetParentHCode(@hCode)
		SET @tmpLevel = @tmpLevel - 1
		SET @hCode = @parentHCode
	END
	RETURN @parentHCode
END
go

