CREATE FUNCTION [dbo].[AcslFindDefaultAcslItem]
(
  @commandId AS              bigint,
  @l2Id AS                   bigint,
  @buId AS                   bigint,
  @consumptionYears AS       int = 0,
  @autoCalculateBy AS        varchar(25),
  @newMaxLevelConsumption AS decimal,
  @itemId AS                 bigint=0
  )
  RETURNS @acslItems TABLE
                     (
                       ItemId                           bigint,
                       StockType                        varchar(25),
                       InspectionPerYear                int,
                       AverageNumberRequired            int,
                       NumberOfAircraft                 int,
                       Expiry                           int,
                       BtEvalNumber                     int,
                       LeadTime                         int,
                       AveragePrice                     decimal(8, 2),
                       AverageRepairLast365Days         int,
                       AverageRepairLeadTime            int,
                       LeadTimeMultiplier               decimal(18, 1),
                       ExpirationMultiplier             decimal(18, 1),
                       TotalOnAircraft                  int,
                       RepairCyclePerMonth              decimal(18, 9),
                       AverageRepairBasedOnLeadTime     decimal(18,9),
                       PercentageOfSafetyStock          decimal(18, 2),
                       SparesRequired                   decimal(18, 9),
                       MaxCurrent                       int,
                       MaxRecommended                   int,
                       SafetyCurrent                    int,
                       MinCurrent                       int,
                       MaxConsumptionYear               int,
                       MaxConsumptionQty                bigint,
                       SafetyRecommended                int,
                       MinRecommended                   int,
                       Min                              int,
                       Max                              int,
                       Safety                           int,
                       PercentageOfSafetyStockRemaining int
                     )
AS
BEGIN
  INSERT @acslItems

  SELECT ItemId
       , StockType
       , InspectionPerYear
       , AverageNumberRequired
       , NumberOfAircraft
       , Expiry
       , BtEvalNumber
       , LeadTime
       , AveragePrice
       , AverageRepairLast365Days
       , AverageRepairLeadTime
       , LeadTimeMultiplier
       , ExpirationMultiplier
       , TotalOnAircraft
       , RepairCyclePerMonth
       , AverageRepairBasedOnLeadTime
       , PercentageOfSafetyStock
       , SparesRequired
       , MaxCurrent
       , MaxRecommended
       , SafetyCurrent
       , MinCurrent
       , MaxConsumptionYear
       , MaxConsumptionQty
       , CAST(ROUND((0.6 * MaxRecommended), 0) AS INT)                                       AS SafetyRecommended
       , CAST(ROUND((0.4 * MaxRecommended), 0) AS INT)                                       AS MinRecommended
       , CASE WHEN StockType = 'Inspection' THEN MinInspection ELSE MinConsumption END       AS Min
       , CASE WHEN StockType = 'Inspection' THEN MaxInspection ELSE MaxConsumption END       AS Max
       , CASE WHEN StockType = 'Inspection' THEN SafetyInspection ELSE SafetyConsumption END AS Safety
       , CASE
           WHEN StockType = 'Inspection' THEN PercentSafetyStockRemainingInspection
           ELSE PercentSafetyStockRemainingConsumption END                                   AS PercentageOfSafetyStockRemaining
  FROM (SELECT *
             , CASE
                 WHEN @autoCalculateBy = 'StockLevelParameters' THEN
                   (cast((ROUND(SparesRequired + 0.2 * SparesRequired, 0)) AS int))
                 ELSE
                   cast((ROUND(MaxConsumptionQty *
                               (CASE
                                  WHEN @newMaxLevelConsumption > LeadTimeMultiplier
                                    THEN @newMaxLevelConsumption
                                  ELSE LeadTimeMultiplier
                                 END), 0)
                     ) AS int
                     ) END                                                        AS MaxRecommended
             , (CAST((ROUND(((MaxInspection + MinInspection) / 2), 0)) AS int))   AS SafetyInspection
             , (CAST((ROUND(((MaxConsumption + MinConsumption) / 2), 0)) AS int)) AS SafetyConsumption
             , (CAST((ROUND(((MaxInspection - MinInspection) / convert(decimal(10, 2), MaxInspection)) * 100,
                            0)) AS int))                                          AS PercentSafetyStockRemainingInspection
             , (CAST((ROUND(((MaxConsumption - MinConsumption) / convert(decimal(10, 2), MaxConsumption)) * 100,
                            0)) AS int))                                          AS PercentSafetyStockRemainingConsumption
        FROM (SELECT *
                   , (TotalOnAircraft * (PercentageOfSafetyStock * 0.01) +
                      AverageRepairBasedOnLeadTime) AS SparesRequired
                   , (cast(
              (ROUND(((MinInspection / 365) * LeadTimeMultiplier + ExpirationMultiplier +
                      MinInspection * InspectionPerYear),
                     0)) AS int))                   AS MaxInspection
                   , CASE
                       WHEN BtEvalNumber > 0
                         THEN
                         (CAST((ROUND(
                             (((AverageNumberRequired / 365) * NumberOfAircraft +
                               (AverageNumberRequired * NumberOfAircraft) +
                               AverageNumberRequired * LeadTimeMultiplier * 5) + MinConsumption), 0)) AS int))
                       ELSE
                         CAST(ROUND(((AverageNumberRequired / 365) * NumberOfAircraft +
                                     (AverageNumberRequired * NumberOfAircraft) +
                                     AverageNumberRequired * LeadTimeMultiplier * 5), 0) AS INT)
            END                                     AS MaxConsumption
              FROM (SELECT *
                         , (SELECT dbo.AcslGetLeadTimeMultiplier(@commandId, LeadTime))     AS LeadTimeMultiplier
                         , (SELECT dbo.AcslGetExpirationTimeMultiplier(@commandId, Expiry)) AS ExpirationMultiplier
                         , (AverageNumberRequired * NumberOfAircraft)                       AS TotalOnAircraft
                         , (AverageRepairLast365Days / 365.0)                               AS RepairCyclePerMonth
                         , ((AverageRepairLast365Days / 365.0) * AverageRepairLeadTime)     AS AverageRepairBasedOnLeadTime
                         , (IIF(AveragePrice < 20000, 25.0, 10.0))                          AS PercentageOfSafetyStock
                         , (SELECT Year
                            FROM dbo.AcslGetMaxConsumptionYear(ItemId, @commandId, @buId, @l2Id,
                                                               @consumptionYears))          AS MaxConsumptionYear
                         , (SELECT Consumption
                            FROM dbo.AcslGetMaxConsumptionYear(ItemId, @commandId, @buId, @l2Id,
                                                               @consumptionYears))          AS MaxConsumptionQty
                    FROM (SELECT *
                               , IIF((SysLeadTime IS NULL OR SysLeadTime = 0) AND SysLeadTimeFlag = 1, UserLeadTime,
                                     SysLeadTime)                  AS LeadTime
                               , IIF((SysAveragePrice IS NULL OR SysAveragePrice = 0) AND SysAveragePriceFlag = 1,
                                     UserAveragePrice,
                                     COALESCE(SysAveragePrice, 0)) AS AveragePrice
                               , IIF((SysAverageLast365 IS NULL OR SysAverageLast365 = 0) AND SysAverageLast365Flag = 1,
                                     UserAverageLast365,
                                     SysAverageLast365)            AS AverageRepairLast365Days
                               , IIF((SysAverageRepairLeadTime IS NULL OR SysAverageRepairLeadTime = 0) AND
                                     SysAverageRepairLeadTimeFlag = 1,
                                     UserAverageRepairLeadTime,
                                     SysAverageRepairLeadTime)     AS AverageRepairLeadTime
                               , (cast(ROUND((AverageNumberRequired * NumberOfAircraft * InspectionPerYear),
                                             0) AS int))           AS MinInspection
                               , (cast(
                          ROUND(((AverageNumberRequired * BtEvalNumber) + (AverageNumberRequired * NumberOfAircraft)),
                                0) AS int))                        AS MinConsumption
                          FROM (SELECT i.ID_                                                          AS ItemId
                                     , p.STOCK_TYPE_                                                  AS StockType
                                     , p.INSP_PER_YEAR_                                               AS InspectionPerYear
                                     , p.AVG_NUMBER_REQ_                                              AS AverageNumberRequired
                                     , p.NUM_OF_ACFT_                                                 AS NumberOfAircraft
                                     , p.EXPIRY_                                                      AS Expiry
                                     , p.BT_EVAL_NO_                                                  AS BtEvalNumber
                                     , (SELECT LeadTime
                                        FROM dbo.AcslGetSystemParam(i.ID_, @commandId, @buId, @l2Id)) AS SysLeadTime
                                     , p.LEAD_TIME_FLAG_                                              AS SysLeadTimeFlag
                                     , p.LEAD_TIME_                                                   AS UserLeadTime
                                     , (SELECT AveragePrice
                                        FROM dbo.AcslGetSystemParam(i.ID_, @commandId, @buId, @l2Id)) AS SysAveragePrice
                                     , p.AVG_PRICE_FLAG_                                              AS SysAveragePriceFlag
                                     , p.AVG_PRICE_                                                   AS UserAveragePrice
                                     , (SELECT AverageRepairLast365
                                        FROM dbo.AcslGetSystemParam(i.ID_, @commandId, @buId, @l2Id)) AS SysAverageLast365
                                     , p.AVG_REPAIR_LAST_365_FLAG_                                    AS SysAverageLast365Flag
                                     , p.AVG_REPAIR_LAST_365_                                         AS UserAverageLast365
                                     , (SELECT AverageRepairLeadTime
                                        FROM dbo.AcslGetSystemParam(i.ID_, @commandId, @buId, @l2Id)) AS SysAverageRepairLeadTime
                                     , p.AVG_REPAIR_LEAD_TIME_FLAG_                                   AS SysAverageRepairLeadTimeFlag
                                     , p.AVG_REPAIR_LEAD_TIME_                                        AS UserAverageRepairLeadTime
                                     , sl.MAX_                                                        AS MaxCurrent
                                     , sl.SAFETY_                                                     AS SafetyCurrent
                                     , sl.MIN_                                                        AS MinCurrent
                                FROM ADM_MST_ITEMS i
                                       JOIN ADM_TRN_ITEM_ASSOCS ia ON ia.ITEM_ID = i.ID_ AND ia.PRIMARY_PART_ = 1
                                       JOIN ADM_TRN_ASSOC_GROUPS ag ON ag.ID_ = ia.L2_ID
                                       LEFT JOIN LOG_TRN_STOCK_LEVEL2 sl
                                                 ON sl.ITEM_ASSOC_ID_ = ia.ID_ AND sl.STORE_ID = @buId AND
                                                    sl.ITEM_ASSOC_ID_ = ia.ID_
                                       JOIN LOG_TRN_SLM_AUTO_STOCK_PARAM p ON p.ITEM_ASSOC_ID_ = ia.ID_
                                WHERE 1 = 1
                                  AND ((p.STOCK_TYPE_ IN ('Consumables', 'Inspection') AND
                                        @autoCalculateBy = 'StockLevelParameters') OR
                                       (p.STOCK_TYPE_ = 'Spare' AND @autoCalculateBy = 'Consumption'))
                                  AND (@itemId = 0 OR i.ID_ = @itemId)
                                  AND ia.L2_ID = @l2Id
                                  AND p.STORE_ID = @buId
                                  AND ((p.STOCK_TYPE_ = 'Inspection' and p.INSP_PER_YEAR_ is not null and p.AVG_NUMBER_REQ_ is not null and p.NUM_OF_ACFT_ is not null and p.EXPIRY_ is not null and p.LEAD_TIME_ is not null)
                                      OR
                                         (p.STOCK_TYPE_ = 'Consumables' and p.AVG_NUMBER_REQ_ is not null and p.NUM_OF_ACFT_ is not null and p.BT_EVAL_NO_ is not null and p.LEAD_TIME_ is not null)
                                      OR
                                         (p.STOCK_TYPE_ = 'Spare' and p.AVG_NUMBER_REQ_ is not null and p.NUM_OF_ACFT_ is not null and p.AVG_PRICE_ is not null and p.AVG_REPAIR_LAST_365_ is not null))
                              ) AS param) AS LvlOne) AS lvlTwo) AS lvlThree) AS LvlFour


  RETURN;
END;
go

