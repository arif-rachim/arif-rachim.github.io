CREATE PROCEDURE [dbo].[GetAsvcFleetStatusReport]
	-- Add the parameters for the stored procedure here
	@input_date datetime,
	@command_id bigint,
	@platform_id bigint,
	@user_id bigint
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		
	--
	DECLARE @FMC int = 220
	DECLARE @PMCM int = 221
	DECLARE @PMCS int = 222
	DECLARE @NMCS1ST int = 223
	DECLARE @NMCM_1st int = 224  
	DECLARE @NMCS2ND int = 226
	DECLARE @NMCM_2nd int = 227  
	DECLARE @DEPOT int = 225
	DECLARE @TOTAL_HRS int = 0
	DECLARE @NRT int = 234
	
	DECLARE @start_date		SMALLDATETIME
	SET @start_date = @input_date - day(@input_date) + 1
	
	DECLARE @end_date       SMALLDATETIME
	IF(@input_date > @start_date)
	SET @end_date = @input_date - 1;
	ELSE
	SET @end_date = @start_date
	
    --SET @end_date = @input_date

	DECLARE @today_date date
    DECLARE @compare_date date
   
    SET @today_date = CONVERT(date, getdate())
    SET @compare_date = CONVERT(date, @input_date)
    
	-- Insert statements for procedure here
    IF DATEDIFF(DAY, @compare_date, @today_date) = 0
    BEGIN
		SELECT DISTINCT X.TailId, X.TailNo, X.PlatformId, 
					  CASE WHEN P_VAR.PLTF_ALIAS_CODE_ IS NULL THEN X.Platform ELSE P_VAR.PLTF_ALIAS_CODE_ END AS Platform, 
					  X.UnitId,  case when S.CODE_ is null then '-' else S.CODE_ end AS Status, C.CODE_ AS Condition, M.REMARKS_ AS Remarks,
                      CASE WHEN M.IS_DEPLOYED_ = 0 THEN '' ELSE 'DEPLOYED' END AS Deploy, 
                      
                      CASE 
                      WHEN (M.MNT_EST_COMP_DATE_ IS NOT NULL AND M.EST_COMP_DATE_ IS NOT NULL AND M.MNT_EST_COMP_DATE_>M.EST_COMP_DATE_) THEN M.MNT_PERCENT_COMP_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NOT NULL AND M.EST_COMP_DATE_ IS NOT NULL AND M.MNT_EST_COMP_DATE_<M.EST_COMP_DATE_) THEN M.PERCENT_COMP_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NOT NULL AND M.EST_COMP_DATE_ IS NULL) THEN M.MNT_PERCENT_COMP_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NOT NULL) THEN M.PERCENT_COMP_
                      WHEN (M.MNT_EST_COMP_DATE_=M.EST_COMP_DATE_ AND M.MNT_START_DATE_>M.START_DATE_) THEN M.MNT_PERCENT_COMP_
                      WHEN (M.MNT_EST_COMP_DATE_=M.EST_COMP_DATE_ AND M.MNT_START_DATE_<=M.START_DATE_) THEN M.PERCENT_COMP_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NULL AND M.MNT_START_DATE_ IS NOT NULL AND M.START_DATE_ IS NOT NULL AND M.MNT_START_DATE_>M.START_DATE_) THEN M.MNT_PERCENT_COMP_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NULL AND M.MNT_START_DATE_ IS NOT NULL AND M.START_DATE_ IS NOT NULL AND M.MNT_START_DATE_<=M.START_DATE_) THEN M.PERCENT_COMP_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NULL AND M.MNT_START_DATE_ IS NOT NULL AND M.START_DATE_ IS NULL) THEN M.MNT_PERCENT_COMP_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NULL AND M.MNT_START_DATE_ IS NULL AND M.START_DATE_ IS NOT NULL) THEN M.PERCENT_COMP_
                      ELSE NULL END AS Completed,
                                            
                      CASE 
                      WHEN (M.MNT_EST_COMP_DATE_ IS NOT NULL AND M.EST_COMP_DATE_ IS NOT NULL AND M.MNT_EST_COMP_DATE_>M.EST_COMP_DATE_) THEN M.MNT_START_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NOT NULL AND M.EST_COMP_DATE_ IS NOT NULL AND M.MNT_EST_COMP_DATE_<M.EST_COMP_DATE_) THEN M.START_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NOT NULL AND M.EST_COMP_DATE_ IS NULL) THEN M.MNT_START_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NOT NULL) THEN M.START_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_=M.EST_COMP_DATE_ AND M.MNT_START_DATE_>M.START_DATE_) THEN M.MNT_START_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_=M.EST_COMP_DATE_ AND M.MNT_START_DATE_<=M.START_DATE_) THEN M.START_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NULL AND M.MNT_START_DATE_ IS NOT NULL AND M.START_DATE_ IS NOT NULL AND M.MNT_START_DATE_>M.START_DATE_) THEN M.MNT_START_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NULL AND M.MNT_START_DATE_ IS NOT NULL AND M.START_DATE_ IS NOT NULL AND M.MNT_START_DATE_<=M.START_DATE_) THEN M.START_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NULL AND M.MNT_START_DATE_ IS NOT NULL AND M.START_DATE_ IS NULL) THEN M.MNT_START_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NULL AND M.MNT_START_DATE_ IS NULL AND M.START_DATE_ IS NOT NULL) THEN M.START_DATE_
                      ELSE NULL END AS StartDate,
                      
                      CASE 
                      WHEN (M.MNT_EST_COMP_DATE_ IS NOT NULL AND M.EST_COMP_DATE_ IS NOT NULL AND M.MNT_EST_COMP_DATE_>M.EST_COMP_DATE_) THEN M.MNT_EST_COMP_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NOT NULL AND M.EST_COMP_DATE_ IS NOT NULL AND M.MNT_EST_COMP_DATE_<=M.EST_COMP_DATE_) THEN M.EST_COMP_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NOT NULL AND M.EST_COMP_DATE_ IS NULL) THEN M.MNT_EST_COMP_DATE_
                      WHEN (M.MNT_EST_COMP_DATE_ IS NULL AND M.EST_COMP_DATE_ IS NOT NULL) THEN M.EST_COMP_DATE_                  
                      ELSE NULL END AS EstCompDate,
                      
                      M.HRS_TO_INSP_ AS HrsInsp, GETDATE() AS AsvcDate, X.P_ORDER AS PlatformOrder,                       
			   dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,UnitId,@FMC) AS FMC,
			   dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,UnitId,@PMCM) AS PMCM,
			   dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,UnitId,@PMCS) AS PMCS,
			   dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,UnitId,@NMCS1ST) AS NMCS1ST,
			   dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,UnitId,@NMCS2ND) AS NMCS2ND,
			   dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,UnitId,@DEPOT) AS DEPOT,
			   dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,UnitId,@TOTAL_HRS) AS TotalHrs,
			   dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, UnitId, @NMCM_1st)	NMCM1Hrs,  
               dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, UnitId, @NMCM_2nd)	NMCM2Hrs,  
			   dbo.GetUnitEffectiveUsageHours(UnitId) AS AcftHours,			   
			   dbo.GetAircraftFlyHrsForAPeriod(@start_date,@end_date,UnitId,@user_id) AS MonthlyFltTime,
			   dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,UnitId,@NRT) AS NRT
		FROM 
		
		 (	SELECT 
				T.ID_ AS TailId, T.T_NUM_ AS TailNo, P.ID_ AS PlatformId, P.CODE_ AS Platform, T.UNIT_ID AS UnitId,P.ORDER_ AS P_ORDER, COMMNAD.ID_ As ParentId
			FROM         
				dbo.ADM_MST_TAILS AS T	INNER JOIN ADM_MST_UNITS AS U ON T.UNIT_ID = U.ID_ 
										INNER JOIN ADM_MST_ITEMS AS I ON U.ITEM_ID = I.ID_ 
										INNER JOIN ADM_MST_PLATFORMS AS P ON I.ID_ = P.ID_ 
										INNER JOIN ADM_MST_RESTRICTIONS BATT ON BATT.ID_ = T.BATLN_ID
										INNER JOIN ADM_MST_RESTRICTIONS COMMNAD ON COMMNAD.ID_ = BATT.PRNT_ID 
                                             
            WHERE     (T.END_DATE_ = CONVERT(date, '31-DEC-9999'))
            AND ( 
					(
						@platform_id = 0 
						and P.ID_ IN (
									select type_id_ from ADM_TRN_SEC_ROLE_ACL_DETAIL acldet
									inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acldet.ROLE_ACL_ID and acldet.TYPE_ = 'Platform'
									inner join ADM_TRN_SEC_ROLE_ASSIGNMENT roleasnmnt on roleasnmnt.ROLE_ID = acl.ROLE_ID
									where roleasnmnt.USR_PRF_ID = @user_id  and acl.MDL_ID = 'MNT.001.00.00.00'  
						)
					) or (@platform_id > 0 and P.ID_ = @platform_id)
			)
			AND T.BATLN_ID IN(
								select type_id_ from ADM_TRN_SEC_ROLE_ACL_DETAIL acldet
								inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acldet.ROLE_ACL_ID and acldet.TYPE_ = 'MilitaryUnit'
								inner join ADM_TRN_SEC_ROLE_ASSIGNMENT roleasnmnt on roleasnmnt.ROLE_ID = acl.ROLE_ID
								inner join ADM_MST_RESTRICTIONS btn on btn.ID_ = acldet.TYPE_ID_ and (@command_id = 0 or btn.PRNT_ID = @command_id)
								where roleasnmnt.USR_PRF_ID = @user_id and acl.MDL_ID = 'MNT.001.00.00.00'
								)
        )AS X LEFT OUTER JOIN
                      dbo.MNT_TRN_AIRCRAFT_SERVS AS M ON X.UnitId = M.UNIT_ID LEFT OUTER JOIN
                      dbo.ADM_MST_STATUS_CONDITIONS AS SC ON M.STSCND_ID = SC.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS S ON SC.STAT_ID = S.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS C ON SC.COND_ID = C.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS DS ON M.DEPL_ID = DS.ID_ LEFT OUTER JOIN 
					  dbo.ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = X.UnitId	LEFT OUTER JOIN 
					  dbo.ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
		ORDER BY PlatformOrder, TailNo, AsvcDate DESC
	END	
	ELSE
	BEGIN
				SELECT T.ID_ AS TailId, H.TAIL_NUM_ AS TailNo, P.ID_ AS PlatformId, 
					  CASE WHEN P_VAR.PLTF_ALIAS_CODE_ IS NULL THEN H.PLTF_ ELSE P_VAR.PLTF_ALIAS_CODE_ END AS Platform, 
					  U.ID_ AS UnitId, H.STAT_ AS Status, H.COND_ AS Condition, H.REMARKS_ AS Remarks,
                      CASE WHEN H.IS_DEPLOYED_ = 0 THEN '' ELSE 'DEPLOYED' END AS Deploy, 
                                            
                      CASE 
                      WHEN (H.MNT_EST_COMP_DATE_ IS NOT NULL AND H.EST_COMP_DATE_ IS NOT NULL AND H.MNT_EST_COMP_DATE_>H.EST_COMP_DATE_) THEN H.MNT_PERCENT_COMP_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NOT NULL AND H.EST_COMP_DATE_ IS NOT NULL AND H.MNT_EST_COMP_DATE_<H.EST_COMP_DATE_) THEN H.PERCENT_COMP_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NOT NULL AND H.EST_COMP_DATE_ IS NULL) THEN H.MNT_PERCENT_COMP_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NOT NULL) THEN H.PERCENT_COMP_
                      WHEN (H.MNT_EST_COMP_DATE_=H.EST_COMP_DATE_ AND H.MNT_START_DATE_>H.START_DATE_) THEN H.MNT_PERCENT_COMP_
                      WHEN (H.MNT_EST_COMP_DATE_=H.EST_COMP_DATE_ AND H.MNT_START_DATE_<=H.START_DATE_) THEN H.PERCENT_COMP_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NULL AND H.MNT_START_DATE_ IS NOT NULL AND H.START_DATE_ IS NOT NULL AND H.MNT_START_DATE_>H.START_DATE_) THEN H.MNT_PERCENT_COMP_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NULL AND H.MNT_START_DATE_ IS NOT NULL AND H.START_DATE_ IS NOT NULL AND H.MNT_START_DATE_<=H.START_DATE_) THEN H.PERCENT_COMP_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NULL AND H.MNT_START_DATE_ IS NOT NULL AND H.START_DATE_ IS NULL) THEN H.MNT_PERCENT_COMP_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NULL AND H.MNT_START_DATE_ IS NULL AND H.START_DATE_ IS NOT NULL) THEN H.PERCENT_COMP_
                      ELSE NULL END AS Completed,
                                            
                      CASE 
                      WHEN (H.MNT_EST_COMP_DATE_ IS NOT NULL AND H.EST_COMP_DATE_ IS NOT NULL AND H.MNT_EST_COMP_DATE_>H.EST_COMP_DATE_) THEN H.MNT_START_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NOT NULL AND H.EST_COMP_DATE_ IS NOT NULL AND H.MNT_EST_COMP_DATE_<H.EST_COMP_DATE_) THEN H.START_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NOT NULL AND H.EST_COMP_DATE_ IS NULL) THEN H.MNT_START_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NOT NULL) THEN H.START_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_=H.EST_COMP_DATE_ AND H.MNT_START_DATE_>H.START_DATE_) THEN H.MNT_START_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_=H.EST_COMP_DATE_ AND H.MNT_START_DATE_<=H.START_DATE_) THEN H.START_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NULL AND H.MNT_START_DATE_ IS NOT NULL AND H.START_DATE_ IS NOT NULL AND H.MNT_START_DATE_>H.START_DATE_) THEN H.MNT_START_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NULL AND H.MNT_START_DATE_ IS NOT NULL AND H.START_DATE_ IS NOT NULL AND H.MNT_START_DATE_<=H.START_DATE_) THEN H.START_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NULL AND H.MNT_START_DATE_ IS NOT NULL AND H.START_DATE_ IS NULL) THEN H.MNT_START_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NULL AND H.MNT_START_DATE_ IS NULL AND H.START_DATE_ IS NOT NULL) THEN H.START_DATE_
                      ELSE NULL END AS StartDate,
                      
                      CASE 
                      WHEN (H.MNT_EST_COMP_DATE_ IS NOT NULL AND H.EST_COMP_DATE_ IS NOT NULL AND H.MNT_EST_COMP_DATE_>H.EST_COMP_DATE_) THEN H.MNT_EST_COMP_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NOT NULL AND H.EST_COMP_DATE_ IS NOT NULL AND H.MNT_EST_COMP_DATE_<=H.EST_COMP_DATE_) THEN H.EST_COMP_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NOT NULL AND H.EST_COMP_DATE_ IS NULL) THEN H.MNT_EST_COMP_DATE_
                      WHEN (H.MNT_EST_COMP_DATE_ IS NULL AND H.EST_COMP_DATE_ IS NOT NULL) THEN H.EST_COMP_DATE_                  
                      ELSE NULL END AS EstCompDate,                                         
                      
                      COMMNAD.ID_ As ParentId,
                      H.HRS_TO_INSP_ AS HrsInsp, H.CREATED_ON_ AS AsvcDate, P.ORDER_ AS PlatformOrder,
                      dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,U.ID_,@FMC) AS FMC,
					  dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,U.ID_,@PMCM) AS PMCM,
			          dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,U.ID_,@PMCS) AS PMCS,
					  dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,U.ID_,@NMCS1ST) AS NMCS1ST,
					  dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,U.ID_,@NMCS2ND) AS NMCS2ND,
			          dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,U.ID_,@DEPOT) AS DEPOT,			          
			          dbo.GetAircraftInvReportHrsForAperiod(@start_date,@end_date,U.ID_,@TOTAL_HRS) AS TotalHrs,
					  dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, U.ID_, @NMCM_1st)	NMCM1Hrs,  
                      dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, U.ID_, @NMCM_2nd)	NMCM2Hrs,  
			          H.TOT_FLIGHT_HRS_	AS AcftHours,	                                
					 dbo.GetAircraftFlyHrsForAPeriod(@start_date,@end_date,U.ID_,@user_id) AS MonthlyFltTime
				FROM         MNT_HST_AIRCRAFT_SERVS AS H INNER JOIN
							  ADM_MST_TAILS AS T ON H.TAIL_NUM_ = T.T_NUM_ AND (T.END_DATE_ = CONVERT(date, '31-DEC-9999') or CONVERT(date, @input_date) < T.END_DATE_) INNER JOIN
							  ADM_MST_UNITS AS U ON T.UNIT_ID = U.ID_ INNER JOIN
							  ADM_MST_PLATFORMS AS P ON H.PLTF_ = P.CODE_ LEFT JOIN
							  ADM_MST_SIMPLE_REF AS DS ON H.DEPL_ = DS.CODE_ AND DS.GRP_ = 'MNT.DPS'
							  INNER JOIN ADM_MST_RESTRICTIONS BATT ON BATT.ID_ = T.BATLN_ID
							  INNER JOIN ADM_MST_RESTRICTIONS COMMNAD ON COMMNAD.ID_ = BATT.PRNT_ID 
							  LEFT JOIN ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = T.UNIT_ID
							  LEFT JOIN ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
				WHERE  P.ID_ IN (
								select type_id_ from ADM_TRN_SEC_ROLE_ACL_DETAIL acldet
								inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acldet.ROLE_ACL_ID and acldet.TYPE_ = 'Platform'
								inner join ADM_TRN_SEC_ROLE_ASSIGNMENT roleasnmnt on roleasnmnt.ROLE_ID = acl.ROLE_ID
								where roleasnmnt.USR_PRF_ID = @user_id  and acl.MDL_ID = 'MNT.001.00.00.00'  
							)
					AND T.BATLN_ID IN(
								select type_id_ from ADM_TRN_SEC_ROLE_ACL_DETAIL acldet
								inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acldet.ROLE_ACL_ID and acldet.TYPE_ = 'MilitaryUnit'
								inner join ADM_TRN_SEC_ROLE_ASSIGNMENT roleasnmnt on roleasnmnt.ROLE_ID = acl.ROLE_ID
								inner join ADM_MST_RESTRICTIONS btn on btn.ID_ = acldet.TYPE_ID_ and (@command_id = 0 or btn.PRNT_ID = @command_id)
								where roleasnmnt.USR_PRF_ID = @user_id and acl.MDL_ID = 'MNT.001.00.00.00'
								)
					AND CONVERT(date,H.CREATED_ON_) = CONVERT(date,@input_date) 										 
				ORDER BY PlatformOrder, TailNo, AsvcDate DESC
	END		
END
go

