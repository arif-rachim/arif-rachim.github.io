CREATE PROC [dbo].[GenerateSequenceNumber] (
	@prefix nvarchar(255),
	@seqCount int,
	@year int, 
	@month int = null
) 
AS
BEGIN
	DECLARE @padFormat nvarchar(255)
	DECLARE @seqType nvarchar(30)
	SELECT @padFormat=PAD_FORMAT_, @seqType=SEQ_TYPE_ FROM ADM_MST_SEQ_ANNUAL_SEQUENCE WHERE CODE_=@prefix

	DECLARE @lastSeq int
	SELECT @lastSeq = LAST_SEQ_ FROM ADM_MST_SEQ_ANNUAL_SEQUENCE
	WHERE CODE_ = @prefix AND YEAR_ = @year AND (MONTH_ IS NULL OR (MONTH_ = @month)) AND SEQ_TYPE_ = @seqType

	declare @curSeq int = isnull(@lastseq, 0);

	IF @lastSeq IS NULL
	BEGIN
		INSERT ADM_MST_SEQ_ANNUAL_SEQUENCE(VERSION_, YEAR_, CODE_, LAST_SEQ_, PAD_FORMAT_, SEQ_TYPE_, MONTH_) VALUES (1, @year, @prefix, ISNULL(@lastSeq, 0) + @seqCount, @padFormat, @seqType, case when @seqType='Monthly' then @month else null end)
	END
	ELSE
	BEGIN
		UPDATE ADM_MST_SEQ_ANNUAL_SEQUENCE 
		SET LAST_SEQ_ = @lastSeq + @seqCount, VERSION_ = VERSION_ + 1, MONTH_=case when @seqType='Monthly' then @month else null end
		WHERE YEAR_ = @year AND CODE_ = @prefix AND (MONTH_ IS NULL OR (MONTH_ = @month)) AND SEQ_TYPE_ = @seqType
	END
	select * from ConstructSequenceNumbers(@prefix,@padFormat,@lastSeq,@seqCount,@year,@month)
	RETURN
END
go

