CREATE FUNCTION [dbo].[D161_GetUndefinedMasterConfiguration] (@componentUnitId bigint, @destPltfId bigint)
RETURNS @undefinedMasterConfiguration TABLE
(
	LEVEL_ int, H_CODE_ varchar(100), END_ITEM_ID bigint, COMP_ID bigint, WORK_UNIT_ID uniqueidentifier
)
AS
BEGIN
		declare @masterId int, @hCodeMaster varchar(100), @level int, @endItem bigint, @compId bigint, @workUnitId uniqueidentifier
		declare @destHCodeMaster varchar(100)

		SELECT @masterId = a.MASTER_ID, @hCodeMaster = m.H_CODE_, @level = m.LEVEL_, @endItem = m.END_ITEM_ID, @compId = m.COMP_ID, @workUnitId = m.WORK_UNIT_ID 
		FROM MNT_TRN_D16_1_ASSIGNMENT a
		JOIN MNT_TRN_D16_1_MASTER m on a.MASTER_ID = m.ID_
		where COMP_UNIT_ID = @componentUnitId


		select @destHCodeMaster  = H_CODE_ from MNT_TRN_D16_1_MASTER
		where PLTF_ID = @destPltfId and LEVEL_ = @level AND COMP_ID = @compId AND WORK_UNIT_ID = @workUnitId AND ((@level = 0 AND 1 = 1) OR END_ITEM_ID = @endItem)

		INSERT @undefinedMasterConfiguration
		SELECT SRC_M.LEVEL_, SRC_M.H_CODE_, SRC_M.END_ITEM_ID, SRC_M.COMP_ID, SRC_M.WORK_UNIT_ID FROM (
			select LEVEL_, H_CODE_, END_ITEM_ID, COMP_ID, WORK_UNIT_ID, CASE WHEN LEVEL_ = 0 THEN 0 ELSE END_ITEM_ID END EI_AL
			from MNT_TRN_D16_1_MASTER
			where H_CODE_ like @hCodeMaster + '%'
		) SRC_M
		LEFT JOIN (
			select LEVEL_, H_CODE_, END_ITEM_ID, COMP_ID, WORK_UNIT_ID, CASE WHEN LEVEL_ = 0 THEN 0 ELSE END_ITEM_ID END EI_AL 
			from MNT_TRN_D16_1_MASTER
			where H_CODE_ LIKE @destHCodeMaster + '%'
		) DST_M ON SRC_M.LEVEL_ = DST_M.LEVEL_ AND SRC_M.COMP_ID = DST_M.COMP_ID AND SRC_M.WORK_UNIT_ID = DST_M.WORK_UNIT_ID AND SRC_M.EI_AL = DST_M.EI_AL
		WHERE DST_M.LEVEL_ IS NULL

      RETURN;
END
go

