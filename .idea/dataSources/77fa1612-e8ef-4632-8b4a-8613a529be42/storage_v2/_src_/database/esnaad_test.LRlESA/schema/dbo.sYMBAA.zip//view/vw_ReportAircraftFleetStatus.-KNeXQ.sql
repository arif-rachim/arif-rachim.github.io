CREATE VIEW [dbo].[vw_ReportAircraftFleetStatus]
AS
SELECT     TOP (100) PERCENT X.TailId, X.TailNo, X.PlatformId, X.Platform, X.UnitId, X.ParentId, X.Command, S.CODE_ AS Status, C.CODE_ AS Condition, 
                      M.REMARKS_ AS Remarks, DS.DESC_ AS Deploy, X.BattalionID, X.Battalion, X.ProfileID, X.UserID, M.PERCENT_COMP_ AS Completed, M.START_DATE_ AS StartDate,
                       M.EST_COMP_DATE_ AS EstCompDate, M.HRS_TO_INSP_ AS HrsInsp, GETDATE() AS AsvcDate, X.P_ORDER AS PlatformOrder, X.ModuleID
FROM         (SELECT     T.ID_ AS TailId, T.T_NUM_ AS TailNo, P.ID_ AS PlatformId, P.CODE_ AS Platform, T.UNIT_ID AS UnitId, B.PRNT_ID AS ParentId, RR.NAME_ AS Command, 
                                              B.ID_ AS BattalionID, B.CODE_ AS Battalion, UP.ID_ AS ProfileID, UP.USER_ID_ AS UserID, P.ORDER_ AS P_ORDER, UR.MODULE_ID AS ModuleID
                        FROM         dbo.ADM_MST_TAILS AS T INNER JOIN
                                              dbo.ADM_MST_UNITS AS U ON T.UNIT_ID = U.ID_ INNER JOIN
                                              dbo.ADM_MST_ITEMS AS I ON U.ITEM_ID = I.ID_ INNER JOIN
                                              dbo.ADM_MST_PLATFORMS AS P ON I.ID_ = P.ID_ INNER JOIN
                                              dbo.ADM_MST_RESTRICTIONS AS B ON T.BATLN_ID = B.ID_ INNER JOIN
                                              dbo.ADM_MST_RESTRICTIONS AS RR ON B.PRNT_ID = RR.ID_ INNER JOIN
                                              dbo.ADM_TRN_USER_RESTRICION_DETAILS AS URD ON B.ID_ = URD.DT_REST_ID INNER JOIN
                                              dbo.ADM_TRN_USER_RESTRICTIONS AS UR ON URD.USR_REST_ID = UR.ID_ INNER JOIN
                                              dbo.ADM_TRN_USER_PROFILES AS UP ON UR.USER_PROFILE_ID = UP.ID_ INNER JOIN
                                              dbo.ADM_TRN_USER_PLATFORM_RESTRICION_DETAILS AS UPR ON P.ID_ = UPR.PLATFORM_ID AND UPR.USR_REST_ID = UR.ID_
                        WHERE     (T.END_DATE_ = CONVERT(date, '31-DEC-9999'))) AS X LEFT OUTER JOIN
                      dbo.MNT_TRN_AIRCRAFT_SERVS AS M ON X.UnitId = M.UNIT_ID LEFT OUTER JOIN
                      dbo.ADM_MST_STATUS_CONDITIONS AS SC ON M.STSCND_ID = SC.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS S ON SC.STAT_ID = S.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS C ON SC.COND_ID = C.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS DS ON M.DEPL_ID = DS.ID_
ORDER BY PlatformOrder, X.TailNo

go

