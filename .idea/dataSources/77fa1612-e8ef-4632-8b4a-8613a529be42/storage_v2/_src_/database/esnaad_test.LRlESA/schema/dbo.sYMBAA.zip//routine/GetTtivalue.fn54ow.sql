CREATE FUNCTION [dbo].[GetTtivalue]
(
          -- Add the parameters for the function here
          @engineId bigint
          
)
RETURNS decimal(18,2)
AS
BEGIN         
          
DECLARE @TTIVALUE decimal(18,2)   

SELECT @TTIVALUE=TempTTI.TTI FROM (
  SELECT   top 1  VAL_ as TTI
    FROM         MNT_TRN_CS_ENGINE_COMPONENT_STAT AS ECS 
    WHERE     (ENGINE_ID_ = @engineId) AND (TYPE_ = 'Tti')
order by READING_DATE_ desc ) AS TempTTI

RETURN @TTIVALUE


END
go

