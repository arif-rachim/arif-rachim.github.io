CREATE FUNCTION dbo.D161_GetActiveRecorderAssignmentId(@compUnitId bigint, @endUnitId bigint)
RETURNS bigint AS
BEGIN
	DECLARE @hrAssignmentId bigint
	DECLARE @parentAssignmentId bigint
	DECLARE @compType nvarchar(10)

	SELECT @parentAssignmentId = ID_, @compType = COMP_TYPE_, @hrAssignmentId = HR_ASGN_ID FROM MNT_TRN_D16_1_ASSIGNMENT
	WHERE COMP_UNIT_ID = @endUnitId AND CR_OP_HRS_ IS NULL 
	
	IF(@hrAssignmentId IS NOT NULL) RETURN @hrAssignmentId

	-- To get active recorder when creating engine assignment to aircraft
	SELECT @hrAssignmentId = ID_ FROM MNT_TRN_D16_1_ASSIGNMENT
	WHERE END_UNIT_ID = @endUnitId AND CR_OP_HRS_ IS NULL AND COMP_TYPE_='HR'

	IF(@hrAssignmentId IS NOT NULL) RETURN @hrAssignmentId

	-- To get active recorder when creating assignment where engine as parent
	SELECT @hrAssignmentId = ID_ FROM MNT_TRN_D16_1_ASSIGNMENT
	WHERE END_UNIT_ID = @compUnitId AND CR_OP_HRS_ IS NULL AND COMP_TYPE_='HR'

	RETURN @hrAssignmentId
END
go

