CREATE FUNCTION [dbo].[GetUnitUsageFromMission]
(	
	@unitId bigint,
	@baselineEffDate datetime
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT mt.UNIT_ID as UnitId, SUM(DATEDIFF(mi,tfr.RTD_,tfr.RTA_)) as FlightMinutes, SUM(tfr.LANDINGS_) as Landing
	FROM 
	OPS_TRN_TAIL_CREWS tc
	JOIN OPS_TRN_WINGS w
	ON tc.WING_ID=w.ID_
	JOIN OPS_TRN_MISSIONS m
	ON w.MISSION_ID=m.ID_ AND m.WF_STATE_ IN ('Verified','Debriefed')
	JOIN OPS_TRN_TAIL_FLIGHT tf
	ON tf.TAIL_CREW_ID=tc.ID_
	RIGHT JOIN ADM_MST_TAILS mt
	ON tc.TAIL_ID=mt.ID_ AND mt.END_DATE_='9999-12-31'
	JOIN ADM_MST_UNITS u
	ON mt.UNIT_ID=u.ID_
	LEFT JOIN OPS_TRN_TAIL_FLIGHT_RECORD tfr
	ON tfr.TAIL_FLIGHT_ID=tf.ID_ AND tfr.RTD_ >= @baselineEffDate
	WHERE mt.UNIT_ID=@unitId
	GROUP BY mt.UNIT_ID,mt.ID_
)
go

