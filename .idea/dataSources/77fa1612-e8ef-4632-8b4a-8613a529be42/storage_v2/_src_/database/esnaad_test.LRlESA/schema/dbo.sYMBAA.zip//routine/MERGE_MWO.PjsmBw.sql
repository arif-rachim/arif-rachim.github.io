-- exec [MERGE_MWO]
CREATE    PROC [dbo].[MERGE_MWO] 
	@fromMwoId uniqueidentifier ,
	@toMwoId uniqueidentifier 
AS
BEGIN
	declare @fromSuperSededByMwoId uniqueidentifier 
	declare @fromSuperSedesMwoId uniqueidentifier 
	declare @fromStatusId bigInt
	declare @fromIsPcw bigInt
	declare @fromIsSupcancelled bigInt
	declare @toSuperSededByMwoId uniqueidentifier 
	declare @toSuperSedesMwoId uniqueidentifier 

	select @fromSuperSededByMwoId = SUP_BY_MWO_ID, @fromSuperSedesMwoId =SUP_MWO_ID, @fromStatusId = MWO_STS_ID, @fromIsPcw = IS_PCW_,  @fromIsSupcancelled = IS_SUP_MWO_CANCELLED_ from MNT_TRN_D5_1_MWO_MASTER where ID_ = @fromMwoId
	select @toSuperSededByMwoId = SUP_BY_MWO_ID, @toSuperSedesMwoId =SUP_MWO_ID  from MNT_TRN_D5_1_MWO_MASTER where ID_ = @toMwoId

	--update supersedes
	if @fromSuperSedesMwoId is not null and @toSuperSedesMwoId is not null
	begin 
		update MNT_TRN_D5_1_MWO_MASTER set SUP_BY_MWO_ID  = null, MWO_STS_ID = null where ID_ = @fromSuperSedesMwoId
		--update MNT_TRN_D5_1_MWO_MASTER set SUP_BY_MWO_ID  = @toMwoId, MWO_STS_ID = null where ID_ = @fromSuperSedesMwoId
	end
	else if @fromSuperSedesMwoId is not null 
	begin 
		update MNT_TRN_D5_1_MWO_MASTER set SUP_MWO_ID  = @fromSuperSedesMwoId, IS_PCW_ = @fromIsPcw, IS_SUP_MWO_CANCELLED_ = @fromIsSupcancelled  where ID_ = @toMwoId
		update MNT_TRN_D5_1_MWO_MASTER set SUP_BY_MWO_ID  = @toMwoId where ID_ = @fromSuperSedesMwoId
	end

	--update superseded by
	if @fromSuperSededByMwoId is not null and @toSuperSededByMwoId is not null
	begin 
		update MNT_TRN_D5_1_MWO_MASTER set SUP_MWO_ID  = null, IS_PCW_ = 0, IS_SUP_MWO_CANCELLED_=0 where ID_ = @fromSuperSededByMwoId
	end
	else if @fromSuperSededByMwoId is not null 
	begin 
		update MNT_TRN_D5_1_MWO_MASTER set SUP_MWO_ID = @toMwoId where ID_ = @fromSuperSededByMwoId
		update MNT_TRN_D5_1_MWO_MASTER set SUP_BY_MWO_ID = @fromSuperSededByMwoId , MWO_STS_ID = @fromStatusId where ID_ = @toMwoId
	end

	update MNT_TRN_D5_1_MWO_MASTER set SUP_BY_MWO_ID  = null, MWO_STS_ID = null where ID_ = @toMwoId and SUP_BY_MWO_ID = @toMwoId
	update MNT_TRN_D5_1_MWO_MASTER set SUP_MWO_ID  = null, IS_PCW_ = 0, IS_SUP_MWO_CANCELLED_=0 where ID_ = @toMwoId and SUP_MWO_ID = @toMwoId

	

	--delete fromassignment if exist in to
	delete from MNT_TRN_D5_1_ASSIGNMENT where MWO_ID = @fromMwoId and D15_COM_ID in (
		select iasg.D15_COM_ID from MNT_TRN_D5_1_ASSIGNMENT iasg where iasg.MWO_ID = @toMwoId
	)
	--update fromassignment to toassignment
	update MNT_TRN_D5_1_ASSIGNMENT set MWO_ID = @toMwoId where MWO_ID = @fromMwoId



	--commands insert frommwo to tomwo
	insert into MNT_TRN_D5_1_MWO_COMMAND
	select 
		NEWID() ID_, VERSION_, @toMwoId AS MWO_ID, CMD_ID,  
		CREATED_BY_,PID_CREATED_BY_,FULL_NAME_CREATED_BY_,CREATED_ON_,
		MOD_BY_,PID_MOD_BY_,FULL_NAME_MOD_BY_,MOD_ON_,TERM_

	from MNT_TRN_D5_1_MWO_COMMAND  
	where MWO_ID = @fromMwoId and CMD_ID not in (
		select CMD_ID from MNT_TRN_D5_1_MWO_COMMAND where MWO_ID = @toMwoId
	)
	--delete fromcommand
	delete from MNT_TRN_D5_1_MWO_COMMAND where MWO_ID = @fromMwoId



	--applicable parts insert frommwo to tomwo
	insert into MNT_TRN_D5_1_MWO_APPL_ITEM
	select 
		NEWID() ID_, VERSION_, @toMwoId AS MWO_ID, APPL_ITEM_ID,  
		CREATED_BY_,PID_CREATED_BY_,FULL_NAME_CREATED_BY_,CREATED_ON_,
		MOD_BY_,PID_MOD_BY_,FULL_NAME_MOD_BY_,MOD_ON_,TERM_

	from MNT_TRN_D5_1_MWO_APPL_ITEM  
	where MWO_ID = @fromMwoId and APPL_ITEM_ID not in (
		select APPL_ITEM_ID from MNT_TRN_D5_1_MWO_APPL_ITEM where MWO_ID = @toMwoId
	)
	--delete applicable parts
	delete from MNT_TRN_D5_1_MWO_APPL_ITEM where MWO_ID = @fromMwoId



	--history update all frommwo history to tomwo
	update MNT_HST_D5_1_MWO_COMPONENTS set TRN_ID_ = @toMwoId where TYPE_ = 'Mwo' AND TRN_ID_ = @fromMwoId

	delete from MNT_TRN_D5_1_MWO_MASTER where ID_ = (@fromMwoId)

--select * from MNT_HST_D5_1_MWO_COMPONENTS where TYPE_ = 'Mwo' AND TRN_ID_ = @toMwoId
--select * from MNT_TRN_D5_1_MWO_APPL_ITEM where MWO_ID IN (@fromMwoId, @toMwoId)
--select * from MNT_TRN_D5_1_MWO_COMMAND where MWO_ID IN (@fromMwoId, @toMwoId)
--select * from MNT_TRN_D5_1_ASSIGNMENT where MWO_ID IN (@fromMwoId, @toMwoId)

END
go

