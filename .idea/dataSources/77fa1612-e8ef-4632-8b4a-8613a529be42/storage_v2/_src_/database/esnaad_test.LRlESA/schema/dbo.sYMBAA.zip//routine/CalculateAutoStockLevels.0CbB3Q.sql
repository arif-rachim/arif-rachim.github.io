CREATE PROCEDURE [dbo].[CalculateAutoStockLevels]
	@acslId bigint,
	@refId uniqueidentifier
AS
BEGIN
	
	SET NOCOUNT ON;

	declare @buId bigint, @l2Id bigInt, @itemClasses nvarchar(30)

	select @buId = STORE_ID, @l2Id = L2_ID, @itemClasses = ITEM_CLASS_ from LOG_TRN_SLM_AUTO_STOCK_LEVEL where id_=@acslId

	insert into LOG_TRN_SLM_AUTO_STOCK_LEVEL_ITEMS (
		ACSL_ID, ITEM_ID, MAX_CRNT_, MAX_RCMD_, SAFETY_CRNT_, SAFETY_RCMD_, MIN_CRNT_, MIN_RCMD_, WAR_CRNT_, WAR_RCMD_, MAX_CONSUMPTION_QTY_, MIN_CONSUMPTION_QTY_, ALT_FACTOR_, LLT_FACTOR_, EXP_FACTOR_, SELECTED_
	)
	select
		@acslId, calc.ItemId, sl.MAX_, calc.MaxLevel, sl.SAFETY_, calc.SafetyLevel, sl.MIN_, calc.MinLevel, sl.WAR_RESERVE_, calc.WarLevel, calc.MaxConsumption, calc.MinConsumption, calc.AvgLeadTime, calc.LongLeadTime, calc.ExpiryFactor, cast(0 as bit)
	from (
		select ItemId,      
			MaxConsumption,
			MinConsumption,
			AvgLeadTime,
			LongLeadTime,
			ExpiryFactor,		
			MinLevel,		
			SafetyLevel,
			MaxLevel,		
			WarLevel
		from dbo.AcslGetItemConsumptionCalculation(@refId, 0)
	) calc
	inner join ADM_TRN_ITEM_ASSOCS ia ON ia.ITEM_ID = calc.ItemId
		and ia.PRIMARY_PART_ = 1
	left join LOG_TRN_STOCK_LEVEL2 sl ON sl.ITEM_ASSOC_ID_ = ia.ID_ and sl.STORE_ID = @buId
	where ia.L2_ID = @l2Id
	and ( calc.MaxLevel <> isnull(sl.MAX_, -1) or calc.SafetyLevel <> isnull(sl.SAFETY_, -1) or calc.MinLevel <> isnull(sl.MIN_, -1) or calc.WarLevel <> isnull(sl.WAR_RESERVE_, -1) )

	END
go

