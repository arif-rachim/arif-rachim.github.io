-- =============================================
-- Author:		KIRAN
-- Create date: 17-NOV-2015
-- Description:	Global Search Aircraft Serviceability - Hours to Inspn and Hours to Phase
-- =============================================
CREATE FUNCTION ConvertHoursToDecimal
(
	-- Add the parameters for the function here
	@searchHour real
)
RETURNS Varchar(15)
AS
BEGIN
	return CONVERT(VARCHAR, CONVERT(DECIMAL(15,1),@searchHour));

END
go

