CREATE view vwJAAMMissionReportHeader
as 
with t (FlightDate, Command, Battalion, Platform, SupportTo
        ,MissionMinutes, MissionId, Pid)
as (
    select DATEADD("Minute", bd.GMT_DIFF_, rec.RTD_) AS FlightDate, cmd.CODE_ as Command, bat.CODE_ as Battalion, pltf.CODE_ as Platform, ext.NAME_ as SupportTo
        , rec.FLIGHT_MINS_ as MissionMinutes, mis.ID_ as MissionId, usr.PID_ as Pid
    from OPS_TRN_MISSIONS mis
    inner join OPS_MST_EXTERNAL ext on mis.EXTERNAL_ID = ext.ID_
    inner join OPS_TRN_FLIGHTS fli on fli.MISSION_ID = mis.ID_
    inner join dbo.OPS_TRN_TAIL_FLIGHT tailf on tailf.FLIGHT_ID = fli.ID_
    inner join dbo.OPS_TRN_TAIL_FLIGHT_RECORD rec on rec.TAIL_FLIGHT_ID = tailf.ID_
    inner join ADM_MST_AIR_BASES bd on bd.ID_ = tailf.ACTUAL_BASE_FROM_ID
    inner join ADM_MST_AIR_BASES ba on ba.ID_ = tailf.ACTUAL_BASE_TO_ID
    inner join OPS_TRN_TAIL_CREWS tailc on tailf.TAIL_CREW_ID = tailc.ID_ 
    inner join OPS_TRN_WINGS wing on tailc.WING_ID = wing.ID_ and wing.MISSION_ID = mis.ID_
    inner join ADM_MST_RESTRICTIONS coy on wing.COY_ID = coy.ID_ 
    inner join ADM_MST_PLATFORMS pltf on wing.PLTF_ID = pltf.ID_ 
    inner join ADM_MST_TAILS tail on tailc.TAIL_ID = tail.ID_ 
    inner join ADM_MST_RESTRICTIONS bat on tail.BATLN_ID = bat.ID_ 
    inner join ADM_MST_RESTRICTIONS cmd on cmd.ID_ = bat.PRNT_ID 
	inner join ADM_TRN_USER_RESTRICION_DETAILS urd on urd.DT_REST_ID = tail.BATLN_ID and urd.LVL_NAME_ = 'Battalion'
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.ID_ = urd.USR_REST_ID and ur.MODULE_ID='EIS.002.00.00.00'
	inner join ADM_TRN_USER_PROFILES usr on usr.ID_ = ur.USER_PROFILE_ID	
    where mis.EXTERNAL_ID is not null
    and convert(varchar(7), DATEADD("Minute", bd.GMT_DIFF_, rec.RTD_), 120) = convert(varchar(7), getdate(), 120)
    and cmd.ID_ in (
		select cmd.ID_
			from CIS_EXCLUDE_COMMAND exc
			inner join CIS_NG_COMMAND_MAP map on exc.CIS_COMMAND_ = map.CIS_COMMAND_
			inner join ADM_MST_RESTRICTIONS cmd on cmd.CODE_ = map.NG_COMMAND_
	)
)  

select jaamc.COMMAND_ CISCommand
	, map.ng_COMMAND_ NGCommand
	, jaamc.JAAM_TOTAL_HOURS TotalHours
	, jaamc.JAAM_TOTAL_SORTIES TotalMissions
	, convert(int, left(jaamc.JAAM_TOTAL_HOURS, charindex( ':', jaamc.JAAM_TOTAL_HOURS) -1 )) AS HourNumber
	, convert(int, substring(jaamc.JAAM_TOTAL_HOURS, charindex( ':', jaamc.JAAM_TOTAL_HOURS) + 1, len(jaamc.JAAM_TOTAL_HOURS)) ) AS MinuteNumber
	, sec.Pid
from CIS_IMP_JAAM_COMMAND jaamc
inner join CIS_NG_COMMAND_MAP map ON  jaamc.COMMAND_ =  map.CIS_COMMAND_
inner join (
	select usr.PID_ as Pid, com.CODE_ as Command
	from ADM_TRN_USER_RESTRICION_DETAILS urd 
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.ID_ = urd.USR_REST_ID and ur.MODULE_ID='EIS.002.00.00.00' and urd.LVL_NAME_ = 'Battalion'
	inner join ADM_MST_RESTRICTIONS bat on urd.DT_REST_ID = bat.ID_
	inner join ADM_MST_RESTRICTIONS com on bat.PRNT_ID= com.ID_
	inner join ADM_TRN_USER_PROFILES usr on usr.ID_ = ur.USER_PROFILE_ID	
	group by usr.PID_, com.CODE_
) sec on sec.Command = map.NG_COMMAND_
where jaamc.COMMAND_ NOT IN (SELECT CIS_COMMAND_ FROM CIS_EXCLUDE_COMMAND)	

union all

select t.Command as CISCommand, t.Command as NGCommand
    --, replace(cast(cast(dbo.ReturnTAAMSTime(sum(t.MissionMinutes)) as decimal(10,2)) as varchar), '.', ':') as TotalHours
    , cast (sum(t.MissionMinutes)/60 as varchar) + ':' 
		+
	  case
	  when sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) < 10
	  then '0' + cast (sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as varchar)
	  else cast (sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60)) as varchar)
	  end as TotalHours	  
    , count(t.MissionId) as TotalMissions
    , sum(t.MissionMinutes)/60 as HourNumber
    , sum(t.MissionMinutes) - (60 * (sum(t.MissionMinutes)/60))as MinuteNumber
    , t.Pid
from t	
group by t.Command, t.Pid
go

