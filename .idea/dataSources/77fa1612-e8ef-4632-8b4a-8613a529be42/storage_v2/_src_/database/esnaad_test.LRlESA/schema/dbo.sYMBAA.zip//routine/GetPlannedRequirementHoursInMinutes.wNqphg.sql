CREATE FUNCTION [dbo].[GetPlannedRequirementHoursInMinutes]
(
	@requirementSnapshotId uniqueidentifier,
	@crewId bigint,
	@companyId bigint,
	@platformId	bigint,
	@year int,
	@month int
)
RETURNS int
AS
BEGIN
	DECLARE @Minutes int
	SELECT @Minutes = MINUTES_ 
	FROM OPS_TRN_CTP_CREW_MONTHLY_PLAN_REQUIREMENT mpr 
		JOIN OPS_TRN_CTP_CREW_MONTHLY_PLAN cmp ON cmp.ID_ = mpr.CREW_MONTHLY_PLAN_ID
		JOIN OPS_TRN_CTP_MONTHLY_PLAN mp ON mp.ID_ = cmp.MONTHLY_PLAN_ID and mp.STATUS_ = 'Approved'
		JOIN OPS_TRN_CTP_UNIT_PLAN_SNAP ups ON ups.ID_ = mp.UNIT_PLAN_ID
	WHERE mpr.REQUIREMENT_ID = @requirementSnapshotId AND cmp.CREW_ID = @crewId AND ups.UNIT_ID = @companyId AND ups.PLTF_ID = @platformId AND ups.YEAR_ = @year AND mp.MONTH_ = @month
	RETURN @Minutes 
END
go

