CREATE FUNCTION [dbo].[ReturnMinutesFromTAAMSTime]
(
	@time decimal(9,1) 
)
RETURNS int
AS
BEGIN
	-- Declare variables
	DECLARE @return_time int 
	DECLARE @hourPart decimal(9,2) 
	DECLARE @minutePart decimal(9,2) 

	if(@time is not null)
	begin

		SELECT @return_time = 0
		SET @hourPart = floor(@time)
		SET @minutePart = (@time - floor(@time)) * 10
		SET @minutePart = @minutePart * 6
		SET @return_time = @hourPart *60 + @minutePart 
	end
	
	RETURN @return_time  

END
go

