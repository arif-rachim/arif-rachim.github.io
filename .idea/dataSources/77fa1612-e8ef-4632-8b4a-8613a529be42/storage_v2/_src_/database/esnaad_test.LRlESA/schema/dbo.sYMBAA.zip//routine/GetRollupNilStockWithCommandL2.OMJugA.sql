CREATE FUNCTION GetRollupNilStockWithCommandL2
(
  @CmdId      bigint,
  @Agl2Id      bigint,
  @BuIds       varchar(max),
  @IsStockInRec bit,
  @IsStoreType bit,
  @partType bit
  
)
RETURNS TABLE 
AS
RETURN 
(
WITH CTE_BASE AS (
		SELECT DISTINCT 
			(CASE WHEN IASSOC.ITEM_ID IS NOT NULL THEN IASSOC.ITEM_ID ELSE L2_ITEMS.ITEM_ID END) AS ItemId, REST.CODE_ AS Command,BU.ID_ AS BuinessUnitId, BU.CODE_ AS BuinessUnit,
			L2.ID_ as Agl2Id,L2.CODE_ AS Agl2, 
			SUM(ISNULL(SUMMARY.RPR_DUES_IN_NOT_CONF_, 0) + ISNULL(SUMMARY.NEW_DUES_IN_NOT_CONF_, 0)) AS DuesInNotConf, 
			SUM(ISNULL(SUMMARY.RPR_DUES_IN_CONF_, 0) + ISNULL(SUMMARY.NEW_DUES_IN_CONF_, 0)) AS DuesInConf, 
			SUM(ISNULL(DUES_OUT.DuesOutUser, 0)) AS DuesOutUser,  BU.ID_ AS BuId  ,L2.ID_ AS L2Id                                                                                               
		FROM   ADM_MST_ITEMS AS ITEMS INNER JOIN
			ADM_TRN_ITEM_ASSOCS AS L2_ITEMS ON L2_ITEMS.ITEM_ID = ITEMS.ID_ LEFT OUTER JOIN
			ADM_TRN_ITEM_ASSOCS AS IASSOC ON IASSOC.L2_ID = L2_ITEMS.L2_ID AND IASSOC.IN_LIEU_CODE_ = L2_ITEMS.IN_LIEU_CODE_ AND IASSOC.PRIMARY_PART_ = 1 INNER JOIN
			ADM_MST_BUSINESS_UNITS_L2 AS BU_L2 ON BU_L2.L2_ID_ = L2_ITEMS.L2_ID INNER JOIN
			ADM_MST_BUSINESS_UNITS AS BU ON BU.ID_ = BU_L2.BU_ID_ AND BU.BU_TYPE_ = 'Store' INNER JOIN
			ADM_TRN_ASSOC_GROUPS AS L2 ON L2.ID_ = L2_ITEMS.L2_ID INNER JOIN
			ADM_MST_RESTRICTIONS AS REST ON REST.ID_ = BU.CMD_ID_ LEFT OUTER JOIN
			VW_DUES_IN_SUMMARY AS SUMMARY ON SUMMARY.ITEM_ID_ = ITEMS.ID_ AND BU.ID_ = SUMMARY.BU_ID_ AND L2.ID_ = SUMMARY.L2_ID_ 

		LEFT JOIN (
									select ItemId as ItemId1 , L2Id as L2Id1, BuId as BuId1, SUM(DuesOutUser) as DuesOutUser 
									from (
										 SELECT SD.ITEM_ID_ AS ItemId, SD.FF_L2_ID_ as L2Id,iif(store.PARENT_STORE_ID_ is null,store.id_,  mainstore.ID_) as BuId
										 , case when (sd.TR_NO_ like 'RQ%' OR sd.TR_NO_ like 'ILR%') then SUM(sd.qty_) else 0 end DuesOutUser 
										 FROM VW_DUES_OUT SD JOIN
										 ADM_MST_BUSINESS_UNITS store on store.ID_= SD.FF_BU_ID_ left join
										ADM_MST_BUSINESS_UNITS mainstore on mainstore.ID_=store.PARENT_STORE_ID_ 
										where store.CMD_ID_=@CmdId
										and ( ( @Agl2Id>0 and SD.FF_L2_ID_=@Agl2Id   ) ) 
										group BY SD.ITEM_ID_, SD.FF_L2_ID_, iif(store.PARENT_STORE_ID_ is null,store.id_,  mainstore.ID_), sd.TR_NO_) as temp 
									   group by ItemId,L2Id,BuId
									) as DUES_OUT ON DUES_OUT.ItemId1=ITEMS.ID_ AND DUES_OUT.BuId1=BU_L2.BU_ID_ AND DUES_OUT.L2Id1= L2.ID_
		WHERE  BU.PARENT_STORE_ID_ is null and 
		BU.IS_ACTIVE_ = 1 AND   (BU.CMD_ID_ = @CmdId)   and ( ( @Agl2Id>0 and L2.ID_=@Agl2Id  AND BU_L2.BU_ID_ IN (SELECT Item from dbo.SplitInts(@BuIds, ',')) ) )  
		GROUP BY L2_ITEMS.IN_LIEU_CODE_, REST.CODE_, BU.CODE_, L2.CODE_, BU.ID_, L2.ID_
		, (CASE WHEN IASSOC.ITEM_ID IS NOT NULL THEN IASSOC.ITEM_ID ELSE L2_ITEMS.ITEM_ID END)
) 
	select  ItemId, Command, BuinessUnit, Agl2, DuesInNotConf, DuesInConf, DuesOutUser, InLieuStock,  Edd.EarliestEdd as EarliestEdd , PartNumber, Nsn, Nomenclature, MfrCode, Category, PblItemType, ItemClass, IsSerialized,IsPrimary, Platforms
                                  ,MAX_ as  MaxLevel, SAFETY_ as SafetyLevel, MIN_ as MinLevel, WAR_RESERVE_ as WarReserve
								  from (
												select  ItemId, Command, BuinessUnit,BuinessUnitId,Agl2Id, Agl2, DuesInNotConf, DuesInConf, DuesOutUser,  ITEMS.PART_NO_ AS PartNumber, 
                                                                        ITEMS.NSN_ AS Nsn, ITEMS.NOMENCLATURE_ AS Nomenclature, MNF.CAGE_CODE_ AS MfrCode, CAT.CODE_ AS Category, ITEMS.PBL_ AS PblItemType, ITEM_CLASS.CODE_ AS ItemClass, 
                                                                        iif( ITEMS.SERIALIZED_ = 0 , 'NO' , 'YES' ) AS IsSerialized,'YES' AS IsPrimary 
																		,(ISNULL(InLieu.Qty, 0)) AS InLieuStock
																		 , isnull(levels.MAX_,0) as MAX_
								                                        , isnull(levels.SAFETY_, 0 ) as SAFETY_
								                                        , isnull(levels.MIN_, 0) as MIN_
								                                        , isnull(levels.WAR_RESERVE_, 0) as WAR_RESERVE_
													from CTE_BASE INNER JOIN 
													ADM_MST_ITEMS AS ITEMS ON ITEMS.ID_ = CTE_BASE.ItemId  INNER JOIN
													ADM_TRN_ITEM_ASSOCS AS L2_ITEMS ON L2_ITEMS.ITEM_ID = ITEMS.ID_ and L2_ITEMS.L2_ID=CTE_BASE.L2Id 
													INNER JOIN
													ADM_MST_BUSINESS_UNITS_L2 AS BU_L2 ON BU_L2.L2_ID_ = L2_ITEMS.L2_ID INNER JOIN
													ADM_MST_BUSINESS_UNITS AS BU ON BU.ID_ = BU_L2.BU_ID_ AND BU.BU_TYPE_ = 'Store' INNER JOIN
													ADM_TRN_ASSOC_GROUPS AS L2 ON L2.ID_ = L2_ITEMS.L2_ID INNER JOIN
													ADM_MST_RESTRICTIONS AS REST ON REST.ID_ = BU.CMD_ID_ LEFT OUTER JOIN
													ADM_MST_SIMPLE_REF AS CAT ON ITEMS.CAT_ID_ = CAT.ID_ INNER JOIN
													ADM_MST_SIMPLE_REF AS ITEM_CLASS ON ITEMS.CLS_ID_ = ITEM_CLASS.ID_ INNER JOIN
													ADM_MST_MANUFACTURES AS MNF ON MNF.ID_ = ITEMS.MNF_ID
													 cross apply (select levels.ID_ as levels_ID_,levels.MAX_ as MAX_
														,levels.SAFETY_ as SAFETY_
														,levels.MIN_ as MIN_
														,levels.WAR_RESERVE_ 
														 FROM  LOG_TRN_STOCK_LEVEL2 AS levels join
														 ADM_MST_BUSINESS_UNITS bul on bul.ID_=levels.STORE_ID
														 WHERE bul.CMD_ID_=@CmdId and  L2_ITEMS.IN_LIEU_CODE_ is null  and levels.ITEM_ASSOC_ID_ = L2_ITEMS.ID_   and levels.STORE_ID=BU.ID_
														 union all
														 SELECT levelsforPrimary.ID_ as levels_ID_, levelsforPrimary.MAX_ as MAX_
															,levelsforPrimary.SAFETY_ as SAFETY_
															,levelsforPrimary.MIN_ as MIN_
															,levelsforPrimary.WAR_RESERVE_ 
														 FROM LOG_TRN_STOCK_LEVEL2 AS levelsforPrimary JOIN
														  ADM_MST_BUSINESS_UNITS bulp on bulp.ID_=levelsforPrimary.STORE_ID JOIN
														 ADM_TRN_ITEM_ASSOCS levelAssoc on levelAssoc.id_=levelsforPrimary.ITEM_ASSOC_ID_ 
														 WHERE bulp.CMD_ID_=@CmdId and  L2_ITEMS.IN_LIEU_CODE_ is not null and     levelsforPrimary.STORE_ID=BU.ID_ and
															   (levelAssoc.L2_ID=L2_ITEMS.L2_ID and  levelAssoc.IN_LIEU_CODE_= L2_ITEMS.IN_LIEU_CODE_ and levelAssoc.PRIMARY_PART_=1)
													)levels  
													 LEFT JOIN (
															SELECT SUM(S.QTY_) as Qty, I.ID_ as ItemId1, s.OWNED_BY_L2_ID_ as L2, iif(store.PARENT_STORE_ID_ is null,store.id_,  mainstore.ID_) as Store, IA.IN_LIEU_CODE_ as InliueCode 
															FROM LOG_TRN_STOCK S JOIN
															ADM_MST_BUSINESS_UNITS store on store.ID_= S.STORE_ID left join
															ADM_MST_BUSINESS_UNITS mainstore on mainstore.ID_=store.PARENT_STORE_ID_
															INNER JOIN ADM_MST_UNITS U ON U.ID_=S.UNIT_ID 
															INNER JOIN ADM_MST_ITEMS I ON I.ID_=U.ITEM_ID 
															INNER JOIN ADM_TRN_ITEM_ASSOCS AS IA ON IA.ITEM_ID = I.ID_ AND IA.L2_ID = S.OWNED_BY_L2_ID_
															WHERE store.CMD_ID_=@CmdId
															and ( ( @Agl2Id>0 and IA.L2_ID=@Agl2Id  ) )  
															and IA.IN_LIEU_CODE_ is not null AND S.TAG_COLOR_COND_ID_ NOT IN (4,8,9,15,16) 
															group by I.ID_, s.OWNED_BY_L2_ID_, iif(store.PARENT_STORE_ID_ is null,store.id_,  mainstore.ID_), IA.IN_LIEU_CODE_
														  ) as InLieu on L2_ITEMS.IN_LIEU_CODE_ is not null   AND InLieu.InliueCode=L2_ITEMS.IN_LIEU_CODE_ AND InLieu.ItemId1<>CTE_BASE.ItemId  

													where  BU.PARENT_STORE_ID_ is null  AND (L2_ITEMS.PRIMARY_PART_ = 1) AND BU.IS_ACTIVE_ = 1 AND (BU.CMD_ID_ = @CmdId) 
													and ( ( @Agl2Id>0 and L2.ID_=@Agl2Id  AND BU_L2.BU_ID_ IN (SELECT Item from dbo.SplitInts(@BuIds, ',')) ) )
													AND levels.levels_ID_ IS NOT NULL and (MAX_ is not null or SAFETY_ is not null or  WAR_RESERVE_ is not null or MIN_ is not null)
													AND NOT EXISTS(
														SELECT 1
														FROM LOG_TRN_STOCK STOCK INNER JOIN
														ADM_MST_UNITS UNIT ON STOCK.UNIT_ID=UNIT.ID_ INNER JOIN
														ADM_MST_UNIT_LOCATION LOC ON LOC.ID_=STOCK.LOC_ID inner join 
														ADM_MST_BUSINESS_UNITS bus on bus.ID_=STOCK.STORE_ID
													   WHERE bus.CMD_ID_ = @CmdId and ( (@Agl2Id>0 and  STOCK.OWNED_BY_L2_ID_=@Agl2Id) ) and UNIT.ITEM_ID = ITEMS.ID_ AND STOCK.OWNED_BY_L2_ID_ = L2.ID_ 
														AND TAG_COLOR_COND_ID_ NOT IN (4,8,9,15,16) AND (UNIT.EXP_DATE_ IS NULL OR UNIT.EXP_DATE_ >= CONVERT(date, GETDATE())  ) 
														AND (( @IsStockInRec=1  AND LOC.LOC_TYPE_ not IN('Receiving','InTransit') ) or (@IsStockInRec=0 and 1=1) )
														)
                                                   	GROUP BY ItemId, Command, BuinessUnit,BuinessUnitId,Agl2Id, Agl2, 
                                DuesInNotConf, DuesInConf, DuesOutUser, ITEMS.PART_NO_, ITEMS.NSN_, 
                                ITEMS.NOMENCLATURE_ , MNF.CAGE_CODE_, CAT.CODE_, ITEMS.PBL_, ITEM_CLASS.CODE_, ITEMS.SERIALIZED_
								 ,(ISNULL(InLieu.Qty, 0)) 
								  , levels.MAX_
                                , levels.SAFETY_
                                , levels.MIN_
                                , levels.WAR_RESERVE_
								)NilStock
								  	 outer apply(
                                        SELECT distinct IPL2.ITEM_ID as pItemId, STRING_AGG(P.CODE_, ', ') as Platforms
                                    FROM ADM_XRF_ITEM_PLATFORM_L2 AS IPL2
                                    INNER JOIN ADM_MST_PLATFORM_L2 AS PL2 ON PL2.ID_ = IPL2.PLATFORM_L2_ID
                                    INNER JOIN ADM_MST_PLATFORMS AS P ON P.ID_ = PL2.PLTF_ID_
                                    WHERE PL2.CMD_ID_ =@CmdId and IPL2.ITEM_ID = ItemId
                                    group by IPL2.ITEM_ID
                           ) IPL   
			              outer apply(
                              select  MIN(VW.EDD_) as EarliestEdd  from(
                               SELECT il.ITEM_ID as ItemId1
                                  FROM ADM_TRN_ITEM_ASSOCS ia
                                       JOIN ADM_TRN_ITEM_ASSOCS il ON ia.IN_LIEU_CODE_ = il.IN_LIEU_CODE_
                                 WHERE ia.ITEM_ID =ItemId
                                   AND ia.L2_ID = Agl2Id
                                   AND ia.IN_LIEU_CODE_ IS NOT NULL 
                                union
	                             SELECT ItemId as ItemId1) temp JOIN VW_DUES_IN_DETAILS AS VW ON temp.ItemId1 = VW.ITEM_ID_   and VW.BU_ID_ = BuinessUnitId AND (VW.L2_ID_ = Agl2Id)
	                            WHERE	 VW.QTY_TYPE_ = 'Confirmed'
                  ) as Edd
)
go

