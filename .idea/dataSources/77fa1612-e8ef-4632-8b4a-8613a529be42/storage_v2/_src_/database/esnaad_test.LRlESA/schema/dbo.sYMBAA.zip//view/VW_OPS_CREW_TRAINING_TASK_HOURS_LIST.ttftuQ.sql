CREATE VIEW [dbo].[VW_OPS_CREW_TRAINING_TASK_HOURS_LIST]
AS
select 
	MissionDate, CompanyId, Company, PlatformId, Platform, Tail, DutySymbol, MissionType, MissionSubType, CrewId, FlightRecordId,IfrActual, IfrSimulated, Seat, MissionTypeSymbol,
	sum (case when (FlightSymbol = 'D' OR FlightSymbol = 'DS' OR FlightSymbol = 'H') then FlyingMinutes else 0 end  ) as DayHours,
	sum (case when (FlightSymbol = 'D' ) then FlyingMinutes else 0 end  ) as D,
	sum (case when (FlightSymbol = 'DS' ) then FlyingMinutes else 0 end  ) as DS,
	sum (case when (FlightSymbol = 'N' OR FlightSymbol = 'NG' OR FlightSymbol = 'NS') then FlyingMinutes else 0 end  ) as NightHours,
	sum (case when (FlightSymbol = 'N' ) then FlyingMinutes else 0 end  ) as N,
	sum (case when (FlightSymbol = 'NG') then FlyingMinutes else 0 end  ) as Nvg,
	sum (case when (FlightSymbol = 'NS') then FlyingMinutes else 0 end  ) as Nvs,
	sum(FlyingMinutes) as Total
from 
	VW_OPS_CREW_TRAINING_TASK_HOURS 
GROUP BY 
	MissionDate, CompanyId, Company, PlatformId, Platform, Tail, DutySymbol, MissionType, MissionSubType, CrewId, FlightRecordId, IfrActual, IfrSimulated, Seat, MissionTypeSymbol
go

