CREATE FUNCTION [dbo].[D16HasDiscrepancyWith2410]
(
  @docId uniqueidentifier
)
  RETURNS bit
AS
BEGIN
  DECLARE @hasDiscrepancy bit;

  SELECT @hasDiscrepancy = (
    CASE
      WHEN (d.IDN_UNIT_ID_ != c.UNIT_ID_ OR
            d.IDN_NO_OF_PREV_OHS_ != ac.PREV_OVR_COUNT_ OR
            d.IDN_WUC_ != m.WUC_ID_ OR
            d.NHA_UNIT_ID_ != p.UNIT_ID_ OR
            d.NHA_HOURS_ != ac.INST_P_HRS_ OR
            ((d.MNT_ACTION_ = 'Install' AND d.GAIN_LOSS_REP_ADM_DATE_ <> ac.INST_DATE_) OR
             (d.MNT_ACTION_ = 'Remove' AND d.GAIN_LOSS_REP_ADM_DATE_ <> ac.REM_DATE_)) OR
            ac.INST_C_LDGS_ != d.IDN_LDGS_) THEN 1
      ELSE 0 END
    )
  FROM MNT_TRN_2410_RECORDING d
         JOIN MNT_TRN_D16_ASSIGNED_COMPONENT ac ON ac.ID_ = d.DOCUMENT_2410_SOURCE_ID_
         JOIN MNT_MST_D16_COMPONENT c ON c.ID_ = ac.COMP_ID_
         JOIN MNT_MST_D16_COMPONENT p ON p.ID_ = ac.PARENT_COMP_ID_
         JOIN MNT_MST_D16_MASTER_COMPONENT m ON m.ID_ = ac.MASTER_COMP_ID_
  WHERE d.ID_ = @docId;

  RETURN @hasDiscrepancy

END;
go

