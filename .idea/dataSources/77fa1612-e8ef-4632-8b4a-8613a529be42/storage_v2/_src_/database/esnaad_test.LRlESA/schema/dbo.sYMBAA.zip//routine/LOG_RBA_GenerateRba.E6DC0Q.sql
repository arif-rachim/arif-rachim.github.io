CREATE PROC [dbo].[LOG_RBA_GenerateRba] 
	@buId bigint, 
	@l2Id bigint, 
	@rrfqIds LOG_BAM_Type_GenerateRBA READONLY, 
	@remarks nvarchar(max)=null,
	@userProfileId bigint,
	@term nvarchar(255),
	@rbaId uniqueidentifier output
AS 
BEGIN
	declare @newBidId uniqueidentifier = dbo.GenerateTimebasedGuid()
	DECLARE @now DATETIME = GETDATE()

	-- Generate RBA Number
	declare @rbaNoTable TABLE(prefix nvarchar(255), year int, month int, formattedNo nvarchar(510))
	declare @year int = YEAR(GETDATE())
	insert @rbaNoTable exec dbo.GenerateSequenceNumber 'RBA', 1, @year
	declare @generatedBidNo varchar(40)
	select @generatedBidNo = formattedNo from @rbaNoTable

	-- Get Priority, RRFQ Number and Repair File Count
	--declare @priority varchar(50), @rrfqNo nvarchar(40), @rfCount int

	--SELECT @priority=PRIORITY_, @rrfqNo=RRFQ_NO_, @rfCount=RF_COUNT_ FROM (
	--	SELECT RRFQ.ID_, RRFQ.RRFQ_NO_, PRIORITY_, CASE PRIORITY_ WHEN 'Express' THEN 0 ELSE 1 END PRIORITY_IDX_, RRFQ.CREATED_ON_
	--	, COUNT(REPAIR_FILE_NO_) OVER() AS RF_COUNT_
	--	, ROW_NUMBER() OVER(ORDER BY CASE PRIORITY_ WHEN 'Express' THEN 0 ELSE 1 END , CREATED_ON_ DESC) AS ROW_NO_
	--	FROM LOG_TRN_RQM_REPAIR_RFQ RRFQ
	--	JOIN @rfqIds RI ON RRFQ.ID_ = RI.rrfqId
	--	JOIN LOG_TRN_RQM_REPAIR_RFQ_ITEM RRFQI ON RRFQI.RRFQ_ID_ = RRFQ.ID_
	--) X
	--WHERE X.ROW_NO_ = 1

	INSERT LOG_TRN_BAM_REPAIR_BID_ANALYSIS(ID_, VERSION_, TFU_BU_ID_, L2_ID_, BID_ANALYSIS_NO_, REMARKS_, STATUS_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, REPAIR_RFQ_NO_, PRIORITY_, ITEM_COUNT_)
	SELECT @newBidId, 1, @buId, @l2Id, @generatedBidNo, @remarks, 'Created', u.UserId, u.Pid, u.FullName, @now, @term, RRFQ_NO_, PRIORITY_,RF_COUNT_
	from dbo.GetUserInfo(@userProfileId) u, (
		SELECT PRIORITY_, RRFQ_NO_, RF_COUNT_ FROM (
			SELECT RRFQ.ID_, RRFQ.RRFQ_NO_, PRIORITY_, CASE PRIORITY_ WHEN 'Express' THEN 0 ELSE 1 END PRIORITY_IDX_, RRFQ.CREATED_ON_
			, COUNT(REPAIR_FILE_NO_) OVER() AS RF_COUNT_
			, ROW_NUMBER() OVER(ORDER BY CASE PRIORITY_ WHEN 'Express' THEN 0 ELSE 1 END , CREATED_ON_ DESC) AS ROW_NO_
			FROM LOG_TRN_RQM_REPAIR_RFQ RRFQ
			JOIN @rrfqIds RI ON RRFQ.ID_ = RI.rrfqId
			JOIN LOG_TRN_RQM_REPAIR_RFQ_ITEM RRFQI ON RRFQI.RRFQ_ID_ = RRFQ.ID_
		) X
		WHERE X.ROW_NO_ = 1
	) RRFQ_SUMMARY


	UPDATE RS
	SET RS.BID_ID_ = @newBidId, RS.REMARKS_ = NULL
	FROM LOG_TRN_RQM_REPAIR_RFQ RRFQ
	JOIN @rrfqIds RI ON RRFQ.ID_ = RI.rrfqId
	JOIN LOG_TRN_BAM_REPAIR_SUPPLIER_RESP RS ON RS.REPAIR_RFQ_NO_ = RRFQ.RRFQ_NO_
	JOIN LOG_TRN_RQM_REPAIR_QUOTATION RQ ON RQ.RRFQ_ID_ = RRFQ.ID_ AND RS.SUP_CODE_ = RQ.SUPPLIER_CODE_
	JOIN LOG_TRN_RPR_REPAIR_FILE RF ON RS.REQ_REPAIR_FILE_ID_ = RF.ID_
	WHERE RS.BID_ID_ IS NULL

	-- Record Bid History
	INSERT LOG_HST_BAM_REPAIR_BID_ANALYSIS(ID_, VERSION_, ACTION_, REPAIR_BID_ID, REMARKS_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
	SELECT dbo.GenerateTimebasedGuid(), 1, 'Create', @newBidId, @remarks, u.UserId, u.Pid, u.FullName, @now ,@term
	FROM dbo.GetUserInfo(@userProfileId) u

	-- Record Item History
	INSERT ADM_HST_ITEM_TX(ID_, VERSION_, ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, IS_SERIALIZED_, MOV_TYPE_, QTY_, BU_ID_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, COND_ID_, DOC_REF_, L2_ID_, REMARKS_, PERF_USER_PROFILE_ID_, PERF_USER_ID_, PERF_PID_, PERF_FULL_NAME_, PERF_ON_, BASE_UOM)
	SELECT dbo.GenerateTimebasedGuid(),1, RF.ITEM_ID, RF.PART_NO_, RF.CAGE_CODE_, RF.NOMENCLATURE_, RF.SERIAL_NO_, I.SERIALIZED_, 'RBAC', 1, RF.TFU_ID_, U.UserId, U.Pid, U.FullName, @now, @term, RF.TAG_COLOR_ID_, RF.REPAIR_FILE_NO_, RF.L2_ID_, 'Repair Bid Analysis Created', @userProfileId, U.UserId, U.Pid, U.FullName,@now,UOM.CODE_
	FROM LOG_TRN_RQM_REPAIR_RFQ_ITEM RRFQI
	JOIN @rrfqIds RI ON RRFQI.RRFQ_ID_ = RI.rrfqId
	JOIN LOG_TRN_RPR_REPAIR_FILE RF ON RF.REPAIR_FILE_NO_ = RRFQI.REPAIR_FILE_NO_
	JOIN ADM_MST_ITEMS I ON RF.ITEM_ID = I.ID_
	JOIN LOG_MST_UNIT_OF_MEASURE UOM ON UOM.ID_ = I.UOM_ID_, dbo.GetUserInfo(@userProfileId) U

	-- Record Repair File History
	INSERT LOG_HST_RPR_REPAIR_FILE(ID_, VERSION_, REPAIR_FILE_NO_, STATUS_, H_CREATED_DATE_, BID_ANALYSIYS_REF_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
	SELECT dbo.GenerateTimebasedGuid(), 1, RF.REPAIR_FILE_NO_, 'BidAnalysisCreated', @now, @generatedBidNo, U.UserId, U.Pid, U.FullName, @now, @term
	FROM LOG_TRN_RQM_REPAIR_RFQ_ITEM RRFQI
	JOIN @rrfqIds RI ON RRFQI.RRFQ_ID_ = RI.rrfqId
	JOIN LOG_TRN_RPR_REPAIR_FILE RF ON RF.REPAIR_FILE_NO_ = RRFQI.REPAIR_FILE_NO_, dbo.GetUserInfo(@userProfileId) U

	-- Update Repair File status
	UPDATE RF
	SET STATUS_ = 'BidAnalysisCreated', MOD_BY_ = U.UserId, PID_MOD_BY_ = U.Pid, FULL_NAME_MOD_BY_ = U.FullName, MOD_ON_ = @now
	FROM LOG_TRN_RQM_REPAIR_RFQ_ITEM RRFQI
	JOIN @rrfqIds RI ON RRFQI.RRFQ_ID_ = RI.rrfqId
	JOIN LOG_TRN_RPR_REPAIR_FILE RF ON RF.REPAIR_FILE_NO_ = RRFQI.REPAIR_FILE_NO_, dbo.GetUserInfo(@userProfileId) U

	-- Update Repair File Latest State Info
	UPDATE RFSI
	SET BID_CREATED_ON_ = @now, BID_CREATED_BY_ = U.UserId
	FROM LOG_TRN_RQM_REPAIR_RFQ_ITEM RRFQI
	JOIN @rrfqIds RI ON RRFQI.RRFQ_ID_ = RI.rrfqId
	JOIN LOG_TRN_RPR_REPAIR_FILE_EXT_LST_STATE_INFO RFSI ON RFSI.REPAIR_FILE_NO_ = RRFQI.REPAIR_FILE_NO_, dbo.GetUserInfo(@userProfileId) U

	SET @rbaId = @newBidId
END
go

