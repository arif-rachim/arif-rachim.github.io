CREATE VIEW [dbo].[VW_CIS_RPT_AIRCRAFT_FLEET]
AS
SELECT        SC.NG_COMMAND_ID AS CommandId, SC.NG_COMMAND AS Command, SP.NG_PLATFORM_ID AS PlatformId, SP.NG_PLATFORM AS Platform, T.T_NUM_ AS TailNo, 
                         ST.STATUS_ AS Status, ST.COND_ AS Condition, ST.REMARKS_ AS ReasonForNonServiceability, NULL AS Remarks, NULL AS Completed, NULL AS StartDate, NULL 
                         AS EstCompletionDate, ST.AC_HRS AS AcftHrs, NULL AS MthFltTime, NULL AS HrsNextInsp, P.ORDER_ AS PlatformOrder
FROM            dbo.CIS_IMP_ACT_STRENGTH_TAIL AS ST INNER JOIN
                         dbo.ADM_MST_TAILS AS T ON ST.NG_TAIL_ID = T.ID_ INNER JOIN
                         dbo.CIS_IMP_ACT_STRENGTH_PLATFORM AS SP ON ST.PLATFORM_ID = SP.ID_ INNER JOIN
                         dbo.ADM_MST_PLATFORMS AS P ON SP.NG_PLATFORM_ID = P.ID_ INNER JOIN
                         dbo.CIS_IMP_ACT_STRENGTH_COMMAND AS SC ON SP.COMMAND_ID = SC.ID_ INNER JOIN
                         dbo.ADM_MST_RESTRICTIONS AS R ON T.BATLN_ID = R.ID_ AND R.PRNT_ID = SC.NG_COMMAND_ID
go

