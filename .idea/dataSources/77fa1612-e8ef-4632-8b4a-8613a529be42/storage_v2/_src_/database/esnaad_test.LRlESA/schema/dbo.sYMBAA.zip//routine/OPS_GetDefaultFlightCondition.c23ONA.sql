CREATE FUNCTION [dbo].[OPS_GetDefaultFlightCondition] (@dateTime AS datetime, @sunRise as time, @sunSet as time) RETURNS CHAR
AS BEGIN
 /**
	Default Official Sun Rise Time: 06:00 Local time (UAE Time) --> 02:00 GMT
	Default Official Sun Set Time: 18:00 Local time (UAE Time) --> 14:00 GMT
 */
 RETURN CASE WHEN CAST(@dateTime AS TIME) BETWEEN DATEADD(mi, -30, ISNULL(@sunRise,CAST('02:00:00' AS TIME))) AND DATEADD(mi, 30, ISNULL(@sunSet, CAST('14:00:00' AS TIME)) )THEN 'D' ELSE 'N' END
END
go

