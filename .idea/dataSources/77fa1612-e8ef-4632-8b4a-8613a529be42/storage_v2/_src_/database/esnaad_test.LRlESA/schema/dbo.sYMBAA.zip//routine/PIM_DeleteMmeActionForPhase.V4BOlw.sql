CREATE Proc [dbo].[PIM_DeleteMmeActionForPhase](
 @mmeRosterId bigint,
 @mmeAction nvarchar(max),
 @mmeActionStatusId bigint
 )
AS
BEGIN
 
		select distinct PHASE_INSP_ID into #Inspections_delete 
		FROM MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS WHERE  MME_ROSTER_ID_=@mmeRosterId 

		alter table #Inspections_delete 
		add mmeIndex int


		Begin tran
		
			update CTE set CTE.mmeIndex=act.IDX_ from MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS act join
			#Inspections_delete CTE  on CTE.PHASE_INSP_ID=act.PHASE_INSP_ID
			where act.ACTION_=@mmeAction and act.MME_ROSTER_ID_=@mmeRosterId;

			delete tmp from
			(select act.*, (ROW_NUMBER() over ( partition by act.PHASE_INSP_ID,act.STATUS_ID,act.ACTION_ order by act.IDX_)) rownum 
			from MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS act
			where act.PHASE_INSP_ID in (select PHASE_INSP_ID from  #Inspections_delete CTE)
			and act.ACTION_=@mmeAction and act.STATUS_ID=@mmeActionStatusId and act.MME_ROSTER_ID_=@mmeRosterId
			) tmp where tmp.rownum=1

			update act set act.IDX_= iif(act.IDX_>CTE.mmeIndex,act.IDX_-1,act.IDX_)
			from MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS act join
			#Inspections_delete CTE  on CTE.PHASE_INSP_ID=act.PHASE_INSP_ID

			update inspDetail
			set INSP_ACTIONS_COUNT_=(select count(*) from MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS where PHASE_INSP_ID=inspDetail.ID_) 
			from MNT_TRN_PIM_PHASE_INSPECTION inspDetail inner join
			#Inspections_delete CTE on CTE.PHASE_INSP_ID=inspDetail.ID_


		Commit

		drop table if exists #Inspections_delete
		
END
go

