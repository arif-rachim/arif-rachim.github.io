-- =============================================
-- Author:		Subhash
-- Create date: 21-May-2013
-- Description:	view OPS_TRN_TAIL_FLIGHT_RECORD_WITH_MISSION
-- =============================================
CREATE VIEW [dbo].[VW_OPS_TRN_TAIL_FLIGHT_RECORD_WITH_MISSION]
AS

SELECT DISTINCT 
                      dbo.OPS_TRN_TAIL_FLIGHT_RECORD.ID_, dbo.OPS_TRN_TAIL_FLIGHT_RECORD.RTA_, dbo.OPS_TRN_TAIL_FLIGHT_RECORD.RTD_, 
                      dbo.OPS_TRN_TAIL_FLIGHT_RECORD.LANDINGS_, dbo.OPS_TRN_TAIL_CREWS.TAIL_ID, dbo.OPS_TRN_MISSIONS.DATE_ AS MISSION_DATE, 
                      dbo.OPS_TRN_MISSIONS.WF_STATE_
FROM         dbo.OPS_TRN_TAIL_FLIGHT_RECORD INNER JOIN
                      dbo.OPS_TRN_TAIL_FLIGHT ON dbo.OPS_TRN_TAIL_FLIGHT_RECORD.TAIL_FLIGHT_ID = dbo.OPS_TRN_TAIL_FLIGHT.ID_ INNER JOIN
                      dbo.OPS_TRN_TAIL_CREWS ON dbo.OPS_TRN_TAIL_FLIGHT.TAIL_CREW_ID = dbo.OPS_TRN_TAIL_CREWS.ID_ INNER JOIN
                      dbo.OPS_TRN_WINGS ON dbo.OPS_TRN_TAIL_CREWS.WING_ID = dbo.OPS_TRN_WINGS.ID_ INNER JOIN
                      dbo.OPS_TRN_MISSIONS ON dbo.OPS_TRN_WINGS.MISSION_ID = dbo.OPS_TRN_MISSIONS.ID_
go

