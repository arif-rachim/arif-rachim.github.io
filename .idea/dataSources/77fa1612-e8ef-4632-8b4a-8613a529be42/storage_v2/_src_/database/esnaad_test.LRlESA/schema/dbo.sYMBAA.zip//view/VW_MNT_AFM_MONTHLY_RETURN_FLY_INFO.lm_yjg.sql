CREATE VIEW [dbo].[VW_MNT_AFM_MONTHLY_RETURN_FLY_INFO] AS

select * from 
(
	select 0 as status_id, 'Flight' as code_, 101 as order_, dbo.[ReturnTAAMSTime](d.flight_mins_) as flight_mins_, 'flights' as Type_,
	datepart(day, d.date_) day_,
	datepart(month, d.date_) month_,
	left(datename(month, d.date_),3) month_text_,
	year(d.date_) year_,
	--d.unit_id_ as tail_id
	t.id_ as tail_id
	from ADM_TRN_UNIT_USAGE_DETAIL d inner join
	adm_mst_units u  ON u.ID_ = d.UNIT_ID_ inner join
	adm_mst_tails t ON t.UNIT_ID = u.ID_ 
) as src
PIVOT
(
	sum(flight_mins_)
	for day_ in ([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15], [16], [17], [18], [19], [20], [21], [22], [23], [24], [25], [26], [27], [28], [29], [30], [31])
) as pivots 


union all

select * from 
(
	select 0 as ststus_id, 'Landing' as code_, 102 as order_,  d.landings_, 'Landings' as Type_,
	datepart(day, d.date_) day_,
	datepart(month, d.date_) month_,
	left(datename(month, d.date_),3) month_text_,
	year(d.date_) year_,
	--d.unit_id_ as tail
	t.id_ as tail_id
	from ADM_TRN_UNIT_USAGE_DETAIL d inner join
	adm_mst_units u  ON u.ID_ = d.UNIT_ID_ inner join
	adm_mst_tails t ON t.UNIT_ID = u.ID_ 
)as src
PIVOT
(
	sum(landings_)
	for day_ in ([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15], [16], [17], [18], [19], [20], [21], [22], [23], [24], [25], [26], [27], [28], [29], [30], [31])
) as pivots
go

