CREATE FUNCTION [dbo].[GetTotalAchievedRequirementHoursInMinutes]
(
	@jacMonthReturnDetailId uniqueidentifier
)
RETURNS int
AS
BEGIN
	DECLARE @Minutes int
	SELECT @Minutes = SUM(MINUTES_) FROM OPS_TRN_MOR_JAC_MONTHLY_RETURN_DETAIL_REQUIREMENT WHERE MOR_DETAIL_ID = @jacMonthReturnDetailId
	RETURN @Minutes 
END
go

