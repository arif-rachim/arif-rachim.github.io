CREATE PROCEDURE [dbo].[OPS_CREW_ANNUAL_FLYING_HOURS]
@crewId BIGINT ,
@timeFormat VARCHAR(100) ,
@platformId BIGINT

AS
BEGIN
IF(@timeFormat = 'HourMinute')
BEGIN
--GetFlightSymbolListWithHourMinuteFormat
SELECT FlightSymbol, CAST(dbo.ConvertMinutesToHHMM(SUM([FlyMinutes]) * 60) AS VARCHAR) as TotalTime FROM
(
      SELECT                                            
      'DAY' As FlightSymbol   
      ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
      FROM OPS_MST_FLIGHT_CREWS Crews     
      INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
      DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
      INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
      INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
      INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
      INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
    WHERE FS.CODE_ IN ('D','DS', 'H')
      AND
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                  OR
                  (@platformId IS NULL OR @platformId = 0)
            )
            
      UNION ALL
      SELECT                                            
      'NIGHT' As FlightSymbol 
      ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
      FROM OPS_MST_FLIGHT_CREWS Crews     
      INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
      DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
      INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
      INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
      INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
      INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
    WHERE FS.CODE_ IN ('N', 'NG', 'NS')
      AND
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                  OR
                  (@platformId IS NULL OR @platformId = 0)
            )
      
      UNION ALL
      SELECT                                            
      'NVG' As FlightSymbol   
      ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
      FROM OPS_MST_FLIGHT_CREWS Crews     
      INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
      DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
      INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
      INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
      INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
      INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
    WHERE FS.CODE_ IN ('NG')
      AND
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                  OR
                  (@platformId IS NULL OR @platformId = 0)
            )
      ) As Drv
GROUP BY FlightSymbol

--GetCrewAnnualFlyingHoursInHourMinute
SELECT CrewName, YearPart, MonthPart, FlightSymbol, CAST(dbo.ConvertMinutesToHHMM(SUM([FlyMinutes]) * 60) AS VARCHAR) as TotalTime FROM
(
      SELECT
      UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
      , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
      , 'DAY' As FlightSymbol 
      ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
      FROM OPS_MST_FLIGHT_CREWS Crews     
      INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
      DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
      INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
      INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
      INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
      INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
    WHERE FS.CODE_ IN ('D', 'DS', 'H')
      AND 
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                        OR
                  (@platformId IS NULL OR @platformId =0)
            )
            
      UNION ALL
      SELECT
      UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
      , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
      , 'NIGHT' As FlightSymbol     
      ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
      FROM OPS_MST_FLIGHT_CREWS Crews     
      INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
      DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
      INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
      INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
      INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
      INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
    WHERE FS.CODE_ IN ('N', 'NG', 'NS')
      AND 
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                        OR
                  (@platformId IS NULL OR @platformId =0)
            )
            
      UNION ALL
      SELECT
      UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
      , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
      , 'NVG' As FlightSymbol 
      ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
      FROM OPS_MST_FLIGHT_CREWS Crews     
      INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
      DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
      INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
      INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
      INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
      INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
    WHERE FS.CODE_ IN ('NG')
      AND 
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                        OR
                  (@platformId IS NULL OR @platformId =0)
            )
      
) As Drv
GROUP BY CrewName, YearPart, MonthPart, FlightSymbol
ORDER BY YearPart, MonthPart

--GetCrewMonthlyFlyingHoursInHourMinute
SELECT YearPart, MonthPart, CAST(dbo.ConvertMinutesToHHMM(SUM([FlyMinutes]) * 60) AS VARCHAR) as TotalTime FROM
(
      SELECT                                           
      DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
      , FS.CODE_ As FlightSymbol    
      ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
      FROM OPS_MST_FLIGHT_CREWS Crews     
      INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
      DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
      INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
      INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
      INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
      INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
      WHERE FS.CODE_ IN ('D', 'DS', 'H', 'N', 'NG', 'NS')
      AND
      (
            (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                  OR
            (@platformId IS NULL OR @platformId =0)
      )           
) As Drv
GROUP BY YearPart, MonthPart
ORDER BY YearPart, MonthPart

----GetGrandTotalHoursInTamms -- Day Total
SELECT CAST(dbo.ConvertMinutesToHHMM(SUM([FlyMinutes]) * 60) AS VARCHAR) as TotalTime FROM
(
      SELECT
      UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
      , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
      , FS.CODE_ As FlightSymbol    
      ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
      FROM OPS_MST_FLIGHT_CREWS Crews     
      INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
      DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
      INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
      INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
      INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
      INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
      WHERE FS.CODE_ IN ('D', 'DS', 'H', 'N', 'NG', 'NS')
      AND
      (
            (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                  OR
            (@platformId IS NULL OR @platformId =0)
      )           
) As Drv

--GetGrandTotalHoursInTamms -- Night Total
SELECT CAST(dbo.ConvertMinutesToHHMM(SUM([FlyMinutes]) * 60) AS VARCHAR) as TotalTime FROM
(
      SELECT
      UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
      , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
      , FS.CODE_ As FlightSymbol    
      ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
      FROM OPS_MST_FLIGHT_CREWS Crews     
      INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
      DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
      INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
      INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
      INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
      INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
      INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
      INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
      WHERE FS.CODE_ IN ('N', 'NG', 'NS')
      AND
      (
            (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                  OR
            (@platformId IS NULL OR @platformId =0)
      )           
) As Drv

END
ELSE
BEGIN
--GetFlightSymbolListWithTammsFormat
SELECT FlightSymbol, CAST(SUM(TotalTime) AS VARCHAR) AS TotalTime FROM
(
      SELECT CrewName, YearPart, MonthPart, FlightSymbol, dbo.ReturnTAAMSTime(SUM([FlyMinutes])) as TotalTime FROM
      (
            SELECT UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName, DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, 
            MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
            , 'DAY' As FlightSymbol, FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                  
            FROM OPS_MST_FLIGHT_CREWS Crews     
            INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND 
            DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
            INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
            INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
            INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
            INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
        WHERE FS.CODE_ IN ('D', 'DS', 'H')                        
            AND 
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                        OR
                  (@platformId IS NULL OR @platformId =0)
            )
      ) As Drv
GROUP BY CrewName, YearPart, MonthPart, FlightSymbol ) AS DRV1
GROUP BY FlightSymbol   

UNION ALL
SELECT FlightSymbol, CAST(SUM(TotalTime) AS VARCHAR) AS TotalTime FROM
(
      SELECT CrewName, YearPart, MonthPart, FlightSymbol, dbo.ReturnTAAMSTime(SUM([FlyMinutes])) as TotalTime FROM
      (
            SELECT UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName, DATEPART(year,DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, 
            MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
            , 'NIGHT' As FlightSymbol, FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
            FROM OPS_MST_FLIGHT_CREWS Crews     
            INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND 
            DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
            INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
            INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
            INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
            INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
        WHERE FS.CODE_ IN ('N', 'NG', 'NS')                       
            AND 
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                        OR
                  (@platformId IS NULL OR @platformId =0)
            )
      ) As Drv
GROUP BY CrewName, YearPart, MonthPart, FlightSymbol ) AS DRV1
GROUP BY FlightSymbol

UNION ALL
SELECT FlightSymbol, CAST(SUM(TotalTime) AS VARCHAR) AS TotalTime FROM
(
      SELECT CrewName, YearPart, MonthPart, FlightSymbol, dbo.ReturnTAAMSTime(SUM([FlyMinutes])) as TotalTime FROM
      (
            SELECT UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName, DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, 
            MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
            , 'NVG' As FlightSymbol, FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                  
            FROM OPS_MST_FLIGHT_CREWS Crews     
            INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND 
            DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
            INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
            INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
            INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
            INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
        WHERE FS.CODE_ IN ('NG')                      
            AND 
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                        OR
                  (@platformId IS NULL OR @platformId =0)
            )
      ) As Drv
GROUP BY CrewName, YearPart, MonthPart, FlightSymbol ) AS DRV1
GROUP BY FlightSymbol


--GetCrewAnnualFlyingHoursInTamms
SELECT CrewName, YearPart, MonthPart, FlightSymbol, CAST(dbo.ReturnTAAMSTime(SUM([FlyMinutes])) AS VARCHAR) as TotalTime FROM
(
    SELECT
        UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
        , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
        , 'DAY' As FlightSymbol     
        ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                    
    FROM OPS_MST_FLIGHT_CREWS Crews     
    INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
    INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
    INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
    DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
    INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
    INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
    INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
    INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
    INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID 
    INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
    WHERE FS.CODE_ IN ('D', 'DS', 'H')
      AND
      (
            (@platformId > 0 AND Wings.PLTF_ID = @platformId)
            OR
            (@platformId IS NULL OR @platformId =0)
      )
      
UNION ALL 
SELECT
        UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
        , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
        , 'NIGHT' As FlightSymbol   
        ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                    
    FROM OPS_MST_FLIGHT_CREWS Crews     
    INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
    INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
    INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
    DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
    INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
    INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
    INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
    INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
    INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID 
    INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
    WHERE FS.CODE_ IN ('N', 'NG', 'NS')
      AND
      (
            (@platformId > 0 AND Wings.PLTF_ID = @platformId)
            OR
            (@platformId IS NULL OR @platformId =0)
      )

UNION ALL 
SELECT
        UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
        , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
        , 'NVG' As FlightSymbol     
        ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                    
    FROM OPS_MST_FLIGHT_CREWS Crews     
    INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
    INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
    INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
    DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
    INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
    INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
    INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
    INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
    INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID 
    INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
    WHERE FS.CODE_ IN ('NG')
      AND
      (
            (@platformId > 0 AND Wings.PLTF_ID = @platformId)
            OR
            (@platformId IS NULL OR @platformId =0)
      )    
      ) As Drv 
GROUP BY CrewName, YearPart, MonthPart, FlightSymbol
ORDER BY YearPart, MonthPart


--GetCrewMonthlyFlyingHoursInTamms
SELECT YearPart, MonthPart, SUM(TotalTime) as TotalTime FROM
(
SELECT YearPart, MonthPart, dbo.ReturnTAAMSTime(SUM(TotalTime)) as TotalTime FROM
(
SELECT CrewName, YearPart, MonthPart, SUM([FlyMinutes]) as TotalTime FROM
                                                            (
                                                                  SELECT
                                                                        UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
                                                                        , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
                                                                        , FS.CODE_ As FlightSymbol      
                                                                    ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                   
                                                                  FROM OPS_MST_FLIGHT_CREWS Crews     
                                                                  INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
                                                                  INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
                                                                  INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
                                                                DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
                                                                  INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
                                                                  INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
                                                                INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
                                                                INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
                                                                INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID 
                                                                INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
                                                                                  WHERE FS.CODE_ IN ('D', 'DS', 'H')
                                                                                  AND
                                                                                                (
                                                                                                      (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                                                                                                      OR
                                                                                                      (@platformId IS NULL OR @platformId =0)
                                                                                                )
) As Drv
GROUP BY CrewName, YearPart, MonthPart
) AS DRV1
GROUP BY YearPart, MonthPart

UNION ALL

SELECT YearPart, MonthPart, dbo.ReturnTAAMSTime(SUM(TotalTime))as TotalTime FROM
(
SELECT CrewName, YearPart, MonthPart, SUM([FlyMinutes]) as TotalTime FROM
                                                            (
                                                                  SELECT
                                                                        UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
                                                                        , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
                                                                        , FS.CODE_ As FlightSymbol      
                                                                    ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                   
                                                                  FROM OPS_MST_FLIGHT_CREWS Crews     
                                                                  INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
                                                                  INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
                                                                  INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
                                                                DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
                                                                  INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
                                                                  INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
                                                                INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
                                                                INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
                                                                INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID 
                                                                INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
                                                                                  WHERE FS.CODE_ IN ('N', 'NG', 'NS')
                                                                                  AND
                                                                                                (
                                                                                                      (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                                                                                                      OR
                                                                                                      (@platformId IS NULL OR @platformId =0)
                                                                                                )
) As Drv
GROUP BY CrewName, YearPart, MonthPart
) AS DRV1
GROUP BY YearPart, MonthPart
) AS DRV2
GROUP BY YearPart, MonthPart
ORDER BY YearPart, MonthPart
      
--GetGrandTotalHoursInTamms -- Day Total
SELECT CAST(SUM(TotalTime) AS VARCHAR) AS TotalTime FROM
(
      SELECT CrewName, YearPart, MonthPart, dbo.ReturnTAAMSTime(SUM([FlyMinutes])) as TotalTime FROM
      (
            SELECT
            UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
            , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
            , FS.CODE_ As FlightSymbol    
            ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
            FROM OPS_MST_FLIGHT_CREWS Crews     
            INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
            DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
            INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
            INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
            INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
            INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
            WHERE FS.CODE_ IN ('D', 'DS', 'H')
            AND
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                  OR
                  (@platformId IS NULL OR @platformId =0)
            )
            ) As Drv
            GROUP BY CrewName, YearPart, MonthPart
      ) AS Drv1
      
--GetGrandTotalHoursInTamms -- Night Total
SELECT CAST(SUM(TotalTime) AS VARCHAR) AS TotalTime FROM
(
      SELECT CrewName, YearPart, MonthPart, dbo.ReturnTAAMSTime(SUM([FlyMinutes])) as TotalTime FROM
      (
            SELECT
            UserProf.F_NAME_ + ' '+ UserProf.L_NAME_ As CrewName
            , DATEPART(year, DATEADD(HOUR, 4 , FlightRecord.RTD_)) As YearPart, MONTH(DATEADD(HOUR, 4 , FlightRecord.RTD_)) As MonthPart 
            , FS.CODE_ As FlightSymbol    
            ,  FlightDetails.FLYING_MINUTES_ As [FlyMinutes]                                      
            FROM OPS_MST_FLIGHT_CREWS Crews     
            INNER JOIN ADM_TRN_USER_PROFILES UserProf ON Crews.PERSON_ID = UserProf.ID_ AND Crews.ID_ = @crewId
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT CrewFlight ON  Crews.ID_ = CrewFlight.FLIGHT_CREW_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT_RECORD FlightRecord ON CrewFlight.TAIL_FLIGHT_RECORD_ID = FlightRecord.ID_ AND
            DATEADD(HOUR, 4 , FlightRecord.RTD_) > = dbo.GetOpsCrewFlyingRecordStartDate(UserProf.DOB_)
            INNER JOIN OPS_TRN_TAIL_CREW_FLIGHT_DETAILS FlightDetails ON CrewFlight.ID_ = FlightDetails.TAIL_CREW_FLIGHT_ID
            INNER JOIN OPS_TRN_TAIL_FLIGHT AS TailFlight ON FlightRecord.TAIL_FLIGHT_ID = TailFlight.ID_ 
            INNER JOIN OPS_TRN_FLIGHTS AS Flights ON TailFlight.FLIGHT_ID = Flights.ID_ 
            INNER JOIN OPS_TRN_MISSIONS AS Missions ON Flights.MISSION_ID = Missions.ID_ 
            INNER JOIN OPS_TRN_WINGS AS Wings ON Missions.ID_ = Wings.MISSION_ID
            INNER JOIN OPS_MST_FLIGHT_SYMBOL FS ON FS.ID_ = FlightDetails.FLIGHT_SYMBOL_ID
            WHERE FS.CODE_ IN ('N', 'NG', 'NS')
            AND
            (
                  (@platformId > 0 AND Wings.PLTF_ID = @platformId)
                  OR
                  (@platformId IS NULL OR @platformId =0)
            )
            ) As Drv
            GROUP BY CrewName, YearPart, MonthPart
      ) AS Drv1 
END   

SELECT USRPROFILE.USER_ID_ AS Pid, SREF.CODE_ AS Rank, 
UPPER(ISNULL(USRPROFILE.F_NAME_, '') + CASE WHEN USRPROFILE.M_NAME_ IS NOT NULL THEN ' ' + USRPROFILE.M_NAME_ ELSE '' END + CASE WHEN USRPROFILE.L_NAME_ IS NOT NULL THEN ' ' + USRPROFILE.L_NAME_ ELSE '' END) AS FullName, 
CREWS.BRF_NAME_ AS BriefName, COUNTRY.NAME_ AS Country, PROQUALI.NAME_ AS ProfQualification, 
PLATFORM.CODE_ AS PrimaryPlatform, RSTFORCOMPANY.CODE_ AS Company, RST.CODE_ AS Command
FROM OPS_MST_FLIGHT_CREWS AS CREWS 
INNER JOIN ADM_TRN_USER_PROFILES AS USRPROFILE ON CREWS.PERSON_ID = USRPROFILE.ID_ 
INNER JOIN ADM_MST_SIMPLE_REF AS SREF ON USRPROFILE.RANK_ID = SREF.ID_ 
LEFT JOIN ADM_MST_COUNTRIES AS COUNTRY ON USRPROFILE.COUNTRY_ID = COUNTRY.ID_ 
INNER JOIN ADM_MST_PROF_QUALIFICATIONS AS PROQUALI ON CREWS.QUALF_ID = PROQUALI.ID_ 
INNER JOIN ADM_MST_RESTRICTIONS AS RSTFORCOMPANY ON CREWS.COMPANY_ID = RSTFORCOMPANY.ID_ 
INNER JOIN ADM_MST_RESTRICTIONS AS RSTFORBTN ON RSTFORCOMPANY.PRNT_ID = RSTFORBTN.ID_ 
INNER JOIN ADM_MST_RESTRICTIONS AS RST ON RSTFORBTN.PRNT_ID = RST.ID_ 
LEFT OUTER JOIN ADM_MST_PLATFORMS AS PLATFORM ON CREWS.PRI_PLTF_ID_ = PLATFORM.ID_
WHERE (CREWS.ID_ = @crewId)

END
go

