-- =============================================
-- Author:		gal2723
-- Create date: 05-AUG-2015
-- Description:	Returns IDs of user records for a given Command and 'CREATED_BY_'
-- Ex: SELECT * FROM dbo.GetMigratedUserIDs('G18', '_DATA_MIGRATION_')
-- =============================================
CREATE FUNCTION GetMigratedUserIDs
(
	@commandName VARCHAR(100),
	@migratedByName VARCHAR(100)
)
RETURNS TABLE
AS
RETURN
(
	SELECT U.ID_ AS UserProfileId, u.*
	FROM ADM_TRN_USER_PROFILES U
		INNER JOIN ADM_MST_RESTRICTIONS R
			ON U.MIL_UNIT_ID = R.ID_
	WHERE R.CODE_ = @commandName AND CREATED_BY_ = @migratedByName
)
go

