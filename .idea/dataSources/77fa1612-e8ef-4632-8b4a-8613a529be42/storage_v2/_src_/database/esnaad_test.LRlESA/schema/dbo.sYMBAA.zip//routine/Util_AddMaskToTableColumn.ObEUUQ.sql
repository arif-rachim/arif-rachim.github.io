
-- =========================================================
-- Date			: 20-May-2021
-- Description	: Add mask to a table column
-- @schemaName	: Schema of table to add mask to
-- @tableName	: Table to add mask to
-- @columnName	: Column to add mask to
-- @maskType	: Type of data to mask: "default", "email"
-- Example		: EXEC Util_AddMaskToTableColumn @schemaName = 'dbo', @tableName = 'sensitive_table1', @columnName = 'sensitive_column1', @maskType = 'email';
-- =========================================================

CREATE   PROCEDURE Util_AddMaskToTableColumn
	@schemaName VARCHAR(MAX),
	@tableName	VARCHAR(MAX),
	@columnName	VARCHAR(MAX),
	@maskType	VARCHAR(MAX) = 'DEFAULT'
AS
BEGIN
IF NOT EXISTS
	(
		SELECT 1
		FROM sys.masked_columns c
		JOIN sys.tables t ON c.object_id = t.object_id
		JOIN sys.schemas s ON t.schema_id = s.schema_id
		WHERE s.name = @schemaName
		AND t.name = @tableName
		AND c.name = @columnName
	)
	BEGIN
		DECLARE @sqlTxt NVARCHAR(MAX) = '
		ALTER TABLE ' + @schemaName + '.' + @tableName
		+ ' ALTER COLUMN ' + @columnName
		+ ' ADD MASKED WITH (FUNCTION = ''' + @maskType +'()'')'
		;

		EXEC sp_executesql @sqlTxt
	END
	ELSE
	BEGIN
		PRINT '';
		PRINT 'Column: ' + @schemaName + '.' + @tableName + '.' + @columnName;
		PRINT '';
		PRINT 'Cannot apply the requested mask as the column is already masked!';
		PRINT 'To modify the mask type, please remove the mask first using SP: ''Util_RemoveMaskFromTableColumn'' and run this script.'
	END

END
go

