CREATE FUNCTION [dbo].[GePartsCountInLocationByClass]
(	
	@BuId bigint,
	@L2Id bigint,
	@LocationId bigint,
	@IncludeClassA bit,
	@IncludeClassB bit,
	@IncludeClassC bit

)
RETURNS TABLE 
AS
RETURN 
(
SELECT     BuId, LocationId,  ISNULL(A, 0) AS A, ISNULL(B, 0) AS B, ISNULL(C, 0) AS C,
((CASE WHEN(@IncludeClassA = 1) THEN ISNULL(A, 0) ELSE 0 END) + (CASE WHEN(@IncludeClassB = 1) THEN ISNULL(B, 0) ELSE 0  END) + (CASE WHEN(@IncludeClassC = 1) THEN ISNULL(C, 0) ELSE 0 END) ) AS SelectedClassTotal,
(ISNULL(A, 0) + ISNULL(B, 0) + ISNULL(C, 0)) AS TotalInLocation
FROM            
( 
				SELECT DISTINCT IL.BU_ID_ AS BuId, IL.LOC_ID_ AS LocationId, sr.CODE_ AS Class, ISNULL(COUNT(DISTINCT U.ID_), 0) AS Count
				FROM            ADM_TRN_IMV_ITEMS_IN_LOCATION AS IL INNER JOIN
										 ADM_MST_UNITS AS U ON U.ID_ = IL.UNIT_ID_ INNER JOIN
										 ADM_MST_ITEMS AS I ON I.ID_ = U.ITEM_ID INNER JOIN
										 ADM_MST_UNIT_LOCATION AS L ON L.ID_ = IL.LOC_ID_ INNER JOIN
										 ADM_MST_UNIT_LOCATION_GROUP AS LG ON LG.ID_ = L.LG_ID INNER JOIN
										 ADM_MST_SIMPLE_REF AS sr ON sr.ID_ = I.CLS_ID_
				WHERE        (L.LOC_TYPE_ = 'Regular') AND (IL.BU_ID_ = @BuId) AND  IL.OWNED_L2_ID_ = (CASE WHEN (@L2Id = 0) THEN IL.OWNED_L2_ID_ ELSE @L2ID  END)  AND (IL.TC_ID_ <> 16) AND (IL.LOC_ID_ = @LocationId)
				GROUP BY sr.CODE_, IL.BU_ID_, IL.LOC_ID_
						   ) AS SourceTable
 PIVOT  (AVG(Count)  FOR Class  IN  ( A, B, C)) AS PivotTable
)
go

