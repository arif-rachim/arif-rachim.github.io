CREATE FUNCTION [dbo].[TranslateBULine](@isFirst bit = 0, @isSecond bit = 0, @isThird bit = 0)
RETURNS VARCHAR(100)
BEGIN
	DECLARE @strFirst varchar(20) = '1ST LN', @strSecond varchar(20) = '2ND LN', @strThird varchar(20) = '3RD LN', @str varchar(100) = ''

	IF @isFirst = 1 SET @str = @str + '1ST LN, '
	IF @isSecond = 1 SET @str = @str + '2ND LN, '
	IF @isThird = 1 SET @str = @str + '3RD LN, '

	IF LEN(@str) = 0 RETURN @str
	RETURN LEFT(@str, len(@str) - 1)
END
go

