-- =============================================
-- Author:		GAL2741
-- Create date: 9-Jul-2013
-- Description:	Generate GHQ Daily Status Report
-- =============================================
CREATE PROCEDURE [dbo].[GetGHQDailyStatusReport] 
	-- Add the parameters for the stored procedure here
	@input_date datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
   
    DECLARE @today_date date;
    DECLARE @compare_date date;
   
    SET @today_date = CONVERT(date, getdate());
    SET @compare_date = CONVERT(date, @input_date);
    
    -- Insert statements for procedure here
    IF DATEDIFF(DAY, @compare_date, @today_date) = 0
    BEGIN
		SELECT * FROM [dbo].[vw_ReportGHQDailyStatus]
	END	
	ELSE
	BEGIN
		SELECT * FROM [dbo].[vw_ReportGHQDailyStatusHistory] 
		WHERE CONVERT(date,AsvcDate) = CONVERT(date,@input_date) 
		ORDER BY TailNo, AsvcDate DESC
	END		
END



go

