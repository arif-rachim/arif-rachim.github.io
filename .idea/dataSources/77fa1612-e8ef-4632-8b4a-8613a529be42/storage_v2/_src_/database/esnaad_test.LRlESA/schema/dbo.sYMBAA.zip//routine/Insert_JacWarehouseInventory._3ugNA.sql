CREATE PROCEDURE [dbo].[Insert_JacWarehouseInventory]
    
AS
BEGIN

    DELETE FROM LOG_JAC_WAREHOUSE_INVENTORY

    
    --once consumption history is done at substore level,
    --all the subqueries in below script can be replaced to take the corresponding value from 
    --LOG_TRN_ITEM_QUANTITY_SNAPSHOT table
    INSERT INTO LOG_JAC_WAREHOUSE_INVENTORY(
        CMD_ID_, 
        CMD_CODE_, 
        L2_ID_, 
        PARENT_BU_ID_, 
        ITEM_ID_, 
        L2_CODE_, 
        PART_NUMBER_, 
        CAGE_CODE_, 
        NOMENCLATURE_, 
        SERIALIZED_, 
        BU_ID_, 
        BU_CODE_, 
        MAX_LEVEL_, 
        SAFETY_LEVEL_, 
        WAR_RESERVE_, 
        TOTAL_STOCK_, 
        AVERAGE_COST_, 
        LATEST_COST_, 
        ON_ORDER_, 
        ALL_ITMS_IN_RPR_, 
        ITMS_HAVING_RPR_ORDER_, 
        CONS_CURRENT_YR, 
        CONS_TWO_YR, 
        CONS_THREE_YR, 
        CREATED_ON_
        )
    select whtable.CMD_ID_ AS CommandId

      ,CMD.CODE_ AS Command

      ,whtable.L2_ID_ AS L2Id

      ,whtable.PARENT_BU_ID_ AS ParentStoreId

      ,whtable.PRIMARY_PART_ITEM_ID_ AS ItemId

      ,L2.CODE_ AS Agl2

      ,items.PART_NO_ AS PartNumber

      ,cage.CAGE_CODE_ AS CageCode

      ,items.NOMENCLATURE_ AS Nomenclature

      ,CASE WHEN items.SERIALIZED_ = 1 THEN 'YES' ELSE 'NO' END AS Serialized

      ,whtable.BU_ID_ AS BusinessUnitId

      ,BU.CODE_ AS BusinessUnit

      ,LVL.MAX_ AS MaxLevel

      ,LVL.SAFETY_ AS SafetyLevel

      ,LVL.WAR_RESERVE_ AS WarReserve

      ,sum((whtable.TOTAL_STOCK_ - whtable.STOCK_AWAITING_RECEPTION_ - whtable.STOCK_AWAITING_LOCATION_)) as TotalStock

      ,avg(whtable.AVG_PRICE) as AverageCost

      ,sum(whtable.LAST_PROC_PRICE) as LatestCost

      ,sum(whtable.NEW_DUES_IN_CONF_) as OnOrder

      ,sum((whtable.RPR_DUES_IN_CONF_ + whtable.RPR_DUES_IN_NOT_CONF_)) as AllItemsInRepair

      ,sum(whtable.RPR_DUES_IN_CONF_) as ItemsHavingRepairOrder

      ,((SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM ADM_TRN_ITEM_ASSOCS iail

                JOIN LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE CHB ON CHB.ITEM_ID = iail.ITEM_ID AND CHB.L2_ID_ = iail.L2_ID

          WHERE iail.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_

            AND YEAR >= DATEPART (YEAR, GETDATE())

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND CHB.BU_ID_ = BU.ID_ 

        ) + 

        (SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM ADM_TRN_ITEM_ASSOCS iail

                JOIN LOG_TRN_ITEM_CONSUMPTION_HISTORY CH ON ch.ITEM_ID = iail.ITEM_ID AND ch.L2_ID_ = iail.L2_ID

          WHERE iail.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_

            AND YEAR >= DATEPART (YEAR, GETDATE()) 

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND ch.BU_ID_ = BU.ID_ 

            )

       ) AS ConsumptionCurrentYear

      ,((SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM ADM_TRN_ITEM_ASSOCS iail

                JOIN LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE CHB ON CHB.ITEM_ID = iail.ITEM_ID AND CHB.L2_ID_ = iail.L2_ID

          WHERE iail.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_

            AND YEAR >= DATEPART (YEAR, GETDATE())-1

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND CHB.BU_ID_ = BU.ID_ 

        ) + 

        (SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM ADM_TRN_ITEM_ASSOCS iail

                JOIN LOG_TRN_ITEM_CONSUMPTION_HISTORY CH ON ch.ITEM_ID = iail.ITEM_ID AND ch.L2_ID_ = iail.L2_ID

          WHERE iail.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_

            AND YEAR >= DATEPART (YEAR, GETDATE())-1

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND ch.BU_ID_ = BU.ID_ 

            )

       ) AS ConsumptionTwoYear

      ,((SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM ADM_TRN_ITEM_ASSOCS iail

                JOIN LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE CHB ON CHB.ITEM_ID = iail.ITEM_ID AND CHB.L2_ID_ = iail.L2_ID

          WHERE iail.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_

            AND YEAR >= DATEPART (YEAR, GETDATE())-2

            AND YEAR <= DATEPART (YEAR, GETDATE())

            AND CHB.BU_ID_ = BU.ID_ 

        ) + 

        (SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM ADM_TRN_ITEM_ASSOCS iail

                JOIN LOG_TRN_ITEM_CONSUMPTION_HISTORY CH ON ch.ITEM_ID = iail.ITEM_ID AND ch.L2_ID_ = iail.L2_ID

          WHERE iail.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_

            AND YEAR >= DATEPART (YEAR, GETDATE())-2 

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND ch.BU_ID_ = BU.ID_ 

            )

       ) AS ConsumptionThreeYear

      ,GETDATE() AS CurrentDateTime

  from LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE whtable

       inner join ADM_MST_RESTRICTIONS CMD ON CMD.ID_ = whtable.CMD_ID_

       inner join ADM_TRN_ASSOC_GROUPS l2 on whtable.L2_ID_ = l2.ID_

       inner join ADM_MST_ITEMS items on whtable.PRIMARY_PART_ITEM_ID_ = items.ID_

       inner join ADM_MST_MANUFACTURES cage on items.MNF_ID = cage.ID_

       inner join ADM_MST_BUSINESS_UNITS bu on whtable.BU_ID_ = bu.ID_

       inner join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = whtable.PRIMARY_PART_ITEM_ID_ and ia.L2_ID = whtable.L2_ID_

       left outer join LOG_TRN_STOCK_LEVEL2 lvl on ia.ID_ = lvl.ITEM_ASSOC_ID_ and lvl.STORE_ID = whtable.BU_ID_

where ia.PRIMARY_PART_ = 1

   and ia.IN_LIEU_CODE_ is not null

group by whtable.CMD_ID_ 

      ,CMD.CODE_

      ,whtable.L2_ID_

      ,whtable.PARENT_BU_ID_

      ,whtable.PRIMARY_PART_ITEM_ID_

      ,L2.CODE_

      ,items.PART_NO_

      ,cage.CAGE_CODE_

      ,items.NOMENCLATURE_

      ,items.SERIALIZED_

      ,whtable.BU_ID_

      ,BU.CODE_

      ,LVL.MAX_

      ,LVL.SAFETY_

      ,LVL.WAR_RESERVE_

      ,ia.IN_LIEU_CODE_

      ,BU.ID_

union all

select whtable.CMD_ID_ AS CommandId

      ,CMD.CODE_ AS Command

      ,whtable.L2_ID_ AS L2Id

      ,whtable.PARENT_BU_ID_ AS ParentStoreId

      ,whtable.PRIMARY_PART_ITEM_ID_ AS ItemId

      ,L2.CODE_ AS Agl2

      ,items.PART_NO_ AS PartNumber

      ,cage.CAGE_CODE_ AS CageCode

      ,items.NOMENCLATURE_ AS Nomenclature

      ,CASE WHEN items.SERIALIZED_ = 1 THEN 'YES' ELSE 'NO' END AS Serialized

      ,whtable.BU_ID_ AS BusinessUnitId

      ,BU.CODE_ AS BusinessUnit

      ,LVL.MAX_ AS MaxLevel

      ,LVL.SAFETY_ AS SafetyLevel

      ,LVL.WAR_RESERVE_ AS WarReserve

      ,sum((whtable.TOTAL_STOCK_ - whtable.STOCK_AWAITING_RECEPTION_ - whtable.STOCK_AWAITING_LOCATION_)) as TotalStock

      ,avg(whtable.AVG_PRICE) as AverageCost

      ,sum(whtable.LAST_PROC_PRICE) as LatestCost

      ,sum(whtable.NEW_DUES_IN_CONF_) as OnOrder

      ,sum((whtable.RPR_DUES_IN_CONF_ + whtable.RPR_DUES_IN_NOT_CONF_)) as AllItemsInRepair

      ,sum(whtable.RPR_DUES_IN_CONF_) as ItemsHavingRepairOrder

      ,((SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE CHB

          WHERE CHB.ITEM_ID = whtable.PRIMARY_PART_ITEM_ID_ 

            AND CHB.L2_ID_ = whtable.L2_ID_

            AND YEAR >= DATEPART (YEAR, GETDATE())

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND CHB.BU_ID_ = BU.ID_ 

        ) + 

        (SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY CH 

          WHERE ch.ITEM_ID = whtable.PRIMARY_PART_ITEM_ID_  

            AND ch.L2_ID_ = whtable.L2_ID_

            AND YEAR >= DATEPART (YEAR, GETDATE()) 

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND ch.BU_ID_ = BU.ID_ 

            )

       ) AS ConsumptionCurrentYear

      ,((SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE CHB

          WHERE CHB.ITEM_ID = whtable.PRIMARY_PART_ITEM_ID_ 

            AND CHB.L2_ID_ = whtable.L2_ID_

            AND YEAR >= DATEPART (YEAR, GETDATE())-1

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND CHB.BU_ID_ = BU.ID_ 

        ) + 

        (SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY CH 

          WHERE ch.ITEM_ID = whtable.PRIMARY_PART_ITEM_ID_ 

            AND ch.L2_ID_ = whtable.L2_ID_

            AND YEAR >= DATEPART (YEAR, GETDATE())-1

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND ch.BU_ID_ = BU.ID_ 

            )

       ) AS ConsumptionTwoYear

      ,((SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE CHB

          WHERE CHB.ITEM_ID = whtable.PRIMARY_PART_ITEM_ID_ 

            AND CHB.L2_ID_ = whtable.L2_ID_

            AND YEAR >= DATEPART (YEAR, GETDATE())-2

            AND YEAR <= DATEPART (YEAR, GETDATE())

            AND CHB.BU_ID_ = BU.ID_ 

        ) + 

        (SELECT ISNULL(SUM(ISNULL(TOTAL_ISSUE_, 0)), 0) - ISNULL(SUM(ISNULL(TOTAL_TURN_IN_, 0)), 0)

           FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY CH 

          WHERE ch.ITEM_ID = whtable.PRIMARY_PART_ITEM_ID_ 

            AND ch.L2_ID_ = whtable.L2_ID_

            AND YEAR >= DATEPART (YEAR, GETDATE())-2 

            AND YEAR <= DATEPART (YEAR, GETDATE()) 

            AND ch.BU_ID_ = BU.ID_ 

            )

       ) AS ConsumptionThreeYear

      ,GETDATE() AS CurrentDateTime

  from LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE whtable

       inner join ADM_MST_RESTRICTIONS CMD ON CMD.ID_ = whtable.CMD_ID_

       inner join ADM_TRN_ASSOC_GROUPS l2 on whtable.L2_ID_ = l2.ID_

       inner join ADM_MST_ITEMS items on whtable.PRIMARY_PART_ITEM_ID_ = items.ID_

       inner join ADM_MST_MANUFACTURES cage on items.MNF_ID = cage.ID_

       inner join ADM_MST_BUSINESS_UNITS bu on whtable.BU_ID_ = bu.ID_

       inner join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = whtable.PRIMARY_PART_ITEM_ID_ and ia.L2_ID = whtable.L2_ID_

       left outer join LOG_TRN_STOCK_LEVEL2 lvl on ia.ID_ = lvl.ITEM_ASSOC_ID_ and lvl.STORE_ID = whtable.BU_ID_

where ia.PRIMARY_PART_ = 1

   and ia.IN_LIEU_CODE_ is null

group by whtable.CMD_ID_ 

      ,CMD.CODE_

      ,whtable.L2_ID_

      ,whtable.PARENT_BU_ID_

      ,whtable.PRIMARY_PART_ITEM_ID_

      ,L2.CODE_

      ,items.PART_NO_

      ,cage.CAGE_CODE_

      ,items.NOMENCLATURE_

      ,items.SERIALIZED_

      ,whtable.BU_ID_

      ,BU.CODE_

      ,LVL.MAX_

      ,LVL.SAFETY_

      ,LVL.WAR_RESERVE_

      ,ia.IN_LIEU_CODE_

      ,BU.ID_
END
go

