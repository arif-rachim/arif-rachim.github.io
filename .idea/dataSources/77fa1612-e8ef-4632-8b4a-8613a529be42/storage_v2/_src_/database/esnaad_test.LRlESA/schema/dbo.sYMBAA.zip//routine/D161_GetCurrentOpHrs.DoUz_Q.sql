CREATE FUNCTION [dbo].[D161_GetCurrentOpHrs](@assignmentId bigint) RETURNS int AS
BEGIN
	DECLARE @compType nvarchar(10)
	DECLARE @opHrs int
	DECLARE @level int
	DECLARE @hCode nvarchar(900)
	DECLARE @curEngineHrs int
	DECLARE @i int
	DECLARE @curOpHrs int
	DECLARE @compUnitId bigint
	DECLARE @hrOpHrs int

	--SET @curEngineHrs = 0

	SELECT @level = M.LEVEL_, @compUnitId = COMP_UNIT_ID, @hrOpHrs = CASE WHEN OP_HRS_REM_ IS NULL THEN (CUR_OP_HRS_) ELSE OP_HRS_REM_ - OP_HRS_INST_ END 
	,@compType = COMP_TYPE_
	FROM MNT_TRN_D16_1_ASSIGNMENT A 
	JOIN MNT_TRN_D16_1_MASTER M ON M.ID_ = A.MASTER_ID
	WHERE A.ID_ = @assignmentId

	IF (@level = 0) 
	BEGIN
		SELECT @curEngineHrs = CASE WHEN OP_HRS_REM_ IS NULL THEN (OP_HRS_PREV_COUNT_ + CUR_OP_HRS_ - OP_HRS_INST_) ELSE OP_HRS_PREV_COUNT_ + OP_HRS_REM_ - OP_HRS_INST_ END
		FROM MNT_TRN_D16_1_ASSIGNMENT 
		WHERE COMP_TYPE_='HR' AND IS_LATEST_ = 1 AND END_UNIT_ID = @compUnitId

		RETURN @curEngineHrs
	END

	IF (@level = 1 AND @compType = 'HR') RETURN @hrOpHrs


	-- Looking for Level 1 NHR
	SET @hCode = dbo.D161_GetParentHCodeByLevel(@assignmentId, 1) 
	IF (@hCode IS NULL) RETURN 0

	SELECT @curEngineHrs = CASE WHEN OP_HRS_REM_ IS NULL THEN (OP_HRS_PREV_COUNT_ + CUR_OP_HRS_ - OP_HRS_INST_) ELSE OP_HRS_PREV_COUNT_ + OP_HRS_REM_ - OP_HRS_INST_ END
	FROM MNT_TRN_D16_1_ASSIGNMENT 
	WHERE COMP_TYPE_='HR' AND IS_LATEST_ = 1 AND END_UNIT_ID = (SELECT N.END_UNIT_ID FROM MNT_TRN_D16_1_ASSIGNMENT N WHERE N.H_CODE_ = @hCode AND N.IS_LATEST_ = 1 AND COMP_TYPE_ = 'NHR')


	IF(@level = 0) RETURN @curEngineHrs

	SET @i = 1
	SET @curOpHrs = @curEngineHrs
	WHILE(@i <= @level)
	BEGIN
		SET @hCode = dbo.D161_GetParentHCodeByLevel(@assignmentId, @i)
		SELECT @curOpHrs = CI_OP_HRS_ - PI_OP_HRS_ + @curOpHrs FROM MNT_TRN_D16_1_ASSIGNMENT WHERE H_CODE_ = @hCode AND IS_LATEST_ = 1
		SET @i = @i + 1 
	END
	--SELECT @opHrs = CI_OP_HRS_ - PI_OP_HRS_ + D161_GetParentOpHrs(D161_GetParentHCode(@hCode)) FROM MNT_TRN_D16_1_ASSIGNMENT WHERE H_CODE_ = @hCode
	RETURN @curOpHrs
END

--select dbo.D161_GetParentHCodeByLevel(126,4)
go

