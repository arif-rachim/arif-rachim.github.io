CREATE   FUNCTION dbo.adm_getstockcardinfo_snapshot
(
	@finalquoteid uniqueidentifier = null
)
RETURNS 
@ResultTable TABLE
( 
	MainStore			VARCHAR(50), 
	AgL2				VARCHAR(50), 
	PartNo				VARCHAR(250), 
	MfrCode				VARCHAR(50), 
	Uom					VARCHAR(50), 
	Stock				INT,  
	NonIssuableStock	INT,  
	DuesInConfirmed		INT, 
	DuesInNotConfirmed	INT, 
	DuesOutUser			INT, 
	DuesOutStore		INT, 
	ShippedOutside		INT,
	StockDate			DATETIME
)
AS
BEGIN
	declare @MainStore VARCHAR(50)
	declare @AGL2 VARCHAR(50)
	declare @PartNo nvarchar(250) 
	declare @MfrCode nvarchar(50) 
	declare @Uom VARCHAR(50)
	declare @Stock int  
	declare @NonIssuableStock int  
	declare @DuesInConfirmed int 
	declare @DuesInNotConfirmed int 
	declare @DuesOutUser int 
	declare @DuesOutStore int 
	declare @ShippedOutside int
	declare @StockDate DATETIME

	SELECT        
		@MainStore = MAIN_STORE_, 
		@AGL2 =AGL2_, 
		@PartNo = i.PART_NO_, 
		@MfrCode = mfr.CAGE_CODE_, 
		@Uom = UOM_, 
		@Stock = STOCK_, 
		@NonIssuableStock = NON_ISSUABLE_, 
		@ShippedOutside = SHIPPED_OUTSIDE_, 
		@DuesInConfirmed = DI_CONFIRMED_, 
		@DuesInNotConfirmed = DI_NOT_CONFIRMED_, 
		@DuesOutUser = DO_USER_, 
		@DuesOutStore = DO_STORE_, 
		@StockDate = STOCK_DATE
	FROM            
		LOG_TRN_FQA_STOCK_SNAPSHOPT snp join
		LOG_TRN_RFQ_REPAIR_FINAL_QUOTATION fqa on fqa.ID_ = snp.RFQA_ID_ join
		LOG_TRN_RPR_REPAIR_FILE rpf on rpf.ID_ = fqa.REPAIR_FILE_ID_ join
		ADM_MST_ITEMS I on i.ID_ = rpf.ITEM_ID  JOIN 
		ADM_MST_MANUFACTURES mfr ON mfr.ID_ = I.MNF_ID
	WHERE 
		fqa.ID_ = @finalquoteid
		
	-- Fill the table variable with the rows for your result set
	INSERT INTO @ResultTable
		SELECT
			@MainStore , 
			@AGL2 , 
			@PartNo , 
			@MfrCode , 
			@Uom , 
			@Stock ,  
			@NonIssuableStock ,  
			@DuesInConfirmed , 
			@DuesInNotConfirmed , 
			@DuesOutUser , 
			@DuesOutStore , 
			@ShippedOutside ,
			@StockDate 
	
	RETURN 
END
go

