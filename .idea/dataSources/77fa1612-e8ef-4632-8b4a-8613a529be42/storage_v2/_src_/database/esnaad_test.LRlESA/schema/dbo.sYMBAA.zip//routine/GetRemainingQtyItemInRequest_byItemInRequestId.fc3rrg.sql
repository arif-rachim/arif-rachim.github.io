CREATE FUNCTION [dbo].[GetRemainingQtyItemInRequest_byItemInRequestId]
(
	@TransferRequestId		int,
	@ItemInRequestId		int
)
RETURNS int
AS
BEGIN
	DECLARE @result int
   
	SELECT @result = ISNULL(SUM(IIR.REQ_QTY_),0) - ISNULL(SUM(IIR.ISSUED_QTY_),0)
					 FROM LOG_TRN_ITEM_IN_REQUEST IIR
					 INNER JOIN ADM_MST_ITEMS I ON IIR.ITEM_ID = I.ID_
					 WHERE IIR.SM_ID = @TransferRequestId
					 AND IIR.ID_ = @ItemInRequestId
	
	RETURN @result
END
go

