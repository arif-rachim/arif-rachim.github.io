CREATE FUNCTION [dbo].[GetSumOfHours](@tableName varchar(50), @command varchar(10)) RETURNS varchar(20)
AS
BEGIN
	DECLARE @hours int
	DECLARE @minutes int
	IF(@tableName = 'CIS_IMP_JAAM_COMMAND_FLIGHT') BEGIN
		SELECT 
			@hours = SUM(CONVERT(int, left(JAAM_TOTAL_HOURS, charindex( ':', JAAM_TOTAL_HOURS) -1 )))
			, @minutes = SUM(CONVERT(int, substring(JAAM_TOTAL_HOURS, charindex( ':', JAAM_TOTAL_HOURS) + 1, len(JAAM_TOTAL_HOURS))))
		FROM CIS_IMP_JAAM_COMMAND	INNER JOIN CIS_NG_COMMAND_MAP ON  CIS_IMP_JAAM_COMMAND.COMMAND_ =  CIS_NG_COMMAND_MAP.CIS_COMMAND_
									INNER JOIN CIS_IMP_JAAM_COMMAND_FLIGHT ON CIS_IMP_JAAM_COMMAND_FLIGHT.COMMAND_ID = CIS_IMP_JAAM_COMMAND.ID_ 
		WHERE
			CIS_IMP_JAAM_COMMAND_FLIGHT.TOTAL_SORTIES_ <> 0 AND ng_COMMAND_ = @command
	END
	ELSE IF (@tableName = 'CIS_IMP_JAAM_COMMAND_SUPPORT_TO') BEGIN
		SELECT 
		@hours = SUM(CONVERT(int, left(HOURS_, charindex( ':', HOURS_) -1 )))
		, @minutes = SUM(CONVERT(int, substring(HOURS_, charindex( ':', HOURS_) + 1, len(HOURS_)) ) )
		FROM
			CIS_IMP_JAAM_COMMAND	INNER JOIN CIS_NG_COMMAND_MAP ON  CIS_IMP_JAAM_COMMAND.COMMAND_ =  CIS_NG_COMMAND_MAP.CIS_COMMAND_
									INNER JOIN CIS_IMP_JAAM_COMMAND_SUPPORT_TO ON CIS_IMP_JAAM_COMMAND_SUPPORT_TO.COMMAND_ID = CIS_IMP_JAAM_COMMAND.ID_ 
		WHERE
			CIS_IMP_JAAM_COMMAND_SUPPORT_TO.SORTIES <> 0 AND ng_COMMAND_ = @command
	END
	ELSE IF (@tableName = 'CIS_IMP_JAAM_COMMAND_PLATFORM') BEGIN
		SELECT 
			@hours = SUM(CONVERT(int, left(HOURS_, charindex( ':', HOURS_) -1 )))
			, @minutes = SUM(CONVERT(int, substring(HOURS_, charindex( ':', HOURS_) + 1, len(HOURS_) )))
		FROM
			CIS_IMP_JAAM_COMMAND	INNER JOIN CIS_NG_COMMAND_MAP ON  CIS_IMP_JAAM_COMMAND.COMMAND_ =  CIS_NG_COMMAND_MAP.CIS_COMMAND_
								INNER JOIN CIS_IMP_JAAM_COMMAND_PLATFORM ON CIS_IMP_JAAM_COMMAND_PLATFORM.COMMAND_ID = CIS_IMP_JAAM_COMMAND.ID_ 
		WHERE 
			CIS_IMP_JAAM_COMMAND_PLATFORM.SORTIES <> 0 AND ng_COMMAND_ = @command
	END
	
	
	DECLARE @totalTimeInMinutes int
	SET @totalTimeInMinutes	= (@hours * 60) + @minutes
	
	DECLARE @calculatedHours int
	DECLARE @calculatedMinutes int
	SET @calculatedHours = @totalTimeInMinutes /60
	SET @calculatedMinutes = @totalTimeInMinutes - (@calculatedHours * 60)
	
	RETURN CONVERT(varchar,@calculatedHours) + ':' + CONVERT(varchar, @calculatedMinutes)
END
go

