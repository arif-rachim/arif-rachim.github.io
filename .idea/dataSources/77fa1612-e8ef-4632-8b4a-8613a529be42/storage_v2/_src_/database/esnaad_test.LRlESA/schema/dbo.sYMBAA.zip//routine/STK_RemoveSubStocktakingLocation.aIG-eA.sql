CREATE PROC [dbo].[STK_RemoveSubStocktakingLocation] (@sstId uniqueidentifier, @locationId bigint, @userProfileId bigint, @remarks nvarchar(max), @term nvarchar(255))
AS
BEGIN
	declare @handle uniqueidentifier
	set @handle = dbo.GenerateTimebasedGuid()
	
	INSERT LOG_TMP_STM_STOCKTAKING2_LOC_SELECTION(HANDLE_, LOC_ID)
    SELECT @handle, LOC_ID FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC
    WHERE SST_ID = @sstId AND LOC_ID <> @locationId

	exec dbo.STK_AddRemoveSubStocktakingLocation  @sstId, @handle, @userProfileId, @term, @remarks

END
go

