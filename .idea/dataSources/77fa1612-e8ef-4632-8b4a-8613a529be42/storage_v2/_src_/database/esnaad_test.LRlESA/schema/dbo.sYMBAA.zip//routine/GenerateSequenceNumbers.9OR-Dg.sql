CREATE PROC [dbo].[GenerateSequenceNumbers] (
	@prefix varchar(2),
	@numberGeneratorParam esnaadm.Type_NumberGeneratorParam READONLY
)
AS
BEGIN
 
	DECLARE @sequenceSpecs table(code varchar(2), padFormat varchar(10), seqType varchar(10))
	insert @sequenceSpecs 
	select CODE_,PAD_FORMAT_,SEQ_TYPE_ from  ADM_MST_SEQ_ANNUAL_SEQUENCE WHERE CODE_=@prefix
	--values('RP','D6','Normal')

	DECLARE @padFormat varchar(10)
	DECLARE @seqType varchar(10)
	SELECT @padFormat=padFormat, @seqType=seqType FROM @sequenceSpecs WHERE code=@prefix


	declare @sequenceResults table(YEAR_ int, MONTH_ int, COUNT_ int, LAST_SEQ_ int, NEW_LAST_SEQ_ int, PREFIX_ varchar(2), PAD_FORMAT_ varchar(10), SEQ_TYPE_ varchar(10))

	INSERT @sequenceResults
	select N.*,ISNULL(LAST_SEQ_,0)LAST_SEQ_, (ISNULL(LAST_SEQ_,0) + N.COUNT_) NEW_LAST_SEQ_ ,ISNULL(CODE_,@prefix) PREFIX_, @padFormat, @seqType
	from @numberGeneratorParam N
	LEFT JOIN ADM_MST_SEQ_ANNUAL_SEQUENCE S ON S.YEAR_ = N.YEAR_ AND ISNULL(S.MONTH_,0) = ISNULL(N.MONTH_,0) AND S.CODE_=@prefix

	
	MERGE ADM_MST_SEQ_ANNUAL_SEQUENCE AS TARGET
	USING @sequenceResults AS SOURCE
	ON (TARGET.CODE_ = SOURCE.PREFIX_ AND TARGET.YEAR_ = SOURCE.YEAR_ AND TARGET.SEQ_TYPE_ = SOURCE.SEQ_TYPE_ AND (ISNULL(TARGET.MONTH_,0) = ISNULL(SOURCE.MONTH_,0)) )
	WHEN MATCHED AND TARGET.LAST_SEQ_ <> SOURCE.NEW_LAST_SEQ_ THEN UPDATE SET TARGET.LAST_SEQ_ = SOURCE.NEW_LAST_SEQ_, TARGET.VERSION_ = TARGET.VERSION_ + 1
	WHEN NOT MATCHED BY TARGET THEN INSERT(VERSION_, YEAR_, CODE_, LAST_SEQ_, PAD_FORMAT_, SEQ_TYPE_, MONTH_) VALUES (1, SOURCE.YEAR_, SOURCE.PREFIX_, SOURCE.NEW_LAST_SEQ_, SOURCE.PAD_FORMAT_, SOURCE.SEQ_TYPE_, CASE WHEN SOURCE.SEQ_TYPE_ = 'Normal' THEN NULL ELSE SOURCE.MONTH_ END);


	SELECT S.YEAR_, (CASE WHEN S.SEQ_TYPE_ = 'Normal' THEN NULL ELSE S.MONTH_ END) MONTH_, Y.formattedNo AS FORMATTED_NO_ 
	FROM @sequenceResults S
	CROSS APPLY (
		select * from esnaadm.ConstructSequenceNumbers(@prefix,@padFormat,s.LAST_SEQ_,s.COUNT_,s.YEAR_,CASE WHEN S.SEQ_TYPE_ = 'Normal' THEN NULL ELSE S.MONTH_ END)
	) Y
END
go

