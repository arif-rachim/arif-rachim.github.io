CREATE FUNCTION [dbo].[GetLastReceivedDate]
(
      @itemId				bigint,
	  @l2Id					bigint,
	  @cmdId				bigint,
	  @filterById			bigint
)
RETURNS date
AS
BEGIN
	DECLARE @result date

	   declare  @itemId_          bigint;
       declare  @l2Id_            bigint;
       declare  @cmdId_           bigint;
       declare  @filterById_   bigint;

       set  @itemId_         = @itemId;
       set  @l2Id_           = @l2Id;
       set  @cmdId_          = @cmdId;
       set  @filterById_     = @filterById;


	IF(@filterById_ = 0)
	BEGIN
		SELECT @result = CONVERT(DATE, (SELECT MAX(DN.RCV_DATE_)
		                                FROM LOG_TRN_REC_DELIVERY_NOTE_ITEM AS DNITM
                                            JOIN LOG_TRN_REC_DELIVERY_NOTE AS DN ON DN.ID_ = DNITM.DN_ID AND DN.STATUS_ IN ('Received', 'Checked', 'Validated') AND DN.REC_TYPE_ = 'PurchaseOrder'
                                            JOIN LOG_TRN_PRC_PURCHASE_ORDER_ITEM AS POITM ON POITM.ID_ = DNITM.PO_ITEM_ID_
                                            JOIN LOG_TRN_PRC_PROCUREMENT_ITEM AS PRI ON PRI.ID_ = POITM.PROC_ITEM_ID
											JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = DN.BU_ID
                                        WHERE PRI.ITEM_ID = @itemId_ AND BU.CMD_ID_ =  @cmdId_
                                        GROUP BY PRI.ITEM_ID), 106) 
	END
	ELSE IF(@filterById_ = 1)
	BEGIN
		SELECT @result = CONVERT(DATE, (SELECT MAX(DN.RCV_DATE_) 
		                                FROM ADM_TRN_ITEM_ASSOCS IP 
                                            JOIN ADM_TRN_ITEM_ASSOCS IL ON IL.IN_LIEU_CODE_ = IP.IN_LIEU_CODE_ AND IL.L2_ID = IP.L2_ID
                                            JOIN LOG_TRN_PRC_PROCUREMENT_ITEM AS PRI ON PRI.ITEM_ID = IL.ITEM_ID
                                            JOIN LOG_TRN_PRC_PURCHASE_ORDER_ITEM AS POITM ON PRI.ID_ = POITM.PROC_ITEM_ID
                                            JOIN LOG_TRN_REC_DELIVERY_NOTE_ITEM AS DNITM ON POITM.ID_ = DNITM.PO_ITEM_ID_
                                            JOIN LOG_TRN_REC_DELIVERY_NOTE AS DN  ON DN.ID_ = DNITM.DN_ID
											JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = DN.BU_ID
                                        WHERE IP.PRIMARY_PART_ = 1 AND DN.STATUS_ IN ('Received', 'Checked', 'Validated') AND DN.REC_TYPE_ = 'PurchaseOrder' AND IP.ITEM_ID = @itemId_ AND IP.L2_ID = @l2Id_ AND BU.CMD_ID_ =  @cmdId_
                                        GROUP BY IP.ITEM_ID), 106) 
	END
	RETURN @result;
END
go

