CREATE VIEW [dbo].[VW_PMO_PROGRAM_LIST] AS (SELECT P.ID_ AS Id, P.NAME_ AS Name, P.PROG_MGR_ AS ProgramManager, COUNT(PRJ.ID_) AS NumberOfProject,
                                                    UP1.PID_ as CreatedByPid,  (UP1.F_NAME_ + ' ' + UP1.L_NAME_) AS CreatedByName , P.CREATED_ON_ AS CreatedOn,
                                                    UP2.PID_ as ModifiedByPid,  (UP2.F_NAME_ + ' ' + UP2.L_NAME_) AS ModifiedByName, P.MOD_ON_ as ModifiedOn
                                                    FROM PMO_TRN_PROGRAM P 
                                                    LEFT OUTER JOIN PMO_TRN_PROJECT PRJ ON PRJ.PROG_ID = P.ID_
                                                    LEFT OUTER JOIN ADM_TRN_USER_PROFILES UP1 ON P.CREATED_BY_ = UP1.USER_ID_ 
                                                    LEFT OUTER JOIN ADM_TRN_USER_PROFILES UP2 ON P.MOD_BY_ = UP2.USER_ID_
                                                    GROUP BY P.ID_, P.NAME_, P.PROG_MGR_, UP1.PID_, P.CREATED_ON_, UP2.PID_, P.MOD_ON_, UP1.F_NAME_, UP1.L_NAME_, UP2.F_NAME_, UP2.L_NAME_) 
go

