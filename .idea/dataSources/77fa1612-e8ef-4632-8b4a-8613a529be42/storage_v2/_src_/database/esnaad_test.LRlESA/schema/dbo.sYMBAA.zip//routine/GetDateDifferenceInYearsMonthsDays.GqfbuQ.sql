CREATE FUNCTION [dbo].[GetDateDifferenceInYearsMonthsDays](@dateStart DATETIME, @dateEnd DATETIME)
  RETURNS VARCHAR(50) AS
  BEGIN


    DECLARE @tmpdate DATETIME, @years INT, @months INT, @days INT

    SELECT @tmpdate = @dateStart
    SELECT @years = datediff(YY, @tmpdate, @dateEnd) - CASE WHEN (month(@dateStart) > month(@dateEnd)) OR
                                                                 (month(@dateStart) = month(@dateEnd) AND
                                                                  day(@dateStart) > day(@dateEnd))
      THEN 1
                                                       ELSE 0 END
    SELECT @tmpdate = dateadd(YY, @years, @tmpdate)
    SELECT @months = datediff(M, @tmpdate, @dateEnd) - CASE WHEN day(@dateStart) > day(@dateEnd)
      THEN 1
                                                       ELSE 0 END
    SELECT @tmpdate = dateadd(M, @months, @tmpdate)
    SELECT @days = datediff(D, @tmpdate, @dateEnd)

    RETURN (CONVERT(VARCHAR(10), @years) + 'Y ' + convert(VARCHAR(10), @months) + 'M ' + CONVERT(VARCHAR(10), @days) +
            'D')

  END
go

