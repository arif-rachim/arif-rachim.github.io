CREATE VIEW [dbo].[VW_LOG_TRANSFER_REQUEST_REQUESTED_ITEMS]
AS

select 
       trq.ID_ As Id,
       trit.PART_NO_ As RequestedPartNo,
       trmf.CAGE_CODE_ As RequestedMfr,
       trit.NSN_ As RequestedNsn,
       trit.NOMENCLATURE_ As RequestedNomenclature,
       tri.REQ_QTY_  As RequestedQty,
       ISNULL(tri.CANCELED_QTY_,0) As CanceledQty,
       truo.CODE_ As RequestedUom,
       trq.TR_NO_ As TransferRequestNo,
     trq.RI_CMD_ID_ As RequestedCmdId,
       trq.RI_BU_ID_ As RequestedBuId,
       trq.RI_L2_ID_ As RequestedL2Id,
     trq.FI_CMD_ID_ As IssuedCmdId,
       trq.FI_BU_ID_ As IssuedBuId,
       trq.FI_L2_ID_ As IssuedL2Id,
       (case tri.ISSUED_QTY_ when 0 then null else ibu.CODE_ end)  As IssuedCommand,
     (case tri.ISSUED_QTY_ when 0 then null else icmd.CODE_ end)  As IssuedBu,
       tri.ISSUED_QTY_ As IssuedQty ,
       (case 
              when ISNULL(tri.CANCELED_QTY_,0) >= tri.REQ_QTY_  then 'CANCELED' 
              when wf.WF_STATE_ = 'Created'  then 'AWAITING VALIDATION' 
              when wf.WF_STATE_ = 'Canceled'  then 'CANCELED' 
              when  isnull(tri.ISSUED_QTY_,0) < (tri.REQ_QTY_ - ISNULL(tri.CANCELED_QTY_,0)) then 'AWAITING FULFULLMENT' 
              when trd_rcm.RCM_STATUS_ = 'AWAITINGLOCATE'  then 'AWAITING LOCATION' 
              when trd_rcm.RCM_STATUS_ = 'AWAITINGRECEIVE'  then 'AWAITING RECEIVE' 
              else 'FULFILLED' 
       end) As RequestItemStatus,
       
       0 As TransferDataItemUnitId,
       null AS ReceivingMgmtId,
       null AS ReceivedPnrNo, 
       wf.WF_STATE_ As WorkFlowState

from 
       LOG_TRN_TRM_TRANSFER_REQUEST trq
       join WF_TRN_INSTANCE wf on wf.ID_ = trq.WF_ID AND wf.WF_DEF_ID_='StoreTransferWorkflow' 
       join LOG_TRN_TRM_TRANSFER_REQUEST_ITEM tri on tri.TR_ID_ = trq.ID_ 
       join LOG_MST_UNIT_OF_MEASURE truo on tri.UOM_ID_ = truo.ID_
       join ADM_MST_ITEMS trit on tri.ITEM_ID = trit.ID_ 
       join ADM_MST_MANUFACTURES trmf on trit.MNF_ID = trmf.ID_ 

     join ADM_MST_BUSINESS_UNITS ibu on ibu.ID_ = trq.FI_BU_ID_
       join ADM_MST_RESTRICTIONS icmd on icmd.ID_ = trq.FI_CMD_ID_ 

       left join (

              select
                     t_.TRF_NO_ as TRF_NO_,
                     t_.REQ_ITEM_ID_ as REQ_ITEM_ID_,
                     t_.RCM_STATUS_ as RCM_STATUS_     
              from
                     (
                           select 
                                  trd.TRF_NO_ as TRF_NO_,
                                  units.ITEM_ID as REQ_ITEM_ID_,
                                  (
                                         select 
                                                top 1 (case when rcm.ID_ IS NULL then 'FULFILLED' when rcm.PNR_NO_ IS NULL then 'AWAITINGRECEIVE' else  'AWAITINGLOCATE' end) as RCM_STATUS_
                                         from 
                                                LOG_TRN_RCM_UNIT_DUES_IN rcm
                                         where
                                                rcm.TRF_NO_ = trd.TRF_NO_ and rcm.UNIT_ID_ = trdi.UNIT_ID_
                                         order by 
                                                rcm.PNR_NO_
                                  ) as RCM_STATUS_
                           from
                                  LOG_TRN_TRF_TRANSFER_DATA trd 
                                  join LOG_TRN_TRF_TRANSFER_DATA_ITEM trdi on trdi.TRF_ID = trd.ID_ 
                                  join ADM_MST_UNITS units on trdi.UNIT_ID_ = units.ID_ --added
                     ) as t_
              group by
                     t_.TRF_NO_,
                     t_.REQ_ITEM_ID_,
                     t_.RCM_STATUS_ 
              
       ) trd_rcm on trd_rcm.TRF_NO_ =  trq.TR_NO_ and trd_rcm.REQ_ITEM_ID_ = tri.ITEM_ID 
where
       trq.TR_TYPE_ ='StoreTransfer'
go

