CREATE FUNCTION [dbo].[GetLatestAssetReference](@unitId bigint)
    RETURNS nvarchar(MAX)
AS
BEGIN
    DECLARE @result nvarchar(MAX);

    select top (1) @result = tx.PBO_MOVEMENT_NO_
                        from LOG_TRN_ASM_ASSET_TRANSACTION_ITEM txi
                                 join LOG_TRN_ASM_ASSET_TRANSACTION tx on tx.ID_ = txi.TR_ID
                        where tx.STATUS_ = 'Closed' and txi.UNIT_ID = @unitId
                        order by CREATED_ON_ desc
    RETURN @result
END;
go

