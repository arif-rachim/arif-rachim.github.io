
-- ==========================================================================
-- Author:		GAL2723
-- Create date: 01-Apr-2014
-- Description:	Get [String value] User ID from user master for a given PID
-- ==========================================================================
create FUNCTION [dbo].[getUserIdDStr_forPid] (@pid VARCHAR(255))
RETURNS VARCHAR(255)
AS
BEGIN
	DECLARE @userIdStr INT = NULL;
	
	SELECT @userIdStr = USER_ID_
	FROM ADM_TRN_USER_PROFILES
	WHERE PID_ = @pid	      
	
	RETURN @userIdStr;
END

-- SELECT dbo.getUserIdDStr_forPid('PP2723');
-- ############################################################################################################


go

