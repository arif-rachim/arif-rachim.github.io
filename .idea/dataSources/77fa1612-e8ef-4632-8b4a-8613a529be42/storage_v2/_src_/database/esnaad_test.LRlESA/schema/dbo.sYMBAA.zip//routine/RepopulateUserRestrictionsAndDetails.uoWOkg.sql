CREATE PROCEDURE [dbo].[RepopulateUserRestrictionsAndDetails]	
	@roleId uniqueidentifier
AS
BEGIN

	create table #UserRestrictionsId (ID_ Uniqueidentifier);
	create table #UserRolesId (ID_ Uniqueidentifier);
	create table #UsersId (ID_ bigint)

	if @roleId is null 
	begin 
		print 'Repopulating all User Restrictions and User Restriction Details' 
	end 
	else 
	begin 
		print 'Repopulating all User Restrictions and User Restriction Details for roleId ' + cast (@roleId as varchar(50));

		insert into #UserRestrictionsId select distinct ID_ from ADM_TRN_USER_RESTRICTIONS where USER_PROFILE_ID in (select USR_PRF_ID from ADM_TRN_SEC_ROLE_ASSIGNMENT where ROLE_ID = @roleId)

		insert into #UsersId select distinct USR_PRF_ID from ADM_TRN_SEC_ROLE_ASSIGNMENT where ROLE_ID = @roleId

		insert into #UserRolesId select distinct ROLE_ID from ADM_TRN_SEC_ROLE_ASSIGNMENT where USR_PRF_ID in (select ID_ from #UsersId)
		
	end

	if @roleId is not null
	begin
		print 'Deleting user restriction details'	

		delete from ADM_TRN_USER_AIRBASE_RESTRICION_DETAILS where USR_REST_ID in (select ID_ from #UserRestrictionsId)
		delete from ADM_TRN_USER_BUSINESS_UNIT_RESTRICION_DETAILS where USR_REST_ID in (select ID_ from #UserRestrictionsId)
		delete from ADM_TRN_USER_CURRENCY_TYPE_RESTRICTION_DETAILS where USR_REST_ID in (select ID_ from #UserRestrictionsId)
		delete from ADM_TRN_USER_DEPARTMENT_RESTRICION_DETAILS where USR_REST_ID in (select ID_ from #UserRestrictionsId)
		delete from ADM_TRN_USER_LEVEL2_ASSOCIATION_RESTRICION_DETAILS where USR_REST_ID in (select ID_ from #UserRestrictionsId)
		delete from ADM_TRN_USER_PLATFORM_RESTRICION_DETAILS where USR_REST_ID in (select ID_ from #UserRestrictionsId)
		delete from ADM_TRN_USER_QUALIFICATION_CAT_DETAILS where USR_REST_ID in (select ID_ from #UserRestrictionsId)
		delete from ADM_TRN_USER_SITE_RESTRICION_DETAILS where USR_REST_ID in (select ID_ from #UserRestrictionsId)
		delete from ADM_TRN_USER_RESTRICION_DETAILS where USR_REST_ID in (select ID_ from #UserRestrictionsId)

		print 'Deleting user restrictions'

		delete from ADM_TRN_USER_RESTRICTIONS where USER_PROFILE_ID in (select ID_ from #UsersId)
	end
	else
	begin
		print 'Deleting all user restriction details'	

		delete from ADM_TRN_USER_AIRBASE_RESTRICION_DETAILS
		delete from ADM_TRN_USER_BUSINESS_UNIT_RESTRICION_DETAILS
		delete from ADM_TRN_USER_CURRENCY_TYPE_RESTRICTION_DETAILS
		delete from ADM_TRN_USER_DEPARTMENT_RESTRICION_DETAILS
		delete from ADM_TRN_USER_LEVEL2_ASSOCIATION_RESTRICION_DETAILS
		delete from ADM_TRN_USER_PLATFORM_RESTRICION_DETAILS
		delete from ADM_TRN_USER_QUALIFICATION_CAT_DETAILS
		delete from ADM_TRN_USER_SITE_RESTRICION_DETAILS
		delete from ADM_TRN_USER_RESTRICION_DETAILS

		print 'Deleting all user restrictions'

		delete from ADM_TRN_USER_RESTRICTIONS
	end


	------------------------------------------------------------
	--- INITIALIZE USER RESTRICTIONS  ---
	------------------------------------------------------------

	print 'Repopulating user restriction'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_RESTRICTIONS (ID_, VERSION_, MODULE_ID, USER_PROFILE_ID, CREATED_BY_, CREATED_ON_)
		select newid(), 1, acl.MDL_ID, asg.USR_PRF_ID, 'SYSTEM', getdate()
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID 
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		where rol.IS_ACTIVE_ = 1 
		group by asg.USR_PRF_ID, acl.MDL_ID	
	end
	else
	begin
		insert into ADM_TRN_USER_RESTRICTIONS (ID_, VERSION_, MODULE_ID, USER_PROFILE_ID, CREATED_BY_, CREATED_ON_)
		select newid(), 1, acl.MDL_ID, asg.USR_PRF_ID, 'SYSTEM', getdate()
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID 
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		where rol.IS_ACTIVE_ = 1 
		group by asg.USR_PRF_ID, acl.MDL_ID	
	end

	----------------------------------------------------------
	--- Populate and Restrictions Details ---
	----------------------------------------------------------

	
	-- 1. populate military unit restriction details
	print 'Repopulating Military Unit restriction details'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_RESTRICION_DETAILS
		select newid(), 1, res.TYPE_NAME_, ur.ID_, acld.TYPE_ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		inner join ADM_MST_RESTRICTIONS res on res.ID_ = acld.TYPE_ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'MilitaryUnit' 
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, res.TYPE_NAME_, ur.ID_	
	end
	else
	begin
		insert into ADM_TRN_USER_RESTRICION_DETAILS
		select newid(), 1, res.TYPE_NAME_, ur.ID_, acld.TYPE_ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_MST_RESTRICTIONS res on res.ID_ = acld.TYPE_ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'MilitaryUnit' 
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, res.TYPE_NAME_, ur.ID_	

	end

	-- 2. populate Platform Restriction details
	print 'Repopulating Platform Restriction details'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_PLATFORM_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'Platform' 
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_	
	end
	else
	begin
		insert into ADM_TRN_USER_PLATFORM_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'Platform' 
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_	
	end


	-- 3. populate Qualification Category Restriction details
	print 'Ropulating Qualification Category Restriction details'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_QUALIFICATION_CAT_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'QualificationCategory'
			and rol.IS_ACTIVE_ = 1
		group by acld.TYPE_ID_, ur.ID_	

	end
	else
	begin
		insert into ADM_TRN_USER_QUALIFICATION_CAT_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'QualificationCategory'
			and rol.IS_ACTIVE_ = 1
		group by acld.TYPE_ID_, ur.ID_	
	end
	
	-- 4. populate Currency Restriction details
	print 'Repopulating Currency Restriction details'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_CURRENCY_TYPE_RESTRICTION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by acld.TYPE_ID_ )) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'Currency'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_	
	end
	else
	begin
		insert into ADM_TRN_USER_CURRENCY_TYPE_RESTRICTION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by acld.TYPE_ID_ )) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'Currency'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_	
	end
	

	-- 5. populate Air Base Restriction details
	print 'Repopulating Air Base Restriction details'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_AIRBASE_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'AirBase'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_
	end
	else
	begin
		insert into ADM_TRN_USER_AIRBASE_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'AirBase'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_
	end	

	-- 6. populate Business Unit Restriction details
	print 'Repopulating Business Unit Restriction details'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_BUSINESS_UNIT_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'BusinessUnit'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_	

	end
	else
	begin
		insert into ADM_TRN_USER_BUSINESS_UNIT_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'BusinessUnit'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_	
	end



	-- 7. populate Department/UnitStructure Restriction details
	print 'Repopulating Department Restriction details'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_DEPARTMENT_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'UnitStructure'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_
	end
	else
	begin
		insert into ADM_TRN_USER_DEPARTMENT_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'UnitStructure'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_
	end

	

	-- 8. populate Association Group Restriction details
	print 'Repopulating Association Group Restriction details'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_LEVEL2_ASSOCIATION_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'AssociationGroup'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_	
	end
	else
	begin
		insert into ADM_TRN_USER_LEVEL2_ASSOCIATION_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'AssociationGroup'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_	
	end



	-- 9. populate Site Restriction details
	print 'Repopulating Site Restriction details'

	if @roleId is not null
	begin
		insert into ADM_TRN_USER_SITE_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as uniqueidentifier))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join #UserRolesId ri on ri.ID_ = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_ 
		inner join #UsersId ui on ui.ID_ = asg.USR_PRF_ID
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'Site'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_
	end
	else
	begin
		insert into ADM_TRN_USER_SITE_RESTRICION_DETAILS
		select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as uniqueidentifier))) - 1
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
		where acld.TYPE_ = 'Site'
			and rol.IS_ACTIVE_ = 1 
		group by acld.TYPE_ID_, ur.ID_
	end



	drop table #UserRestrictionsId;
	drop table #UserRolesId;
	drop table #UsersId;

END
go

