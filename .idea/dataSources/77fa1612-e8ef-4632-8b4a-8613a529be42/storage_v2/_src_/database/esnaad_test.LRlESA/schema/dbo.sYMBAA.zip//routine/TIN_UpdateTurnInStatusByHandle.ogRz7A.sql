CREATE proc [dbo].[TIN_UpdateTurnInStatusByHandle] @handle uniqueidentifier, @itemStatus varchar(100)
as
begin 
	declare @userProfileId bigint, @performedOn datetime

	SELECT TOP 1 @performedOn=TI.CREATED_ON_, @userProfileId=UP.ID_
	FROM TMP_TRANSFER_ITEM TI
	LEFT JOIN ADM_TRN_USER_PROFILES UP ON TI.CREATED_BY_ = UP.USER_ID_
	WHERE HANDLE_ = @handle

	UPDATE TNI
	SET STATUS_ = @itemStatus
	FROM LOG_TRN_TIN_TURN_IN_ITEM TNI
	JOIN TMP_TRANSFER_ITEM TI ON TNI.UNIT_ID = TI.UNIT_ID_
	JOIN LOG_TRN_TIN_TURN_IN TN ON TN.ID_ = TNI.TURN_IN_ID AND TN.TURN_IN_NO_ = TI.REF_NO_
	WHERE TI.HANDLE_ = @handle
	
	declare @threshold dbo.TIN_Type_StatusThreshold

	INSERT @threshold
	SELECT TN.ID_ AS TurnInId
	, COUNT(1) * 1000 AS thReceived
	, COUNT(1) * 100 AS thValidated
	, COUNT(1) * 10 AS thCreated
	FROM LOG_TRN_TIN_TURN_IN TN 
	JOIN LOG_TRN_TIN_TURN_IN_ITEM TNI ON TNI.TURN_IN_ID = TN.ID_ 
	WHERE EXISTS (
		SELECT 1
		FROM TMP_TRANSFER_ITEM TI
		WHERE HANDLE_ = @handle AND TI.REF_NO_ = TN.TURN_IN_NO_
	)
	--FROM TMP_TRANSFER_ITEM TI
	--JOIN LOG_TRN_TIN_TURN_IN TN ON TI.REF_NO_ = TN.TURN_IN_NO_
	--JOIN LOG_TRN_TIN_TURN_IN_ITEM TNI ON TNI.TURN_IN_ID = TN.ID_ AND TNI.UNIT_ID = TI.UNIT_ID_
	--WHERE TI.HANDLE_=@handle
	GROUP BY TN.ID_

	UPDATE TN
	SET TN.STATUS_ = TIS.TurnInStatus
	, RECEIVED_ON_ = CASE WHEN TIS.TurnInStatus = 'Received' OR TIS.TurnInStatus ='PartiallyReceived' THEN @performedOn ELSE NULL END
	, RECEIVED_BY_ID = CASE WHEN TIS.TurnInStatus = 'Received' OR TIS.TurnInStatus ='PartiallyReceived' THEN @userProfileId ELSE NULL END
	, SENT_ON_ = CASE 
		WHEN TIS.TurnInStatus = 'Received' OR TIS.TurnInStatus ='PartiallyReceived' THEN SENT_ON_ 
		WHEN TIS.TurnInStatus = 'Validated' OR TIS.TurnInStatus ='PartiallyRejected' THEN @performedOn 
		ELSE NULL 
	END
	, SENT_BY_ID = CASE 
		WHEN TIS.TurnInStatus = 'Received' OR TIS.TurnInStatus ='PartiallyReceived' THEN SENT_BY_ID 
		WHEN TIS.TurnInStatus = 'Validated' OR TIS.TurnInStatus ='PartiallyRejected' THEN @userProfileId 
		ELSE NULL 
	END
	FROM LOG_TRN_TIN_TURN_IN TN
	JOIN (
		SELECT 
		x.TURN_IN_ID_,TURN_IN_NO_
		,CASE 
			WHEN StatusVal = thReceived THEN 'Received'
			WHEN StatusVal < thReceived AND StatusVal > thValidated THEN 'PartiallyReceived'
			WHEN StatusVal = thValidated THEN 'Validated'
			WHEN StatusVal < thValidated AND StatusVal > thCreated THEN 'PartiallyRejected'
			WHEN StatusVal = thCreated THEN 'Created'
			ELSE 'Rejected'
		END AS TurnInStatus
		--, TH.thCreated, TH.thValidated, TH.thReceived
		FROM (
			SELECT TN.ID_ AS TURN_IN_ID_, TN.TURN_IN_NO_, SUM(CASE TNI.STATUS_
				WHEN 'Created' THEN 10
				WHEN 'RejectedByReceiver' THEN 10
				WHEN 'Validated' THEN 100
				WHEN 'Received' THEN 1000
				ELSE 0
			END ) AS StatusVal	
			FROM LOG_TRN_TIN_TURN_IN TN 
			JOIN LOG_TRN_TIN_TURN_IN_ITEM TNI ON TNI.TURN_IN_ID = TN.ID_ 
			WHERE EXISTS (
				SELECT 1
				FROM TMP_TRANSFER_ITEM TI
				WHERE HANDLE_ = @handle AND TN.TURN_IN_NO_ = TI.REF_NO_
			)
			--FROM TMP_TRANSFER_ITEM TI
			--JOIN LOG_TRN_TIN_TURN_IN TN ON TI.REF_NO_ = TN.TURN_IN_NO_
			--JOIN LOG_TRN_TIN_TURN_IN_ITEM TNI ON TNI.TURN_IN_ID = TN.ID_ AND TNI.UNIT_ID = TI.UNIT_ID_
			--WHERE HANDLE_ = @handle
			GROUP BY TN.ID_, TN.TURN_IN_NO_
		) X
		JOIN @threshold TH ON TH.TurnInId = X.TURN_IN_ID_
	) TIS ON TN.ID_ = TIS.TURN_IN_ID_

end
go

