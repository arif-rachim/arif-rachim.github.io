CREATE FUNCTION [dbo].[D161GetChildrenIdByEndUnitId] (@endUnitId bigint)
RETURNS TABLE
AS RETURN
with cte as (
select prnt_ac.ID_, prnt_ac.COMP_UNIT_ID
from MNT_TRN_D16_1_ASSIGNMENT prnt_ac
where prnt_ac.END_UNIT_ID = @endUnitId
union all
select chd_ac.ID_, chd_ac.COMP_UNIT_ID
from MNT_TRN_D16_1_ASSIGNMENT as chd_ac 
inner join cte on chd_ac.END_UNIT_ID= cte.COMP_UNIT_ID
)
select cte.ID_
from cte
go

