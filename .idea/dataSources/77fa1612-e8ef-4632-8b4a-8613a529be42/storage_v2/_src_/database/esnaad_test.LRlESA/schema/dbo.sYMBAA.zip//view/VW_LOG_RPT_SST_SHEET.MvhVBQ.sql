CREATE VIEW [dbo].[VW_LOG_RPT_SST_SHEET]
AS
SELECT     sst.ID_ AS sstid, ag.NAME_ AS agl2, l.NAME_ AS location, i.PART_NO_ AS partnumber, sr.CODE_ AS ui, u.SERIAL_NO_ AS serialnumber, 
                      mst.MAIN_STOCKTAKING_NO_ AS mst, sst.SUB_STOCKTAKING_NO_ AS sst, msti.SYS_QTY_ AS incomp, msti.ACT_QTY_ AS phys, 
                      CASE WHEN msti.ACT_QTY_ > msti.SYS_QTY_ THEN msti.ACT_QTY_ - msti.SYS_QTY_ ELSE NULL END AS surp, 
                      CASE WHEN msti.SYS_QTY_ > msti.ACT_QTY_ THEN msti.SYS_QTY_ - msti.ACT_QTY_ ELSE NULL END AS defic, sst.REMARKS_ AS remarks
FROM         dbo.LOG_TRN_STM_SUB_STOCKTAKING AS sst INNER JOIN
                      dbo.LOG_TRN_STM_MAIN_STOCKTAKING_ITEM AS msti ON msti.SST_ID_ = sst.ID_ INNER JOIN
                      dbo.LOG_TRN_STM_MAIN_STOCKTAKING AS mst ON mst.ID_ = msti.MST_ID_ INNER JOIN
                      dbo.ADM_TRN_ASSOC_GROUPS AS ag ON ag.ID_ = msti.AGL2_ID_ INNER JOIN
                      dbo.ADM_MST_UNIT_LOCATION AS l ON l.ID_ = msti.LOC_ID_ INNER JOIN
                      dbo.ADM_MST_UNITS AS u ON u.ID_ = msti.UNIT_ID_ INNER JOIN
                      dbo.ADM_MST_ITEMS AS i ON i.ID_ = u.ITEM_ID INNER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS sr ON sr.ID_ = i.UI_ID
go

