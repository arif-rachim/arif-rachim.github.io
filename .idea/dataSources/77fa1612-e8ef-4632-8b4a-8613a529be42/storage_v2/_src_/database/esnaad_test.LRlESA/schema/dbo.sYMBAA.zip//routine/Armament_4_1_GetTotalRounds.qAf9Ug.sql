CREATE FUNCTION [dbo].[Armament_4_1_GetTotalRounds]
(
  @unitId AS BIGINT
)
  RETURNS INT
AS
BEGIN
  DECLARE @totalRounds INT = 0;

  SELECT @totalRounds = CASE
                          WHEN (SELECT count(rec.ID_)
                                FROM MNT_TRN_ARMAMENT_RECORDING AS rec
                                WHERE rec.STATUS_ = 'Validated'
                                  AND rec.RECORD_TYPE_ = 'Operation'
                                  AND rec.RECORDED_FROM_UNIT_ID_ = @unitId) > 0 THEN
                            (SELECT ISNULL(base.ROUNDS_, 0) + SUM(ROUNDS_FIRED_)
                             FROM MNT_TRN_ARMAMENT_RECORDING AS rec
                                    LEFT JOIN MNT_TRN_ARMAMENT_BASELINE base
                                              ON base.UNIT_ID_ = rec.RECORDED_FROM_UNIT_ID_
                             WHERE rec.STATUS_ = 'Validated'
                               AND rec.RECORD_TYPE_ = 'Operation'
                               AND rec.RECORDED_FROM_UNIT_ID_ = @unitId
                               AND (base.ID_ IS NULL OR rec.RECORDED_DATE_ >= base.EFFECTIVE_DATE_)
                             GROUP BY base.ROUNDS_)
                          ELSE
                            (SELECT ROUNDS_
                             FROM MNT_TRN_ARMAMENT_BASELINE b
                             WHERE UNIT_ID_ = @unitId)
    END
  RETURN @totalRounds
END
go

