CREATE PROCEDURE [dbo].[SEC_RepopulateLinkedRoles]
	-- master role id
	@m_role_id uniqueidentifier,
	-- child role id
	@c_role_id uniqueidentifier
AS 
BEGIN
	-- Remove all group, group FACL and group user belong to the child role
	-- and then recreate new groups and repopulate group facl with all facl defined in the corresponding master role 
	-- finally repopulate group user based on role assigned users

	declare @newGroup table(id_ bigint, role_id_ uniqueidentifier, mdl_ varchar(255))

	delete from ADM_XRF_USER_PROFILE_GROUPS where GROUP_ID in (select ID_ from ADM_TRN_GROUPS where ROLE_ID = @c_role_id)
	delete from ADM_XRF_GROUPS_SECURED_RESOURCES where GROUP_ID in (select ID_ from ADM_TRN_GROUPS where ROLE_ID = @c_role_id)
	delete from ADM_TRN_GROUPS where ROLE_ID = @c_role_id

	insert into ADM_TRN_GROUPS (VERSION_, NAME_, GRP_TYPE_, MDL_ID, ROLE_ID, CREATED_BY_, CREATED_ON_)
	output  inserted.ID_, inserted.role_id, inserted.MDL_ID into @newGroup
	select 1, 'ROLE_GROUP_'+cast(newid() as varchar(36)), 'RoleGroup', gm.MDL_ID, @c_role_id, 'SYSTEM', getdate()
	from ADM_TRN_GROUPS gm 
	where gm.ROLE_ID = @m_role_id

	insert into ADM_XRF_GROUPS_SECURED_RESOURCES
	select ng.id_, gsr.FUNC_ID
	from ADM_XRF_GROUPS_SECURED_RESOURCES gsr
	join ADM_TRN_GROUPS gm on gm.ID_ = gsr.GROUP_ID
	join @newGroup ng on ng.mdl_ = gm.MDL_ID
	where gm.ROLE_ID = @m_role_id
	group by ng.id_, gsr.FUNC_ID

	insert into ADM_XRF_USER_PROFILE_GROUPS
	select ng.id_, asg.USR_PRF_ID
	from ADM_TRN_SEC_ROLE_ASSIGNMENT asg
	join @newGroup ng on ng.role_id_ = asg.ROLE_ID
	where asg.ROLE_ID = @c_role_id

END
go

