CREATE VIEW [dbo].[VW_MNT_PC_TOTAL_FLIGHT_HOURS]
as SELECT
  P.UnitId
  , P.Tail
  , P.Platform
  , P.PlatformId
  , P.[Order]
  , P.VerifiedFlightMinutes
  , P.Baseline
  , ROUND(Q.UnverifiedFlightMinutes / 60.0, 1) AS UnverifiedFlightHours
  , Q.UnverifiedLandings                       AS UnverifiedLandings
  , Q.UnverifiedCycles                         AS UnverifiedCycles
  , CASE WHEN VerifiedFlightMinutes IS NOT NULL AND Baseline IS NOT NULL
  THEN (ROUND((VerifiedFlightMinutes + Baseline) / 60.0, 1))
    WHEN VerifiedFlightMinutes IS NOT NULL AND Baseline IS NULL
      THEN (ROUND(VerifiedFlightMinutes / 60.0, 1))
    WHEN VerifiedFlightMinutes IS NULL AND
         Baseline IS NOT NULL
      THEN (ROUND(Baseline / 60.0, 1))
    WHEN VerifiedFlightMinutes IS NULL AND Baseline IS NULL
      THEN NULL END                            AS OldAircraftHours
  , R.UnrecordedFlight
  , R.UnrecordedMission
  , S.LastModifiedBy
  , S.LastModifiedOn
  , S.LastModifiedPid
  , ROUND(P.AircraftMinutes / 60.0, 1)         AS AircraftHours
  , P.Landings                                 AS Landings
  , P.Cycles                                   AS Cycles
  , P.CreatedBy            AS CreatedBy
  , P.PidCreatedBy        AS PidCreatedBy
  , P.FullNameCreatedBy  AS FullNameCreatedBy
  , P.CreatedOn            AS CreatedOn
  , P.ModifiedBy                AS ModifiedBy
  , P.PidModifiedBy            AS PidModifiedBy
  , P.FullNameModifiedBy      AS FullNameModifiedBy
  , P.ModifiedOn                AS ModifiedOn
FROM (SELECT
          mt.UNIT_ID                                           AS UnitId
        , mt.T_NUM_                                            AS Tail
        , p.CODE_                                              AS Platform
        , p.ID_                                                AS PlatformId
        , p.ORDER_                                             AS [Order]
        , SUM(dbo.ToTAAMSMinute(DATEDIFF(MI,
                                         tfr.RTD_, tfr.RTA_))) AS VerifiedFlightMinutes
        , ab.MINUTES_                                          AS Baseline
        , uu.TOT_FLIGHT_MINS_                                  AS AircraftMinutes
        , uu.LANDINGS_                                         AS Landings
        , uu.CYCLES_                                           AS Cycles
        , uu.CREATED_BY_            AS CreatedBy
        , uu.PID_CREATED_BY_        AS PidCreatedBy
        , uu.FULL_NAME_CREATED_BY_  AS FullNameCreatedBy
        , uu.CREATED_ON_            AS CreatedOn
        , uu.MOD_BY_                AS ModifiedBy
        , uu.PID_MOD_BY_            AS PidModifiedBy
        , uu.FULL_NAME_MOD_BY_      AS FullNameModifiedBy
        , uu.MOD_ON_                AS ModifiedOn
      FROM dbo.OPS_TRN_TAIL_CREWS AS tc INNER JOIN
        dbo.OPS_TRN_WINGS AS w ON tc.WING_ID = w.ID_
        INNER JOIN
        dbo.OPS_TRN_MISSIONS AS m ON w.MISSION_ID = m.ID_
        INNER JOIN
        dbo.OPS_TRN_TAIL_FLIGHT AS tf ON tf.TAIL_CREW_ID = tc.ID_
        RIGHT OUTER JOIN
        dbo.ADM_MST_TAILS AS mt ON tc.TAIL_ID = mt.ID_ AND mt.END_DATE_ = '9999-12-31'
        LEFT OUTER JOIN
        dbo.ADM_MST_UNITS AS u ON mt.UNIT_ID = u.ID_
        LEFT OUTER JOIN
        dbo.ADM_TRN_AIRCRAFT_BASELINES AS ab ON u.ID_ = ab.AIRCRAFT_ID_
        LEFT OUTER JOIN
        dbo.OPS_TRN_TAIL_FLIGHT_RECORD AS tfr ON tfr.TAIL_FLIGHT_ID = tf.ID_ AND (ab.AIRCRAFT_ID_ IS NULL OR
                                                                                  tfr.RTD_ > ab.MINUTES_EFF_DATE_)
        LEFT OUTER JOIN
        dbo.ADM_MST_ITEMS AS i ON u.ITEM_ID = i.ID_
        LEFT OUTER JOIN
        dbo.ADM_MST_PLATFORMS AS p ON p.ID_ = i.ID_
        LEFT OUTER JOIN
        dbo.WF_TRN_INSTANCE AS wf ON wf.ID_ = m.WF_ID AND wf.WF_DEF_ID_='MissionWorkflow' AND wf.WF_STATE_ IN ('Verified', 'Debriefed')
        LEFT OUTER JOIN
        dbo.ADM_TRN_UNIT_USAGE AS uu ON uu.UNIT_ID_ = u.ID_
      GROUP BY mt.UNIT_ID, mt.T_NUM_, p.CODE_, p.ID_, p.ORDER_, ab.MINUTES_, uu.TOT_FLIGHT_MINS_, uu.LANDINGS_, uu.CYCLES_
        , uu.CREATED_BY_, uu.PID_CREATED_BY_, uu.FULL_NAME_CREATED_BY_, uu.CREATED_ON_, uu.MOD_BY_, uu.PID_MOD_BY_, uu.FULL_NAME_MOD_BY_, uu.MOD_ON_   
    ) AS P LEFT OUTER JOIN
  (SELECT
       mt.UNIT_ID AS UnitId
     , mt.T_NUM_  AS Tail
     , p.CODE_    AS Platform
     , p.ID_      AS PlatformId
     , SUM(dbo.ToTAAMSMinute(DATEDIFF(MI, tfr.RTD_, tfr.RTA_)))
                  AS UnverifiedFlightMinutes
     , SUM(tfr.LANDINGS_) AS UnverifiedLandings
     , SUM(tfr.CYCLES_)   AS UnverifiedCycles
   FROM dbo.OPS_TRN_TAIL_CREWS AS tc INNER JOIN
     dbo.OPS_TRN_WINGS AS w ON tc.WING_ID = w.ID_
     INNER JOIN
     dbo.OPS_TRN_MISSIONS AS m ON w.MISSION_ID = m.ID_
     INNER JOIN
     dbo.OPS_TRN_TAIL_FLIGHT AS tf ON tf.TAIL_CREW_ID = tc.ID_
     RIGHT OUTER JOIN
     dbo.ADM_MST_TAILS AS mt ON tc.TAIL_ID = mt.ID_ AND mt.END_DATE_ = '9999-12-31'
     LEFT OUTER JOIN
     dbo.ADM_MST_UNITS AS u ON mt.UNIT_ID = u.ID_
     LEFT OUTER JOIN
     dbo.ADM_TRN_AIRCRAFT_BASELINES AS ab ON u.ID_ = ab.AIRCRAFT_ID_
     LEFT OUTER JOIN
     dbo.OPS_TRN_TAIL_FLIGHT_RECORD AS tfr ON tfr.TAIL_FLIGHT_ID = tf.ID_ AND (ab.AIRCRAFT_ID_ IS NULL OR
                                                                               tfr.RTD_ > ab.MINUTES_EFF_DATE_)
     LEFT OUTER JOIN
     dbo.ADM_MST_ITEMS AS i ON u.ITEM_ID = i.ID_
     LEFT OUTER JOIN
     dbo.ADM_MST_PLATFORMS AS p ON p.ID_ = i.ID_
     INNER JOIN
     dbo.WF_TRN_INSTANCE AS wf ON wf.ID_ = m.WF_ID AND wf.WF_DEF_ID_='MissionWorkflow' AND wf.WF_STATE_ = 'Accomplished'
   GROUP BY mt.UNIT_ID, mt.T_NUM_, p.CODE_, p.ID_) AS Q ON P.UnitId = Q.UnitId
  LEFT OUTER JOIN
  (SELECT
       dbo.ADM_MST_TAILS.UNIT_ID                                      AS UnitId
     , dbo.ADM_MST_PLATFORMS.ID_                                      AS PlatformId
     , CAST(COUNT(dbo.OPS_TRN_TAIL_FLIGHT.ID_)
            AS VARCHAR(10))                                           AS UnrecordedMission
     , CAST(COUNT(dbo.OPS_TRN_TAIL_FLIGHT_RECORD.ID_) AS VARCHAR(10)) AS UnrecordedFlight
   FROM dbo.ADM_MST_PLATFORMS
     RIGHT OUTER JOIN
     dbo.ADM_MST_ITEMS ON dbo.ADM_MST_PLATFORMS.ID_ = dbo.ADM_MST_ITEMS.ID_
     RIGHT OUTER JOIN
     dbo.ADM_MST_UNITS ON dbo.ADM_MST_ITEMS.ID_ = dbo.ADM_MST_UNITS.ITEM_ID
     RIGHT OUTER JOIN
     dbo.ADM_MST_TAILS
     LEFT OUTER JOIN
     dbo.OPS_TRN_MISSIONS
     INNER JOIN
     dbo.OPS_TRN_TAIL_CREWS
     INNER JOIN
     dbo.OPS_TRN_WINGS ON dbo.OPS_TRN_TAIL_CREWS.WING_ID = dbo.OPS_TRN_WINGS.ID_ ON
                                                                                   dbo.OPS_TRN_MISSIONS.ID_ =
                                                                                   dbo.OPS_TRN_WINGS.MISSION_ID
       ON dbo.ADM_MST_TAILS.ID_ = dbo.OPS_TRN_TAIL_CREWS.TAIL_ID ON
                                                                   dbo.ADM_MST_UNITS.ID_ = dbo.ADM_MST_TAILS.UNIT_ID
     LEFT OUTER JOIN
     dbo.OPS_TRN_TAIL_FLIGHT_RECORD
     RIGHT OUTER JOIN
     dbo.OPS_TRN_TAIL_FLIGHT ON dbo.OPS_TRN_TAIL_FLIGHT_RECORD.TAIL_FLIGHT_ID = dbo.OPS_TRN_TAIL_FLIGHT.ID_ ON
                                                                                                              dbo.OPS_TRN_TAIL_CREWS.ID_
                                                                                                              =
                                                                                                              dbo.OPS_TRN_TAIL_FLIGHT.TAIL_CREW_ID
     INNER JOIN
     dbo.WF_TRN_INSTANCE AS wf ON wf.ID_ = dbo.OPS_TRN_MISSIONS.WF_ID AND wf.WF_DEF_ID_='MissionWorkflow'
   WHERE (wf.WF_STATE_ IN ('Authorized', 'OnMission', 'InCorrection'))
   GROUP BY dbo.ADM_MST_TAILS.UNIT_ID, dbo.ADM_MST_TAILS.T_NUM_, dbo.ADM_MST_PLATFORMS.CODE_,
     dbo.ADM_MST_PLATFORMS.ID_) AS R ON
                                       P.UnitId = R.UnitId
  LEFT OUTER JOIN
  (SELECT
       t.UNIT_ID_            AS UnitId
     , CASE WHEN t.MOD_BY_ IS NULL
      THEN (up.F_NAME_ + ' ' + up.L_NAME_)
       ELSE (up2.F_NAME_ + ' ' + up2.L_NAME_)
       END                   AS 'LastModifiedBy'
     , CASE WHEN t.MOD_BY_ IS NULL
      THEN t.CREATED_ON_
       ELSE t.MOD_ON_ END    AS 'LastModifiedOn'
     , CASE WHEN t.MOD_BY_ IS NULL
      THEN up.USER_ID_
       ELSE up2.USER_ID_ END AS 'LastModifiedPid'
   FROM dbo.MNT_TRN_TFH AS t LEFT OUTER JOIN
     dbo.ADM_TRN_USER_PROFILES AS up ON t.CREATED_BY_ = up.USER_ID_
     LEFT OUTER JOIN
     dbo.ADM_TRN_USER_PROFILES AS up2 ON t.MOD_BY_ = up2.USER_ID_) AS S ON P.UnitId = S.UnitId
go

