CREATE view VW_CIS_RPT_AIRCRAFT_STRENGTH
AS  
-- 
SELECT DISTINCT   
    SecurityFootprint.UserId As UserId
    , SC.NG_COMMAND AS Command
    --, ISNULL(P.EN_SHORT_NAME_, '') + ' ' + ISNULL(P.AR_LONG_NAME_, '') AS Name
    , P.CODE_ as Name
    , ISNULL(F.MTO_, 0) AS Mtoe
    , SP.FLEET_STRENGTH_ AS Total
    , 0 Depot
    , cast (0 as bit) as IsFromNg
    , SP.MISSION_CAPABLE_ AS Fmc
    , SP.FLEET_STRENGTH_ - SP.MISSION_CAPABLE_ AS Nmc
    , CASE SP.FLEET_STRENGTH_ 
		WHEN 0 THEN '0.00 %' 
		--ELSE CONVERT(VARCHAR, CAST((SP.MISSION_CAPABLE_ * 100.00 / SP.FLEET_STRENGTH_) AS DECIMAL(10,2))) + ' %' 
		ELSE CONVERT(VARCHAR, CAST(SP.DAILY_OR_ AS DECIMAL(10,2))) + ' %' 
	  END AS Serviceability
	, ISNULL(F.REMARKS_, '') AS Remarks  
FROM dbo.CIS_IMP_ACT_STRENGTH_PLATFORM AS SP 
INNER JOIN dbo.CIS_IMP_ACT_STRENGTH_COMMAND AS SC ON SP.COMMAND_ID = SC.ID_ 
INNER JOIN dbo.ADM_MST_PLATFORMS AS P ON SP.NG_PLATFORM_ID = P.ID_ 
LEFT OUTER JOIN  dbo.MNT_TRN_GHQ_FLEET_RPTS AS F ON P.ID_ = F.PLTF_ID AND SC.NG_COMMAND_ID = F.CMD_ID 
INNER JOIN (
	SELECT UPROFILE.USER_ID_ As UserId, command.ID_ As CommandId
    FROM ADM_MST_RESTRICTIONS command  
    INNER JOIN ADM_MST_SECURED_RESOURCES SecuredResources ON SecuredResources.ID_= 'EIS.002.00.00.00' 
	INNER JOIN ADM_TRN_USER_RESTRICTIONS UserRestrictions ON UserRestrictions.MODULE_ID = SecuredResources.ID_ 
	INNER JOIN ADM_TRN_USER_PROFILES UPROFILE ON UPROFILE.ID_ = UserRestrictions.USER_PROFILE_ID
	INNER JOIN ADM_TRN_USER_RESTRICION_DETAILS urd ON urd.USR_REST_ID = UserRestrictions.ID_ AND urd.DT_REST_ID = Command.ID_                     
    WHERE TYPE_NAME_ = 'Command'        
) SecurityFootprint ON SC.NG_COMMAND_ID  = SecurityFootprint.CommandId
where SC.NG_COMMAND_ID NOT IN (
	select cmd.ID_
	from ADM_MST_RESTRICTIONS cmd
	inner join CIS_NG_COMMAND_MAP map on map.NG_COMMAND_ = cmd.CODE_
	inner join CIS_EXCLUDE_COMMAND exc on map.CIS_COMMAND_ = exc.CIS_COMMAND_
)

union

select 
	secur.UserId
	, secur.Command as Command
    --, ISNULL(pltf.EN_SHORT_NAME_, '') + ' ' + ISNULL(pltf.AR_LONG_NAME_, '') AS Name
    , pltf.CODE_ as Name
    , ISNULL(fleet.MTO_, 0) AS Mtoe
    , count(tail.id_) as Total
	, sum(case when (scon.CODE_ = 'DEPOT') then 1 else 0 end) as Depot
	, cast (1 as bit) as IsFromNg
    , sum(case when (scon.CODE_ <> 'DEPOT' and scon.CODE_ <> 'NMCM' and scon.CODE_ <> 'NMCS') then 1 else 0 end) as Fmc
    , count(tail.id_) 
		-
	  sum(case when (scon.CODE_ <> 'DEPOT' and scon.CODE_ <> 'NMCM' and scon.CODE_ <> 'NMCS') then 1 else 0 end) 
	  as Nmc
	, CASE count(tail.id_) 
		WHEN 0 THEN '0.00 %'
		ELSE CONVERT(VARCHAR, CAST((sum(case when (scon.CODE_ <> 'DEPOT' and scon.CODE_ <> 'NMCM' and scon.CODE_ <> 'NMCS') then 1 else 0 end) * 100.00 
				/ (count(tail.id_) - sum(case when (scon.CODE_ = 'DEPOT') then 1 else 0 end))
			 ) AS DECIMAL(10,1))) + ' %'
	  END AS Serviceability
    , ISNULL(fleet.REMARKS_, '') AS Remarks
from MNT_TRN_AIRCRAFT_SERVS srv
inner join ADM_MST_STATUS_CONDITIONS con on con.ID_ = srv.STSCND_ID inner join ADM_MST_SIMPLE_REF scon on scon.ID_ = con.COND_ID
right join ADM_MST_TAILS tail on tail.UNIT_ID = srv.UNIT_ID inner join ADM_MST_UNITS unit on tail.UNIT_ID = unit.ID_
right join ADM_MST_ITEMS item on item.ID_ = unit.ITEM_ID inner join ADM_MST_PLATFORMS pltf on item.ID_ = pltf.ID_
inner join
(
	select usr.USER_ID_ as UserId, item.ID_ as PlatformId, bat.ID_ as BatId, com.CODE_ as Command, com.ID_ as CommandId
	from ADM_MST_ITEMS item
	inner join ADM_MST_UNITS unit on item.ID_ = unit.ITEM_ID
	inner join ADM_MST_TAILS tail on tail.UNIT_ID = unit.ID_
	inner join ADM_TRN_USER_RESTRICION_DETAILS urd on urd.DT_REST_ID = tail.BATLN_ID and urd.LVL_NAME_ = 'Battalion'
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.ID_ = urd.USR_REST_ID and ur.MODULE_ID='EIS.002.00.00.00'
	inner join ADM_MST_RESTRICTIONS bat on urd.DT_REST_ID = bat.ID_
	inner join ADM_MST_RESTRICTIONS com on bat.PRNT_ID= com.ID_
	inner join ADM_TRN_USER_PROFILES usr on usr.ID_ = ur.USER_PROFILE_ID
	group by item.ID_, usr.USER_ID_, bat.ID_ , com.CODE_ , com.ID_
) as secur on secur.PlatformId = pltf.ID_ and tail.BATLN_ID = secur.BatId
LEFT OUTER JOIN  MNT_TRN_GHQ_FLEET_RPTS AS fleet ON pltf.ID_ = fleet.PLTF_ID AND secur.CommandId = fleet.CMD_ID 
where secur.CommandId IN (
	select cmd.ID_
	from ADM_MST_RESTRICTIONS cmd
	inner join CIS_NG_COMMAND_MAP map on map.NG_COMMAND_ = cmd.CODE_
	inner join CIS_EXCLUDE_COMMAND exc on map.CIS_COMMAND_ = exc.CIS_COMMAND_
)
group by secur.UserId
		--, pltf.EN_SHORT_NAME_, pltf.AR_LONG_NAME_
		, pltf.CODE_
		, secur.Command, fleet.MTO_, fleet.REMARKS_
go

