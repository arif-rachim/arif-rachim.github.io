CREATE FUNCTION [dbo].[D16GetForecastReportByPart]
(
  @commandId    int,
  @platformId   int,
  @battalionId  int,
  @tailId       bigint,
  @itemId       bigint,
  @nomenclature varchar(250),
  @hrs          real,
  @landing      int,
  @cValueMonth  int,
  @cValueYear   int
  )
  RETURNS TABLE
    AS
    RETURN
    SELECT TailNo          AS TailNo
         , PartNo          AS PartNo
         , MFR             AS MFR
         , Description     AS Description
         , OverDuePlatform AS OverDuePlatform
         , sum(OverDueQty) AS OverDueQty
         , DueNextPlatform AS DueNextPlatform
         , sum(DueNextQty) AS DueNextQty
         , RequisitionNo   AS RequisitionNo
         , RQtyOnHand	   AS RQtyOnHand
         , InLieu          AS InLieu
         , ILQtyOnHand     AS ILQtyOnHand
    FROM (SELECT DISTINCT ByPart.TailNo                                                     AS TailNo
               , ByPart.PartNo                                                     AS PartNo
               , ByPart.MFR                                                        AS MFR
               , ByPart.Description                                                AS Description
               , ByPart.OverDuePlatform                                            AS OverDuePlatform
               , ByPart.DueNextPlatform                                            AS DueNextPlatform
               , ByPart.RequisitionNo                                              AS RequisitionNo
               , ByPart.RQtyOnHand                                                 AS RQtyOnHand
               , ByPart.InLieu                                                     AS InLieu
               , ByPart.ILQtyOnHand                                                AS ILQtyOnHand
               , IIF((count(ByPart.OverDueQty)) > 0, sum(ByPart.OverDueQty), NULL) AS OverDueQty
               , (SELECT MAX(ds.val)
                  FROM (
						SELECT CONVERT(INT, IIF(@hrs < ByPart.FrequencyHours, 1, IIF(ByPart.FrequencyHours>0, IIF((Hrs - usageHours)<0, (@hrs/ByPart.FrequencyHours), ((@hrs + (FrequencyHours - (Hrs - usageHours))) / ByPart.FrequencyHours)), 0))) AS val
						UNION ALL
						SELECT CONVERT(INT, IIF(@landing < ByPart.FrequencyLandings, 1, IIF(ByPart.FrequencyLandings>0, IIF((Landing - usageLanding)<0, (@landing/ByPart.FrequencyLandings), ((@landing + (FrequencyLandings - (Landing - usageLanding))) / ByPart.FrequencyLandings)), 0))) AS val
						UNION ALL
						SELECT CONVERT(INT, IIF(IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth) < ByPart.CValue, 1, IIF(ByPart.CValue>0, IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth)/ByPart.CValue, 0))) AS val
						UNION ALL
						SELECT CONVERT(INT, IIF(IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth) < ByPart.TsiValue, 1, IIF(ByPart.TsiValue>0, IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth)/ByPart.TsiValue, 0))) AS val
						UNION ALL
						SELECT CONVERT(INT, IIF(@hrs < ByPart.OvrFrequencyHours, 1, IIF(ByPart.OvrFrequencyHours>0, IIF((Hrs - usageHours)<0, (@hrs/ByPart.OvrFrequencyHours), ((@hrs + (OvrFrequencyHours - (Hrs - usageHours))) / ByPart.OvrFrequencyHours)), 0))) AS val
						UNION ALL
						SELECT CONVERT(INT, IIF(@landing < ByPart.OvrFrequencyLandings, 1, IIF(ByPart.OvrFrequencyLandings>0, IIF((Landing - usageLanding)<0, (@landing/ByPart.OvrFrequencyLandings), ((@landing + (OvrFrequencyLandings - (Landing - usageLanding))) / ByPart.OvrFrequencyLandings)), 0))) AS val
						UNION ALL
						SELECT CONVERT(INT, IIF(IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth) < ByPart.OvrCValue, 1, IIF(ByPart.OvrCValue>0, IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth)/ByPart.OvrCValue, 0))) AS val

	  --				  SELECT IIF((count(ByPart.DueNextQty)) > 0, sum(ByPart.DueNextQty), NULL) AS val
      --                  UNION ALL
      --                  SELECT IIF(((count(ByPart.DueNextQty)) > 0 AND ByPart.FrequencyHours > 0)
      --                           , sum(ByPart.DueNextQty) *
      --                             (IIF(@hrs < ByPart.FrequencyHours, 1, convert(int,
      --                                   (@hrs + (FrequencyHours - (Hrs - usageHours))) / ByPart.FrequencyHours)))
      --                           , NULL) AS val
      --                  UNION ALL
      --                  SELECT IIF(((count(ByPart.DueNextQty)) > 0 AND ByPart.OvrFrequencyHours > 0)
      --                           , sum(ByPart.DueNextQty) *
      --                             (IIF(@hrs < ByPart.FrequencyHours, 1, convert(int,
      --                                   (@hrs + (OvrFrequencyHours - (Hrs - usageHours))) / ByPart.OvrFrequencyHours)))
      --                           , NULL) AS val
      --                  UNION ALL
      --                  SELECT IIF(((count(ByPart.DueNextQty)) > 0 AND ByPart.FrequencyLandings > 0)
      --                           , sum(ByPart.DueNextQty) * (IIF(@landing < ByPart.FrequencyLandings, 1,
      --                                                           convert(int,
      --                                                                 (@landing + (OvrFrequencyLandings - (Landing - usageLanding))) /
      --                                                                 ByPart.FrequencyLandings)))
      --                           , NULL) AS val
      --                  UNION ALL
      --                  SELECT IIF(((count(ByPart.DueNextQty)) > 0 AND ByPart.OvrFrequencyLandings > 0)
      --                           , sum(ByPart.DueNextQty) * (IIF(@landing < ByPart.OvrFrequencyLandings, 1,
      --                                                           convert(int,
      --                                                                 (@landing + (OvrFrequencyLandings - (Landing - usageLanding))) /
      --                                                                 ByPart.OvrFrequencyLandings)))
      --                           , NULL) AS val
      --                  UNION ALL
      --                  SELECT IIF(((count(ByPart.DueNextQty)) > 0 AND ByPart.CValue > 0 AND
      --                              (@cValueYear > 0 OR @cValueMonth > 0))
      --                           , sum(ByPart.DueNextQty) *
      --                             (IIF(IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth) < ByPart.CValue, 1,
      --                                  convert(int,
      --                                      (IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth) / ByPart.CValue))))
      --                           , NULL) AS val
      --                  UNION ALL
      --                  SELECT IIF(((count(ByPart.DueNextQty)) > 0 AND ByPart.OvrCValue > 0 AND
      --                              (@cValueYear > 0 OR @cValueMonth > 0))
      --                           , sum(ByPart.DueNextQty) *
      --                             (IIF(IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth) < ByPart.OvrCValue, 1,
      --                                  convert(int,
      --                                      (IIF(@cValueYear > 0, @cValueYear * 12, @cValueMonth) / ByPart.OvrCValue))))
      --                           , NULL) AS val
					) AS ds
      )                                                                            AS DueNextQty
				, ByPart.ReplacementDate											AS ReplacementDate
				, ByPart.AssignmentId												AS AssignmentId
          FROM (
                 SELECT t.T_NUM_                                                     AS TailNo
                      , ISNULL(nha_item.ID_, ci.ID_)                                 AS ItemId
                      , ci.ID_                                                       AS NhaChildItemId
                      , ISNULL(nha_item.PART_NO_, ci.PART_NO_)                       AS PartNo
                      , ISNULL(nha_cm.CAGE_CODE_, cm.CAGE_CODE_)                     AS MFR
                      , ISNULL(nha_item.NOMENCLATURE_, ci.NOMENCLATURE_)             AS Description
                      , c_due._hours                                                 AS Hrs
                      , dbo.ReturnTAAMSTime(uu.TOT_FLIGHT_MINS_)                     AS usageHours
                      , IIF(nha.ID_ IS NOT NULL, nha_due._landings, c_due._landings) AS Landing
                      , uu.LANDINGS_                                                 AS UsageLanding
                      , iif(mc.REP_CAL_UNIT_ = 'Months', mc.REP_CAL_VALUE_,
                            mc.REP_CAL_VALUE_ * 12)                                  AS CValue
                      , iif(mc.TSI_UNIT_ = 'Months', mc.TSI_VALUE_,
                            mc.TSI_VALUE_ * 12)										 AS TsiValue
                      , mc.REP_HRS_
                   + (CASE
                        WHEN mspu.MSPU_FLAG_ = 1 AND mc.MSPU_HRS_ > 0 THEN mc.MSPU_HRS_
                        ELSE 0 END)
                   + ISNULL(ac.REP_DUE_HRS_EXT_, 0)
                                                                                     AS FrequencyHours
                      , mc.REP_LDGS_                                                 AS FrequencyLandings
                      , mc.OVR_HRS_                                                  AS OvrFrequencyHours
                      , mc.OVR_LDGS_                                                 AS OvrFrequencyLandings
                      , iif(mc.OVR_CAL_UNIT_ = 'Months', mc.OVR_CAL_VALUE_,
                            mc.OVR_CAL_VALUE_ * 12)                                  AS OvrCValue
                      , p.ID_                                                        AS PlatformId
                      , b.ID_                                                        AS BattalionId
                      , cmd.ID_                                                      AS CommandId
                      , IIF(nha.ID_ IS NOT NULL, nha_due._date, c_due._date)         AS ReplacementDate
                      , IIF(
                       dbo.D16IsOverdue(c_due._hours, c_due._landings, c_due._date, uu.TOT_FLIGHT_MINS_, uu.LANDINGS_) =
                       1, p.CODE_, NULL)                                             AS OverduePlatform
                      , IIF(
                       dbo.D16IsOverdue(c_due._hours, c_due._landings, c_due._date, uu.TOT_FLIGHT_MINS_, uu.LANDINGS_) =
                       1, 1, NULL)                                                   AS OverDueQty
                      , IIF(
                       dbo.D16IsOverdue(c_due._hours, c_due._landings, c_due._date, uu.TOT_FLIGHT_MINS_, uu.LANDINGS_) =
                       0, p.CODE_, NULL)                                             AS DueNextPlatform
                      , IIF(
                       dbo.D16IsOverdue(c_due._hours, c_due._landings, c_due._date, uu.TOT_FLIGHT_MINS_, uu.LANDINGS_) =
                       0, 1, NULL)                                                   AS DueNextQty
                      , (SELECT STUFF((SELECT ',' + TRNREQUEST1.TR_NO_
                                       FROM LOG_TRN_TRM_TRANSFER_REQUEST AS TRNREQUEST1
                                              INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST_ITEM AS RequestItem1
                                                         ON RequestItem1.TR_ID_ = TRNREQUEST1.ID_
                                              INNER JOIN WF_TRN_CURR_STATE AS Workflow ON Workflow.WF_INST_ID = TRNREQUEST1.WF_ID
                                       WHERE TRNREQUEST1.END_ITEM_UNIT_ID_ = ac.ACFT_UNIT_ID_
                                         AND RequestItem1.ITEM_ID = ISNULL(nha_item.ID_, ci.ID_)
                                         AND Workflow.NAME_ NOT IN ('Fulfilled','Deleted')
                                         AND RequestItem1.FF_STATUS_ IN ('NotFulfilled', 'PartiallyFulfilled')
                                       ORDER BY TRNREQUEST1.TR_NO_ FOR XML PATH ('')
                                      ), 1, 1, ''
                                  )
                 )                                                                   AS RequisitionNo
                      , (SELECT ISNULL(SUM(STOCK1.QTY_), 0) AS Qty
                         FROM ADM_MST_UNITS AS UNIT1
                                INNER JOIN LOG_TRN_STOCK AS STOCK1 ON UNIT1.ID_ = STOCK1.UNIT_ID
                                INNER JOIN ADM_MST_UNIT_LOCATION ON STOCK1.LOC_ID = ADM_MST_UNIT_LOCATION.ID_
                         WHERE (UNIT1.ITEM_ID = ISNULL(nha_item.ID_, ci.ID_))
                           AND (ADM_MST_UNIT_LOCATION.LOC_TYPE_ = 'Regular' OR ADM_MST_UNIT_LOCATION.LOC_TYPE_='Receiving')
                           AND STOCK1.OWNED_BY_L2_ID_ = pl2.L2_ID_
                           AND STOCK1.TAG_COLOR_COND_ID_ = 1
						   AND (UNIT1.EXP_DATE_ is null or UNIT1.EXP_DATE_ >= GETDATE())
                 )                                                                   AS RQtyOnHand
                      , (SELECT stuff((SELECT ',' + PART_NO_
                                       FROM ADM_MST_ITEMS i2
                                       JOIN ADM_TRN_ITEM_ASSOCS ia2 ON ia2.ITEM_ID = i2.ID_ and ia2.L2_ID = pl2.L2_ID_
                                       WHERE ia2.IN_LIEU_CODE_ =
                                             ISNULL(nha_ia.IN_LIEU_CODE_, ia.IN_LIEU_CODE_)
                                         AND i2.ID_ <> ISNULL(nha_item.ID_, ci.ID_) FOR XML PATH ('')
                                      ), 1, 1, ''
                                  )
                 )                                                                   AS InLieu
                      , (SELECT stuff((SELECT ',' + CONVERT(varchar, tta.qty)
                                       FROM (SELECT inlieuitem6.ID_, ISNULL(SUM(stock6.qty_), 0) AS qty
                                             FROM ADM_MST_ITEMS inlieuitem6
                                                    INNER JOIN ADM_MST_UNITS units6 ON units6.ITEM_ID = inlieuitem6.ID_
                                                    INNER JOIN LOG_TRN_STOCK stock6 ON stock6.UNIT_ID = units6.ID_
                                                    INNER JOIN ADM_MST_UNIT_LOCATION ON stock6.LOC_ID = ADM_MST_UNIT_LOCATION.ID_
                                                    INNER JOIN ADM_TRN_ITEM_ASSOCS ATIA ON inlieuitem6.ID_ = ATIA.ITEM_ID AND ATIA.L2_ID = stock6.OWNED_BY_L2_ID_
                                             WHERE ATIA.IN_LIEU_CODE_ =
                                                   ISNULL(nha_ia.IN_LIEU_CODE_, ia.IN_LIEU_CODE_)
                                               AND inlieuitem6.ID_ <> ISNULL(nha_item.ID_, ci.ID_)
                                               AND stock6.OWNED_BY_L2_ID_ = pl2.L2_ID_
                                               AND (ADM_MST_UNIT_LOCATION.LOC_TYPE_ = 'Regular')
                                               AND stock6.TAG_COLOR_COND_ID_ = 1
                                             GROUP BY inlieuitem6.ID_
                                            ) AS tta FOR XML PATH ('')
                                      ), 1, 1, ''
                                  )
                 )                                                                   AS ILQtyOnHand
				 , ac.ID_															 AS AssignmentId

                 FROM MNT_TRN_D16_ASSIGNED_COMPONENT AS ac
                        INNER JOIN MNT_MST_D16_MASTER_COMPONENT mc ON mc.ID_ = ac.MASTER_COMP_ID_
                        INNER JOIN MNT_MST_D16_COMPONENT c ON c.ID_ = ac.COMP_ID_
                        INNER JOIN ADM_MST_TAILS AS t ON t.UNIT_ID IN (
							SELECT IIF(P_AC.REM_DATE_ IS NULL, AC1.ACFT_UNIT_ID_, NULL)
							FROM MNT_TRN_D16_ASSIGNED_COMPONENT AC1
								LEFT JOIN MNT_TRN_D16_ASSIGNED_COMPONENT P_AC ON P_AC.COMP_ID_ = AC1.PARENT_COMP_ID_
							WHERE AC1.ID_ = ac.ID_
						) AND t.END_DATE_ = '9999-12-31 00:00:00.000'
                        INNER JOIN ADM_MST_RESTRICTIONS AS b ON b.ID_ = t.BATLN_ID
                        INNER JOIN ADM_MST_RESTRICTIONS AS cmd ON b.PRNT_ID = cmd.ID_
                        INNER JOIN ADM_MST_UNITS AS tu ON tu.ID_ = t.UNIT_ID
                        INNER JOIN ADM_MST_PLATFORMS AS p ON tu.ITEM_ID = p.ID_
                        INNER JOIN ADM_MST_PLATFORM_L2 AS pl2
                                   ON pl2.CMD_ID_ = mc.CMD_ID_ AND pl2.PLTF_ID_ = p.ID_
                        LEFT JOIN ADM_TRN_UNIT_USAGE AS uu ON uu.UNIT_ID_ = tu.ID_
                        INNER JOIN ADM_MST_UNITS AS cu ON cu.ID_ = c.UNIT_ID_
                        INNER JOIN ADM_MST_ITEMS AS ci ON ci.ID_ = cu.ITEM_ID
                        LEFT JOIN ADM_TRN_ITEM_ASSOCS ia ON ia.ITEM_ID = ci.ID_ and ia.L2_ID = pl2.L2_ID_
                        INNER JOIN ADM_MST_MANUFACTURES AS cm ON cm.ID_ = ci.MNF_ID
                        LEFT JOIN MNT_MST_D16_MSPU_TAIL_CONFIG mspu ON mspu.ID_ = t.ID_
                        CROSS APPLY dbo.D16GetComponentDue(c.ID_) c_due
						LEFT JOIN MNT_TRN_D16_ASSIGNED_COMPONENT nha 
									ON nha.COMP_ID_ = ac.PARENT_COMP_ID_ and mc.REPLACE_NHA_=1
                        LEFT JOIN MNT_MST_D16_COMPONENT nha_comp ON nha_comp.ID_ = nha.COMP_ID_
                        LEFT JOIN ADM_MST_UNITS nha_unit ON nha_unit.ID_ = nha_comp.UNIT_ID_
                        LEFT JOIN ADM_MST_ITEMS nha_item ON nha_item.ID_ = nha_unit.ITEM_ID
                        LEFT JOIN ADM_TRN_ITEM_ASSOCS nha_ia ON nha_ia.ITEM_ID = nha_item.ID_ and nha_ia.L2_ID = pl2.L2_ID_
						LEFT JOIN ADM_MST_MANUFACTURES AS nha_cm ON nha_cm.ID_ = nha_item.MNF_ID
                        CROSS APPLY dbo.D16GetComponentDue(nha_comp.ID_) nha_due
                 WHERE cmd.ID_ = @commandId
                   AND ac.IS_ACTIVE_ = 1
                   AND t.ID_ = (CASE WHEN @tailId > 0 THEN @tailId ELSE t.ID_ END)
                   AND (@battalionId = 0 OR t.UNIT_ID IN (SELECT ADM_MST_TAILS.UNIT_ID
                                                          FROM ADM_MST_TAILS
                                                          WHERE ADM_MST_TAILS.BATLN_ID = b.ID_))
                   AND (@platformId = 0 OR t.UNIT_ID IN (SELECT ADM_MST_TAILS.UNIT_ID
                                                         FROM ADM_MST_TAILS
                                                                INNER JOIN
                                                              ADM_MST_RESTRICTIONS
                                                              ON ADM_MST_TAILS.BATLN_ID = ADM_MST_RESTRICTIONS.ID_
                                                                INNER JOIN
                                                              ADM_MST_UNITS AS ADM_MST_UNITS_1
                                                              ON ADM_MST_TAILS.UNIT_ID = ADM_MST_UNITS_1.ID_
                                                                INNER JOIN
                                                              ADM_MST_ITEMS AS ADM_MST_ITEMS_1
                                                              ON ADM_MST_UNITS_1.ITEM_ID = ADM_MST_ITEMS_1.ID_
                                                         WHERE (ADM_MST_RESTRICTIONS.PRNT_ID = cmd.ID_)
                                                           AND (ADM_MST_ITEMS_1.ID_ = p.ID_))
                   )
               ) AS ByPart
          WHERE ByPart.CommandId = (CASE WHEN @commandId > 0 THEN @commandId ELSE ByPart.CommandId END)
            AND ByPart.BattalionId = (CASE WHEN @battalionId > 0 THEN @battalionId ELSE ByPart.BattalionId END)
            AND ByPart.PlatformId = (CASE WHEN @platformId > 0 THEN @platformId ELSE ByPart.PlatformId END)
            AND (ByPart.ItemId = (CASE WHEN @itemId > 0 THEN @itemId ELSE ByPart.ItemId END) OR
                 ByPart.NhaChildItemId = (CASE WHEN @itemId > 0 THEN @itemId ELSE ByPart.NhaChildItemId END))
            --AND ByPart.Description LIKE
            --    (CASE WHEN @nomenclature IS NOT NULL THEN ('%' + @nomenclature + '%') ELSE ByPart.Description END)
			AND ( ( (@nomenclature IS NOT NULL or @nomenclature!='No-Value') and ByPart.Description LIKE '%\' + @nomenclature + '%' escape '\') or ( (@nomenclature IS  NULL or @nomenclature='No-Value') and ByPart.Description = ByPart.Description))
            AND (ByPart.OverduePlatform IS NOT NULL OR
                 (@hrs > 0 OR @landing > 0 OR @cValueMonth > 0 OR @cValueYear > 0))
            AND ((ByPart.OverduePlatform is not null) OR
                 (
                  (@hrs > 0 AND ByPart.Hrs - usageHours <= @hrs) OR
                  (@landing > 0 AND ByPart.Landing - UsageLanding <= @landing) OR
                  ((@cValueYear > 0 AND
                    (DATEADD(YEAR, @cValueYear, convert(date, GETDATE())) >= ByPart.ReplacementDate)) OR
                   (@cValueMonth > 0 AND
                    (DATEADD(MONTH, @cValueMonth, convert(date, GETDATE())) >= ByPart.ReplacementDate))
                    )
                 )
                )

          GROUP BY ByPart.TailNo, ByPart.PartNo, ByPart.MFR, ByPart.Description, ByPart.OverDuePlatform,
                   ByPart.DueNextPlatform, ByPart.RequisitionNo, ByPart.RQtyOnHand, ByPart.InLieu,
                   ByPart.FrequencyHours, ByPart.FrequencyLandings, ByPart.CValue, ByPart.TsiValue,
                   ByPart.OvrFrequencyHours, ByPart.OvrFrequencyLandings, ByPart.OvrCValue,
                   ByPart.ILQtyOnHand, Hrs, Landing, usageHours, UsageLanding, ByPart.ReplacementDate, ByPart.AssignmentId
         ) AS ByPart2
    GROUP BY  PartNo, MFR, Description,TailNo, OverDuePlatform, DueNextPlatform, RequisitionNo, InLieu, ILQtyOnHand, RQtyOnHand
go

