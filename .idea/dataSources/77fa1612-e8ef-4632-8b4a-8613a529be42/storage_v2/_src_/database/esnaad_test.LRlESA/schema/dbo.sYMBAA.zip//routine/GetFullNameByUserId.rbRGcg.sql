CREATE FUNCTION [dbo].[GetFullNameByUserId](@userId nvarchar(255))
    RETURNS nvarchar(MAX)
AS
BEGIN
    DECLARE @result nvarchar(MAX);

    select @result = upper(F_NAME_ + coalesce(' ' + M_NAME_, '') + coalesce(' ' + L_NAME_, ''))
    from ADM_TRN_USER_PROFILES
    where USER_ID_ = @userId

    RETURN @result
END;
go

