CREATE FUNCTION [dbo].[GetAchievedRequirementHoursInMinutes]
(
	@requirementSnapshotId uniqueidentifier,
	@jacMonthReturnDetailId uniqueidentifier
)
RETURNS int
AS
BEGIN
	DECLARE @Minutes int
	SELECT @Minutes = MINUTES_ FROM OPS_TRN_MOR_JAC_MONTHLY_RETURN_DETAIL_REQUIREMENT WHERE REQUIREMENT_SNAPSHOT_ID = @requirementSnapshotId AND MOR_DETAIL_ID = @jacMonthReturnDetailId
	RETURN @Minutes 
END
go

