create function [dbo].[D16_GetDueStatus](@assignmentId uniqueidentifier,
                                         @currentHours real,
                                         @currentLandings bigint,
                                         @currentCycles bigint,
                                         @currentDate datetime)

    returns int
as
begin
    DECLARE @dueStatus int;

select @dueStatus =
     case
         when PartType = 'RC' and ReplaceDue = 2 then 2
         when PartType = 'TC' and ReplaceDue = 2 or OverhaulDue = 2 then 2
         when PartType = 'RC' and ReplaceDue = 1 then 1
         when PartType = 'TC' and ReplaceDue = 1 or OverhaulDue = 1 then 1
         else 0 end
from (
         select
             dbo.D16_GetReplaceDueStatus(@assignmentId, @currentHours, @currentLandings, @currentCycles, @currentDate)  as ReplaceDue
           , dbo.D16_GetOverhaulDueStatus(@assignmentId, @currentHours, @currentLandings, @currentCycles, @currentDate) as OverhaulDue
           , m.PART_TYPE_                                                                                               as PartType
         from MNT_TRN_D16_ASSIGNED_COMPONENT a
         join MNT_MST_D16_MASTER_COMPONENT m on m.ID_ = a.MASTER_COMP_ID_
         where a.ID_ = @assignmentId) root

    return @dueStatus
end
go

