
CREATE PROCEDURE DM_US20180_MNT_VALIDATED_DFR_DEFECT_ITEM_CONDITION_MIGRATION
AS
BEGIN

	SET NOCOUNT ON;
	SET DATEFORMAT DMY;

	DECLARE @errormsg nvarchar(max);

	-- Esnaad vars
	declare @wfinstid uniqueidentifier 
	DECLARE @defectId UNIQUEIDENTIFIER
	DECLARE @defectNo nvarchar(255);
	DECLARE @partNo nvarchar(255);
	DECLARE @cageCode nvarchar(255);
	DECLARE @serialNoOrBatchNo nvarchar(255);
	DECLARE @unittId BIGINT;
	DECLARE @partTagcolor BIGINT;
	DECLARE @toTagcolorInDrm BIGINT;
	DECLARE @orgBuid BIGINT;
	DECLARE @agL2Id BIGINT;
	DECLARE @wfState nvarchar(255);

	DECLARE @tagcolorIdDefectReportCreated BIGINT = 10;


	DECLARE copierCursor CURSOR FOR
	SELECT 
		 dfr.ID_
		,wf.WF_STATE_
		,DEFECT_NO_
		,ORG_BU_ID_
		,AGL2_ID_
		,PART_NO_
		,CAGE_CODE_
		,SERIAL_BATCH_NO_
		,dfr.UNIT_ID_
		,PART_TAG_COLOR_ID_
		,TO_TAG_COLOR_ID_
	FROM
		MNT_TRN_DFR_DEFECT_REPORT dfr  join 
		WF_TRN_INSTANCE wf on wf.ID_ = dfr.WF_ID and wf.WF_STATE_ in ('Validated') join
		ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.UNIT_ID_ = dfr.UNIT_ID_ and imv.BU_ID_ = dfr.ORG_BU_ID_ and imv.OWNED_L2_ID_ = dfr.AGL2_ID_ 
	WHERE 
		DFR.UNIT_ID_ is not null 
		and imv.TC_ID_ not in ( 8,9,10,11)
		and imv.TC_ID_ = dfr.TO_TAG_COLOR_ID_
		and US20180_DFR_TC_ is null
	FOR UPDATE OF US20180_DFR_TC_


	OPEN copierCursor
	
	FETCH NEXT FROM copierCursor
	INTO
		 @defectId
		,@wfState
		,@defectNo
		,@orgBuid
		,@agL2Id
		,@partNo
		,@cageCode
		,@serialNoOrBatchNo
		,@unittId
		,@partTagcolor
		,@toTagcolorInDrm
	;
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
	
		
			BEGIN TRY
				BEGIN	
					print @defectNo
					if(@wfState = 'Validated')
					begin
						print 'in Validated'
						EXEC DM_US20180_UPDATE_CONDITION @buid = @orgBuid, @esnaad_unit_id_ = @unittId, @tagcolor = @toTagcolorInDrm, @agl2 = @agL2Id, @createduserid = 2, @changetotagcolor = @tagcolorIdDefectReportCreated;
					end
					
					UPDATE MNT_TRN_DFR_DEFECT_REPORT SET US20180_DFR_TC_ = '10'
					WHERE CURRENT OF copierCursor

				END
			END TRY
			BEGIN CATCH
				SELECT @errormsg = ERROR_MESSAGE();
				print 'Error: ' + @errormsg + ' in ' + @defectNo

				
				FETCH NEXT FROM copierCursor
				INTO
					 @defectId
					,@wfState
					,@defectNo
					,@orgBuid
					,@agL2Id
					,@partNo
					,@cageCode
					,@serialNoOrBatchNo
					,@unittId
					,@partTagcolor
					,@toTagcolorInDrm
				;			
			END CATCH


		FETCH NEXT FROM copierCursor
		INTO
			 @defectId
			,@wfState
			,@defectNo
			,@orgBuid
			,@agL2Id
			,@partNo
			,@cageCode
			,@serialNoOrBatchNo
			,@unittId
			,@partTagcolor
			,@toTagcolorInDrm
				;			
	
	END
	
	CLOSE copierCursor
	DEALLOCATE copierCursor


	print '=> end of exec'
END



go

