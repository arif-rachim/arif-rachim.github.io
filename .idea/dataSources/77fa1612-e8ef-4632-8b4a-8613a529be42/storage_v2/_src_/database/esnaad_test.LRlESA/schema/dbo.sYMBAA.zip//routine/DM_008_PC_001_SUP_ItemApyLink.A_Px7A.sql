
CREATE PROCEDURE DM_008_PC_001_SUP_ItemApyLink
	@InputCommand VARCHAR(10)
AS
BEGIN
	-- ######################################## Time logging : start block #############################################################
	DECLARE @scriptName VARCHAR(MAX) = OBJECT_NAME(@@PROCID);
	DECLARE @startTime DATETIME = GETDATE();
	DECLARE @logRecordID BIGINT;
	EXEC DM_003_PUTIL_001_StartLog  @scriptName = @scriptName, @logRecordID_OUT = @logRecordID OUTPUT, @InputCommand = @InputCommand
	-- #################################################################################################################################

	SET NOCOUNT ON;
	SET DATEFORMAT DMY;
	
	-- ####################################### Get Data migration user info #######################################
	DECLARE	@DM_USR_FULLNAME varchar(100), @DM_USR_PID varchar(100), @DM_USR_USER_ID varchar(100);
	DECLARE @hostName VARCHAR(MAX) = HOST_NAME();
	EXEC DM_003_PUTIL_004_GetDataMigrationUserRec @DM_USR_FULLNAME OUTPUT, @DM_USR_PID OUTPUT, @DM_USR_USER_ID OUTPUT
	-- ############################################################################################################

--	DECLARE @successRecCount  BIGINT = 0;
	DECLARE @insertedRecCount BIGINT = 0;
	DECLARE @skippedRecCount  BIGINT = 0; 
	DECLARE @errorCount       INT = 0;
	DECLARE @ErrorMessage     VARCHAR(MAX);
	DECLARE @esnaadStatus     NVARCHAR(1);
	DECLARE @duplicateError   VARCHAR(MAX) = 'Duplicate record';  --Error message is used elsewhere in the code. hence declaring as variable
	
	DECLARE @esnaad_item_id_  BIGINT;
	DECLARE @esnaad_l2_id_    BIGINT;
		
	DECLARE @commandId BIGINT = (SELECT COMMAND.ID_ FROM ADM_MST_RESTRICTIONS COMMAND WHERE COMMAND.CODE_ = @InputCommand AND TYPE_NAME_ = 'Command');	
	DECLARE @nextSequence NVARCHAR(20);
	DECLARE @esnaad_transfer_data_key UNIQUEIDENTIFIER;
	DECLARE @esnaad_transfer_data_item_key UNIQUEIDENTIFIER;
	DECLARE @esnaad_key     UNIQUEIDENTIFIER;
	
	DECLARE copierCursor CURSOR FOR
	SELECT
		 AADMIS.ESNAAD_ITEM_ID_
		,AADMIS.ESNAAD_L2_ID_
	FROM AADMIS_TBL__SUP_ItemApyLink AADMIS
	WHERE AADMIS.ESNAAD_FORCE = @InputCommand
		AND AADMIS.ESNAAD_STATUS IS NULL
	FOR UPDATE OF ESNAAD_STATUS, ESNAAD_ERROR, ESNAAD_MODIFIED_TIME
	   

	DECLARE errorReportingCursor CURSOR FOR
	SELECT ESNAAD_STATUS AS esnaadStatus,
	       ESNAAD_ERROR AS errorMessage,
	       COUNT(1) AS errorCount
	  FROM AADMIS_TBL__SUP_ItemApyLink
	 WHERE ESNAAD_FORCE = @InputCommand
	 GROUP BY ESNAAD_STATUS, ESNAAD_ERROR;


	IF @InputCommand = 'NAG'
	BEGIN
		UPDATE AADMIS_TBL__SUP_ItemApyLink SET ESNAAD_MODIFIED_TIME = GETDATE(), ESNAAD_FORCE = 'NAG' WHERE [Force] = 'NAVY' AND ISNULL(ESNAAD_FORCE, 'NAVY') <> 'NAG'
	END
	ELSE IF @InputCommand = 'G18'
	BEGIN
		UPDATE AADMIS_TBL__SUP_ItemApyLink SET ESNAAD_MODIFIED_TIME = GETDATE(), ESNAAD_FORCE = 'G18' WHERE [Force] = 'SOC' AND ISNULL(ESNAAD_FORCE, 'SOC') <> '!@#$'
		UPDATE AADMIS_TBL__SUP_ItemApyLink SET ESNAAD_MODIFIED_TIME = GETDATE(), ESNAAD_FORCE = 'G18' WHERE [Force] = 'G18' AND ISNULL(ESNAAD_FORCE, 'G18') <> '!@#$'
	END
	ELSE IF @InputCommand = 'SARSQ'
	BEGIN
		UPDATE AADMIS_TBL__SUP_ItemApyLink SET ESNAAD_MODIFIED_TIME = GETDATE(), ESNAAD_FORCE = 'SARSQ' WHERE [Force] = 'JSR' AND ISNULL(ESNAAD_FORCE, 'JSR') <> 'SARSQ'
	END
	ELSE IF @InputCommand = 'FWG'
	BEGIN
		UPDATE AADMIS_TBL__SUP_ItemApyLink SET ESNAAD_FORCE = 'FWG' WHERE [Force] = 'FWG' AND ISNULL(ESNAAD_FORCE, 'FWG') <> '~!@#$%^'
	END

	PRINT 'Updated Force for '+ CAST(@@ROWCOUNT AS VARCHAR)+' records';

	--Clear existing errors
	UPDATE AADMIS_TBL__SUP_ItemApyLink 
	SET
	   ESNAAD_STATUS = NULL,
	   ESNAAD_ERROR = NULL,
	   ESNAAD_MODIFIED_TIME = NULL
	 WHERE ESNAAD_STATUS = 'E'
	   AND ESNAAD_FORCE = @InputCommand
	PRINT 'Cleared errors in AADMIS_TBL__SUP_ItemApyLink for '+ CAST(@@ROWCOUNT AS VARCHAR)+' records';


	-- Moved this block up as the error was incorrectly showing as 1 record missing Part No. and remaing all as 'Duplicate'
	-- 09-SEP-2018
	-- Flag missing PartNo.
	UPDATE AADMIS_TBL__SUP_ItemApyLink
	SET
		ESNAAD_STATUS = 'E',
		ESNAAD_ERROR = 'Part No. missing',
		ESNAAD_MODIFIED_TIME = GETDATE()
	 WHERE
		 ESNAAD_FORCE = @InputCommand
		 AND ESNAAD_STATUS IS NULL
		 AND ([part number] IS NULL OR LTRIM(RTRIM([part number])) = '')
		 ;

	--Flag duplicates
	WITH CTE AS (
	SELECT [part number]
	      ,[MFR code]
	      ,Applicability
		  ,ESNAAD_STATUS
		  ,ESNAAD_ERROR
		  ,RN = ROW_NUMBER()OVER(PARTITION BY [part number], [MFR code], Applicability 
		                             ORDER BY [part number], [MFR code], Applicability )
	  FROM AADMIS_TBL__SUP_ItemApyLink
	 WHERE ESNAAD_FORCE = @InputCommand
	 )
	UPDATE CTE SET ESNAAD_STATUS = 'E', ESNAAD_ERROR = @duplicateError
	WHERE RN > 1
	AND ESNAAD_STATUS IS NULL;
	
	UPDATE AADMIS_TBL__SUP_ItemApyLink
	SET 
		ESNAAD_ITEM_ID_ = 
		(
			SELECT ITEMS.ID_ 
			FROM ADM_MST_ITEMS ITEMS 
			   JOIN ADM_MST_MANUFACTURES MNF ON ITEMS.MNF_ID = MNF.ID_ 
											AND ITEMS.PART_NO_ = LTRIM(RTRIM(UPPER(AADMIS.[part number]))) 
											AND MNF.CAGE_CODE_ = LTRIM(RTRIM(UPPER(AADMIS.[MFR code])))
		)
		,ESNAAD_L2_ID_ = 
		(
			SELECT AG.ID_
			FROM DM_APPLICABILITY_AGL2_MAP MAP
			INNER JOIN ADM_TRN_ASSOC_GROUPS AG ON MAP.ESNAAD_AGL2_CODE_ = AG.CODE_ AND AG.LEVEL_ = 'Level2'
			WHERE MAP.AADMIS_APPLICABILITY_ = (SUBSTRING(LTRIM(RTRIM(UPPER(AADMIS.Applicability))), CHARINDEX('-', LTRIM(RTRIM(UPPER(AADMIS.Applicability)))) + 1, LEN(LTRIM(RTRIM(UPPER(AADMIS.Applicability)))))))
		,ESNAAD_MODIFIED_TIME = GETDATE()
	FROM AADMIS_TBL__SUP_ItemApyLink AADMIS
	WHERE AADMIS.ESNAAD_STATUS IS NULL
		AND AADMIS.ESNAAD_FORCE = @InputCommand


	UPDATE AADMIS_TBL__SUP_ItemApyLink
	SET ESNAAD_STATUS = 'E'
		,ESNAAD_ERROR = CASE WHEN ESNAAD_ITEM_ID_ IS NULL THEN 'Could not derive part' ELSE 'Could not derive AGL2' END
		,ESNAAD_MODIFIED_TIME = GETDATE()
	 WHERE ESNAAD_STATUS IS NULL
	   AND ESNAAD_FORCE = @InputCommand
	   AND (ESNAAD_ITEM_ID_ IS NULL OR ESNAAD_L2_ID_ IS NULL)
	   
	   
	UPDATE AADMIS_TBL__SUP_ItemApyLink
	   SET ESNAAD_STATUS = 'E'
	      ,ESNAAD_ERROR = 'Record already exists'
	      ,ESNAAD_MODIFIED_TIME = GETDATE()
	  FROM AADMIS_TBL__SUP_ItemApyLink AADMIS
	 WHERE AADMIS.ESNAAD_STATUS IS NULL
	   AND AADMIS.ESNAAD_FORCE = @InputCommand
	   AND EXISTS (
	       SELECT 1
	         FROM ADM_XRF_ITEM_ASSOCS XRF
	        WHERE XRF.ITEM_ID_ = AADMIS.ESNAAD_ITEM_ID_
	          AND XRF.L2_ID_ = AADMIS.ESNAAD_L2_ID_
	       )
	

	OPEN copierCursor;
	FETCH NEXT FROM copierCursor
	INTO @esnaad_item_id_
	    ,@esnaad_l2_id_
	    
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    BEGIN TRY
			INSERT INTO ADM_XRF_ITEM_ASSOCS (
				L2_ID_
			   ,ITEM_ID_
			)
			VALUES (
				@esnaad_l2_id_
			   ,@esnaad_item_id_
			)
			;	
			
			SET @insertedRecCount = @insertedRecCount + 1;
			UPDATE AADMIS_TBL__SUP_ItemApyLink SET ESNAAD_STATUS = 'S', ESNAAD_MODIFIED_TIME = GETDATE() WHERE CURRENT OF copierCursor
			
	    END TRY
	    BEGIN CATCH
			SET @ErrorMessage = ERROR_MESSAGE()
			UPDATE AADMIS_TBL__SUP_ItemApyLink 
			SET 
				ESNAAD_STATUS = 'E',
			    ESNAAD_ERROR = @ErrorMessage,
			    ESNAAD_MODIFIED_TIME = GETDATE()
			 WHERE CURRENT OF copierCursor
			 
			FETCH NEXT FROM copierCursor 
			INTO @esnaad_item_id_
	            ,@esnaad_l2_id_
 			CONTINUE
	    END CATCH
	    	    
		FETCH NEXT FROM copierCursor
		INTO @esnaad_item_id_
	        ,@esnaad_l2_id_
	END
	
	CLOSE copierCursor;
	DEALLOCATE copierCursor;
	

    PRINT '------------------------------------'
    PRINT '           Error report '
    PRINT '------------------------------------'
    SET @skippedRecCount = 0;
	OPEN errorReportingCursor;
	FETCH NEXT FROM errorReportingCursor
	INTO   @esnaadStatus
	      ,@ErrorMessage
	      ,@errorCount
	WHILE @@FETCH_STATUS = 0
	BEGIN
		/*
	    IF @esnaadStatus = 'S'
			SET @successRecCount = @errorCount;
		ELSE
		*/
	    IF @esnaadStatus = 'E'
		BEGIN
			PRINT @ErrorMessage + ': ' + CAST(@errorCount AS VARCHAR)
			SET @skippedRecCount = @skippedRecCount + @errorCount
		END
		FETCH NEXT FROM errorReportingCursor
		INTO   @esnaadStatus
			  ,@ErrorMessage
			  ,@errorCount
	END
	CLOSE errorReportingCursor;
	DEALLOCATE errorReportingCursor;
	
	-- Show Record count
	EXEC DM_003_PUTIL_003_ShowRecCount  @insertedRecCount = @insertedRecCount, @skippedRecCount = @skippedRecCount	
	      
	-- ############################################### Time logging : stop block ###############################################	
	EXEC DM_003_PUTIL_002_StopLog  @logRecordID = @logRecordID, @scriptName = @scriptName, @startTime = @startTime, @isDisplayOn = 1;
	-- #########################################################################################################################
END
go

