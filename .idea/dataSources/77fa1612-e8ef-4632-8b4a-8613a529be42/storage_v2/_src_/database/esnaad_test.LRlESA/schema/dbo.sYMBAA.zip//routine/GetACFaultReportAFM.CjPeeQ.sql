CREATE PROC [dbo].[GetACFaultReportAFM]
	@TailIds	varchar(max),
	@IncludeCloseFault bit = 0,
	@OrderBy varchar(max) = 'TAILS.T_NUM_, FAULTUNIT.FAULT_INFO_DATE_'
AS

declare @sqlStr nvarchar(max) = N'';

set @sqlStr = '
				SELECT 
					TAILS.T_NUM_				As TailNo,
					PLATFORMS.CODE_				As ACType,
					BATT.CODE_					As Battalion,
					FAULTUNIT.FAULT_NO_			As FaultNo,
					FAULTUNIT.FAULT_INFO_DATE_  As FaultDate,
					FAULTUNIT.FAULT_INFO_STS_ID As FaultStatus,
					dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_SYS_ID, ''code'') As FaultSystem,
					dbo.ReturnPID(FAULTUNIT.FAULT_INFO_USR_ID) As FaultPID,
					FAULTUNIT.FAULT_INFO_REMARKS_ As FaultRemarks,
					FAULTUNIT.FAULT_INFO_AIRCRAFT_HR_ As FaultACHours,
					dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_DISC_ID, ''code'') As WhenDisc,
					dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_REC_ID, ''code'') As HowRec,
					dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_MEFF_ID, ''code'') As MalEff,
					dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_FG_ID, ''code'') As FaultFGC,
					dbo.ReturnPID(FAULTUNIT.FAULT_TI_VAL_USR_ID) As TIPID,
					FAULTUNIT.FAULT_TI_VAL_VAL_	As TIManHours,			
					WO.WO_NO_					As WorkOrderNo,
					CORRECTS.ID_				As CorrectingInfoId,
					CORRECTS.DATE_				As CorrectingDate,
					CORRECTS.AIRCRAFT_HR_		As CorrectingACHours,
					CORRECTS.AIRCRAFT_ROUNDS_	As CorrectingRounds,
					dbo.ReturnDisplyStringForSimpleRef(CORRECTS.ACT_ID, ''code'') As CorectingActionCode,
					dbo.ReturnDisplyStringForSimpleRef(CORRECTS.FG_ID, ''code'') As CorectingFGC,
					CORRECTS.ACT_DESC_			As CorrectingActionRemarks
				FROM	
					ADM_MST_TAILS TAILS INNER JOIN ADM_MST_RESTRICTIONS BATT		ON TAILS.BATLN_ID = BATT.ID_ 
					INNER JOIN ADM_MST_UNITS UNITS				ON TAILS.UNIT_ID = UNITS.ID_
					INNER JOIN ADM_MST_ITEMS ITEMS				ON UNITS.ITEM_ID = ITEMS.ID_
					INNER JOIN ADM_MST_PLATFORMS PLATFORMS		ON ITEMS.ID_ = PLATFORMS.ID_
					INNER JOIN MNT_TRN_FAULT_UNITS FAULTUNIT	ON UNITS.ID_ = 	FAULTUNIT.UNIT_ID
					LEFT JOIN MNT_TRN_FAULT_CORRECTS CORRECTS	ON FAULTUNIT.ID_ = CORRECTS.FAULT_UNIT_ID
					LEFT JOIN MNT_TRN_WOTS_WORK_ORDER WO				ON FAULTUNIT.FAULT_NO_ = WO.REF_NO_
					LEFT JOIN ADM_MST_SIMPLE_REF AS sts ON sts.ID_ = FAULTUNIT.FAULT_INFO_STS_ID
				WHERE
					TAILS.UNIT_ID IN (SELECT Item from dbo.SplitInts(' + @TailIds + ', '','')	)
					AND (
						(' + cast(@IncludeCloseFault as char(1)) + ' = 1 and (FAULTUNIT.CLOSE_DATE_ IS NULL OR FAULTUNIT.CLOSE_DATE_ IS NOT NULL)) 
						or 
						(' + cast(@IncludeCloseFault as char(1)) + '  = 0 and FAULTUNIT.CLOSE_DATE_ IS NULL)
					)
				ORDER BY 
					' + @OrderBy
				;

exec sp_executesql @sqlStr

SELECT
	FLT_CORR_ID As CorrectingInfoId, dbo.ReturnPID(USR_ID) As PID, dbo.ReturnDisplyStringForSimpleRef(CAT_ID, 'code') As Category, SUM(MNT_MAIN_HRS) As ManHours
FROM
	ADM_MST_TAILS TAILS	INNER JOIN ADM_MST_UNITS UNITS							ON TAILS.UNIT_ID = UNITS.ID_
						INNER JOIN MNT_TRN_FAULT_UNITS FAULTUNIT				ON UNITS.ID_ = 	FAULTUNIT.UNIT_ID
						INNER JOIN MNT_TRN_FAULT_CORRECTS CORRECTS				ON FAULTUNIT.ID_ = CORRECTS.FAULT_UNIT_ID
						INNER JOIN MNT_TRN_FAULT_CORRECTING_ITEMS CORRECTITEMS	ON CORRECTS.ID_	= CORRECTITEMS.FLT_CORR_ID 
WHERE
	TAILS.UNIT_ID IN (SELECT Item from dbo.SplitInts(@TailIds, ',')	)
	AND (
		(@IncludeCloseFault = 1 and (FAULTUNIT.CLOSE_DATE_ IS NULL OR FAULTUNIT.CLOSE_DATE_ IS NOT NULL)) 
		or 
		(@IncludeCloseFault = 0 and FAULTUNIT.CLOSE_DATE_ IS NULL)
	)
GROUP BY 
	FLT_CORR_ID, USR_ID, CAT_ID
ORDER BY 
	FLT_CORR_ID  
	
	
--Getting data to set heading disregarding above query returns data or not
SELECT * FROM dbo.ReturnTailHeader(@TailIds)
go

