
-- =============================================
-- Author:		gal2723
-- Create date: 02-JUN-2016
-- Description:	Returns Tail details 
-- =============================================

--
-- Ex: 
-- SELECT * FROM GetTailInfo('NAG', NULL)
-- SELECT * FROM GetTailInfo('NAG', '2166')

CREATE FUNCTION GetTailInfo(@commandCode VARCHAR(MAX), @tailNum VARCHAR(MAX))
RETURNS TABLE
AS
RETURN
(
	SELECT
		T.T_NUM_,
		CMD.CODE_ AS Command,
		BAT.CODE_ AS Battalion,
		P.CODE_ Platform, 
		CASE WHEN END_DATE_ = '9999-12-31' THEN 'Active' ELSE 'Inactive' END AS TailStatus,
		T.BEGIN_DATE_,
		T.END_DATE_
	FROM ADM_MST_TAILS T
	JOIN ADM_MST_UNITS U
		ON T.UNIT_ID = U.ID_
	JOIN ADM_MST_ITEMS I
		ON U.ITEM_ID = I.ID_
	JOIN ADM_MST_PLATFORMS P
		ON I.ID_ = P.ID_
	JOIN ADM_MST_RESTRICTIONS BAT
		ON T.BATLN_ID = BAT.ID_ AND BAT.TYPE_NAME_ = 'Battalion'
	JOIN ADM_MST_RESTRICTIONS CMD
		ON BAT.PRNT_ID = CMD.ID_ AND CMD.TYPE_NAME_ = 'Command'
	WHERE
		CMD.CODE_ = @commandCode
		
		AND
		
		@tailNum IS NULL
		OR
		(
			@tailNum IS NOT NULL
			AND T.T_NUM_ = @tailNum
		)
)
go

