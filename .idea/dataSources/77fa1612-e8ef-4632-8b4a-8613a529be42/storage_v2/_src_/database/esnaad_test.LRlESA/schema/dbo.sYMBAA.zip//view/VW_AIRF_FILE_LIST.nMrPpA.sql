CREATE VIEW VW_AIRF_FILE_LIST
AS
SELECT        ff.ID_ AS Id, ff.TITLE_ AS FileTitle, '' AS PhysicalFileName, ff.REMARKS_ AS Description, ff.CREATED_ON_ AS CreatedDate, ff.PUBLISHED_DATE_ AS PublishedDate, ff.EXPIRY_DATE_ AS ExpiryDate, fs.STATUS_ AS FileStatus, 
                         ff.CREATED_BY_ AS CreatedBy, ff.FULL_NAME_CREATED_BY_ AS FullNameCreatedBy, ff.CREATED_ON_ AS CreatedOn, ff.MOD_BY_ AS ModifiedBy, ff.FULL_NAME_MOD_BY_ AS FullNameModifiedBy, 
                         ff.MOD_ON_ AS ModifiedOn,
                             (SELECT        CAST(COUNT(F.ID_) AS VARCHAR) AS Expr1
                               FROM            dbo.OPS_TRN_FCIF_FILES AS F INNER JOIN
                                                         dbo.OPS_TRN_FCIF_CREW_FILE AS FC ON F.ID_ = FC.FCIF_FILE_ID INNER JOIN
                                                         dbo.OPS_MST_FLIGHT_CREWS AS CR ON CR.ID_ = FC.CREW_ID
                               WHERE        (F.ID_ = ff.ID_) AND (CR.PRI_PLTF_ID_ IN
                                                             (SELECT        PLATFORM_ID_ AS PlatformId
                                                               FROM            dbo.OPS_TRN_FCIF_PLATFORMS
                                                               WHERE        (FCIF_FILE_ID_ = ff.ID_))) AND (CR.QUALF_ID IN
                                                             (SELECT        PRO_QUALIFICATION_ID_ AS ProQualId
                                                               FROM            dbo.OPS_TRN_FCIF_PROF_QUALIFICATIONS
                                                               WHERE        (FCIF_FILE_ID_ = ff.ID_)))) + ' of ' +
                             (SELECT        CAST(COUNT(crw.ID_) AS VARCHAR) AS Expr1
                               FROM            dbo.OPS_MST_FLIGHT_CREWS AS crw INNER JOIN
                                                         dbo.ADM_MST_RESTRICTIONS AS cmp ON crw.COMPANY_ID = cmp.ID_ INNER JOIN
                                                         dbo.ADM_MST_RESTRICTIONS AS bat ON bat.ID_ = cmp.PRNT_ID
                               WHERE        (bat.PRNT_ID = ff.CMD_ID) AND (crw.PRI_PLTF_ID_ IN
                                                             (SELECT        PLATFORM_ID_ AS PlatformId
                                                               FROM            dbo.OPS_TRN_FCIF_PLATFORMS AS OPS_TRN_FCIF_PLATFORMS_1
                                                               WHERE        (FCIF_FILE_ID_ = ff.ID_))) AND (crw.QUALF_ID IN
                                                             (SELECT        PRO_QUALIFICATION_ID_ AS ProQualId
                                                               FROM            dbo.OPS_TRN_FCIF_PROF_QUALIFICATIONS AS OPS_TRN_FCIF_PROF_QUALIFICATIONS_1
                                                               WHERE        (FCIF_FILE_ID_ = ff.ID_)))) AS ReadingCompletion, ff.CMD_ID
FROM            dbo.OPS_TRN_FCIF_FILES AS ff INNER JOIN
                             (SELECT        ID_, CASE WHEN IS_OBSOLETE_ = 1 THEN 'Obsolete' ELSE STATUS_ END AS STATUS_, UPPER(REPLACE(CONVERT(varchar, CREATED_ON_, 106), ' ', '-')) AS CreatedDate, UPPER(REPLACE(CONVERT(varchar, 
                                                         PUBLISHED_DATE_, 106), ' ', '-')) AS PublishedDate
                               FROM            dbo.OPS_TRN_FCIF_FILES) AS fs ON fs.ID_ = ff.ID_
go

