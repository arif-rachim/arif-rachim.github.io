
-- ============================================================
-- Created date	: 28-Sep-2016
-- Description	: Add all roles to an ADMIN user

-- Ex:
-- EXEC UTIL_Add_All_RolesTo_AdminUser @adminUserIdToAssign = 'GAL99999'
-- ============================================================

CREATE PROCEDURE UTIL_Add_All_RolesTo_AdminUser
	@adminUserIdToAssign VARCHAR(255)
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @adminUser_UserProfileId VARCHAR(255);
	DECLARE @adminUser_UserFullName VARCHAR(255);
	DECLARE @secRoledId_Each VARCHAR(255);
	DECLARE @secRoledName_Each VARCHAR(255);
	DECLARE @assignmentType VARCHAR(255) = 'Admin';
	
	DECLARE @createdByUserId VARCHAR(255) = 'SYSTEM';
	DECLARE @pidCreatedBy VARCHAR(255) = 'SYSTEM';
	DECLARE @fullNameCreatedBy VARCHAR(255) = 'SYSTEM';
	DECLARE @actionDateTime DATETIME = GETDATE();
	DECLARE @hostname VARCHAR(255) = HOST_NAME();

	DECLARE @HST_Action VARCHAR(255) = 'Assign Admin'
	DECLARE @HST_actionByUserId VARCHAR(255) = @createdByUserId;
	DECLARE @HST_actionByFullName VARCHAR(255) = @fullNameCreatedBy;

	DECLARE @ErrorMessage VARCHAR(MAX);
	DECLARE @scriptName VARCHAR(MAX) = OBJECT_NAME(@@PROCID);
	
	DECLARE @recsAdded INT = 0;

	PRINT ''
	PRINT '========================================================================================================================================'
	PRINT @scriptName + ' [Host: ' + HOST_NAME() + '] [DB server: ' + CAST(SERVERPROPERTY ('ServerName') AS VARCHAR(MAX)) + '] [DB: ' + DB_NAME() +'] : Started >>>>'
	PRINT ''

	DECLARE @today date = getdate();	
	PRINT '[Date: ' + CAST(YEAR(@today) AS VARCHAR) + '-' + DATENAME (MONTH, (@today)) + '-' + CAST(DAY(@today) AS VARCHAR) + ']'
	PRINT ''

	PRINT 'Giving full access to admin user: ' + @adminUserIdToAssign;
	PRINT ''
	
	SELECT @adminUser_UserProfileId = ID_, @adminUser_UserFullName = F_NAME_ + ' ' + L_NAME_
	FROM ADM_TRN_USER_PROFILES WHERE USER_ID_ = @adminUserIdToAssign;
	
	IF @adminUser_UserProfileId IS NULL
	BEGIN
		PRINT 'User ID does not exist: ' + @adminUserIdToAssign
		PRINT ''
		PRINT @scriptName + ': Ended <<<<<<<<<<<<<'
		PRINT '========================================================================================================================================'
		RETURN;
	END

	DECLARE copierCursor CURSOR FOR
	SELECT ID_, NAME_
	FROM ADM_TRN_SEC_ROLE;
	
	OPEN copierCursor;
	
	FETCH NEXT FROM copierCursor
	INTO @secRoledId_Each, @secRoledName_Each;
	
	BEGIN TRAN;
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT EXISTS
		(
			SELECT 1 
			FROM ADM_TRN_SEC_ROLE_ASSIGNMENT
			WHERE ASSIGNMENT_TYPE_ = @assignmentType
			AND USR_PRF_ID = @adminUser_UserProfileId
			AND ROLE_ID = @secRoledId_Each
		)
		BEGIN
			BEGIN TRY
				-- Write to SecRole assignment		
				INSERT INTO ADM_TRN_SEC_ROLE_ASSIGNMENT
				(
					 ID_
					,VERSION_
					,ASSIGNMENT_TYPE_
					,USR_PRF_ID
					,ROLE_ID
					
					,CREATED_BY_
					,PID_CREATED_BY_
					,FULL_NAME_CREATED_BY_
					,CREATED_ON_
					,TERM_
				)
				VALUES 
				(
					 NEWID() 
					,1
					,@assignmentType
					,@adminUser_UserProfileId 
					,@secRoledId_Each
					
					,@createdByUserId
					,@pidCreatedBy
					,@fullNameCreatedBy
					,@actionDateTime
					
					,@hostname
				);
				
				PRINT 'Added role: ' + @secRoledName_Each;
				
				SET @recsAdded = @recsAdded + 1;
				
				-- Write to history
				INSERT INTO ADM_HST_SEC_ROLE
				(
					 ID_
					,VERSION_
					,DATE_TIME_
					,USER_ID_
					,FULL_NAME_
					,AREA_
					,ACTION_
					,MODIFICAITION_

					,CREATED_BY_
					,PID_CREATED_BY_
					,FULL_NAME_CREATED_BY_
					,CREATED_ON_

					,TERM_
				) 
				VALUES 
				(
					 NEWID()				-- ID_
					,1						-- VERSION_
					,@actionDateTime		-- DATE_TIME_
					,@HST_actionByUserId	-- USER_ID_
					,@HST_actionByFullName	-- FULL_NAME_
					,@assignmentType		-- AREA_
					,@HST_Action			-- ACTION_
					,'Assign ' + @adminUserIdToAssign + ' - ' + @adminUser_UserFullName + ' for ' + @secRoledName_Each  -- MODIFICAITION_

					,@createdByUserId		-- CREATED_BY_
					,@pidCreatedBy			-- PID_CREATED_BY_
					,@fullNameCreatedBy		-- FULL_NAME_CREATED_BY_
					,@actionDateTime		-- CREATED_ON_
					
					,@hostname				-- TERM_
				);

/*				
				-- Write to activity logs
				INSERT INTO ADM_TRN_ACTIVITY_LOGS
				(
					 ID_
					,VERSION_
					,ACTIVITY_
					,ADDRESS_
					,REQ_TIME_
					,REQUEST_
					,USER_ID_
				)
				VALUES
				(
					 NEWID()			-- ID_
					,1					-- VERSION_
					,NULL				-- ACTIVITY_
					,@hostname			-- ADDRESS_
					,GETDATE()			-- REQ_TIME_
					,NULL				-- REQUEST_
					,@createdByUserId	-- USER_ID_
				);
*/

			END TRY
			BEGIN CATCH
				SET @ErrorMessage = ERROR_MESSAGE();
				PRINT @ErrorMessage;
				
				ROLLBACK;
				
				BREAK;
				
			END CATCH			
		END
		
		FETCH NEXT FROM copierCursor
		INTO @secRoledId_Each, @secRoledName_Each;
		
	END
	
	CLOSE copierCursor;
	DEALLOCATE copierCursor;
	
	COMMIT;
	
	PRINT ''
	PRINT 'Total No. of Roles newly added to user: ' + CAST(@recsAdded AS VARCHAR(255));
	PRINT ''
	
	PRINT ''
	PRINT @scriptName + ': Ended <<<<<<<<<<<<<'
	PRINT '========================================================================================================================================'

END

go

