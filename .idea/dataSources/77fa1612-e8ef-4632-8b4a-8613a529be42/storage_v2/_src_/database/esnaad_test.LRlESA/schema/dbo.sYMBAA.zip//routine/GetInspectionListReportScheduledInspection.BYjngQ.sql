CREATE PROC [dbo].[GetInspectionListReportScheduledInspection]
  @TailIds      varchar(max),
  @SelectedInspIds  varchar(max)
AS
SELECT * FROM
(
  SELECT
    TAILS.T_NUM_        As TailNo,
    PLATFORMS.CODE_       As ACType,
    BATT.CODE_          As Battalion,
    INSPMASTER.INSP_NUMBER_   As InspNumber,
    INSPMASTER.INSP_NAME_   As InspName,
    INSPMASTER.INSP_REF_    As InspReference,
    INSPMASTER.INT_DUR_UNIT_  As Frequceny,
    INSPMASTER.INT_DUR_VALUE_ As Interval,
    REPLACE(CONVERT(NVARCHAR(11), CONVERT(NVARCHAR, INSPASSIGN.DUE_DATE_, 113)), ' ', '-') As NextDue,
    INSPMASTER.ORDER_ As SortOrder,
	ITEMS.NOMENCLATURE_ as Nomenclature
  FROM
    ADM_MST_TAILS TAILS INNER JOIN ADM_MST_RESTRICTIONS BATT          ON TAILS.BATLN_ID = BATT.ID_
              INNER JOIN ADM_MST_UNITS UNITS              ON TAILS.UNIT_ID = UNITS.ID_
              INNER JOIN ADM_MST_ITEMS ITEMS              ON UNITS.ITEM_ID = ITEMS.ID_
              INNER JOIN ADM_MST_PLATFORMS PLATFORMS          ON ITEMS.ID_ = PLATFORMS.ID_
              INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER    ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
              INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN  ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
  WHERE
      INSPMASTER.INT_DUR_UNIT_ IS NOT NULL
    AND (TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',')) OR @TailIds IS NULL)
    AND INSPASSIGN.ID_ IN (SELECT Item from dbo.SplitInts(@SelectedInspIds, ','))

  UNION ALL

  SELECT
    TAILS.T_NUM_        As TailNo,
    PLATFORMS.CODE_       As ACType,
    BATT.CODE_          As Battalion,
    INSPMASTER.INSP_NUMBER_   As InspNumber,
    INSPMASTER.INSP_NAME_   As InspName,
    INSPMASTER.INSP_REF_    As InspReference,
    'Hours'           As Frequceny,
    INSPMASTER.INT_DUR_HOURS_ As Interval,
    CONVERT(varchar,CONVERT(decimal(18, 2), INSPASSIGN.DUE_HOURS_))   As NextDue,
    INSPMASTER.ORDER_ As SortOrder,
	ITEMS.NOMENCLATURE_ as Nomenclature
  FROM
    ADM_MST_TAILS TAILS INNER JOIN ADM_MST_RESTRICTIONS BATT          ON TAILS.BATLN_ID = BATT.ID_
              INNER JOIN ADM_MST_UNITS UNITS              ON TAILS.UNIT_ID = UNITS.ID_
              INNER JOIN ADM_MST_ITEMS ITEMS              ON UNITS.ITEM_ID = ITEMS.ID_
              INNER JOIN ADM_MST_PLATFORMS PLATFORMS          ON ITEMS.ID_ = PLATFORMS.ID_
              INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER    ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
              INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN  ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
  WHERE
      INSPMASTER.INT_DUR_HOURS_ IS NOT NULL
  AND (TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ','))  OR @TailIds IS NULL )
  AND INSPASSIGN.ID_ IN (SELECT Item from dbo.SplitInts(@SelectedInspIds, ','))

  UNION ALL

  SELECT
              TAILS.T_NUM_                      As TailNo,
              PLATFORMS.CODE_                          As ACType,
              BATT.CODE_                               As Battalion,
              INSPMASTER.INSP_NUMBER_           As InspNumber,
              INSPMASTER.INSP_NAME_             As InspName,
              INSPMASTER.INSP_REF_       As InspReference,
              'Cycles'                                         As Frequceny,
              INSPMASTER.INT_DUR_CYCLES_  As Interval,
              CONVERT(varchar,CONVERT(decimal(10, 1), INSPASSIGN.DUE_CYCLES_))            As NextDue,
             INSPMASTER.ORDER_  As SortOrder,
	         ITEMS.NOMENCLATURE_ as Nomenclature
       FROM
              ADM_MST_TAILS TAILS INNER JOIN ADM_MST_RESTRICTIONS BATT                                 ON TAILS.BATLN_ID = BATT.ID_
                                                INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                                INNER JOIN ADM_MST_ITEMS ITEMS                                              ON UNITS.ITEM_ID = ITEMS.ID_
                                                INNER JOIN ADM_MST_PLATFORMS PLATFORMS                               ON ITEMS.ID_ = PLATFORMS.ID_
                                                INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER              ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
                                                INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN   ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
       WHERE
                     INSPMASTER.INT_DUR_CYCLES_ IS NOT NULL
      AND (TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',')) OR @TailIds IS NULL)
    AND INSPASSIGN.ID_ IN (SELECT Item from dbo.SplitInts(@SelectedInspIds, ','))

        UNION ALL

       SELECT
              TAILS.T_NUM_                      As TailNo,
              PLATFORMS.CODE_                          As ACType,
              BATT.CODE_                               As Battalion,
              INSPMASTER.INSP_NUMBER_           As InspNumber,
              INSPMASTER.INSP_NAME_             As InspName,
              INSPMASTER.INSP_REF_       As InspReference,
              'Landings'                                         As Frequceny,
              INSPMASTER.INT_DUR_LANDINGS_  As Interval,
              CONVERT(varchar,CONVERT(decimal(10, 1), INSPASSIGN.DUE_LANDINGS_))            As NextDue,
              INSPMASTER.ORDER_ As SortOrder,
			  ITEMS.NOMENCLATURE_ as Nomenclature
       FROM
              ADM_MST_TAILS TAILS INNER JOIN ADM_MST_RESTRICTIONS BATT                                 ON TAILS.BATLN_ID = BATT.ID_
                                                INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                                INNER JOIN ADM_MST_ITEMS ITEMS                                              ON UNITS.ITEM_ID = ITEMS.ID_
                                                INNER JOIN ADM_MST_PLATFORMS PLATFORMS                               ON ITEMS.ID_ = PLATFORMS.ID_
                                                INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER              ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
                                                INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN   ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
       WHERE
                     INSPMASTER.INT_DUR_LANDINGS_ IS NOT NULL
      AND (TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',')) OR @TailIds IS NULL)
    AND INSPASSIGN.ID_ IN (SELECT Item from dbo.SplitInts(@SelectedInspIds, ','))

	   UNION ALL

       SELECT
              TAILS.T_NUM_                      As TailNo,
              PLATFORMS.CODE_                          As ACType,
              BATT.CODE_                               As Battalion,
              INSPMASTER.INSP_NUMBER_           As InspNumber,
              INSPMASTER.INSP_NAME_             As InspName,
              INSPMASTER.INSP_REF_       As InspReference,
              'Equipment'                                         As Frequceny,
              INSPMASTER.INT_DUR_EQP_CYCLES_  As Interval,
              CONVERT(varchar,CONVERT(decimal(10, 1), INSPASSIGN.DUE_EQP_CYCLES_))            As NextDue,
              INSPMASTER.ORDER_ As SortOrder,
	          ITEMS.NOMENCLATURE_ as Nomenclature
       FROM
              ADM_MST_TAILS TAILS INNER JOIN ADM_MST_RESTRICTIONS BATT                                 ON TAILS.BATLN_ID = BATT.ID_
                                                INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                                INNER JOIN ADM_MST_ITEMS ITEMS                                              ON UNITS.ITEM_ID = ITEMS.ID_
                                                INNER JOIN ADM_MST_PLATFORMS PLATFORMS                               ON ITEMS.ID_ = PLATFORMS.ID_
                                                INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER              ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
                                                INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN   ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
       WHERE
                     INSPMASTER.INT_DUR_EQP_CYCLES_ IS NOT NULL
      AND (TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',')) OR @TailIds IS NULL)
    AND INSPASSIGN.ID_ IN (SELECT Item from dbo.SplitInts(@SelectedInspIds, ','))





  UNION ALL

  SELECT
    TAILS.T_NUM_        As TailNo,
    PLATFORMS.CODE_       As ACType,
    BATT.CODE_          As Battalion,
    INSPMASTER.INSP_NUMBER_   As InspNumber,
    INSPMASTER.INSP_NAME_   As InspName,
    INSPMASTER.INSP_REF_    As InspReference,
    CASE INT_OTHER_
      WHEN 'BeforeFlight' THEN 'BEFORE FLIGHT'
      WHEN 'AfterFlight' THEN 'AFTER FLIGHT'
      WHEN 'BeforeEveryFlight' THEN 'BEFORE EVERY FLIGHT'
      WHEN 'AfterEveryFlight' THEN 'AFTER EVERY FLIGHT'
    END             As Frequceny,
    NULL            As Interval,
    CONVERT(varchar,INSPASSIGN.DUE_HOURS_)    As NextDue,
    INSPMASTER.ORDER_ As SortOrder,
	ITEMS.NOMENCLATURE_ as Nomenclature
  FROM
    ADM_MST_TAILS TAILS INNER JOIN ADM_MST_RESTRICTIONS BATT          ON TAILS.BATLN_ID = BATT.ID_
              INNER JOIN ADM_MST_UNITS UNITS              ON TAILS.UNIT_ID = UNITS.ID_
              INNER JOIN ADM_MST_ITEMS ITEMS              ON UNITS.ITEM_ID = ITEMS.ID_
              INNER JOIN ADM_MST_PLATFORMS PLATFORMS          ON ITEMS.ID_ = PLATFORMS.ID_
              INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER    ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
              INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN  ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
  WHERE
      INSPMASTER.INT_OTHER_ IS NOT NULL
  AND (TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ','))  OR @TailIds IS NULL)
  AND INSPASSIGN.ID_ IN (SELECT Item from dbo.SplitInts(@SelectedInspIds, ','))

) TailInspections
ORDER BY TailNo, SortOrder

SELECT * FROM dbo.ReturnTailHeader(@TailIds)
go

