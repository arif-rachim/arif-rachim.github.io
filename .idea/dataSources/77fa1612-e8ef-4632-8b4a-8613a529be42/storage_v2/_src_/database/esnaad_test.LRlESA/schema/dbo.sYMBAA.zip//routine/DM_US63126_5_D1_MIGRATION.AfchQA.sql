
CREATE PROCEDURE DM_US63126_5_D1_MIGRATION
AS
BEGIN

	SET NOCOUNT ON;
	SET DATEFORMAT DMY;

	DECLARE @execResult nvarchar(max);
	DECLARE @errormsg nvarchar(max);
	
	-- Esnaad vars
	  DECLARE @oldcomasg_ACFT_ID bigint;
	  DECLARE @oldmwo_MAT_CHG_NO_ nvarchar(255);
      DECLARE @oldmwo_MWO_NO_ nvarchar(255);
      DECLARE @oldmwo_MWO_PUB_DATE_ datetime;
      DECLARE @oldmwo_MWO_TITLE_ nvarchar(255);
      DECLARE @oldmwo_SW_VER_ nvarchar(255);

      DECLARE @CMD_ID bigint;
      DECLARE @ITEM_ID bigint;
      DECLARE @oldcomasg_COM_UNIT_ID bigint;
      DECLARE @oldcomasg_MWO_PRI_ID bigint;
      DECLARE @oldcomasg_MNT_LVL_ID bigint;
      DECLARE @oldcomasg_APP_DATE_ datetime;
      DECLARE @oldcomasg_APP_MAN_HRS_ bigint;
      DECLARE @oldcomasg_DUE_DATE_ datetime;
      DECLARE @oldcomasg_RSN_DEL_ID bigint;
      DECLARE @oldcomasg_APP_USER_ID bigint;
      DECLARE @oldcomasg_ORG_APPL_ nvarchar(255);
      DECLARE @oldcomasg_SUP_MWO_ID  uniqueidentifier 
      DECLARE @oldcomasg_IS_PCW_ bit;
      DECLARE @oldcomasg_IS_CANCELLED_ bit;
      DECLARE @oldcomasg_LAST_TRIGGERED_ON_ datetime;
      DECLARE @oldcomasg_FAULT_UNIT_ID_ bigint;

	  DECLARE @oldmwo_ID_  uniqueidentifier 
      DECLARE @oldmwo_VERSION_ bigint;
	  DECLARE @oldcomasg_MWO_HEADER_ID  uniqueidentifier 
      DECLARE @oldcomasg_ID_  uniqueidentifier 
      DECLARE @oldcomasg_VERSION_ bigint;

      DECLARE @oldmwo_CREATED_BY_ nvarchar(255);
      DECLARE @oldmwo_PID_CREATED_BY_ nvarchar(255);
      DECLARE @oldmwo_FULL_NAME_CREATED_BY_ nvarchar(255);
      DECLARE @oldmwo_CREATED_ON_ datetime;
      DECLARE @oldmwo_MOD_BY_  nvarchar(255);
      DECLARE @oldmwo_PID_MOD_BY_  nvarchar(255);
      DECLARE @oldmwo_FULL_NAME_MOD_BY_ nvarchar(255);
      DECLARE @oldmwo_MOD_ON_ datetime;
      DECLARE @oldmwo_TERM_  nvarchar(255);
      DECLARE @oldcomasg_CREATED_BY_  nvarchar(255);
      DECLARE @oldcomasg_PID_CREATED_BY_ nvarchar(255);
      DECLARE @oldcomasg_FULL_NAME_CREATED_BY_ nvarchar(255);
      DECLARE @oldcomasg_CREATED_ON_ datetime;
      DECLARE @oldcomasg_MOD_BY_ nvarchar(255);
      DECLARE @oldcomasg_PID_MOD_BY_ nvarchar(255);
      DECLARE @oldcomasg_FULL_NAME_MOD_BY_ nvarchar(255);
      DECLARE @oldcomasg_MOD_ON_ datetime;
      DECLARE @oldcomasg_TERM_  nvarchar(255);

	DECLARE @TagcolorIdWorkOrderCreated BIGINT = 14;


	DECLARE copierCursor CURSOR FOR
	SELECT 
	   bat.PRNT_ID
	  ,u.ITEM_ID mwoITEM_ID 
	  ,oldmwo.[MAT_CHG_NO_]
      ,oldmwo.[MWO_NO_]
      ,oldmwo.[MWO_PUB_DATE_]
      ,oldmwo.[MWO_TITLE_]
      ,oldmwo.[SW_VER_]
      ,oldcomasg.[ACFT_ID]
      ,oldcomasg.[COM_UNIT_ID]
      ,oldcomasg.[MWO_PRI_ID]
      ,oldcomasg.[MNT_LVL_ID]
      ,oldcomasg.[APP_DATE_]
      ,oldcomasg.[APP_MAN_HRS_]
      ,oldcomasg.[DUE_DATE_]
      ,oldcomasg.[RSN_DEL_ID]
      ,oldcomasg.[APP_USER_ID]
      ,oldcomasg.[ORG_APPL_]
      ,oldcomasg.[SUP_MWO_ID]
      ,oldcomasg.[IS_PCW_]
      ,oldcomasg.[IS_CANCELLED_]
      ,oldcomasg.[LAST_TRIGGERED_ON_]
      ,oldcomasg.[FAULT_UNIT_ID_]

	  ,oldmwo.[ID_]
      ,oldmwo.[VERSION_]
	  ,oldcomasg.[MWO_HEADER_ID]
      ,oldcomasg.[ID_]
      ,oldcomasg.[VERSION_]

      ,oldmwo.[CREATED_BY_]
      ,oldmwo.[PID_CREATED_BY_]
      ,oldmwo.[FULL_NAME_CREATED_BY_]
      ,oldmwo.[CREATED_ON_]
      ,oldmwo.[MOD_BY_]
      ,oldmwo.[PID_MOD_BY_]
      ,oldmwo.[FULL_NAME_MOD_BY_]
      ,oldmwo.[MOD_ON_]
      ,oldmwo.[TERM_]
      ,oldcomasg.[CREATED_BY_]
      ,oldcomasg.[PID_CREATED_BY_]
      ,oldcomasg.[FULL_NAME_CREATED_BY_]
      ,oldcomasg.[CREATED_ON_]
      ,oldcomasg.[MOD_BY_]
      ,oldcomasg.[PID_MOD_BY_]
      ,oldcomasg.[FULL_NAME_MOD_BY_]
      ,oldcomasg.[MOD_ON_]
      ,oldcomasg.[TERM_]

	from
		MNT_TRN_D5_1_MODIFICATION_WO_HEADER oldmwo
		inner join MNT_TRN_D5_1_MODIFICATION_WO_COMPONENTS oldcomasg on oldcomasg.MWO_HEADER_ID = oldmwo.ID_
		inner join ADM_MST_UNITS u on u.ID_ = oldcomasg.COM_UNIT_ID
		inner join ADM_MST_TAILS t on t.UNIT_ID = oldcomasg.ACFT_ID
		inner join ADM_MST_RESTRICTIONS bat on bat.ID_ = t.BATLN_ID 
	where
		ISNULL(oldmwo.US63126_MWO_STS_, 'E') ='E' OR ISNULL(oldcomasg.US63126_STS_,'E') = 'E'

		FOR UPDATE OF  US63126_MSG_, US63126_STS_, US63126_MWO_MSG_, US63126_MWO_STS_
	OPEN copierCursor
	
	FETCH NEXT FROM copierCursor
	INTO
	   @CMD_ID
	  ,@ITEM_ID
	  ,@oldmwo_MAT_CHG_NO_
      ,@oldmwo_MWO_NO_
      ,@oldmwo_MWO_PUB_DATE_
      ,@oldmwo_MWO_TITLE_
      ,@oldmwo_SW_VER_
      ,@oldcomasg_ACFT_ID
      ,@oldcomasg_COM_UNIT_ID
      ,@oldcomasg_MWO_PRI_ID
      ,@oldcomasg_MNT_LVL_ID
      ,@oldcomasg_APP_DATE_
      ,@oldcomasg_APP_MAN_HRS_
      ,@oldcomasg_DUE_DATE_
      ,@oldcomasg_RSN_DEL_ID
      ,@oldcomasg_APP_USER_ID
      ,@oldcomasg_ORG_APPL_
      ,@oldcomasg_SUP_MWO_ID
      ,@oldcomasg_IS_PCW_
      ,@oldcomasg_IS_CANCELLED_
      ,@oldcomasg_LAST_TRIGGERED_ON_
      ,@oldcomasg_FAULT_UNIT_ID_

	  ,@oldmwo_ID_
      ,@oldmwo_VERSION_
	  ,@oldcomasg_MWO_HEADER_ID
      ,@oldcomasg_ID_
      ,@oldcomasg_VERSION_

      ,@oldmwo_CREATED_BY_
      ,@oldmwo_PID_CREATED_BY_
      ,@oldmwo_FULL_NAME_CREATED_BY_
      ,@oldmwo_CREATED_ON_
      ,@oldmwo_MOD_BY_
      ,@oldmwo_PID_MOD_BY_
      ,@oldmwo_FULL_NAME_MOD_BY_
      ,@oldmwo_MOD_ON_
      ,@oldmwo_TERM_
      ,@oldcomasg_CREATED_BY_
      ,@oldcomasg_PID_CREATED_BY_
      ,@oldcomasg_FULL_NAME_CREATED_BY_
      ,@oldcomasg_CREATED_ON_
      ,@oldcomasg_MOD_BY_
      ,@oldcomasg_PID_MOD_BY_
      ,@oldcomasg_FULL_NAME_MOD_BY_
      ,@oldcomasg_MOD_ON_
      ,@oldcomasg_TERM_
	;
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
	--===>
		
			BEGIN TRY
				BEGIN	
					if(@oldcomasg_ID_ is not null)
					begin
					--===>
						print 'mwo: ' + @oldmwo_MWO_NO_
						if not exists (select * from MNT_TRN_D5_1_MWO_MASTER where MWO_NO_ = @oldmwo_MWO_NO_)
						begin 
							EXEC DM_US63126_5_D1__INSERT_MWO 
								@ID_ = @oldmwo_ID_
							   ,@MWO_NO_ = @oldmwo_MWO_NO_
							   ,@MWO_PUB_DATE_ = @oldmwo_MWO_PUB_DATE_
							   ,@MAT_CHG_NO_ = @oldmwo_MAT_CHG_NO_
							   ,@MWO_TITLE_ = @oldmwo_MWO_TITLE_
							   ,@SW_VER_ = @oldmwo_SW_VER_
							   ,@MWO_PRI_ID =@oldcomasg_MWO_PRI_ID
							   ,@MNT_LVL_ID=@oldcomasg_MNT_LVL_ID
							   ,@MWO_STS_ID = NULL
							   ,@SUP_BY_MWO_ID = NULL
							   ,@SUP_MWO_ID = NULL
							   ,@IS_PCW_ = @oldcomasg_IS_PCW_
							   ,@IS_SUP_MWO_CANCELLED_ = @oldcomasg_IS_CANCELLED_
							   ,@CREATED_BY_ = @oldmwo_CREATED_BY_
							   ,@PID_CREATED_BY_ = @oldmwo_PID_CREATED_BY_
							   ,@FULL_NAME_CREATED_BY_ = @oldmwo_FULL_NAME_CREATED_BY_
							   ,@CREATED_ON_ = @oldmwo_CREATED_ON_
							   ,@MOD_BY_ = @oldmwo_MOD_BY_
							   ,@PID_MOD_BY_ = @oldmwo_PID_MOD_BY_
							   ,@FULL_NAME_MOD_BY_ = @oldmwo_FULL_NAME_MOD_BY_
							   ,@MOD_ON_ = @oldmwo_MOD_ON_
							   ,@TERM_ = @oldmwo_TERM_
							   ,@CMD_ID = @CMD_ID

							   UPDATE MNT_TRN_D5_1_MODIFICATION_WO_HEADER SET US63126_MWO_STS_ = 'S', US63126_MWO_MSG_ = 'MWO and MWO_APPL_ITEM Inserted' 	WHERE CURRENT OF copierCursor
						end
						else
						begin
							UPDATE MNT_TRN_D5_1_MODIFICATION_WO_HEADER SET US63126_MWO_STS_ = 'S', US63126_MWO_MSG_ = 'already exist mwo: ' + @oldmwo_MWO_NO_ 	WHERE CURRENT OF copierCursor
							print 'already exist mwo: ' + @oldmwo_MWO_NO_
						end

						if not exists (select * from MNT_TRN_D5_1_COMPONENT where UNIT_ID = @oldcomasg_COM_UNIT_ID)
						begin 
							EXEC DM_US63126_5_D1__INSERT_COMPONENT 
								@ID_ = @oldcomasg_ID_
							   ,@CMD_ID = @CMD_ID 
							   ,@UNIT_ID = @oldcomasg_COM_UNIT_ID
							   ,@CREATED_BY_ = @oldcomasg_CREATED_BY_
							   ,@PID_CREATED_BY_ = @oldcomasg_PID_CREATED_BY_
							   ,@FULL_NAME_CREATED_BY_ = @oldcomasg_FULL_NAME_CREATED_BY_
							   ,@CREATED_ON_ = @oldcomasg_CREATED_ON_
							   ,@MOD_BY_ = @oldcomasg_MOD_BY_
							   ,@PID_MOD_BY_ = @oldcomasg_PID_MOD_BY_
							   ,@FULL_NAME_MOD_BY_ = @oldcomasg_FULL_NAME_MOD_BY_
							   ,@MOD_ON_ = @oldcomasg_MOD_ON_
							   ,@TERM_ = @oldcomasg_TERM_

								UPDATE MNT_TRN_D5_1_MODIFICATION_WO_COMPONENTS SET US63126_STS_ = 'S', US63126_MSG_ = 'COMPONENTS Inserted' 	WHERE CURRENT OF copierCursor
						end
						else
						begin
							UPDATE MNT_TRN_D5_1_MODIFICATION_WO_COMPONENTS SET US63126_STS_ = 'S', US63126_MSG_ = 'already exists UNITID:' +@oldcomasg_COM_UNIT_ID  	WHERE CURRENT OF copierCursor
						end
						
						if not exists (select * from MNT_TRN_D5_1_MWO_APPL_ITEM where MWO_ID = @oldmwo_ID_ and APPL_ITEM_ID = @ITEM_ID)
						begin 
							EXEC DM_US63126_5_D1__INSERT_MWO_APPL_ITEM 
								@MWO_ID = @oldmwo_ID_
							   ,@APPL_ITEM_ID = @ITEM_ID
							   ,@CREATED_BY_ = @oldmwo_CREATED_BY_
							   ,@PID_CREATED_BY_ = @oldmwo_PID_CREATED_BY_
							   ,@FULL_NAME_CREATED_BY_ = @oldmwo_FULL_NAME_CREATED_BY_
							   ,@CREATED_ON_ = @oldmwo_CREATED_ON_
							   ,@MOD_BY_ = @oldmwo_MOD_BY_
							   ,@PID_MOD_BY_ = @oldmwo_PID_MOD_BY_
							   ,@FULL_NAME_MOD_BY_ = @oldmwo_FULL_NAME_MOD_BY_
							   ,@MOD_ON_ = @oldmwo_MOD_ON_
							   ,@TERM_ = @oldmwo_TERM_
						end
						
						
						UPDATE MNT_TRN_D5_1_MODIFICATION_WO_COMPONENTS SET US63126_STS_ = 'S', US63126_MSG_ = 'COMPONENTS Inserted' 	WHERE CURRENT OF copierCursor

					--<===
					end

				END
			END TRY
			BEGIN CATCH
				SELECT @errormsg = ERROR_MESSAGE();
				print 'Error: ' + @errormsg + ' in ' + @oldmwo_MWO_NO_
				UPDATE MNT_TRN_D5_1_MODIFICATION_WO_COMPONENTS SET US63126_STS_ = 'E', US63126_MSG_ = @errormsg WHERE CURRENT OF copierCursor

				FETCH NEXT FROM copierCursor
				INTO
					 @CMD_ID
					,@ITEM_ID
					,@oldmwo_MAT_CHG_NO_
					,@oldmwo_MWO_NO_
					,@oldmwo_MWO_PUB_DATE_
					,@oldmwo_MWO_TITLE_
					,@oldmwo_SW_VER_

					,@oldcomasg_ACFT_ID
					,@oldcomasg_COM_UNIT_ID
					,@oldcomasg_MWO_PRI_ID
					,@oldcomasg_MNT_LVL_ID
					,@oldcomasg_APP_DATE_
					,@oldcomasg_APP_MAN_HRS_
					,@oldcomasg_DUE_DATE_
					,@oldcomasg_RSN_DEL_ID
					,@oldcomasg_APP_USER_ID
					,@oldcomasg_ORG_APPL_
					,@oldcomasg_SUP_MWO_ID
					,@oldcomasg_IS_PCW_
					,@oldcomasg_IS_CANCELLED_
					,@oldcomasg_LAST_TRIGGERED_ON_
					,@oldcomasg_FAULT_UNIT_ID_

					,@oldmwo_ID_
					,@oldmwo_VERSION_
					,@oldcomasg_MWO_HEADER_ID
					,@oldcomasg_ID_
					,@oldcomasg_VERSION_

					,@oldmwo_CREATED_BY_
					,@oldmwo_PID_CREATED_BY_
					,@oldmwo_FULL_NAME_CREATED_BY_
					,@oldmwo_CREATED_ON_
					,@oldmwo_MOD_BY_
					,@oldmwo_PID_MOD_BY_
					,@oldmwo_FULL_NAME_MOD_BY_
					,@oldmwo_MOD_ON_
					,@oldmwo_TERM_
					,@oldcomasg_CREATED_BY_
					,@oldcomasg_PID_CREATED_BY_
					,@oldcomasg_FULL_NAME_CREATED_BY_
					,@oldcomasg_CREATED_ON_
					,@oldcomasg_MOD_BY_
					,@oldcomasg_PID_MOD_BY_
					,@oldcomasg_FULL_NAME_MOD_BY_
					,@oldcomasg_MOD_ON_
					,@oldcomasg_TERM_
						;			
			END CATCH


		FETCH NEXT FROM copierCursor
		INTO
		   @CMD_ID
		  ,@ITEM_ID
		  ,@oldmwo_MAT_CHG_NO_
		  ,@oldmwo_MWO_NO_
		  ,@oldmwo_MWO_PUB_DATE_
		  ,@oldmwo_MWO_TITLE_
		  ,@oldmwo_SW_VER_

		  ,@oldcomasg_ACFT_ID
		  ,@oldcomasg_COM_UNIT_ID
		  ,@oldcomasg_MWO_PRI_ID
		  ,@oldcomasg_MNT_LVL_ID
		  ,@oldcomasg_APP_DATE_
		  ,@oldcomasg_APP_MAN_HRS_
		  ,@oldcomasg_DUE_DATE_
		  ,@oldcomasg_RSN_DEL_ID
		  ,@oldcomasg_APP_USER_ID
		  ,@oldcomasg_ORG_APPL_
		  ,@oldcomasg_SUP_MWO_ID
		  ,@oldcomasg_IS_PCW_
		  ,@oldcomasg_IS_CANCELLED_
		  ,@oldcomasg_LAST_TRIGGERED_ON_
		  ,@oldcomasg_FAULT_UNIT_ID_

		  ,@oldmwo_ID_
		  ,@oldmwo_VERSION_
		  ,@oldcomasg_MWO_HEADER_ID
		  ,@oldcomasg_ID_
		  ,@oldcomasg_VERSION_

		  ,@oldmwo_CREATED_BY_
		  ,@oldmwo_PID_CREATED_BY_
		  ,@oldmwo_FULL_NAME_CREATED_BY_
		  ,@oldmwo_CREATED_ON_
		  ,@oldmwo_MOD_BY_
		  ,@oldmwo_PID_MOD_BY_
		  ,@oldmwo_FULL_NAME_MOD_BY_
		  ,@oldmwo_MOD_ON_
		  ,@oldmwo_TERM_
		  ,@oldcomasg_CREATED_BY_
		  ,@oldcomasg_PID_CREATED_BY_
		  ,@oldcomasg_FULL_NAME_CREATED_BY_
		  ,@oldcomasg_CREATED_ON_
		  ,@oldcomasg_MOD_BY_
		  ,@oldcomasg_PID_MOD_BY_
		  ,@oldcomasg_FULL_NAME_MOD_BY_
		  ,@oldcomasg_MOD_ON_
		  ,@oldcomasg_TERM_
		;			

	--<===
	END
	
	CLOSE copierCursor
	DEALLOCATE copierCursor

	print '=> end of exec'
END



go

