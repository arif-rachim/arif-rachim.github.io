CREATE FUNCTION ConvertDateToDDMMMYY
(
	-- Add the parameters for the function here
	@date DateTime
)
RETURNS Varchar(21)
AS
BEGIN
	declare @ddmmmyyyy varchar(11) = null;

	select @ddmmmyyyy = upper(isNull(
		replace(
			convert(varchar, @date, 106)
		, ' ','-')
	, null))

	return SUBSTRING(@ddmmmyyyy, 0, 8) + SUBSTRING(@ddmmmyyyy, 10, 2)

END
go

