CREATE FUNCTION [dbo].[D161GetForecastReportByPart]
(
  @commandId    int,
  @platformId   int,
  @battalionId  int,
  @tailId       bigint,
  @itemId       bigint,
  @nomenclature varchar(250),
  @hrs          real,
  @landing      int,
  @cValueMonth  int,
  @cValueYear   int
  )
  RETURNS TABLE
    AS
    RETURN
SELECT TailNo          AS TailNo
    , PartNo          AS PartNo
    , MFR             AS MFR
    , Description     AS Description
    , OverDuePlatform AS OverDuePlatform
    , sum(OverDueQty) AS OverDueQty
    , DueNextPlatform AS DueNextPlatform
    , sum(DueNextQty) AS DueNextQty
    , RequisitionNo   AS RequisitionNo
    , sum(RQtyOnHand) AS RQtyOnHand
    , InLieu          AS InLieu
    , ILQtyOnHand     AS ILQtyOnHand
FROM (SELECT DISTINCT ByPart.TailNo                           AS TailNo
            , ByPart.PartNo                                    AS PartNo
            , ByPart.MFR                                       AS MFR
            , ByPart.Description                               AS Description
            , ByPart.OverDuePlatform                           AS OverDuePlatform
			, SUM(ByPart.OverDueQty)							  AS OverDueQty
            , ByPart.DueNextPlatform                           AS DueNextPlatform
			, SUM(ByPart.DueNextQty)							  AS DueNextQty
            , ByPart.RequisitionNo                             AS RequisitionNo
            , ByPart.RQtyOnHand                                AS RQtyOnHand
            , ByPart.InLieu                                    AS InLieu
            , ByPart.ILQtyOnHand                               AS ILQtyOnHand
		FROM	   (
			SELECT 
				cmd.ID_														AS CommandId,
				p2.ID_   													AS PlatformId,
				b.ID_														AS BattalionId,
				ISNULL(nha_item.ID_, ci.ID_)								AS ItemId,
				ci.ID_														AS NhaChildItemId,
				t.T_NUM_													AS TailNo,
				IIF(mc.IS_REPLACE_NHA_=1, ii.PART_NO_, ISNULL(nha_item.PART_NO_, ci.PART_NO_))						AS PartNo,
				IIF(mc.IS_REPLACE_NHA_=1, m2.CAGE_CODE_, m.CAGE_CODE_)												AS MFR,
				IIF(mc.IS_REPLACE_NHA_=1, ii.NOMENCLATURE_, ISNULL(nha_item.NOMENCLATURE_, ci.NOMENCLATURE_))		AS Description,
				p.CODE_														AS OverduePlatform,
				CASE WHEN mc.REPLACE_ > 0 THEN 1 ELSE 0 END					AS OverDueQty,
				''															AS DueNextPlatform,
				ac.CUR_OP_HRS_												AS Hrs,
				ISNULL(dbo.ReturnTAAMSTime(uus.TOT_FLIGHT_MINS_),0)         AS usageHours,
				0															AS Landing,
				0															AS UsageLanding,
				ac.REM_DATE_												AS ReplacementDate,
				CASE WHEN (
				CASE WHEN (mc.OVERHAUL_ IS NOT NULL AND mc.REPLACE_ IS NOT NULL)
						THEN CASE WHEN ((mc.OVERHAUL_ + ISNULL(ac.LAST_OH_,0)) - ac.CUR_OP_HRS_) < (mc.REPLACE_ - ac.CUR_OP_HRS_)
									THEN CASE WHEN p.CODE_ IS NOT NULL
												THEN mc.OVERHAUL_ + ISNULL(ac.LAST_OH_,0)
												ELSE mc.OVERHAUL_ - ISNULL(ac.LAST_OH_,0) + ISNULL(p_ac.CUR_OP_HRS_,0)
											END
									ELSE 
									CASE WHEN p.CODE_ IS NOT NULL
											THEN mc.REPLACE_ - ISNULL(hra.PC_OP_HRS_,0) + ISNULL(hra.CI_OP_HRS_,0)
											ELSE mc.REPLACE_ - ISNULL(ac.CUR_OP_HRS_,0) + ISNULL(p_ac.CUR_OP_HRS_,0)
									END
								END
					WHEN mc.OVERHAUL_ IS NOT NULL
						THEN CASE WHEN p.CODE_ IS NOT NULL
									THEN mc.OVERHAUL_ + ISNULL(ac.LAST_OH_,0)
									ELSE mc.OVERHAUL_ - ISNULL(ac.LAST_OH_,0) + ISNULL(p_ac.CUR_OP_HRS_,0)
								END
					WHEN mc.REPLACE_ IS NOT NULL
						THEN CASE WHEN p.CODE_ IS NOT NULL
									THEN mc.REPLACE_ - ISNULL(hra.PC_OP_HRS_,0) + ISNULL(hra.CI_OP_HRS_,0)
									ELSE mc.REPLACE_ - ISNULL(ac.CUR_OP_HRS_,0) + ISNULL(p_ac.CUR_OP_HRS_,0)
								END
				END) > 0 THEN 1 ELSE 0 END					AS DueNextQty,
				(SELECT STUFF((SELECT ',' + TRNREQUEST1.TR_NO_
						   FROM dbo.ADM_MST_TAILS AS TAILS1
								INNER JOIN dbo.LOG_TRN_TRM_TRANSFER_REQUEST AS TRNREQUEST1 ON TRNREQUEST1.END_ITEM_UNIT_ID_ = TAILS1.UNIT_ID
								INNER JOIN dbo.LOG_TRN_TRM_TRANSFER_REQUEST_ITEM AS RequestItem1 ON RequestItem1.TR_ID_ = TRNREQUEST1.ID_
						  WHERE (TAILS1.T_NUM_ = t.T_NUM_)
							AND RequestItem1.ITEM_ID = ISNULL(nha_item.ID_, ci.ID_)
							AND RequestItem1.FF_STATUS_ IN ('NotFulfilled', 'PartiallyFulfilled')
						  ORDER BY TRNREQUEST1.TR_NO_ FOR XML PATH ('')), 1, 1, '')) AS RequisitionNo,
				(SELECT ISNULL(SUM(STOCK1.QTY_), 0) AS Qty
						   FROM LOG_TRN_STOCK AS STOCK1
								INNER JOIN ADM_MST_UNIT_LOCATION ON STOCK1.LOC_ID = ADM_MST_UNIT_LOCATION.ID_
								LEFT OUTER JOIN ADM_MST_UNITS AS UNIT1 ON UNIT1.ID_ = STOCK1.UNIT_ID
						  WHERE (UNIT1.ITEM_ID = ci.ID_)
							AND (ADM_MST_UNIT_LOCATION.LOC_TYPE_ = 'REGULAR')
							AND STOCK1.OWNED_BY_L2_ID_ = pl2.L2_ID_)                   AS RQtyOnHand,
				(SELECT stuff((SELECT ',' + PART_NO_
							FROM ADM_MST_ITEMS i2
							JOIN ADM_TRN_ITEM_ASSOCS ia2 ON ia2.ITEM_ID = i2.ID_ and ia2.L2_ID = pl2.L2_ID_
							WHERE ia2.IN_LIEU_CODE_ =
									ISNULL(nha_ia.IN_LIEU_CODE_, ia.IN_LIEU_CODE_)
								AND i2.ID_ <> ISNULL(nha_item.ID_, ci.ID_) FOR XML PATH ('')
							), 1, 1, ''
						)
			)     AS InLieu,
			(SELECT stuff((SELECT ',' + CONVERT(varchar, tta.qty)
								FROM (SELECT inlieuitem6.ID_, ISNULL(SUM(stock6.qty_), 0) AS qty
										FROM ADM_MST_ITEMS inlieuitem6
											INNER JOIN ADM_MST_UNITS units6 ON units6.ITEM_ID = inlieuitem6.ID_
											INNER JOIN LOG_TRN_STOCK stock6 ON stock6.UNIT_ID = units6.ID_
											INNER JOIN ADM_MST_UNIT_LOCATION ON stock6.LOC_ID = ADM_MST_UNIT_LOCATION.ID_
											INNER JOIN ADM_TRN_ITEM_ASSOCS ATIA ON inlieuitem6.ID_ = ATIA.ITEM_ID AND ATIA.L2_ID = stock6.OWNED_BY_L2_ID_
										WHERE ATIA.IN_LIEU_CODE_ =
											ISNULL(nha_ia.IN_LIEU_CODE_, ia.IN_LIEU_CODE_)
										AND inlieuitem6.ID_ <> ISNULL(nha_item.ID_, ci.ID_)
										AND stock6.OWNED_BY_L2_ID_ = pl2.L2_ID_
										AND (ADM_MST_UNIT_LOCATION.LOC_TYPE_ = 'Regular')
										AND stock6.TAG_COLOR_COND_ID_ = 1
										GROUP BY inlieuitem6.ID_
									) AS tta FOR XML PATH ('')
								), 1, 1, ''
							)
			)  AS ILQtyOnHand
		FROM 
			MNT_TRN_D16_1_ASSIGNMENT ac 
			INNER JOIN ADM_MST_UNITS u ON u.ID_ = ac.COMP_UNIT_ID
			INNER JOIN ADM_MST_ITEMS i ON i.ID_ = u.ITEM_ID
			INNER JOIN ADM_MST_UNITS uu ON uu.ID_ = ac.END_UNIT_ID
			INNER JOIN ADM_MST_ITEMS ii ON ii.ID_ = uu.ITEM_ID
			INNER JOIN MNT_TRN_D16_1_MASTER mc ON mc.ID_ = ac.MASTER_ID
			LEFT JOIN ADM_MST_TAILS t ON t.UNIT_ID = ac.END_ACFT_UNIT_ID
			INNER JOIN ADM_MST_RESTRICTIONS AS b ON b.ID_ = t.BATLN_ID
			INNER JOIN ADM_MST_RESTRICTIONS AS cmd ON b.PRNT_ID = cmd.ID_
			LEFT JOIN ADM_MST_MANUFACTURES m ON m.ID_ = i.MNF_ID
			LEFT JOIN ADM_MST_MANUFACTURES m2 ON m2.ID_ = ii.MNF_ID
			LEFT JOIN ADM_MST_SIMPLE_REF sr ON sr.ID_ = i.CLS_ID_
			LEFT JOIN ADM_MST_SIMPLE_REF cat ON cat.ID_ = i.CAT_ID_
			LEFT JOIN ADM_MST_SIMPLE_REF scat ON scat.ID_ = i.SUB_CAT_ID_
			LEFT JOIN ADM_MST_PLATFORMS p ON p.ID_ = ii.ID_
			LEFT JOIN ADM_MST_PLATFORM_L2 AS pl2 ON pl2.CMD_ID_ = mc.CMD_ID AND pl2.PLTF_ID_ = p.ID_
			LEFT JOIN ADM_TRN_UNIT_USAGE AS uus ON uus.UNIT_ID_ = uu.ID_
			INNER JOIN ADM_MST_ITEMS AS ci ON ci.ID_ = u.ITEM_ID
			LEFT JOIN ADM_TRN_ITEM_ASSOCS ia ON ia.ITEM_ID = ci.ID_ and ia.L2_ID = pl2.L2_ID_
			LEFT JOIN ADM_MST_SIMPLE_REF ic ON ic.CODE_ = mc.INTERVAL_CAT_ AND ic.GRP_ = 'MNT.PTYP16'
			LEFT JOIN MNT_TRN_D16_1_ASSIGNMENT hra ON hra.ID_ = ac.HR_ASGN_ID
			LEFT JOIN ADM_MST_UNITS hru ON hru.ID_ = hra.COMP_UNIT_ID
			LEFT JOIN ADM_MST_ITEMS hri ON hri.ID_ = hru.ITEM_ID
			LEFT JOIN ADM_MST_MANUFACTURES hrm ON hrm.ID_ = hri.MNF_ID
			LEFT JOIN ADM_MST_SIMPLE_REF hrc ON hrc.ID_ = hri.CLS_ID_
			LEFT JOIN MNT_MST_D16_WORK_UNIT_CODE hrw ON hrw.ID_ = hra.WORK_UNIT_ID
			LEFT JOIN MNT_TRN_D16_1_ASSIGNMENT p_ac ON p_ac.COMP_UNIT_ID = ac.END_UNIT_ID
			LEFT JOIN ADM_MST_UNITS nha_unit ON nha_unit.ID_ = ac.COMP_UNIT_ID
			LEFT JOIN ADM_MST_ITEMS nha_item ON nha_item.ID_ = nha_unit.ITEM_ID
			LEFT JOIN ADM_TRN_ITEM_ASSOCS nha_ia ON nha_ia.ITEM_ID = nha_item.ID_ and nha_ia.L2_ID = pl2.L2_ID_
			LEFT JOIN ADM_MST_UNITS ut ON ut.ID_ = t.UNIT_ID
			LEFT JOIN ADM_MST_PLATFORMS p2 ON p2.ID_ = ut.ITEM_ID
		WHERE cmd.ID_ = @commandId                   
			AND t.ID_ = (CASE WHEN @tailId > 0 THEN @tailId ELSE t.ID_ END)
			AND (@battalionId = 0 OR t.UNIT_ID IN (SELECT ADM_MST_TAILS.UNIT_ID
													FROM ADM_MST_TAILS
													WHERE ADM_MST_TAILS.BATLN_ID = b.ID_))
			AND (@platformId = 0 OR t.UNIT_ID IN (SELECT ADM_MST_TAILS.UNIT_ID
													FROM ADM_MST_TAILS 
														JOIN ADM_MST_RESTRICTIONS ON ADM_MST_TAILS.BATLN_ID = ADM_MST_RESTRICTIONS.ID_
														JOIN ADM_MST_UNITS AS ADM_MST_UNITS_1 ON ADM_MST_TAILS.UNIT_ID = ADM_MST_UNITS_1.ID_
														JOIN ADM_MST_ITEMS AS ADM_MST_ITEMS_1 ON ADM_MST_UNITS_1.ITEM_ID = ADM_MST_ITEMS_1.ID_
													WHERE (ADM_MST_RESTRICTIONS.PRNT_ID = cmd.ID_) AND (ADM_MST_ITEMS_1.ID_ = p2.ID_)
				))
			) as ByPart
	WHERE ByPart.CommandId = (CASE WHEN @commandId > 0 THEN @commandId ELSE ByPart.CommandId END)
            AND ByPart.BattalionId = (CASE WHEN @battalionId > 0 THEN @battalionId ELSE ByPart.BattalionId END)
            AND ByPart.PlatformId = (CASE WHEN @platformId > 0 THEN @platformId ELSE ByPart.PlatformId END)
            AND (ByPart.ItemId = (CASE WHEN @itemId > 0 THEN @itemId ELSE ByPart.ItemId END) OR
                 ByPart.NhaChildItemId = (CASE WHEN @itemId > 0 THEN @itemId ELSE ByPart.NhaChildItemId END))
            --AND ByPart.Description LIKE
            --    (CASE WHEN @nomenclature IS NOT NULL THEN ('%' + @nomenclature + '%') ELSE ByPart.Description END)
            AND ( ( (@nomenclature IS NOT NULL or @nomenclature!='No-Value') and ByPart.Description LIKE '%\' + @nomenclature + '%' escape '\') or ( (@nomenclature IS  NULL or @nomenclature='No-Value') and ByPart.Description = ByPart.Description))
			AND (ByPart.OverduePlatform IS NOT NULL OR
                 (@hrs > 0 OR @landing > 0 OR @cValueMonth > 0 OR @cValueYear > 0))
            AND ((ByPart.OverduePlatform is not null) OR
                 (
                  (@hrs > 0 AND ByPart.Hrs - usageHours <= @hrs) 
				  OR
                  (@landing > 0 AND ByPart.Landing - UsageLanding <= @landing) OR
                  ((@cValueYear > 0 AND
                    (DATEADD(YEAR, @cValueYear, convert(date, GETDATE())) >= ByPart.ReplacementDate)) OR
                   (@cValueMonth > 0 AND
                    (DATEADD(MONTH, @cValueMonth, convert(date, GETDATE())) >= ByPart.ReplacementDate))
                    )
                 )
                )
        GROUP BY ByPart.TailNo, ByPart.PartNo, ByPart.MFR, ByPart.Description, ByPart.OverDuePlatform,
                ByPart.DueNextPlatform, ByPart.RequisitionNo, ByPart.RQtyOnHand, ByPart.InLieu,       
                ByPart.ILQtyOnHand
				) AS ByPart2
GROUP BY TailNo, PartNo, MFR, Description, OverDuePlatform, DueNextPlatform, RequisitionNo, InLieu, ILQtyOnHand
go

