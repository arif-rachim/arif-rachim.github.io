CREATE VIEW VW_MNT_TRN_AIRCRAFT_INVENTORIES_FLIGHT_HRS
AS
select * from
(
select 
datepart(day, d.DATE_) day_, datepart(month, d.DATE_) month_, left(datename(month, d.DATE_),3) month_text_, year(d.DATE_) year_, 
dbo.ReturnTAAMSTime(d.FLIGHT_MINS_) as FltMins, t.ID_ as TailId
from ADM_TRN_UNIT_USAGE_DETAIL d
inner join adm_mst_units as u on u.ID_ = d.UNIT_ID_
inner join adm_mst_tails t on t.UNIT_ID = u.ID_
) as src
PIVOT
(
      sum(FltMins)
      for day_ in ([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15], [16], [17], [18], [19], [20], [21], 
      [22], [23], [24], [25], [26], [27], [28], [29], [30], [31])
) as pivots
go

