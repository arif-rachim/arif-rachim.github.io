CREATE FUNCTION [dbo].[GetAircraftLandingsCurrent] 
(
	@date datetime,
	@tail_id bigint
)
RETURNS bigint -- landings
AS
BEGIN
	-- Declare variables
	DECLARE @landings bigint 

	IF(@date is not null)
	BEGIN
		SELECT @landings = dbo.ReturnTAAMSTime(ab.LANDING_) + SUM(tfr.LANDINGS_)
		FROM OPS_TRN_TAIL_CREWS tc 
			JOIN OPS_TRN_WINGS w ON tc.WING_ID=w.ID_
			JOIN OPS_TRN_MISSIONS m ON w.MISSION_ID=m.ID_
			JOIN OPS_TRN_TAIL_FLIGHT tf ON tf.TAIL_CREW_ID=tc.ID_
			JOIN ADM_MST_TAILS mt ON tc.TAIL_ID=mt.ID_ AND mt.END_DATE_='9999-12-31'
			JOIN ADM_MST_UNITS u ON mt.UNIT_ID=u.ID_
			LEFT JOIN ADM_TRN_AIRCRAFT_BASELINES ab ON u.ID_=ab.AIRCRAFT_ID_
			JOIN OPS_TRN_TAIL_FLIGHT_RECORD tfr ON tfr.TAIL_FLIGHT_ID=tf.ID_ AND ( ab.ID_ IS NULL OR tfr.RTD_ > ab.MINUTES_EFF_DATE_ )
			join WF_TRN_INSTANCE wf on wf.ID_ = m.WF_ID AND wf.WF_DEF_ID_='MissionWorkflow' AND wf.WF_STATE_ IN ('Verified','Debriefed')
		WHERE mt.ID_ = @tail_id
			and CONVERT(VARCHAR, tfr.RTD_, 112) < CONVERT(VARCHAR, @date, 112)
		GROUP BY mt.UNIT_ID, mt.ID_, ab.LANDING_
	END
	
	RETURN ISNULL(@landings ,0)
END
go

