CREATE VIEW [dbo].[VW_MNT_D16_ASSIGNED_ITEM_LIST]
AS SELECT DISTINCT       ac.ID_ AS ComponentId, ac.MAJOR_END_UNIT_ID_ AS MajorEndUnitId, ac.COMP_UNIT_ID_ AS ComponentUnitId, i.PART_NO_ AS PartNo, 
                      i.NOMENCLATURE_ AS Nomenclature, u.SERIAL_NO_ AS SerialNo, mc.REP_TYPE_ AS Category, 
                      SUBSTRING(CONVERT(VARCHAR, CONVERT(MONEY,ac.TS_OVR_HR_), 1), 1, LEN(CONVERT(VARCHAR, CONVERT(MONEY,ac.TS_OVR_HR_), 1)) - 1) AS TimeSinceOhAircraftHour, 
                      REPLACE(CONVERT(varchar, CONVERT(Money, ac.TS_OVR_LDG_), 1), '.00', '') AS TimeSinceOhLanding, 
                      CONVERT(VARCHAR, (YEAR(GETDATE()) - YEAR(ac.L_OVR_DATE_)) * 12 + (MONTH(GETDATE()) - MONTH(ac.L_OVR_DATE_))) + ' M' AS TimeSinceOhCalendar, 
                      SUBSTRING(CONVERT(VARCHAR, CONVERT(MONEY,ac.ACFT_OVR_DUE_HR_), 1), 1, LEN(CONVERT(VARCHAR, CONVERT(MONEY,ac.ACFT_OVR_DUE_HR_), 1)) - 1) AS DueOverhaulAircraftHour,
                      ac.ACFT_OVR_DUE_DATE_ AS DueOverhaulCalendar, REPLACE(CONVERT(varchar, CONVERT(Money, ac.ACFT_OVR_DUE_LDG_), 1), '.00', '') AS DueOverhaulLanding, 
                      SUBSTRING(CONVERT(VARCHAR, CONVERT(MONEY,ac.ACFT_REP_DUE_HR_), 1), 1, LEN(CONVERT(VARCHAR, CONVERT(MONEY,ac.ACFT_REP_DUE_HR_), 1)) - 1) AS DueReplaceAircraftHour,                       
                      ac.ACFT_REP_DUE_DATE_ AS DueReplaceCalendar, REPLACE(CONVERT(varchar, CONVERT(Money, ac.ACFT_REP_DUE_LDG_), 1), '.00', '') AS DueReplaceLanding, 
                      CASE WHEN (ac.REM_DATE_ IS NOT NULL OR
                      ac.REM_P_HR_ IS NOT NULL OR
                      REM_P_LDG_ IS NOT NULL) THEN '0x9B9B9B' WHEN (ac.ACFT_OVR_DUE_HR_ <= uu.TOT_FLIGHT_MINS_ / 60 OR
                      ac.ACFT_OVR_DUE_LDG_ <= uu.LANDINGS_ OR
                      ac.ACFT_REP_DUE_HR_ <= uu.TOT_FLIGHT_MINS_ / 60 OR
                      ac.ACFT_REP_DUE_LDG_ <= uu.LANDINGS_ OR
                      DATEDIFF(day, GETDATE(), ac.ACFT_OVR_DUE_DATE_) <= 0 OR
                      DATEDIFF(day, GETDATE(), ac.ACFT_REP_DUE_DATE_) <= 0) THEN '0x8FBD50' ELSE '0x000000' END AS Status, ac.CREATED_BY_ AS CreatedBy, 
                      ac.PID_CREATED_BY_ AS PidCreatedBy, ac.FULL_NAME_CREATED_BY_ AS FullNameCreatedBy, ac.CREATED_ON_ AS CreatedOn, ac.MOD_BY_ AS ModifiedBy, 
                      ac.PID_MOD_BY_ AS PidModifiedBy, ac.FULL_NAME_MOD_BY_ AS FullNameModifiedBy, ac.MOD_ON_ AS ModifiedOn, meu.SERIAL_NO_ AS MajorEndItemSerialNo, 
                      ac.NO_PREV_OVR_ AS NoOfPreOverhaul, mc.ID_ AS MasterComponentId, ac.IS_ACTIVE_ AS IsActive, CASE WHEN fa.ID_ IS NULL 
                      THEN 1 ELSE 0 END AS DeassignAllowed
FROM         dbo.MNT_TRN_D16_ASSIGNED_COMPONENT AS ac INNER JOIN
                      dbo.ADM_MST_UNITS AS u ON ac.COMP_UNIT_ID_ = u.ID_ INNER JOIN
                      dbo.ADM_MST_ITEMS AS i ON u.ITEM_ID = i.ID_ INNER JOIN
                      dbo.MNT_MST_D16_MASTER_COMPONENT AS mc ON ac.MST_COMP_ID_ = mc.ID_ INNER JOIN
                      dbo.ADM_MST_UNITS AS meu ON ac.MAJOR_END_UNIT_ID_ = meu.ID_ LEFT OUTER JOIN
                      dbo.MNT_TRN_D16_FAULT_ASSIGNED AS fa ON fa.ASSIGNED_COMP_ID_ = ac.ID_ LEFT OUTER JOIN
                      dbo.ADM_TRN_UNIT_USAGE AS uu ON uu.UNIT_ID_ = ac.ACFT_UNIT_ID_
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "ac"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 125
               Right = 260
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "u"
            Begin Extent = 
               Top = 126
               Left = 38
               Bottom = 245
               Right = 266
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "i"
            Begin Extent = 
               Top = 246
               Left = 38
               Bottom = 365
               Right = 260
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "mc"
            Begin Extent = 
               Top = 366
               Left = 38
               Bottom = 485
               Right = 260
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "meu"
            Begin Extent = 
               Top = 486
               Left = 38
               Bottom = 605
               Right = 266
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "fa"
            Begin Extent = 
               Top = 606
               Left = 38
               Bottom = 725
               Right = 260
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "uu"
            Begin Extent = 
               Top = 726
               Left = 38
               Bottom = 845
               Right = 260
            End
            DisplayFlags = 280
            TopColumn = 0
         E', 'SCHEMA', 'dbo', 'VIEW', 'VW_MNT_D16_ASSIGNED_ITEM_LIST'
go

exec sp_addextendedproperty 'MS_DiagramPane2', N'nd
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'VW_MNT_D16_ASSIGNED_ITEM_LIST'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 2, 'SCHEMA', 'dbo', 'VIEW', 'VW_MNT_D16_ASSIGNED_ITEM_LIST'
go

