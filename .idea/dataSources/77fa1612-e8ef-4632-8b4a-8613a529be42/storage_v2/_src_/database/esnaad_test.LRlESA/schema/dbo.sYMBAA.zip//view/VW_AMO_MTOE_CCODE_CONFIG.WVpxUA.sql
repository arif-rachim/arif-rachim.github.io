CREATE VIEW VW_AMO_MTOE_CCODE_CONFIG
AS
SELECT CcodeConfigurationId, GroupId, GroupCode, [Type], Compatibility, CcodeId, Ccode, Description,
                            CommandId, CommandCode, PlatformId, PlatformCode, ConfiguredTailCount,
                            CASE WHEN TotalTailCount > 0 THEN
                            CAST((CAST(ConfiguredTailCount AS DECIMAL(10, 2))/CAST(TotalTailCount AS DECIMAL(10, 2)) * 100) AS INT)
                            ELSE 0 END AS PlatformPercentage, WeaponQuantity, Rounds, FirstLineX, SecondLineX, ThirdLineX, FourthLineX,
                            ModifiedBy, FullNameModifiedBy, ModifiedOn
                            FROM
                            (SELECT CCC.ID_ AS CcodeConfigurationId, GRP.ID_ AS GroupId, GRP.CODE_ AS GroupCode,
                            CAT.CODE_ AS [Type], CG.CODE_ AS Compatibility,
                            AMI.ID_ AS CcodeId, AMI.PART_NO_ AS Ccode, AMI.NAME_ AS Description,
                            CMD.ID_ AS CommandId, CMD.CODE_ AS CommandCode, PLF.ID_ AS PlatformId, PLF.CODE_ AS PlatformCode, 
                            (SELECT COUNT(*)
                            FROM AMO_TRN_MTOE_PLATFORM_TAIL_CONFIG AS PTC
                            INNER JOIN ADM_MST_UNITS AS TU ON PTC.TAIL_UNIT_ID_ = TU.ID_
                            INNER JOIN ADM_MST_TAILS AS T ON T.UNIT_ID = TU.ID_
                            WHERE PLATFORM_CONFIG_ID_ = PC.ID_
                            ) AS ConfiguredTailCount,
                            (SELECT COUNT(*)
                            FROM ADM_MST_TAILS AS TAILS
                            INNER JOIN ADM_MST_UNITS AS UNITS ON TAILS.UNIT_ID = UNITS.ID_
                            INNER JOIN ADM_MST_ITEMS AS ITM ON ITM.ID_ = UNITS.ITEM_ID
                            INNER JOIN ADM_MST_PLATFORMS AS PLFM ON PLFM.ID_ = ITM.ID_
                            INNER JOIN ADM_MST_RESTRICTIONS AS BTN ON BTN.ID_ = TAILS.BATLN_ID
                            INNER JOIN ADM_MST_RESTRICTIONS AS COMMAND ON BTN.PRNT_ID = COMMAND.ID_
                            WHERE TAILS.END_DATE_  = '9999-12-31' AND COMMAND.ID_ = CMD.ID_ AND PLFM.ID_ = PLF.ID_) AS TotalTailCount,
                            PC.WEAPON_QTY_ AS WeaponQuantity, ROUNDS_ AS Rounds, FIRST_LINE_X_ AS FirstLineX, SECOND_LINE_X_ AS SecondLineX,
                            THIRD_LINE_X_ AS ThirdLineX, FOURTH_LINE_X_ AS FourthLineX,
                            CCODEH.CREATED_BY_ AS ModifiedBy, CCODEH.FULL_NAME_CREATED_BY_ AS FullNameModifiedBy, CCODEH.CREATED_ON_ AS ModifiedOn
                            FROM ADM_MST_ITEMS AS AMI
                            INNER JOIN ADM_MST_SIMPLE_REF AS GRP ON GRP.ID_ = AMI.AMMO_GRP_ID_
                            INNER JOIN ADM_MST_SIMPLE_REF AS CAT ON CAT.ID_ = AMI.AMMO_CAT_ID_
                            INNER JOIN ADM_MST_COMPATIBILITY_GROUP AS CG ON CG.ID_ = AMI.COMPAT_GROUP_ID_
                            INNER JOIN ADM_XRF_AMO_ITEM_COMMAND AS AMI_CMD ON AMI_CMD.AMO_ITEM_ID_ = AMI.ID_
                            INNER JOIN ADM_MST_RESTRICTIONS AS CMD ON AMI_CMD.CMD_ID_ = CMD.ID_
                            INNER JOIN ADM_XRF_AMO_ITEM_PLATFORM AS AMI_PLF ON AMI_PLF.AMO_ITEM_ID_ = AMI.ID_
                            INNER JOIN ADM_MST_PLATFORMS AS PLF ON PLF.ID_ = AMI_PLF.PLTF_ID_
                            INNER JOIN ADM_MST_PLATFORM_L2 AS PLF_L2 ON PLF_L2.CMD_ID_ = CMD.ID_ AND PLF_L2.PLTF_ID_ = PLF.ID_
                            LEFT JOIN AMO_TRN_MTOE_PLATFORM_CONFIG AS PC ON PC.CMD_ID_ =  CMD.ID_ AND PC.PLATFORM_ID_ = PLF.ID_
                            LEFT JOIN AMO_TRN_MTOE_CCODE_CONFIG AS CCC ON CCC.CCODE_ID_ = AMI.ID_ AND CCC.CMD_ID_ = CMD.ID_ AND CCC.PLATFORM_ID_ = PLF.ID_
                            LEFT JOIN (SELECT MAX(CCH.CREATED_ON_) AS MaxCreatedOn,
                            CCH.CCODE_ID_ AS CcodeId, CCH.CMD_ID_ AS CommandId, CCH.PLATFORM_ID_ AS PlatformId
                            FROM AMO_HST_MTOE_CCODE_CONFIG AS CCH
                            GROUP BY CCH.CCODE_ID_, CCH.CMD_ID_, CCH.PLATFORM_ID_) AS MAXH ON MAXH.CcodeId = AMI.ID_ AND MAXH.CommandId = CMD.ID_ AND MAXH.PlatformId = PLF.ID_
                            LEFT JOIN AMO_HST_MTOE_CCODE_CONFIG AS CCODEH ON CCODEH.CCODE_ID_ = AMI.ID_ AND CCODEH.CMD_ID_ = CMD.ID_ AND CCODEH.PLATFORM_ID_ = PLF.ID_ 
                            AND CCODEH.CREATED_ON_ = MAXH.MaxCreatedOn
                            WHERE AMI.ITEM_GROUP_ = 'Ammo'
                            ) AS SRC
go

