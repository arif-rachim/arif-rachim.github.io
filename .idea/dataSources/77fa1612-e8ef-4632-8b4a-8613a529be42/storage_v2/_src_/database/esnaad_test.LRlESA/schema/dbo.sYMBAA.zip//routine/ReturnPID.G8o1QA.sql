CREATE FUNCTION [dbo].[ReturnPID](@UserId int) RETURNS varchar(100)
BEGIN
      DECLARE @retValue varchar(100)
      SELECT @retValue = USER_ID_ FROM dbo.ADM_TRN_USER_PROFILES WHERE ID_ =  @UserId
      RETURN @retValue
END   
go

