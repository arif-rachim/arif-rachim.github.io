CREATE FUNCTION [dbo].[GetAfm132Status]
(
      @faultId				bigint
)
RETURNS int
AS
BEGIN
	DECLARE @result int = 0;
	declare  @faultId_     bigint;

	set  @faultId_      = @faultId;

 SELECT @result = count(fci.ID_)
    FROM MNT_TRN_FAULT_UNITS f
    LEFT JOIN MNT_TRN_FAULT_CORRECTS fc on fc.FAULT_UNIT_ID = f.ID_
    LEFT JOIN MNT_TRN_FAULT_CORRECTING_ITEMS fci on  fci.FLT_CORR_ID = fc.ID_
    LEFT JOIN ADM_MST_SIMPLE_REF r on fci.STS_ID = r.ID_ and r.GRP_ = 'MNT.STS' and r.ORDER_ > 2
    WHERE f.ID_= @faultId_  AND fc.ITEM_TYPE_ = 'Correcting132' AND 
    ( 
	((fci.REL_ACT_ IS NULL OR LEN(fci.REL_ACT_) < 5 OR fci.ACT_ IS NULL OR fci.USR_ID IS NULL OR fci.CAT_ID IS  NULL OR fci.MNT_MAIN_HRS <= 0) AND r.ID_ IS  NULL)
    OR
    ((fci.REL_ACT_ IS NULL OR LEN(fci.REL_ACT_) < 5 OR fci.ACT_ IS NULL OR fci.USR_ID IS NULL OR fci.CAT_ID IS  NULL OR fci.MNT_MAIN_HRS <= 0 OR fci.TI_USR_ID IS  NULL) and r.ID_ IS NOT NULL)
    )

    RETURN @result
END
go

