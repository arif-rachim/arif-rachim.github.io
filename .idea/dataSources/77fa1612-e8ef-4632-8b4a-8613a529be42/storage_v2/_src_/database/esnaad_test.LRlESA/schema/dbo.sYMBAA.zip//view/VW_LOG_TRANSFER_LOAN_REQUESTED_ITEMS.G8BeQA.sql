CREATE VIEW [dbo].[VW_LOG_TRANSFER_LOAN_REQUESTED_ITEMS]
AS

SELECT        Id, DocumentDate, DocumentNo, ReferenceDoc, Agl2, OrgCommandId, OrgCommand, OrgBuId, OrgBu, DestCommandId, DestCommand, DestBuId, DestBu, Remarks, Status, StockStatus, CreatedOn, CreatedBy, 
                         FullNameCreatedBy, FullNameModifiedBy, ModifiedBy, ModifiedOn, PartNo, MfrCode, Nsn, Nomenclature, Uom, RequestedQty, FulfilledQty, CancelledQty, PendingQty, DocType, ItemId, IsSerialized
FROM            (SELECT        TR_REQ_ITM.ID_ AS Id, CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN TR_REQ.TR_DATE_ ELSE TR_REQ.CREATED_ON_ END AS DocumentDate, TR_REQ.TR_NO_ AS DocumentNo, 
                                                    ref.ReferenceNumber AS ReferenceDoc, 
                                      CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN DTFL2.CODE_ ELSE L2.CODE_ END AS Agl2, 
                                        CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN FICMD.ID_ ELSE RICMD.ID_ END AS OrgCommandId, 
                                        CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN FICMD.CODE_ ELSE RICMD.CODE_ END     AS OrgCommand, 
                                        CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN FIBU.ID_ ELSE RIBU.ID_ END AS    OrgBuId, 
                                        CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN FIBU.CODE_ ELSE RIBU.CODE_ END  AS OrgBu, 
                                        CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN RICMD.ID_ ELSE FICMD.ID_ END AS   DestCommandId, 
                                                                                CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN RICMD.CODE_ ELSE FICMD.CODE_ END AS   DestCommand, 
                                        CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN RIBU.ID_ ELSE FIBU.ID_ END AS   DestBuId, 
                                        CASE WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') THEN RIBU.CODE_ ELSE FIBU.CODE_ END AS   DestBu, 
                                                                                TR_REQ.REMARKS_ AS Remarks,  
                                                                              CASE  WHEN (TR_REQ.TR_TYPE_ = 'DirectTransfer') 
                                                                          THEN ( CASE 
                                                                    WHEN DT_WF.WF_STATE_= 'InTransit' AND LOG_TRN_TRF_TRANSFER_DATA.RCV_DATE_ IS NULL THEN 'AWAITING RECEIVING' 
                                                                    WHEN DT_WF.WF_STATE_= 'Canceled' then 'CANCELLED'
                                                                    ELSE  'CLOSED' END) 
                                                                                ELSE 
                                            CASE 
                                                                                        WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (TR_REQ.IS_ORIGIN_BU_VALIDATE_REQUIRED_ =1  ) THEN 'AWAITING REQUESTOR VALIDATION'
                                            WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (TR_REQ.IS_ORIGIN_BU_APPROVAL_REQUIRED_ =1  ) THEN 'AWAITING REQUESTOR APPROVAL'
                                            WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (TR_REQ.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =1  ) THEN 'AWAITING FULFILLER VALIDATION'
                                            WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (TR_REQ.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =1  ) THEN 'AWAITING FULFILLER APPROVAL'
                                            WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (TR_REQ.IS_ORIGIN_BU_VALIDATE_REQUIRED_ =0 AND TR_REQ.IS_ORIGIN_BU_APPROVAL_REQUIRED_ =0  AND TR_REQ.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =0  AND TR_REQ.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =0  ) THEN 'AWAITING FULFILLMENT'                                            
                                                                                        WHEN WF.WF_STATE_ = 'Validated' AND (TR_REQ.IS_ORIGIN_BU_APPROVAL_REQUIRED_ =1  ) THEN   'AWAITING REQUESTOR APPROVAL' 
                                            WHEN WF.WF_STATE_ = 'Validated' AND (TR_REQ.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =1  ) THEN   'AWAITING FULFILLER VALIDATION' 
                                              WHEN WF.WF_STATE_ = 'Validated' AND (TR_REQ.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =1  ) THEN   'AWAITING FULFILLER APPROVAL'
                                            WHEN WF.WF_STATE_ = 'Validated' AND (TR_REQ.IS_ORIGIN_BU_APPROVAL_REQUIRED_ =0 AND TR_REQ.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =0 AND TR_REQ.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =0 ) THEN   'AWAITING FULFILLMENT'                                              
                                            WHEN WF.WF_STATE_ = 'Approved' AND TR_REQ.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =1 THEN 'AWAITING FULFILLER VALIDATION' 
                                            WHEN WF.WF_STATE_ = 'Approved' AND TR_REQ.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =1 THEN 'AWAITING FULFILLER APPROVAL' 
                                            WHEN WF.WF_STATE_ = 'Approved' AND TR_REQ.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =0 AND TR_REQ.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =0 THEN 'AWAITING FULFILLMENT'
                                                                                        WHEN WF.WF_STATE_ = 'ValidatedByFulfiller' AND TR_REQ.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =1 THEN 'AWAITING FULFILLER APPROVAL'
                                            WHEN WF.WF_STATE_ = 'ValidatedByFulfiller' AND TR_REQ.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =0 THEN 'AWAITING FULFILLMENT'
                                            WHEN WF.WF_STATE_ = 'ApprovedByFulfiller'  THEN 'AWAITING FULFILLMENT' 
                                            WHEN WF.WF_STATE_ = 'PartiallyFulfilled' THEN 'PARTIALLY FULFILLED'
                                            WHEN (WF.WF_STATE_  IN  ('Fulfilled') and TR_REQ_ITM.FF_STATUS_ = 'Deleted') THEN 'CANCELLED' 
                                            WHEN WF.WF_STATE_  IN  ('Completed', 'Fulfilled') THEN 'CLOSED' 
                                            WHEN WF.WF_STATE_ IN ('Canceled') THEN 'CANCELLED'
                                            WHEN WF.WF_STATE_ IN ('RejectByReceiverValidate','RejectByReceiverApprove') THEN 'REJECTED'
                                            ELSE UPPER(WF.WF_STATE_) END   
                                        END AS Status,
                                                        (SELECT        dbo.GetIssueableStockStatusByTransferRequest(TR_REQ.ID_) AS Expr1) AS StockStatus, TR_REQ_ITM.CREATED_ON_ AS CreatedOn, TR_REQ_ITM.FULL_NAME_CREATED_BY_ AS CreatedBy, 
                                                    TR_REQ_ITM.CREATED_BY_ AS FullNameCreatedBy, TR_REQ_ITM.MOD_BY_ AS FullNameModifiedBy, TR_REQ_ITM.FULL_NAME_MOD_BY_ AS ModifiedBy, TR_REQ_ITM.MOD_ON_ AS ModifiedOn, 
                                                    ITMS.PART_NO_ AS PartNo, MFR.CAGE_CODE_ AS MfrCode, ITMS.NSN_ AS Nsn, ITMS.NOMENCLATURE_ AS Nomenclature, UOM.CODE_ AS Uom, TR_REQ_ITM.REQ_QTY_ AS RequestedQty, 
                                                    TR_REQ_ITM.ISSUED_QTY_ AS FulfilledQty, ISNULL(TR_REQ_ITM.CANCELED_QTY_, 0) AS CancelledQty, TR_REQ_ITM.REQ_QTY_ - ISNULL(TR_REQ_ITM.CANCELED_QTY_, 0) 
                                                    - TR_REQ_ITM.ISSUED_QTY_ AS PendingQty, CASE WHEN TR_REQ.TR_TYPE_ = 'StoreTransfer' THEN 'TR' ELSE 'DT' END   AS DocType, TR_REQ_ITM.ITEM_ID AS ItemId,  ITMS.SERIALIZED_ AS IsSerialized
                          FROM            LOG_TRN_TRM_TRANSFER_REQUEST AS TR_REQ INNER JOIN
                                                    LOG_TRN_TRM_TRANSFER_REQUEST_ITEM AS TR_REQ_ITM ON TR_REQ_ITM.TR_ID_ = TR_REQ.ID_ INNER JOIN
                                                    ADM_MST_ITEMS AS ITMS ON ITMS.ID_ = TR_REQ_ITM.ITEM_ID INNER JOIN
                                                    ADM_MST_MANUFACTURES AS MFR ON MFR.ID_ = ITMS.MNF_ID INNER JOIN
                                                    LOG_MST_UNIT_OF_MEASURE AS UOM ON UOM.ID_ = ITMS.UOM_ID_ LEFT OUTER JOIN
                                                    WF_TRN_INSTANCE AS WF ON WF.ID_ = TR_REQ.WF_ID AND WF.WF_DEF_ID_='StoreTransferWorkflow' LEFT OUTER JOIN
                                                        (SELECT        Id, ReferenceNumber, Priority, EndItem
                                                          FROM            (SELECT        trf.ID_ AS Id, trf.REF_TYPE_ AS ReferenceType, (CASE WHEN req.ID_ IS NOT NULL THEN req.TR_NO_ ELSE ISNULL(parent.TR_NO_, trf.REF_NO_) END) AS ReferenceNumber, 
                                                                                                              (CASE WHEN req.ID_ IS NOT NULL THEN req.PRIORITY_ ELSE trf.PRIORITY_ END) AS Priority, req.END_ITEM_UNIT_ID_ AS EndItem
                                                                                    FROM            LOG_TRN_TRM_TRANSFER_REQUEST AS trf LEFT OUTER JOIN
                                                                                                              LOG_TRN_TRM_TRANSFER_REQUEST AS req ON req.GENERATED_TRANSFER_REQ_ID = trf.ID_ LEFT OUTER JOIN
                                                                                                              WF_TRN_INSTANCE AS wf ON wf.ID_ = trf.WF_ID AND wf.WF_DEF_ID_='StoreTransferWorkflow' LEFT OUTER JOIN
                                                                                                              LOG_TRN_TRM_TRANSFER_REQUEST AS parent ON parent.ID_ = trf.PARENT_TRANSFER_REQ_ID_
                                                                                    WHERE        (trf.TR_TYPE_ = 'StoreTransfer')) AS ref) AS ref ON ref.Id = TR_REQ.ID_ LEFT OUTER JOIN
                                                    ADM_TRN_ASSOC_GROUPS AS L2 ON L2.ID_ = TR_REQ.RI_L2_ID_ LEFT OUTER JOIN
                                                    ADM_MST_RESTRICTIONS AS RICMD ON RICMD.ID_ = TR_REQ.RI_CMD_ID_ LEFT OUTER JOIN
                                                    ADM_MST_RESTRICTIONS AS FICMD ON FICMD.ID_ = TR_REQ.FI_CMD_ID_ LEFT OUTER JOIN
                                                    ADM_MST_BUSINESS_UNITS AS RIBU ON RIBU.ID_ = TR_REQ.RI_BU_ID_ LEFT OUTER JOIN
                                                    ADM_MST_BUSINESS_UNITS AS FIBU ON FIBU.ID_ = TR_REQ.FI_BU_ID_ LEFT OUTER JOIN
                                                    LOG_TRN_TRF_TRANSFER_DATA ON TR_REQ.TR_NO_ = LOG_TRN_TRF_TRANSFER_DATA.DOC_REF_NO_ AND TR_REQ.TR_TYPE_ = 'DirectTransfer' LEFT OUTER JOIN
                                                    WF_TRN_INSTANCE AS DT_WF ON DT_WF.ID_ = LOG_TRN_TRF_TRANSFER_DATA.WF_ID AND DT_WF.WF_DEF_ID_='TransferWorkflow' LEFT OUTER JOIN
                                                    ADM_TRN_ASSOC_GROUPS AS DTFL2 ON DTFL2.ID_ = TR_REQ.FI_L2_ID_
                          WHERE        (TR_REQ.TR_TYPE_ = 'StoreTransfer') OR
                                                    (TR_REQ.TR_TYPE_ = 'DirectTransfer')
                          UNION ALL
                          SELECT        L_ITEM.ID_ AS Id, EXTLOAN.CREATED_ON_ AS DocumentDate, EXTLOAN.LOAN_NO_ AS DocumentNo, '' AS ReferenceDoc, REQAGL2.CODE_ AS Agl2, REQCMD.ID_ AS OrgCommandId, 
                                                   REQCMD.CODE_ AS OrgCommand, REQBU.ID_ AS OrgBuId, REQBU.CODE_ AS OrgBu, FULCMD.ID_ AS DestCommandId, FULCMD.CODE_ AS DestCommand, FULBU.ID_ AS DestBuId, FULBU.CODE_ AS DestBu, 
                                                   EXTLOAN.REMARKS_ AS Remarks,
                           CASE 
                            WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (EXTLOAN.IS_ORIGIN_BU_VALIDATE_REQUIRED_ =1  ) THEN 'AWAITING REQUESTOR VALIDATION'
                            WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (EXTLOAN.IS_ORIGIN_BU_APPROVAL_REQUIRED_ =1  ) THEN 'AWAITING REQUESTOR APPROVAL'
                            WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (EXTLOAN.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =1  ) THEN 'AWAITING FULFILLER VALIDATION'
                            WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (EXTLOAN.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =1  ) THEN 'AWAITING FULFILLER APPROVAL'
                            WHEN WF.WF_STATE_ IN ('Submitted', 'Created', 'Invalidated') AND (EXTLOAN.IS_ORIGIN_BU_VALIDATE_REQUIRED_ =0 AND EXTLOAN.IS_ORIGIN_BU_APPROVAL_REQUIRED_ =0  AND EXTLOAN.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =0  AND EXTLOAN.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =0  ) THEN 'AWAITING FULFILLMENT'
                            WHEN WF.WF_STATE_ = 'Validated' AND (EXTLOAN.IS_ORIGIN_BU_APPROVAL_REQUIRED_ =1  ) THEN   'AWAITING REQUESTOR APPROVAL' 
                            WHEN WF.WF_STATE_ = 'Validated' AND (EXTLOAN.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =1  ) THEN   'AWAITING FULFILLER VALIDATION' 
                            WHEN WF.WF_STATE_ = 'Validated' AND (EXTLOAN.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =1  ) THEN   'AWAITING FULFILLER APPROVAL'
                            WHEN WF.WF_STATE_ = 'Validated' AND (EXTLOAN.IS_ORIGIN_BU_APPROVAL_REQUIRED_ =0 AND EXTLOAN.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =0 AND EXTLOAN.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =0 ) THEN   'AWAITING FULFILLMENT'                                                                                 
                            WHEN WF.WF_STATE_ = 'Approved' AND EXTLOAN.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =1 THEN 'AWAITING FULFILLER VALIDATION' 
                            WHEN WF.WF_STATE_ = 'Approved' AND EXTLOAN.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =1 THEN 'AWAITING FULFILLER APPROVAL' 
                            WHEN WF.WF_STATE_ = 'Approved' AND EXTLOAN.IS_DESTINATION_BU_VALIDATE_REQUIRED_ =0 AND EXTLOAN.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =0 THEN 'AWAITING FULFILLMENT' 
                            WHEN WF.WF_STATE_ = 'ValidatedByFulfiller' AND EXTLOAN.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =1 THEN 'AWAITING FULFILLER APPROVAL'
                            WHEN WF.WF_STATE_ = 'ValidatedByFulfiller' AND EXTLOAN.IS_DESTINATION_BU_APPROVAL_REQUIRED_ =0 THEN 'AWAITING FULFILLMENT'
                            WHEN WF.WF_STATE_ = 'ApprovedByFulfiller'  THEN 'AWAITING FULFILLMENT' 
                            WHEN wf.WF_STATE_ = 'PartiallyFulfilled' THEN 'PARTIALLY FULFILLED'
                            WHEN wf.WF_STATE_ IN ('Completed', 'Fulfilled') THEN 'AWAITING RETURN' 
                            WHEN wf.WF_STATE_ IN ('Canceled') THEN 'CANCELLED'
                            WHEN wf.WF_STATE_ IN ('RejectByReceiverValidate','RejectByReceiverApprove') THEN 'REJECTED'
                          ELSE UPPER(wf.WF_STATE_) END AS Status,
                                                       (SELECT        dbo.GetIssueableStockStatusByLoanRequest(EXTLOAN.ID_) AS Expr1) AS StockStatus, EXTLOAN.CREATED_ON_ AS CreatedOn, EXTLOAN.FULL_NAME_CREATED_BY_ AS CreatedBy, 
                                                   EXTLOAN.CREATED_BY_ AS FullNameCreatedBy, EXTLOAN.MOD_BY_ AS FullNameModifiedBy, EXTLOAN.FULL_NAME_MOD_BY_ AS ModifiedBy, EXTLOAN.MOD_ON_ AS ModifiedOn, ITMS.PART_NO_ AS PartNo, 
                                                   MFR.CAGE_CODE_ AS MfrCode, ITMS.NSN_ AS Nsn, ITMS.NOMENCLATURE_ AS Nomenclature, UOM.CODE_ AS Uom, L_ITEM.RQ_QTY_ AS RequestedQty, L_ITEM.FF_QTY_ AS FulfilledQty, 
                                                   ISNULL(L_ITEM.CL_QTY_, 0) AS CancelledQty, L_ITEM.RQ_QTY_ - ISNULL(L_ITEM.CL_QTY_, 0) - L_ITEM.FF_QTY_ AS PendingQty,  'LOAN' AS DocType, L_ITEM.ITEM_ID AS ItemId,  ITMS.SERIALIZED_ AS IsSerialized
                          FROM            LOG_TRN_ELM_EXTERNAL_LOAN AS EXTLOAN INNER JOIN
                                                   LOG_TRN_ELM_LOAN_ITEM AS L_ITEM ON L_ITEM.EL_ID = EXTLOAN.ID_ INNER JOIN
                                                   ADM_MST_ITEMS AS ITMS ON ITMS.ID_ = L_ITEM.ITEM_ID INNER JOIN
                                                   ADM_MST_MANUFACTURES AS MFR ON MFR.ID_ = ITMS.MNF_ID INNER JOIN
                                                   LOG_MST_UNIT_OF_MEASURE AS UOM ON UOM.ID_ = ITMS.UOM_ID_ INNER JOIN
                                                   ADM_TRN_ASSOC_GROUPS AS FULAGL2 ON EXTLOAN.FF_L2_ID = FULAGL2.ID_ INNER JOIN
                                                   ADM_MST_BUSINESS_UNITS AS FULBU ON EXTLOAN.FF_STORE_ID = FULBU.ID_ INNER JOIN
                                                   ADM_TRN_ASSOC_GROUPS AS REQAGL2 ON EXTLOAN.RQ_L2_ID = REQAGL2.ID_ INNER JOIN
                                                   ADM_MST_BUSINESS_UNITS AS REQBU ON EXTLOAN.RQ_BU_ID = REQBU.ID_ INNER JOIN
                                                   WF_TRN_INSTANCE AS WF ON EXTLOAN.WF_ID = WF.ID_ AND WF.WF_DEF_ID_='ExternalLoanWorkflow' INNER JOIN
                                                   ADM_MST_RESTRICTIONS AS FULCMD ON FULCMD.ID_ = EXTLOAN.FF_CMD_ID INNER JOIN
                                                   ADM_MST_RESTRICTIONS AS REQCMD ON REQCMD.ID_ = EXTLOAN.CMD_ID) AS SRC
go

