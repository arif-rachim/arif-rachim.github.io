CREATE FUNCTION [dbo].[GetIssueableStockStatusByLoanRequest]
(
	@loanRequestId			uniqueidentifier
)
RETURNS int
AS
BEGIN
	-- return value
	DECLARE @result int

	select  

	@result =
	case 
		when sum(partialyavailable) > 0 then 2
		when sum(nostock) > 0 and sum(availablestock) > 0 then 2
		when sum(availablestock) > 0 then 1
		when sum(nostock) > 0 then 3
	end

		from (
		select 

		stockchcek.ITEM_ID as itemid,
		case 
			when ISNULL(stockchcek.AvailableStock,0) = 0 then 1
			else 0 end nostock 
		,
		case 
			when ISNULL(stockchcek.AvailableStock,0) >= ((stockchcek.RQ_QTY_ - stockchcek.CANCELED_QTY_) - isnull(stockchcek.FF_QTY_,0)) then 1
			else 0 end availablestock 
		,
		case 
			when ISNULL(stockchcek.AvailableStock,0) > 0 AND ISNULL(stockchcek.AvailableStock,0) < ((stockchcek.RQ_QTY_ - stockchcek.CANCELED_QTY_) - isnull(stockchcek.FF_QTY_,0)) then 1
			else 0 end partialyavailable


		from
			(
			SELECT        loanReqItem.ITEM_ID, loanReqItem.RQ_QTY_, loanReqItem.FF_QTY_, ISNULL(loanReqItem.CL_QTY_, 0) AS CANCELED_QTY_, loanReqItem.STATUS_
									, dbo.GetAvailableStock(loanReqItem.ITEM_ID, loanReq.FF_L2_ID, loanReq.FF_STORE_ID, loanReqItem.IN_LIEU_, 0, loanReq.FF_CMD_ID) AS AvailableStock
				FROM            LOG_TRN_ELM_EXTERNAL_LOAN AS loanReq INNER JOIN
										 LOG_TRN_ELM_LOAN_ITEM AS loanReqItem ON loanReq.ID_ = loanReqItem.EL_ID
				WHERE        (loanReq.ID_ =@loanRequestId) AND
				(loanReqItem.STATUS_ IN ('Submitted', 'Validated', 'Approved',  'PartiallyFulfilled'))
			) as stockchcek
		) as tmp

	RETURN @result
END
go

