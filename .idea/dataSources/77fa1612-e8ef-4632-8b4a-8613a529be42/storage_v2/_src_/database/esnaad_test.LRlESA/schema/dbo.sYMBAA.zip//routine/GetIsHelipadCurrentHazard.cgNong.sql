CREATE FUNCTION [dbo].[GetIsHelipadCurrentHazard]
(
  @assessmentId uniqueidentifier
)
  RETURNS bit
AS
BEGIN
  DECLARE @result bit;

  select @result = cast(iif(ra.ASSESSMENT_NO_=x.ASSESSMENT_NO_, 1, 0) as bit)
  from ADM_TRN_RA_RISK_ASSESSMENT ra
		left join ADM_TRN_RA_RISK_DETAILS_HELIPAD h on h.ASSESSMENT_ID_ = ra.ID_
		left join (
			select h1.HELIPAD_ID,  max(ra1.ASSESSMENT_NO_) as ASSESSMENT_NO_
			from ADM_TRN_RA_RISK_ASSESSMENT ra1
				join ADM_TRN_RA_RISK_DETAILS_HELIPAD h1 on h1.ASSESSMENT_ID_ = ra1.ID_
				join ADM_TRN_RA_RISK_HAZARD hz on hz.ASSESSMENT_ID_ = ra1.ID_
			where upper(ra1.STATUS_) NOT IN ('DRAFTED','REJECTED')
			group by h1.HELIPAD_ID
		) x on x.HELIPAD_ID = h.HELIPAD_ID
  where ra.ID_ = @assessmentId;

  RETURN @result
END;
go

