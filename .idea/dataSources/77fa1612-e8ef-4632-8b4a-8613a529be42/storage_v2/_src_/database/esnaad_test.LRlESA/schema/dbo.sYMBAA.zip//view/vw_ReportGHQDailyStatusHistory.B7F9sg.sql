CREATE VIEW [dbo].[vw_ReportGHQDailyStatusHistory]
AS
SELECT     TOP (100) PERCENT H.TAIL_NUM_ AS TailNo, P.ID_ AS PlatformID, H.PLTF_ AS Platform, R.PRNT_ID AS ParentID, RR.NAME_ AS Command, H.STAT_ AS Status, 
                      H.COND_ AS Condition, H.REMARKS_ AS Remarks, DS.DESC_ AS Deploy, R.ID_ AS BattalionID, H.BATT_ AS Battalion, US.ID_ AS ProfileID, 
                      H.CREATED_BY_ AS UserID, H.CREATED_ON_ AS AsvcDate, UR.MODULE_ID AS ModuleID, P.EN_SHORT_NAME_ As PlatformDesc
FROM         dbo.MNT_HST_AIRCRAFT_SERVS AS H INNER JOIN
                      dbo.ADM_MST_PLATFORMS AS P ON H.PLTF_ = P.CODE_ INNER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS DS ON H.DEPL_ = DS.CODE_ AND DS.GRP_ = 'MNT.DPS' INNER JOIN
                      dbo.ADM_MST_RESTRICTIONS AS R ON H.BATT_ = R.CODE_ AND UPPER(R.TYPE_NAME_) = 'BATTALION' INNER JOIN
                      dbo.ADM_MST_RESTRICTIONS AS RR ON R.PRNT_ID = RR.ID_ INNER JOIN
                      dbo.ADM_TRN_USER_PROFILES AS US ON H.CREATED_BY_ = US.USER_ID_ INNER JOIN
                      dbo.ADM_TRN_USER_RESTRICTIONS AS UR ON US.ID_ = UR.USER_PROFILE_ID INNER JOIN
                      dbo.ADM_TRN_USER_PLATFORM_RESTRICION_DETAILS AS UPR ON P.ID_ = UPR.PLATFORM_ID AND UPR.USR_REST_ID = UR.ID_
ORDER BY P.ORDER_, TailNo
go

