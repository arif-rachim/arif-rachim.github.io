CREATE PROC [dbo].[GetInspectionListReport]
       @TailIds      varchar(max)
AS

DECLARE @TailIdsTable TABLE (TAIL_ID BIGINT);

INSERT @TailIdsTable
SELECT Item
  FROM dbo.SplitInts(@TailIds, ',');


--SELECT * FROM
--(
       SELECT
              TAILS.T_NUM_                      As TailNo,
              PLATFORMS.CODE_                          As ACType,
              BATT.CODE_                               As Battalion,
              INSPMASTER.INSP_NUMBER_           As InspNumber,
              INSPMASTER.INSP_NAME_             As InspName,
              INSPMASTER.INSP_REF_       As InspReference,
              INSPMASTER.INT_DUR_UNIT_   As Frequceny,
              INSPMASTER.INT_DUR_VALUE_  As Interval,
			  ISNULL(CAT.NAME_,ITEMS.NOMENCLATURE_)    As Nomenclature,
              REPLACE(CONVERT(NVARCHAR(11), CONVERT(NVARCHAR, INSPASSIGN.DUE_DATE_, 113)), ' ', '-') As NextDue,
              INSPMASTER.ORDER_ As SortOrder
       FROM @TailIdsTable AS TailsTable
                                  INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                            INNER JOIN ADM_MST_RESTRICTIONS BATT                                ON TAILS.BATLN_ID = BATT.ID_
                                                INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                                INNER JOIN ADM_MST_ITEMS ITEMS                                              ON UNITS.ITEM_ID = ITEMS.ID_
                                                INNER JOIN ADM_MST_PLATFORMS PLATFORMS                               ON ITEMS.ID_ = PLATFORMS.ID_
                                                INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER              ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
                                                INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN   ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
												LEFT JOIN ADM_MST_PLTF_CATEGORY CAT   ON PLATFORMS.PLTF_CAT_ID=CAT.ID_
       WHERE
                     INSPMASTER.INT_DUR_UNIT_ IS NOT NULL
              --AND  TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',')   )

       UNION ALL
       SELECT
              TAILS.T_NUM_                      As TailNo,
              PLATFORMS.CODE_                          As ACType,
              BATT.CODE_                               As Battalion,
              INSPMASTER.INSP_NUMBER_           As InspNumber,
              INSPMASTER.INSP_NAME_             As InspName,
              INSPMASTER.INSP_REF_       As InspReference,
	          'Hours'                                         As Frequceny,
              INSPMASTER.INT_DUR_HOURS_  As Interval,
			  ISNULL(CAT.NAME_,ITEMS.NOMENCLATURE_)    As Nomenclature,
              CONVERT(varchar,CONVERT(decimal(10, 1), INSPASSIGN.DUE_HOURS_))            As NextDue,
              INSPMASTER.ORDER_ As SortOrder
       FROM @TailIdsTable AS TailsTable
                                  INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                            INNER JOIN ADM_MST_RESTRICTIONS BATT                                ON TAILS.BATLN_ID = BATT.ID_
                                                INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                                INNER JOIN ADM_MST_ITEMS ITEMS                                              ON UNITS.ITEM_ID = ITEMS.ID_
                                                INNER JOIN ADM_MST_PLATFORMS PLATFORMS                               ON ITEMS.ID_ = PLATFORMS.ID_
                                                INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER              ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
                                                INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN   ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
												LEFT JOIN ADM_MST_PLTF_CATEGORY CAT   ON PLATFORMS.PLTF_CAT_ID=CAT.ID_
       WHERE
                     INSPMASTER.INT_DUR_HOURS_ IS NOT NULL
       --AND TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ','))

       UNION ALL
       SELECT
              TAILS.T_NUM_                      As TailNo,
              PLATFORMS.CODE_                          As ACType,
              BATT.CODE_                               As Battalion,
              INSPMASTER.INSP_NUMBER_           As InspNumber,
              INSPMASTER.INSP_NAME_             As InspName,
              INSPMASTER.INSP_REF_       As InspReference,
			  CASE INT_OTHER_
                     WHEN 'BeforeFlight' THEN 'BEFORE FLIGHT'
                     WHEN 'AfterFlight' THEN 'AFTER FLIGHT'
              END                                             As Frequceny,
              NULL                                     As Interval,
			  ISNULL(CAT.NAME_,ITEMS.NOMENCLATURE_)    As Nomenclature,
              CONVERT(varchar,INSPASSIGN.DUE_HOURS_)          As NextDue,
              INSPMASTER.ORDER_ As SortOrder
       FROM @TailIdsTable AS TailsTable
                                  INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                            INNER JOIN ADM_MST_RESTRICTIONS BATT                                ON TAILS.BATLN_ID = BATT.ID_
                                                INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                                INNER JOIN ADM_MST_ITEMS ITEMS                                              ON UNITS.ITEM_ID = ITEMS.ID_
                                                INNER JOIN ADM_MST_PLATFORMS PLATFORMS                               ON ITEMS.ID_ = PLATFORMS.ID_
                                                INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER              ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
                                                INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN   ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
												LEFT JOIN ADM_MST_PLTF_CATEGORY CAT   ON PLATFORMS.PLTF_CAT_ID=CAT.ID_
       WHERE
                     INSPMASTER.INT_OTHER_ IS NOT NULL
       --AND TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ','))
	    UNION ALL
	    SELECT
              TAILS.T_NUM_                      As TailNo,
              PLATFORMS.CODE_                          As ACType,
              BATT.CODE_                               As Battalion,
              INSPMASTER.INSP_NUMBER_           As InspNumber,
              INSPMASTER.INSP_NAME_             As InspName,
              INSPMASTER.INSP_REF_       As InspReference,
	          'L'                                         As Frequceny,
              INSPMASTER.INT_DUR_LANDINGS_  As Interval,
			  ISNULL(CAT.NAME_,ITEMS.NOMENCLATURE_)    As Nomenclature,
              CONVERT(varchar,INSPASSIGN.DUE_LANDINGS_)            As NextDue,
              INSPMASTER.ORDER_ As SortOrder
       FROM @TailIdsTable AS TailsTable
                                  INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                            INNER JOIN ADM_MST_RESTRICTIONS BATT                                ON TAILS.BATLN_ID = BATT.ID_
                                                INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                                INNER JOIN ADM_MST_ITEMS ITEMS                                              ON UNITS.ITEM_ID = ITEMS.ID_
                                                INNER JOIN ADM_MST_PLATFORMS PLATFORMS                               ON ITEMS.ID_ = PLATFORMS.ID_
                                                INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER              ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
                                                INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN   ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
												LEFT JOIN ADM_MST_PLTF_CATEGORY CAT   ON PLATFORMS.PLTF_CAT_ID=CAT.ID_
       WHERE
                  (INSPMASTER.INT_DUR_LANDINGS_ is not null )
		 UNION ALL
	    SELECT
              TAILS.T_NUM_                      As TailNo,
              PLATFORMS.CODE_                          As ACType,
              BATT.CODE_                               As Battalion,
              INSPMASTER.INSP_NUMBER_           As InspNumber,
              INSPMASTER.INSP_NAME_             As InspName,
              INSPMASTER.INSP_REF_       As InspReference,
	          'LC'                                         As Frequceny,
              INSPMASTER.INT_DUR_CYCLES_  As Interval,
			  ISNULL(CAT.NAME_,ITEMS.NOMENCLATURE_)    As Nomenclature,
              CONVERT(varchar,INSPASSIGN.DUE_CYCLES_)            As NextDue,
              INSPMASTER.ORDER_ As SortOrder
       FROM @TailIdsTable AS TailsTable
                                  INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                            INNER JOIN ADM_MST_RESTRICTIONS BATT                                ON TAILS.BATLN_ID = BATT.ID_
                                                INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                                INNER JOIN ADM_MST_ITEMS ITEMS                                              ON UNITS.ITEM_ID = ITEMS.ID_
                                                INNER JOIN ADM_MST_PLATFORMS PLATFORMS                               ON ITEMS.ID_ = PLATFORMS.ID_
                                                INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER              ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
                                                INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN   ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
												LEFT JOIN ADM_MST_PLTF_CATEGORY CAT   ON PLATFORMS.PLTF_CAT_ID=CAT.ID_
       WHERE
                   (INSPMASTER.INT_DUR_CYCLES_ is not null )
 UNION ALL
	    SELECT
              TAILS.T_NUM_                      As TailNo,
              PLATFORMS.CODE_                          As ACType,
              BATT.CODE_                               As Battalion,
              INSPMASTER.INSP_NUMBER_           As InspNumber,
              INSPMASTER.INSP_NAME_             As InspName,
              INSPMASTER.INSP_REF_       As InspReference,
	          'EC'                                         As Frequceny,
              INSPMASTER.INT_DUR_EQP_CYCLES_  As Interval,
			  ISNULL(CAT.NAME_,ITEMS.NOMENCLATURE_)    As Nomenclature,
               CONVERT(varchar,INSPASSIGN.DUE_EQP_CYCLES_)            As NextDue,
              INSPMASTER.ORDER_ As SortOrder
       FROM @TailIdsTable AS TailsTable
                                  INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                            INNER JOIN ADM_MST_RESTRICTIONS BATT                                ON TAILS.BATLN_ID = BATT.ID_
                                                INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                                INNER JOIN ADM_MST_ITEMS ITEMS                                              ON UNITS.ITEM_ID = ITEMS.ID_
                                                INNER JOIN ADM_MST_PLATFORMS PLATFORMS                               ON ITEMS.ID_ = PLATFORMS.ID_
                                                INNER JOIN MNT_TRN_INSPECTION_MASTERS INSPMASTER              ON PLATFORMS.ID_ = INSPMASTER.PLTF_ID
                                                INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS INSPASSIGN   ON INSPMASTER.ID_ = INSPASSIGN.INSP_MST_ID AND UNITS.ID_ = INSPASSIGN.UNIT_ID
												LEFT JOIN ADM_MST_PLTF_CATEGORY CAT   ON PLATFORMS.PLTF_CAT_ID=CAT.ID_
       WHERE
                  (INSPMASTER.INT_DUR_EQP_CYCLES_ is not null)
--) TailInspections


ORDER BY TailNo, SortOrder
OPTION (FORCE ORDER);

SELECT * FROM dbo.ReturnTailHeader(@TailIds)
go

