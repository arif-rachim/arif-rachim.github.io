CREATE FUNCTION [dbo].[ConvertDateToCompleteString]
(
	-- Add the parameters for the function here
	@searchDate DateTime
)
RETURNS Varchar(21)
AS
BEGIN
	return (CASE WHEN LEN(convert(varchar(2), datepart(dd, @searchDate))) = 1 THEN '0' + convert(varchar(2), datepart(dd, @searchDate)) ELSE convert(varchar(2), datepart(dd, @searchDate)) END)
	+ '-' + convert(varchar(3), datename(m, @searchDate)) 
	+ '-' + convert(varchar(4), datepart(yyyy, @searchDate))
	+ ' ' + (CASE WHEN LEN(convert(varchar(2), datepart(HH, @searchDate))) = 1 THEN '0' + convert(varchar(2), datepart(HH, @searchDate)) ELSE convert(varchar(2), datepart(HH, @searchDate)) END)
	+ ':' + (CASE WHEN LEN(convert(varchar(2), datepart(mi, @searchDate))) = 1 THEN '0' + convert(varchar(2), datepart(mi, @searchDate)) ELSE convert(varchar(2), datepart(mi, @searchDate)) END)
	+ ':' + (CASE WHEN LEN(convert(varchar(2), datepart(ss, @searchDate))) = 1 THEN '0' + convert(varchar(2), datepart(ss, @searchDate)) ELSE convert(varchar(2), datepart(ss, @searchDate)) END)

END
go

