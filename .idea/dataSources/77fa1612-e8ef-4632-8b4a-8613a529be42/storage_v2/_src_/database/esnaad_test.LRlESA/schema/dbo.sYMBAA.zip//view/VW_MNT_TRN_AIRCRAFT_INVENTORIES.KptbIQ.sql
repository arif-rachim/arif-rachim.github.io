CREATE VIEW [dbo].[VW_MNT_TRN_AIRCRAFT_INVENTORIES] AS
select * from 
(
	select s.id_ as status_id, s.S_DESC_ as code_, s.order_, d.HOURS_ as HRS_, 'Hours' as Type_, 
	datepart(day, d.DATE_) day_,
	datepart(month, d.DATE_) month_,
	left(datename(month, d.DATE_),3) month_text_,
	year(d.DATE_) year_,
	--r.ARCFT_ID_ as tail_id,
	t.id_ as tail_id
	FROM 
	adm_mst_simple_ref s LEFT OUTER JOIN 
	MNT_TRN_AIRCRAFT_INVENTORIES d ON s.id_ = d.COND_ID  INNER JOIN 
	adm_mst_units u  ON u.ID_ = d.AIRCRAFT_ID inner join
	adm_mst_tails t ON t.UNIT_ID = u.ID_ 
	WHERE s.grp_ = 'MNT.AIRROW' 
) as src
PIVOT
(
	MAX(HRS_)
	--MAX(ConditionCode_)
	--case 1=1 then MAX(ConditionCode_) else 0 end
	for day_ in ([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15], [16], [17], [18], [19], [20], [21], [22], [23], [24], [25], [26], [27], [28], [29], [30], [31])
) as pivots
go

