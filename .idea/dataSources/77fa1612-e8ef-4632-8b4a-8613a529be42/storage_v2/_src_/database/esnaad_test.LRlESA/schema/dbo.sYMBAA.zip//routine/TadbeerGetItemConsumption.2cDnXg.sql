CREATE FUNCTION [dbo].[TadbeerGetItemConsumption]
  (
    @item_id bigint,
    @year int,

    @cmdId bigint = 0,
    @buId bigint = 0
    )
  RETURNS bigint
  AS
  BEGIN

    DECLARE @CONSUMPTION BIGINT

    SELECT @CONSUMPTION = SUM((CH.TOTAL_ISSUE_ - CH.TOTAL_TURN_IN_))
    FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY CH
    WHERE CH.ITEM_ID = @item_id
      AND CH.YEAR = @year
      AND CH.CMD_ID = (CASE WHEN @cmdId > 0 THEN @cmdId ELSE CH.CMD_ID END)
      AND CH.BU_ID_ = (CASE WHEN @buId > 0 THEN @buId ELSE CH.BU_ID_ END)

    RETURN ISNULL(@CONSUMPTION, 0)

  END
go

