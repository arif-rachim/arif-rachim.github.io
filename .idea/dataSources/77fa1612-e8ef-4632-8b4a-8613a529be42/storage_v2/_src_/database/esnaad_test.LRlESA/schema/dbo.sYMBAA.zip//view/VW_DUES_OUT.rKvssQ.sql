CREATE VIEW [dbo].[VW_DUES_OUT] AS
select eli.ITEM_ID     ITEM_ID_
      ,'Store'         DUES_OUT_TO_
      ,'ExternalLoan'  DUES_OUT_TYPE_
      ,el.LOAN_NO_     TR_NO_
      ,el.CMD_ID       RQ_CMD_ID_
      ,el.RQ_BU_ID     RQ_BU_ID_
      ,el.RQ_L2_ID     RQ_L2_ID_
      ,el.FF_CMD_ID    FF_CMD_ID_
      ,el.FF_STORE_ID  FF_BU_ID_
      ,el.FF_L2_ID     FF_L2_ID_
      ,(isnull(eli.RQ_QTY_,0) -  isnull(eli.FF_QTY_,0) - isnull(eli.CL_QTY_,0)) QTY_
      ,el.CREATED_BY_  REQUESTED_BY_
      ,el.CREATED_ON_  REQUESTED_ON_
  from LOG_TRN_ELM_EXTERNAL_LOAN el
       join WF_TRN_INSTANCE wf on el.WF_ID = wf.ID_ AND wf.WF_DEF_ID_='ExternalLoanWorkflow'
       join LOG_TRN_ELM_LOAN_ITEM eli on el.ID_ = eli.EL_ID
       join ADM_MST_BUSINESS_UNITS fbu on el.FF_STORE_ID = fbu.ID_ and fbu.IS_ACTIVE_ = 1
 where wf.WF_DEF_ID_ = 'ExternalLoanWorkflow'
   and wf.WF_STS_ = 'Active'
   AND ((wf.WF_STATE_ = 'Created' AND el.IS_ORIGIN_BU_VALIDATE_REQUIRED_ = 0 AND  el.IS_ORIGIN_BU_APPROVAL_REQUIRED_ = 0 AND el.IS_DESTINATION_BU_VALIDATE_REQUIRED_ = 0  AND el.IS_DESTINATION_BU_APPROVAL_REQUIRED_ = 0 )
        OR (wf.WF_STATE_ IN ('PartiallyFulfilled', 'Validated','Approved', 'ValidatedByFulfiller', 'ApprovedByFulfiller') AND wf.WF_STATE_ != 'Created'))
   and eli.STATUS_ in ('Validated','Approved', 'PartiallyFulfilled')
   and (eli.RQ_QTY_ - eli.FF_QTY_ - eli.CL_QTY_) > 0
 union all
select tri.ITEM_ID     ITEM_ID_
      ,'Store'         DUES_OUT_TO_
      ,'StoreTransfer' DUES_OUT_TYPE_
      ,tr.TR_NO_       TR_NO_
      ,tr.RI_CMD_ID_   RQ_CMD_ID_
      ,tr.RI_BU_ID_    RQ_BU_ID_
      ,tr.RI_L2_ID_    RQ_L2_ID_
      ,tr.FI_CMD_ID_   FF_CMD_ID_
      ,tr.FI_BU_ID_    FF_BU_ID_
      ,tr.FI_L2_ID_    FF_L2_ID_
      ,(isnull(tri.REQ_QTY_,0) - isnull(tri.ISSUED_QTY_,0) - isnull(tri.CANCELED_QTY_,0)) QTY_
      ,tr.CREATED_BY_  REQUESTED_BY_
      ,tr.CREATED_ON_  REQUESTED_ON_
  from LOG_TRN_TRM_TRANSFER_REQUEST tr
       join LOG_TRN_TRM_TRANSFER_REQUEST_ITEM tri on tr.ID_ = tri.TR_ID_
       join WF_TRN_INSTANCE wfi on tr.WF_ID = wfi.ID_ AND wfi.WF_DEF_ID_='StoreTransferWorkflow'
       join ADM_MST_BUSINESS_UNITS fbu on tr.FI_BU_ID_ = fbu.ID_ and fbu.IS_ACTIVE_ = 1
 where tr.TR_TYPE_ = 'StoreTransfer'
   and wfi.WF_DEF_ID_ = 'StoreTransferWorkflow'
   and wfi.WF_STS_ = 'Active'
   AND ((wfi.WF_STATE_ = 'Created' AND tr.IS_ORIGIN_BU_VALIDATE_REQUIRED_ = 0 AND   tr.IS_ORIGIN_BU_APPROVAL_REQUIRED_ = 0 AND tr.IS_DESTINATION_BU_VALIDATE_REQUIRED_ = 0  AND tr.IS_DESTINATION_BU_APPROVAL_REQUIRED_ = 0)
        OR (wfi.WF_STATE_ IN ('PartiallyFulfilled', 'Validated','Approved', 'ValidatedByFulfiller', 'ApprovedByFulfiller') AND wfi.WF_STATE_ != 'Created'))
   and tri.FF_STATUS_ in ('NotFulfilled', 'PartiallyFulfilled')
 union all
select tri.ITEM_ID ITEM_ID_
      ,'User'          DUES_OUT_TO_
      ,'Requisition'   DUES_OUT_TYPE_
      ,tr.TR_NO_       TR_NO_
      ,tr.RI_CMD_ID_   RQ_CMD_ID_
      ,tr.RI_BU_ID_    RQ_BU_ID_
      ,tr.RI_L2_ID_    RQ_L2_ID_
      ,tr.FI_CMD_ID_   FF_CMD_ID_
      ,tr.FI_BU_ID_    FF_BU_ID_
      ,tr.FI_L2_ID_    FF_L2_ID_
      ,(isnull(tri.REQ_QTY_,0) - isnull(tri.ISSUED_QTY_,0) - isnull(tri.CANCELED_QTY_,0)) QTY_
      ,tr.CREATED_BY_  REQUESTED_BY_
      ,tr.CREATED_ON_  REQUESTED_ON_
  from LOG_TRN_TRM_TRANSFER_REQUEST tr
       join LOG_TRN_TRM_TRANSFER_REQUEST_ITEM tri on tr.ID_ = tri.TR_ID_
       join WF_TRN_INSTANCE wfi on tr.WF_ID = wfi.ID_ AND wfi.WF_DEF_ID_='RequisitionWorkflow'
       join ADM_MST_BUSINESS_UNITS fbu on tr.FI_BU_ID_ = fbu.ID_ and fbu.IS_ACTIVE_ = 1
       --left outer join LOG_MST_TRM_REQUISITION_CONFIG config on tr.RI_CMD_ID_ = config.CMD_ID
 where tr.TR_TYPE_ = 'Requisition'
   and wfi.WF_DEF_ID_ = 'RequisitionWorkflow'
   and wfi.WF_STS_ = 'Active'
   and wfi.WF_STATE_ in (
          'PartiallyFulfilled'
         ,'Approved'
         ,case when (wfi.WF_STATE_ = 'Validated' and (isnull(tr.IS_APPROVAL_REQUIRED_, 0) = 1)) then 'ToBeApproved' 
               else 'Validated'
           end
         )
   and tri.FF_STATUS_ in ('NotFulfilled', 'PartiallyFulfilled');
go

