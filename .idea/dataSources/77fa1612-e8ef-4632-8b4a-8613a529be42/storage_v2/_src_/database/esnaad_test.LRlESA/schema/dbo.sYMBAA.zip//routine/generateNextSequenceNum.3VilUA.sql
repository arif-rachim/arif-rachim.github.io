
-- =============================================
-- Author:		GAL2723
-- Create date: 19-Mar-2014
-- Description:	Generate next sequence number from string
-- =============================================
create FUNCTION [dbo].[generateNextSequenceNum] (@fullSeqNumStr VARCHAR(MAX), @prefixLength INT)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @prefixStr VARCHAR(1024);
	DECLARE @newSeqNumStr VARCHAR(1024);
	DECLARE @seqNum INT;
	DECLARE @seqNumStrLength INT = LEN(@fullSeqNumStr) - @prefixLength;
	
	SELECT TOP (1) 
		@prefixStr = SUBSTRING(@fullSeqNumStr, 1, @prefixLength)
		,@seqNum = CAST(SUBSTRING(@fullSeqNumStr, (@prefixLength + 1), @seqNumStrLength) AS INT)
	
	SET @seqNum = @seqNum + 1;
	SET @newSeqNumStr = @prefixStr + RIGHT('00000000000' + RTRIM(CAST(@seqNum AS VARCHAR)), 6);

	RETURN @newSeqNumStr;
END

-- SELECT dbo.generateNextSequenceNum('SI2014000024', 6);


go

