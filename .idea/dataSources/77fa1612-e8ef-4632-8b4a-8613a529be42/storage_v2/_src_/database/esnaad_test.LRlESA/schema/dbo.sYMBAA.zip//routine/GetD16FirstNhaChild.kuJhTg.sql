CREATE FUNCTION [dbo].[GetD16FirstNhaChild] (@AssignedComponentId uniqueidentifier)
RETURNS TABLE
AS RETURN
	WITH AssignedComponent AS
        (
            SELECT ac.ID_, ac.COMP_ID_,mc.REPLACE_NHA_, mc.LEVEL_
            FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
            JOIN MNT_MST_D16_MASTER_COMPONENT mc ON mc.ID_ = ac.MASTER_COMP_ID_
            WHERE ac.ID_ = @AssignedComponentId
            UNION ALL
            SELECT c_ac.ID_, c_ac.COMP_ID_, mc.REPLACE_NHA_, mc.LEVEL_
            FROM MNT_TRN_D16_ASSIGNED_COMPONENT c_ac
            JOIN MNT_MST_D16_MASTER_COMPONENT mc ON mc.ID_ = c_ac.MASTER_COMP_ID_
            JOIN AssignedComponent ac ON ac.COMP_ID_ = c_ac.PARENT_COMP_ID_ AND c_ac.IS_ACTIVE_ = 1
        )
    SELECT top(1) ac.ID_ FROM AssignedComponent ac
      WHERE ac.REPLACE_NHA_ = 1
      ORDER BY LEVEL_ ASC
go

