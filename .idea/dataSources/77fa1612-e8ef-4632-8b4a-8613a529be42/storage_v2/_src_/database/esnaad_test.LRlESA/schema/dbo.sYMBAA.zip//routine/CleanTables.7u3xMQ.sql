CREATE PROCEDURE [dbo].[CleanTables]
	-- Add the parameters for the stored procedure here
	@tableNames nvarchar(1000)
AS
BEGIN
	DECLARE @deleteTable AS VARCHAR(500);
	DECLARE @separator AS VARCHAR(5) = ',';
	DECLARE @separatorPosition AS INT;

	SET @tableNames = @tableNames + @separator;

	SET @separator = '%' + @separator + '%';
	SET @separatorPosition = PATINDEX(@separator, @tableNames);

	WHILE @separatorPosition <> 0
	BEGIN
		SET @deleteTable = 'DELETE FROM ' + LEFT(@tableNames, @separatorPosition - 1);
		EXEC(@deleteTable);
		
		SET @tableNames = STUFF(@tableNames, 1, @separatorPosition, '')
		SET @separatorPosition = PATINDEX(@separator, @tableNames);
	END;
END
go

