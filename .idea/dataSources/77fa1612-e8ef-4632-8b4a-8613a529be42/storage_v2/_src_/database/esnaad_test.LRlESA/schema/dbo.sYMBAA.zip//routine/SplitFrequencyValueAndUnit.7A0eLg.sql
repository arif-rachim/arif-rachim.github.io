

-- ============================================================
-- Author:		gal2723
-- Create date: 18-Mar-2015
-- Description:	Get Aircraft Inventory Report Total Hours of a condition For a period

-- Ex: 
-- SELECT dbo.SplitFrequencyValueAndUnit('100.0000 H', 'UNIT')  ==> 'H'
-- SELECT dbo.SplitFrequencyValueAndUnit('100.0000 H', 'VALUE') ==> '100.00'
-- ============================================================

CREATE FUNCTION [dbo].[SplitFrequencyValueAndUnit]
(
	@freqFullStr_In VARCHAR(MAX), -- Ex: '100.0000 H'
	@returnType VARCHAR(MAX) -- Ex: 'UNIT',  or  'VALUE'
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @result VARCHAR(MAX)
	DECLARE	@freqValue varchar(MAX);
	DECLARE	@freqUnit varchar(MAX);
	
	DECLARE @strLength INT;
	DECLARE @freqValueStr VARCHAR(MAX);
	
	SET @strLength = CHARINDEX(' ', @freqFullStr_In) - 1
	SET @freqValueStr = substring(@freqFullStr_In, 1, @strLength)
	
	SET @freqUnit = substring(@freqFullStr_In, @strLength + 2, 1)
	SET @freqValue = CAST(CAST(@freqValueStr AS MONEY) AS VARCHAR(MAX))

	IF @returnType = 'UNIT'
		SET @result = @freqUnit
	ELSE
		SET @result = @freqValue
	
	RETURN @result
END

go

