CREATE PROCEDURE [dbo].[GetGHQFleetServiceabilityReport]
      -- Add the parameters for the stored procedure here
      @input_date datetime,
      @include bit,
	  @commandId int,
	  @userId bigint
AS

BEGIN
      -- SET NOCOUNT ON added to prevent extra result sets from
      -- interfering with SELECT statements.
      SET NOCOUNT ON;
            
      --
      DECLARE @FMC int = 32
      DECLARE @PMCM int = 36
      DECLARE @PMCS int = 37
      DECLARE @DEPOT int = 33
      DECLARE @NMCM int = 34
      DECLARE @NMCS int = 35
      
      -- Insert statements for procedure here
     -- if(@exclude = 1)
     -- BEGIN 
     -- SELECT DISTINCT s.PlatformId, s.ApplicabilityName, UPPER(t.REMARKS_) as Remarks, t.MTO_ as Mto, s.ParentId, s.ProfileId, s.UserID, s.PlatformOrder, s.ModuleID,
     --          dbo.GetConditionCountExcludeDeployed2(s.PlatformVar, s.PlatformId, 1, @input_date) AS McCount,
     --          dbo.GetConditionCountExcludeDeployed2(s.PlatformVar, s.PlatformId, 0, @input_date)  AS NmcCount
     -- FROM [dbo].[vw_ReportGHQFleetServiceability] s inner join [TMP_RPT_MNT_GHQ_FLEET_SERVICEABILITY_REPORT_TEMPDATA] t ON
     -- s.PlatformId = t.PLATFORM_ID_  and s.ProfileId = t.USER_PROFILE_ID_
     -- order by s.ApplicabilityName 
     -- END
     -- ELSE
     --BEGIN
     --       SELECT DISTINCT s.PlatformId, s.ApplicabilityName, UPPER(t.REMARKS_) as Remarks, t.MTO_ as Mto, s.ParentId, s.ProfileId, s.UserID, s.PlatformOrder, s.ModuleID,
     --          dbo.GetConditionCount2(s.PlatformVar, s.PlatformId, 1, @input_date) AS McCount,
     --          dbo.GetConditionCount2(s.PlatformVar, s.PlatformId, 0, @input_date) AS NmcCount
     -- FROM [dbo].[vw_ReportGHQFleetServiceability] s inner join [TMP_RPT_MNT_GHQ_FLEET_SERVICEABILITY_REPORT_TEMPDATA] t ON
     -- s.PlatformId = t.PLATFORM_ID_  and s.ProfileId = t.USER_PROFILE_ID_
     -- order by s.ApplicabilityName 
     -- END


	if(@include = 0)
    BEGIN 
      select s.PlatformId,
				CASE WHEN PlatformVariantId IS NULL THEN ISNULL(p.EN_SHORT_NAME_, '') + ' ' + ISNULL(p.AR_LONG_NAME_, '') 
					 ELSE ISNULL(p_var.PLTF_ALIAS_CODE_, '') + ' ' + ISNULL(p_var.PLTF_ALIAS_AR_LONG_NAME_, '') 
				END AS ApplicabilityName,
				s.Remarks,
				s.Mto,
				s.ParentId,
				s.UserProfileId as ProfileId,
				s.UserId as UserID,
				p.ORDER_ as PlatformOrder,
				[dbo].[GetConditionCountExcludeDeployed2](s.PlatformVariantId, s.ParentId, s.PlatformId, 1, @input_date) AS McCount,
				[dbo].[GetConditionCountExcludeDeployed2](s.PlatformVariantId, s.ParentId, s.PlatformId, 0, @input_date) AS NmcCount
		from (
			SELECT distinct
				PLTFM.ID_ AS PlatformId, PLTFM.CODE_ AS Platform, UP.ID_ AS UserProfileId, UP.USER_ID_ AS UserId, FLTRPT.REMARKS_ AS Remarks, FLTMTORPT.MTO_ AS Mto, FLTRPT.PLTF_VARIANT_ID AS PlatformVariantId
				,r.PRNT_ID as ParentId
			FROM 
			    MNT_TRN_GHQ_FLEET_MTO_RPTS AS FLTMTORPT  LEFT JOIN        
				MNT_TRN_GHQ_FLEET_RPTS AS FLTRPT on FLTRPT.PLTF_ID=FLTMTORPT.PLTF_ID and FLTRPT.PLTF_VARIANT_ID is null and FLTRPT.CMD_ID=FLTMTORPT.CMD_ID AND FLTRPT.USER_ID = @userId LEFT JOIN
				ADM_TRN_USER_PROFILES AS UP ON FLTRPT.USER_ID = UP.ID_  RIGHT OUTER JOIN
				ADM_MST_PLATFORMS AS PLTFM ON FLTMTORPT.PLTF_ID = PLTFM.ID_ AND FLTRPT.PLTF_VARIANT_ID is null --and FLTMTORPT.CMD_ID=@commandId
				join ADM_MST_ITEMS i on i.ID_ = PLTFM.ID_
				join ADM_MST_UNITS u on u.ITEM_ID = i.ID_
				join ADM_MST_TAILS t on t.UNIT_ID = u.ID_
				join ADM_MST_RESTRICTIONS r on r.ID_ = t.BATLN_ID  and FLTMTORPT.CMD_ID = r.PRNT_ID
			where (@commandId = 0 or r.PRNT_ID = @commandId) and FLTMTORPT.PLTF_VARIANT_ID is  null
				  and PLTFM.ID_ IN ( 
					SELECT PLF.ID_
					FROM ADM_TRN_SEC_ROLE_ACL_DETAIL dacl 
							INNER JOIN ADM_TRN_SEC_ROLE_ACL roleacl on dacl.ROLE_ACL_ID = roleacl.id_ AND roleacl.MDL_ID = 'MNT.001.00.00.00' 
							INNER JOIN ADM_TRN_SEC_ROLE role on roleacl.ROLE_ID = role.id_ 
							INNER JOIN ADM_TRN_SEC_ROLE_ASSIGNMENT roleassignment on roleassignment.ROLE_ID = role.id_ and roleassignment.USR_PRF_ID = @userId
							INNER JOIN ADM_MST_PLATFORMS AS PLF ON PLF.ID_ = dacl.TYPE_ID_ AND dacl.TYPE_ = 'Platform' 
							INNER JOIN ADM_MST_ITEMS AS ITEM ON ITEM.ID_ = PLF.ID_ 
							INNER JOIN ADM_MST_UNITS AS UNITS ON UNITS.ITEM_ID = ITEM.ID_
							INNER JOIN ADM_MST_TAILS AS TAILS ON TAILS.UNIT_ID = UNITS.ID_
							INNER JOIN ADM_MST_RESTRICTIONS AS BTN ON BTN.ID_ = TAILS.BATLN_ID 
							INNER JOIN ADM_MST_RESTRICTIONS AS CMD ON CMD.ID_ = BTN.PRNT_ID
					WHERE (@commandId = 0 or CMD.ID_ = @commandId) AND TAILS.END_DATE_='9999-12-31'
					GROUP BY PLF.ID_			 
				  )
				  and r.PRNT_ID in (
					select dacl.TYPE_ID_ FROM ADM_TRN_SEC_ROLE_ACL_DETAIL dacl 
					INNER JOIN ADM_TRN_SEC_ROLE_ACL roleacl on dacl.ROLE_ACL_ID = roleacl.id_ AND roleacl.MDL_ID = 'MNT.001.00.00.00' 
					INNER JOIN ADM_TRN_SEC_ROLE role on roleacl.ROLE_ID = role.id_ 
					INNER JOIN ADM_TRN_SEC_ROLE_ASSIGNMENT roleassignment on roleassignment.ROLE_ID = role.id_ and roleassignment.USR_PRF_ID = @userId
					where dacl.TYPE_='MilitaryUnit'
				  )
			union
			select  
				PLTFM.ID_ AS PlatformId, PLTFM.PLTF_ALIAS_CODE_ AS Platform, UP.ID_ AS UserProfileId, UP.USER_ID_ AS UserId, FLTRPT.REMARKS_ AS Remarks, FLTMTORPT.MTO_ AS Mto, PLTFM.PlatformVariantId AS PlatformVariantId     
				 , CommandId as ParentId
			from 
			    MNT_TRN_GHQ_FLEET_MTO_RPTS AS FLTMTORPT  LEFT JOIN  
				MNT_TRN_GHQ_FLEET_RPTS AS FLTRPT on FLTRPT.PLTF_ID=FLTMTORPT.PLTF_ID and FLTRPT.PLTF_VARIANT_ID is NOT null and FLTRPT.CMD_ID=FLTMTORPT.CMD_ID AND FLTRPT.USER_ID = @userId  LEFT JOIN
				ADM_TRN_USER_PROFILES AS UP ON FLTRPT.USER_ID = UP.ID_  RIGHT OUTER JOIN
	        
				(select pl.ID_ as ID_, pv.ID_ As PlatformVariantId, pv.PLTF_ALIAS_CODE_ AS PLTF_ALIAS_CODE_ 
						,r.PRNT_ID as CommandId
				 from ADM_MST_PLATFORMS AS pl inner join
					ADM_MST_PLATFORM_VARIANT pv on pv.PLTF_ID = pl.ID_ inner join
					ADM_MST_TAIL_VARIANT tv ON tv.PLTF_VARIANT_ID = pv.ID_ inner join
					ADM_MST_TAILS t on t.UNIT_ID = tv.ID_ inner join
					ADM_MST_RESTRICTIONS r on r.ID_ = t.BATLN_ID
					where 
						(@commandId = 0 or r.PRNT_ID = @commandId)
						AND pl.ID_ IN ( 
								SELECT PLF.ID_
								FROM ADM_TRN_SEC_ROLE_ACL_DETAIL dacl 
										INNER JOIN ADM_TRN_SEC_ROLE_ACL roleacl on dacl.ROLE_ACL_ID = roleacl.id_ AND roleacl.MDL_ID = 'MNT.001.00.00.00' 
										INNER JOIN ADM_TRN_SEC_ROLE role on roleacl.ROLE_ID = role.id_ 
										INNER JOIN ADM_TRN_SEC_ROLE_ASSIGNMENT roleassignment on roleassignment.ROLE_ID = role.id_ and roleassignment.USR_PRF_ID = @userId
										INNER JOIN ADM_MST_PLATFORMS AS PLF ON PLF.ID_ = dacl.TYPE_ID_ AND dacl.TYPE_ = 'Platform' 
										INNER JOIN ADM_MST_ITEMS AS ITEM ON ITEM.ID_ = PLF.ID_ 
										INNER JOIN ADM_MST_UNITS AS UNITS ON UNITS.ITEM_ID = ITEM.ID_
										INNER JOIN ADM_MST_TAILS AS TAILS ON TAILS.UNIT_ID = UNITS.ID_
										INNER JOIN ADM_MST_RESTRICTIONS AS BTN ON BTN.ID_ = TAILS.BATLN_ID 
										INNER JOIN ADM_MST_RESTRICTIONS AS CMD ON CMD.ID_ = BTN.PRNT_ID
								WHERE (@commandId = 0 or CMD.ID_ = @commandId) AND TAILS.END_DATE_='9999-12-31'
								GROUP BY PLF.ID_			 
						) 
						AND pv.ID_ is not null
					group by 
						pl.ID_ , pv.PLTF_ALIAS_CODE_ ,  pv.ID_ , r.PRNT_ID  
					having count(t.ID_) > 0 
				) As PLTFM ON FLTMTORPT.PLTF_ID = PLTFM.ID_ AND FLTMTORPT.PLTF_VARIANT_ID  = PLTFM.PlatformVariantId and (@commandId = 0 or FLTMTORPT.CMD_ID=@commandId)
			) s 
			join ADM_MST_PLATFORMS p on p.ID_ = s.PlatformId
			left join (
				select pv1.ID_ as VARIAN_ID, PLTF_ID, PLTF_ALIAS_CODE_, PLTF_ALIAS_AR_LONG_NAME_
				from ADM_MST_PLATFORM_VARIANT pv1 								
				group by pv1.ID_, PLTF_ID, PLTF_ALIAS_CODE_, PLTF_ALIAS_AR_LONG_NAME_
			) p_var on p_var.PLTF_ID = p.ID_ and p_var.VARIAN_ID = s.PlatformVariantId

		ORDER BY CASE WHEN PlatformVariantId IS NULL THEN ISNULL(p.EN_SHORT_NAME_, '') + ' ' + ISNULL(p.AR_LONG_NAME_, '') 
					  ELSE ISNULL(p_var.PLTF_ALIAS_CODE_, '') + ' ' + ISNULL(p_var.PLTF_ALIAS_AR_LONG_NAME_, '') 
				 END
    END
    ELSE
    BEGIN
		select s.PlatformId,
				CASE WHEN PlatformVariantId IS NULL THEN ISNULL(p.EN_SHORT_NAME_, '') + ' ' + ISNULL(p.AR_LONG_NAME_, '') 
					 ELSE ISNULL(p_var.PLTF_ALIAS_CODE_, '') + ' ' + ISNULL(p_var.PLTF_ALIAS_AR_LONG_NAME_, '') 
				END AS ApplicabilityName,
				s.Remarks,
				s.Mto,
				s.ParentId,
				s.UserProfileId as ProfileId,
				s.UserId as UserID,
				p.ORDER_ as PlatformOrder,
				[dbo].[GetConditionCount2](s.PlatformVariantId, s.ParentId, s.PlatformId, 1, @input_date) AS McCount,
				[dbo].[GetConditionCount2](s.PlatformVariantId, s.ParentId, s.PlatformId, 0, @input_date) AS NmcCount
		from (
			SELECT     
				PLTFM.ID_ AS PlatformId, PLTFM.CODE_ AS Platform, UP.ID_ AS UserProfileId, UP.USER_ID_ AS UserId, FLTRPT.REMARKS_ AS Remarks, FLTMTORPT.MTO_ AS Mto, FLTRPT.PLTF_VARIANT_ID AS PlatformVariantId
				,r.PRNT_ID as ParentId
			FROM    
			    MNT_TRN_GHQ_FLEET_MTO_RPTS AS FLTMTORPT  LEFT JOIN     
				MNT_TRN_GHQ_FLEET_RPTS AS FLTRPT on FLTRPT.PLTF_ID=FLTMTORPT.PLTF_ID and FLTRPT.PLTF_VARIANT_ID is null and FLTRPT.CMD_ID=FLTMTORPT.CMD_ID AND FLTRPT.USER_ID = @userId LEFT JOIN
				ADM_TRN_USER_PROFILES AS UP ON FLTRPT.USER_ID = UP.ID_  RIGHT OUTER JOIN
				ADM_MST_PLATFORMS AS PLTFM ON FLTMTORPT.PLTF_ID = PLTFM.ID_ AND FLTRPT.PLTF_VARIANT_ID is null 
				join ADM_MST_ITEMS i on i.ID_ = PLTFM.ID_
				join ADM_MST_UNITS u on u.ITEM_ID = i.ID_
				join ADM_MST_TAILS t on t.UNIT_ID = u.ID_
				join ADM_MST_RESTRICTIONS r on r.ID_ = t.BATLN_ID and FLTMTORPT.CMD_ID = r.PRNT_ID
			where (@commandId = 0 or r.PRNT_ID = @commandId) and FLTMTORPT.PLTF_VARIANT_ID is  null
				  and PLTFM.ID_ IN ( 
					SELECT PLF.ID_
					FROM ADM_TRN_SEC_ROLE_ACL_DETAIL dacl 
							INNER JOIN ADM_TRN_SEC_ROLE_ACL roleacl on dacl.ROLE_ACL_ID = roleacl.id_ AND roleacl.MDL_ID = 'MNT.001.00.00.00' 
							INNER JOIN ADM_TRN_SEC_ROLE role on roleacl.ROLE_ID = role.id_ 
							INNER JOIN ADM_TRN_SEC_ROLE_ASSIGNMENT roleassignment on roleassignment.ROLE_ID = role.id_ and roleassignment.USR_PRF_ID = @userId
							INNER JOIN ADM_MST_PLATFORMS AS PLF ON PLF.ID_ = dacl.TYPE_ID_ AND dacl.TYPE_ = 'Platform' 
							INNER JOIN ADM_MST_ITEMS AS ITEM ON ITEM.ID_ = PLF.ID_ 
							INNER JOIN ADM_MST_UNITS AS UNITS ON UNITS.ITEM_ID = ITEM.ID_
							INNER JOIN ADM_MST_TAILS AS TAILS ON TAILS.UNIT_ID = UNITS.ID_
							INNER JOIN ADM_MST_RESTRICTIONS AS BTN ON BTN.ID_ = TAILS.BATLN_ID 
							INNER JOIN ADM_MST_RESTRICTIONS AS CMD ON CMD.ID_ = BTN.PRNT_ID
					WHERE (@commandId = 0 or CMD.ID_ = @commandId) AND TAILS.END_DATE_='9999-12-31'
					GROUP BY PLF.ID_			 
				  )
				  and r.PRNT_ID in (
					select dacl.TYPE_ID_ FROM ADM_TRN_SEC_ROLE_ACL_DETAIL dacl 
					INNER JOIN ADM_TRN_SEC_ROLE_ACL roleacl on dacl.ROLE_ACL_ID = roleacl.id_ AND roleacl.MDL_ID = 'MNT.001.00.00.00' 
					INNER JOIN ADM_TRN_SEC_ROLE role on roleacl.ROLE_ID = role.id_ 
					INNER JOIN ADM_TRN_SEC_ROLE_ASSIGNMENT roleassignment on roleassignment.ROLE_ID = role.id_ and roleassignment.USR_PRF_ID = @userId
					where dacl.TYPE_='MilitaryUnit'
				  )
			union
			select  
				PLTFM.ID_ AS PlatformId, PLTFM.PLTF_ALIAS_CODE_ AS Platform, UP.ID_ AS UserProfileId, UP.USER_ID_ AS UserId, FLTRPT.REMARKS_ AS Remarks, FLTMTORPT.MTO_ AS Mto, PLTFM.PlatformVariantId AS PlatformVariantId     
				 , CommandId as ParentId
			from 
			    MNT_TRN_GHQ_FLEET_MTO_RPTS AS FLTMTORPT  LEFT JOIN
				MNT_TRN_GHQ_FLEET_RPTS AS FLTRPT on FLTRPT.PLTF_ID=FLTMTORPT.PLTF_ID and FLTRPT.PLTF_VARIANT_ID is NOT null and FLTRPT.CMD_ID=FLTMTORPT.CMD_ID AND FLTRPT.USER_ID = @userId  LEFT JOIN
				ADM_TRN_USER_PROFILES AS UP ON FLTRPT.USER_ID = UP.ID_  RIGHT OUTER JOIN
	        
				(select pl.ID_ as ID_, pv.ID_ As PlatformVariantId, pv.PLTF_ALIAS_CODE_ AS PLTF_ALIAS_CODE_ 
						,r.PRNT_ID as CommandId
				 from ADM_MST_PLATFORMS AS pl inner join
					ADM_MST_PLATFORM_VARIANT pv on pv.PLTF_ID = pl.ID_ inner join
					ADM_MST_TAIL_VARIANT tv ON tv.PLTF_VARIANT_ID = pv.ID_ inner join
					ADM_MST_TAILS t on t.UNIT_ID = tv.ID_ inner join
					ADM_MST_RESTRICTIONS r on r.ID_ = t.BATLN_ID
					where 
						(@commandId = 0 or r.PRNT_ID = @commandId)
						AND pl.ID_ IN ( 
								SELECT PLF.ID_
								FROM ADM_TRN_SEC_ROLE_ACL_DETAIL dacl 
										INNER JOIN ADM_TRN_SEC_ROLE_ACL roleacl on dacl.ROLE_ACL_ID = roleacl.id_ AND roleacl.MDL_ID = 'MNT.001.00.00.00' 
										INNER JOIN ADM_TRN_SEC_ROLE role on roleacl.ROLE_ID = role.id_ 
										INNER JOIN ADM_TRN_SEC_ROLE_ASSIGNMENT roleassignment on roleassignment.ROLE_ID = role.id_ and roleassignment.USR_PRF_ID = @userId
										INNER JOIN ADM_MST_PLATFORMS AS PLF ON PLF.ID_ = dacl.TYPE_ID_ AND dacl.TYPE_ = 'Platform' 
										INNER JOIN ADM_MST_ITEMS AS ITEM ON ITEM.ID_ = PLF.ID_ 
										INNER JOIN ADM_MST_UNITS AS UNITS ON UNITS.ITEM_ID = ITEM.ID_
										INNER JOIN ADM_MST_TAILS AS TAILS ON TAILS.UNIT_ID = UNITS.ID_
										INNER JOIN ADM_MST_RESTRICTIONS AS BTN ON BTN.ID_ = TAILS.BATLN_ID 
										INNER JOIN ADM_MST_RESTRICTIONS AS CMD ON CMD.ID_ = BTN.PRNT_ID
								WHERE (@commandId = 0 or CMD.ID_ = @commandId) AND TAILS.END_DATE_='9999-12-31'
								GROUP BY PLF.ID_			 
						) 
						AND pv.ID_ is not null
					group by 
						pl.ID_ , pv.PLTF_ALIAS_CODE_ ,  pv.ID_ , r.PRNT_ID  
					having count(t.ID_) > 0 
				) As PLTFM ON FLTMTORPT.PLTF_ID = PLTFM.ID_ AND FLTMTORPT.PLTF_VARIANT_ID  = PLTFM.PlatformVariantId and(@commandId = 0 or  FLTMTORPT.CMD_ID=@commandId)
			) s 
			join ADM_MST_PLATFORMS p on p.ID_ = s.PlatformId
			left join (
				select pv1.ID_ as VARIAN_ID, PLTF_ID, PLTF_ALIAS_CODE_, PLTF_ALIAS_AR_LONG_NAME_
				from ADM_MST_PLATFORM_VARIANT pv1 								
				group by pv1.ID_, PLTF_ID, PLTF_ALIAS_CODE_, PLTF_ALIAS_AR_LONG_NAME_
			) p_var on p_var.PLTF_ID = p.ID_ and p_var.VARIAN_ID = s.PlatformVariantId

		ORDER BY CASE WHEN PlatformVariantId IS NULL THEN ISNULL(p.EN_SHORT_NAME_, '') + ' ' + ISNULL(p.AR_LONG_NAME_, '') 
					  ELSE ISNULL(p_var.PLTF_ALIAS_CODE_, '') + ' ' + ISNULL(p_var.PLTF_ALIAS_AR_LONG_NAME_, '') 
				 END
    END
END
go

