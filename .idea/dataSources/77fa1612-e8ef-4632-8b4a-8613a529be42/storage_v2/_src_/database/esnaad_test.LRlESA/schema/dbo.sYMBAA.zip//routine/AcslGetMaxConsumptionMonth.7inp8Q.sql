CREATE FUNCTION [dbo].[AcslGetMaxConsumptionMonth]
(
  @itemId AS    BIGINT,
  @commandId AS BIGINT,
  @buId AS      BIGINT,
  @l2Id AS      BIGINT,
  @month AS  int
  )
  RETURNS @month_consumption TABLE
                            (
                              Month        int,
                              Consumption BIGINT
                            )
AS
BEGIN
  DECLARE
    @year int,
    @consumption BIGINT;

	with ct (Month, TotalConsumption)
	as 
	(
		select datefromparts(TotalConsumption.YEAR, TotalConsumption.MONTH_, 1) as Month, sum(TotalConsumption.TotalConsumption) as TotalConsumption
		from 
		(
			select cons.ITEM_ID, cons.YEAR, cons.MONTH_, cons.Consumption + coalesce(base.BaseConsumption, 0) as TotalConsumption
			from 
			(
				select CH.ITEM_ID, CH.YEAR, CH.MONTH_, SUM(CH.TOTAL_ISSUE_ - CH.TOTAL_TURN_IN_ - CH.REGULARIZED_QTY_) as Consumption
				from LOG_TRN_ITEM_CONSUMPTION_HISTORY CH
				INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.PARENT_STORE_ID_ = @buId OR BU.ID_ = @buId)
				WHERE (CH.L2_ID_ = @l2Id) 
					AND (BU.BU_TYPE_ = 'Store') 
				GROUP BY CH.ITEM_ID, CH.YEAR, CH.MONTH_
			) as cons
			left join (
				select ITEM_ID, YEAR, MONTH_, sum(TOTAL_ISSUE_ - TOTAL_TURN_IN_ - REGULARIZED_QTY_) as BaseConsumption
				from LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE CHB 
				INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CHB.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.PARENT_STORE_ID_ = @buId OR BU.ID_ = @buId)
				WHERE (CHB.L2_ID_ = @l2Id) 
				AND (BU.BU_TYPE_ = 'Store') 
				group by CHB.ITEM_ID, CHB.YEAR, MONTH_
			) as base on cons.ITEM_ID = base.ITEM_ID and cons.YEAR = base.YEAR and cons.MONTH_ = base.MONTH_
			where cons.Consumption > 0
		) as TotalConsumption
		inner join ADM_MST_ITEMS AS ADM_MST_ITEMS_2 ON TotalConsumption.ITEM_ID = ADM_MST_ITEMS_2.ID_
		inner join ADM_TRN_ITEM_ASSOCS AS IT13 ON IT13.ITEM_ID = TotalConsumption.ITEM_ID AND IT13.L2_ID = @l2Id
		where IT13.IN_LIEU_CODE_ = (select IN_LIEU_CODE_ from ADM_TRN_ITEM_ASSOCS where ITEM_ID = @itemId and L2_ID = @l2Id)
			or (IT13.IN_LIEU_CODE_ is null and IT13.ITEM_ID = @itemId)
		group by TotalConsumption.YEAR, TotalConsumption.MONTH_
	)
	select @month=@month, @consumption=ct.TotalConsumption
	from ct
	where ct.TotalConsumption = (
		select max(ct.TotalConsumption) from ct
		where ct.Month >= dateadd(month, @month*-1, GETDATE())
		--where ct.Month >= datefromparts(2020, 09, 1)
	)

  INSERT @month_consumption
  SELECT @month, @consumption;
  RETURN
END;
go

