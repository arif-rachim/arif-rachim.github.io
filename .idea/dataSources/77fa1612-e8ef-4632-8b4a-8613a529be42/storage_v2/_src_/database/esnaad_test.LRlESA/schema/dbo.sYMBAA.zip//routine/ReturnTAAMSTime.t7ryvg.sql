CREATE FUNCTION ReturnTAAMSTime(@timeInMinutes decimal(12,3)) RETURNS decimal(9,1)   
AS  
BEGIN  
 DECLARE @return_taams_time decimal(9,1)   
 DECLARE @hourPart int   
 DECLARE @minutePart decimal(9,1)  
   
 if(@timeInMinutes >= 60) BEGIN  
  SET @hourPart = @timeInMinutes / 60;  
  SET @minutePart = @timeInMinutes -  (@hourPart * 60)  
 END    
 ELSE BEGIN  
  SET @hourPart = 0  
  SET @minutePart =  @timeInMinutes  
 END  
 SET @return_taams_time =  @hourPart + ceiling(@minutePart/6) /10  
   
 RETURN @return_taams_time  
END
go

