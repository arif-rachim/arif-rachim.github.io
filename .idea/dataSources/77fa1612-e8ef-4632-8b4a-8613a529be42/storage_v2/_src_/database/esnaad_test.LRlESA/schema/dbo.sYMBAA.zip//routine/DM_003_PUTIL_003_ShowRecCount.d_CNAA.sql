
CREATE PROCEDURE DM_003_PUTIL_003_ShowRecCount
	  @insertedRecCount BIGINT
	, @skippedRecCount BIGINT = NULL
	, @updatedRecCount BIGINT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	PRINT '---------------------------------------------------'
	IF @skippedRecCount IS NOT NULL
	BEGIN
		PRINT 'Records INSERTED: ' + CAST(@insertedRecCount AS VARCHAR(100)) + ', SKIPPED : ' + CAST(@skippedRecCount AS VARCHAR(100))
	END
	ELSE
		BEGIN
			IF @insertedRecCount IS NOT NULL
			BEGIN
				PRINT 'Records INSERTED: ' + CAST(@insertedRecCount AS VARCHAR(100))
			END
		END
	
	IF @updatedRecCount IS NOT NULL
	BEGIN	
		PRINT 'Records UPDATED: ' + CAST(@updatedRecCount AS VARCHAR(100))
	END
	PRINT '---------------------------------------------------'
END

/*
DM_003_PUTIL_003_ShowRecCount @insertedRecCount = 112
EXEC DM_003_PUTIL_003_ShowRecCount @insertedRecCount = 112, @skippedRecCount = 2, @updatedRecCount = 33
*/
go

