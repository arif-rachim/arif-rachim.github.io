CREATE VIEW [dbo].[VW_LOG_REPAIR_REQUEST_REPORT]
AS
SELECT        CONVERT(varchar(255),rf.ID_) AS ID_, rf.REPAIR_FILE_NO_ AS FileReferenceNo, rf.CREATED_ON_ AS Date, p.CODE_ AS AircraftType, i.PART_NO_ AS PartNo, i.NOMENCLATURE_ AS Description, 
              u.SERIAL_NO_ AS SerialNo, m.COMPANY_NAME_ AS Manufacturer, pmd.DESC_ AS DefectDescription
FROM          dbo.MNT_TRN_PMD_REPAIR_FILE AS rf INNER JOIN
                         dbo.MNT_TRN_PMD_PART_MAINTENANCE AS pmd ON rf.PMD_ID_ = pmd.ID_ INNER JOIN
                         dbo.LOG_TRN_STOCK AS s ON pmd.STOCK_ID = s.ID_ INNER JOIN
                         dbo.ADM_MST_UNITS AS u ON s.UNIT_ID = u.ID_ INNER JOIN
                         dbo.ADM_MST_ITEMS AS i ON u.ITEM_ID = i.ID_ LEFT OUTER JOIN
                         dbo.ADM_MST_MANUFACTURES AS m ON i.MNF_ID = m.ID_ LEFT OUTER JOIN
                         dbo.ADM_MST_TAILS AS t ON u.ID_ = t.UNIT_ID LEFT OUTER JOIN
                         dbo.ADM_MST_PLATFORMS AS p ON t.PLTF_ID = p.ID_
go

