--================================================
--Author:		Kiran
--Crew Management - Crew Flying Record
--Time in Minutes to be converted to HH:MM
--US-10256
--================================================
CREATE FUNCTION [dbo].[ConvertMinutesToHHMM]
(
	@totalSeconds BIGINT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @hourPart BIGINT;
	DECLARE @minutesRem INT;
	DECLARE @minPart INT;	
	DECLARE @minPartStr VARCHAR(5);	
	
	-- Find Hr
	SET @hourPart = @totalSeconds / 3600
	SET @minutesRem = @totalSeconds % 3600;
	
	-- Find Min
	SET @minPart = @minutesRem / 60;
	
	SET @minPartStr = 
	CASE 
		WHEN @minPart = 0 
		THEN
			'00'
		ELSE
			CONVERT(VARCHAR(MAX), @minPart)
	END;
	
	IF LEN(@minPartStr) = 1 
		SET @minPartStr = '0' + @minPartStr;
	 		
	RETURN CONVERT(VARCHAR(MAX), @hourPart) + ':' + @minPartStr;
END


go

