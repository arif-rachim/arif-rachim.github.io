CREATE FUNCTION [dbo].[GetD16ComponentReplaceDueDateTsi] (@TsiValue int, @TsiUnit nvarchar(10), @InstallationDate datetime)
RETURNS DATETIME
AS
BEGIN
    select @TsiValue = coalesce(@TsiValue, 0);

	IF (@TsiValue <= 0 OR @InstallationDate IS NULL)
		RETURN NULL;

	IF (@TsiUnit = 'Months' and @TsiValue < 95000 )
		RETURN dateadd(month, @TsiValue, @InstallationDate);
	else if (@TsiUnit = 'Months')
		return '31-Dec-9999'
	ELSE if (@TsiUnit = 'Years' and  DATEPART(YEAR, @InstallationDate) + @TsiValue < 9999)
		RETURN dateadd(year, @TsiValue, @InstallationDate);
	else 
		return '31-Dec-9999'

RETURN NULL;
END
go

