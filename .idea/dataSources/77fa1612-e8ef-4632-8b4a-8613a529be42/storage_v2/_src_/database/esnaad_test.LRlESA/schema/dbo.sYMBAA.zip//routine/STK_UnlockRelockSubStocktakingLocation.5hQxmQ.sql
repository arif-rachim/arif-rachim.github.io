CREATE PROC [dbo].[STK_UnlockRelockSubStocktakingLocation] (
	@sslId uniqueidentifier,
	@isUnlock bit,
	@userProfileId bigint,
	@term nvarchar(255),
	@remarks nvarchar(255)
) AS
BEGIN
	DECLARE @itemClasses STK_TYPE_ItemClass
	DECLARE @userId nvarchar(255), @userPid nvarchar(255), @userFullName nvarchar(765), @auditTrailId uniqueidentifier
	SET @auditTrailId = [dbo].[GenerateTimebasedGuid]();
	
	SELECT @userId = USER_ID_, @userPid = PID_, @userFullName = F_NAME_ + ' ' + ISNULL(L_NAME_, '')
	FROM ADM_TRN_USER_PROFILES 
	WHERE ID_ = @userProfileId

	IF @isUnlock = 1
	BEGIN

		--Check if the locations can be unlocked
		IF EXISTS (	
				SELECT ID_
				FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM
				WHERE DISC_LEVEL_ IS NOT NULL AND SST_LOC_ID = @sslId
		) 
		BEGIN
			RAISERROR('LOG.029.055',16,1)
			RETURN
		END

		--Set unlock flag in sst location
		UPDATE LOG_TRN_STM_SUB_STOCKTAKING2_LOC SET IS_UNLOCKED_ = 1
		WHERE ID_ = @sslId;

		--Create audit trail header data
		INSERT LOG_TRN_STM_SUB_STOCKTAKING2_LOC_AUDIT_TRAIL(ID_, VERSION_, SST_LOC_ID, ACTION_ ,PERF_ID, REASON_,CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
		SELECT @auditTrailId, 1, @sslId, 'Unlock', @userProfileId, @remarks, @userId, @userPid, @userFullName, GETDATE(), @term;

		--Create audit trail item data snapshot
		INSERT LOG_TRN_STM_SUB_STOCKTAKING2_LOC_AUDIT_TRAIL_ITEM(VERSION_, SST_LOC_AT_ID, ITEM_ID, UNIT_ID, QTY_)
		SELECT 1, @auditTrailId, ITEM_ID, UNIT_ID, SYS_QTY_
		FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM
		WHERE SST_LOC_ID = @sslId;

	END
	ELSE 
	BEGIN
		--Check if the location can be re-locked / already locked
		IF NOT EXISTS (	
				SELECT ID_
				FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC
				WHERE ID_ = @sslId AND IS_UNLOCKED_ = 1
		) 
		BEGIN
			RAISERROR('LOG.029.056',16,1)
			RETURN
		END

		--Get Item classes
		INSERT @itemClasses
		SELECT C.CLS_ID_ FROM LOG_TRN_STM_STOCKTAKING2_CLASS C
		JOIN LOG_TRN_STM_SUB_STOCKTAKING2 SST ON SST.ST_ID = C.ST_ID
		JOIN LOG_TRN_STM_SUB_STOCKTAKING2_LOC SSL ON SSL.SST_ID = SST.ID_
		WHERE SSL.ID_ = @sslId

		--Clear locked locked location item data before repopulate
		DELETE FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM
		WHERE SST_LOC_ID = @sslId
			
		--Repopulate items in the location
		INSERT LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM(VERSION_, SST_LOC_ID, ITEM_ID, UNIT_ID, TC_ID, SYS_QTY_, ACT_QTY_, SYS_LOG_, ACT_LOG_, SYS_COC_, ACT_COC_, SYS_EXP_, ACT_EXP_
		, MNF_DATE_, IS_CONFIRMED_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, OVERRIDE_UNIT_INFO_,L2_ID, SYS_SERIAL_NO_)
		SELECT 1, SL.ID_, I.ID_, U.ID_ UnitId, IL.TC_ID_ TagColorCondId
		, ISNULL(IL.QTY_, 0), ISNULL(IL.QTY_, 0)
		, ISNULL(U.IS_LOG_, 0), ISNULL(U.IS_LOG_, 0)
		, ISNULL(U.IS_COC_, 0), ISNULL(U.IS_COC_, 0)
		, U.EXP_DATE_, U.EXP_DATE_, U.MANF_DATE_, 0
		, '', '', '', GETDATE(), '', 0
		,IL.OWNED_L2_ID_, U.SERIAL_NO_
		FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC SL
		JOIN LOG_TRN_STM_SUB_STOCKTAKING2 SST ON SST.ID_ = SL.SST_ID AND SL.ID_ = @sslId
		JOIN LOG_TRN_STM_STOCKTAKING2 ST ON ST.ID_ = SST.ST_ID
		LEFT JOIN ADM_TRN_IMV_ITEMS_IN_LOCATION IL ON IL.LOC_ID_ = SL.LOC_ID AND (IL.OWNED_L2_ID_ = ST.L2_ID OR ST.L2_ID IS NULL) AND IL.TC_ID_ <> 16 --16 = DISPOSED
		AND IL.TYPE_='Logistic'
		LEFT JOIN ADM_MST_UNITS U ON U.ID_ = IL.UNIT_ID_
		LEFT JOIN ADM_MST_ITEMS I ON I.ID_ = U.ITEM_ID 
		LEFT JOIN @itemClasses C ON C.ClassId = I.CLS_ID_ 
		WHERE (I.ID_ IS NOT NULL AND ClassId IS NOT NULL) OR (I.ID_ IS NULL AND ClassId IS NULL) --Exclude item with different class but include empty location

		--Set unlock flag in sst location
		UPDATE LOG_TRN_STM_SUB_STOCKTAKING2_LOC SET IS_UNLOCKED_ = 0
		WHERE ID_ = @sslId;

		--Create audit trail header data
		INSERT LOG_TRN_STM_SUB_STOCKTAKING2_LOC_AUDIT_TRAIL(ID_, VERSION_, SST_LOC_ID, ACTION_ ,PERF_ID, REASON_,CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
		SELECT @auditTrailId, 1, @sslId, 'Relock', @userProfileId, @remarks, @userId, @userPid, @userFullName, GETDATE(), @term;

		--Create audit trail item data snapshot
		INSERT LOG_TRN_STM_SUB_STOCKTAKING2_LOC_AUDIT_TRAIL_ITEM(VERSION_, SST_LOC_AT_ID, ITEM_ID, UNIT_ID, QTY_)
		SELECT 1, @auditTrailId, ITEM_ID, UNIT_ID, SYS_QTY_
		FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM
		WHERE SST_LOC_ID = @sslId;

	END
END
go

