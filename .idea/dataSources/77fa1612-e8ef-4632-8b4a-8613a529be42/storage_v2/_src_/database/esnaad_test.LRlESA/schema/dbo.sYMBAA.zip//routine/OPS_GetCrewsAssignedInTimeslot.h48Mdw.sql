CREATE FUNCTION [dbo].[OPS_GetCrewsAssignedInTimeslot] (
    @flightTimes dbo.OPS_Type_FlightTime READONLY
) RETURNS @assignedCrews TABLE  (
    FC_ID_ bigint, ETDZ_ datetime, ETAZ_ datetime, MISSION_ID_ bigint
) AS
BEGIN

    declare @Flights [dbo].[OPS_Type_FlightTimeMissionId];

    insert into @Flights
    select  ds.* 
    from    (
            select  F.ETD_, F.ETA_, F.MISSION_ID
            from    OPS_TRN_FLIGHTS f
                    JOIN @flightTimes FT ON (FT.ETDZ <= F.ETD_ AND FT.ETAZ >= F.ETD_ ) 
            union
            select  F.ETD_, F.ETA_, F.MISSION_ID
            from    OPS_TRN_FLIGHTS f
                    JOIN @flightTimes FT ON (FT.ETDZ >= F.ETD_ AND FT.ETDZ <= F.ETA_)
            ) as ds;

    INSERT @assignedCrews
    SELECT  FC.ID_ FC_ID_, 
            FL.ETD_, 
            FL.ETA_, 
            FL.MISSION_ID
    FROM    @Flights FL
            JOIN OPS_TRN_MISSIONS M ON M.ID_ = FL.MISSION_ID
            JOIN WF_TRN_INSTANCE WF ON M.WF_ID = WF.ID_ AND WF.WF_DEF_ID_='MissionWorkflow'
            JOIN OPS_TRN_WINGS W ON M.ID_ = W.MISSION_ID
            JOIN OPS_TRN_TAIL_CREWS TC ON TC.WING_ID = W.ID_
            JOIN OPS_TRN_MISSION_CREW_PLAN CP ON CP.TAIL_CREW_ID = TC.ID_
            JOIN OPS_MST_FLIGHT_CREWS FC ON CP.FLIGHT_CREW_ID = FC.ID_
    WHERE   WF_STATE_ NOT IN ('Verified', 'Debriefed','Canceled', 'Rejected')

    RETURN;
END
go

