CREATE PROCEDURE [dbo].[ConsumptionHistory_Insert]
      @pExecutionDate datetime
AS

BEGIN TRY
    BEGIN TRAN
      SET NOCOUNT ON;

	  DECLARE @RunForYear INT = null;    --leave this as null to refresh for all previous years
	  --DECLARE @RunForMonth INT = MONTH(GETDATE());  --leave this as null to refresh for the whole year
	  DECLARE @RunForMonth INT = null;  --leave this as null to refresh for the whole year

	  --To run data scan for current year except sunday, on sunday include all previous years as well
	if(datepart(weekday,getdate())=1)
	   begin
	     set @RunForYear=null
	   end
	else
	   begin 
	      set @RunForYear=YEAR(GETDATE())
	   end

      DECLARE @storeId BIGINT;
      DECLARE @cmdId BIGINT;
      DECLARE @L2Id BIGINT;
	  DECLARE @createdBy NVARCHAR(255);
	  DECLARE @pidCreatedBy NVARCHAR(255);
	  DECLARE @fullNameCreatedBy NVARCHAR(255);
	  DECLARE @term NVARCHAR(255) = host_name();

      DECLARE @tagColorId_Serviceable BIGINT = (SELECT ID_ FROM dbo.ADM_MST_TAG_COLOR_CONDITION WHERE CONDITION_ = 'Serviceable');

      DECLARE StoreCursor CURSOR FOR
      SELECT ID_
            ,CMD_ID_
            ,L2_ID_
        FROM ADM_MST_BUSINESS_UNITS BU
             JOIN ADM_MST_BUSINESS_UNITS_L2 BUL2 ON BU.ID_ = BUL2.BU_ID_
       WHERE BU_TYPE_ = 'Store'
         AND IS_ACTIVE_ = 1;

      OPEN StoreCursor;
      FETCH NEXT FROM StoreCursor
      INTO @storeId, @cmdId, @L2Id;

      --get who column values
	  select @createdBy = users.USER_ID_
            ,@pidCreatedBy = users.PID_
	        ,@fullNameCreatedBy = isnull(users.F_NAME_,'') + ' ' + isnull(users.L_NAME_, '')
        from ADM_TRN_USER_PROFILES users
       where users.USER_ID_ = 'SYSTEM';


	  --make sure complete refresh is done for all months
	  IF @RunForYear IS NULL
	  BEGIN
		SET @RunForMonth = NULL;
	  END

      -- create empty table
      SELECT * INTO #TblTempConsumption FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY WHERE 1=0

      WHILE @@FETCH_STATUS = 0
      BEGIN

            --requisition fulfillment
            INSERT INTO #TblTempConsumption (
                   ITEM_ID
                  ,CMD_ID
                  ,BU_ID_
                  ,L2_ID_
                  ,YEAR
				  ,MONTH_
				  ,FIRST_DAY_
                  ,TOTAL_ISSUE_
                  ,TOTAL_TURN_IN_
				   ,PLTF_ID_
				   ,TOTAL_SCHEDULE_ISSUE_
				   ,REGULARIZED_QTY_
                  )
            SELECT U.ITEM_ID 
                  ,@cmdId AS CMD_ID_
                  ,D.ORG_BU_ID_
                  ,D.ORG_L2_ID_
                  ,YEAR(D.TRF_DATE_) AS QueryYear
				  ,MONTH(D.TRF_DATE_) AS QueryMonth
				  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.TRF_DATE_),0)) AS QueryFirstDay
                  ,ISNULL(SUM(DI.QTY_), 0) AS TOTAL_ISSUE_
                  ,0 TOTAL_TURN_IN_
				  ,PLTFRM.PLTF_ID_
				  ,0 TOTAL_SCHEDULE_ISSUE_
				  ,0 REGULARIZED_QTY_
              FROM LOG_TRN_TRF_TRANSFER_DATA AS D 
                   INNER JOIN LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON D.ID_ = DI.TRF_ID 
                   INNER JOIN ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ 
				    INNER JOIN LOG_TRN_TRM_TRANSFER_INFO AS TRFINFO ON TRFINFO.TRF_DATA_ID_ = D.ID_
				   INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST AS TR_REQ ON TR_REQ.ID_ = TRFINFO.TRF_REQ_ID_
				   LEFT JOIN ADM_MST_PLATFORM_L2 AS PLTFRM ON PLTFRM.L2_ID_ = D.ORG_L2_ID_ AND PLTFRM.PLTF_ID_ = TR_REQ.PLATFORM_ID_ AND PLTFRM.CMD_ID_ = @cmdId
             WHERE (D.PROC_REF_TYPE_ = 'REQ')
               AND D.ORG_BU_ID_ = @storeId
               AND D.ORG_L2_ID_ = @L2Id
			   AND D.TRF_DATE_ IS NOT NULL
               AND YEAR(D.TRF_DATE_) =  ISNULL(@RunForYear,YEAR(D.TRF_DATE_))
			   AND MONTH(D.TRF_DATE_) = ISNULL(@RunForMonth,MONTH(D.TRF_DATE_))
             GROUP BY U.ITEM_ID
                  ,D.ORG_BU_ID_
                  ,D.ORG_L2_ID_
				  ,PLTFRM.PLTF_ID_
				  ,YEAR(D.TRF_DATE_)
				  ,MONTH(D.TRF_DATE_)
				  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.TRF_DATE_),0));


            --Real Serviceable turn-in
            MERGE #TblTempConsumption AS TARGET
            USING (SELECT U.ITEM_ID
                         ,BU.CMD_ID_
                         ,D.DST_BU_ID_ AS BU_ID_
                         ,D.DST_L2_ID_ AS L2_ID_
                         ,YEAR(D.RCV_DATE_) AS QueryYear
				         ,MONTH(D.RCV_DATE_) AS QueryMonth
				         ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.RCV_DATE_),0)) AS QueryFirstDay
                         ,SUM(DI.QTY_) AS TOTAL_TURN_IN_
						 ,PLTFRM.PLTF_ID_ AS PLTF_ID_                
                     FROM LOG_TRN_TRF_TRANSFER_DATA AS D 
                          INNER JOIN LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON D.ID_ = DI.TRF_ID 
                          INNER JOIN ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ 
                          INNER JOIN ADM_MST_BUSINESS_UNITS BU ON D.DST_BU_ID_ = BU.ID_ AND BU.BU_TYPE_ = 'Store'
						  INNER  JOIN LOG_TRN_TIN_TURN_IN  AS TURNIN ON TURNIN.TURN_IN_NO_ = D.DOC_REF_NO_
						LEFT JOIN ADM_MST_PLATFORM_L2 AS PLTFRM ON PLTFRM.L2_ID_ = D.ORG_L2_ID_ AND PLTFRM.PLTF_ID_ = TURNIN.PLTF_ID_ AND PLTFRM.CMD_ID_ = @cmdId
                    WHERE (D.PROC_REF_TYPE_ = 'TI')
                      AND D.DST_BU_ID_ = @storeId
                      AND D.DST_L2_ID_ = @L2Id                  
					  AND D.RCV_DATE_ IS NOT NULL
                      AND YEAR(D.RCV_DATE_) =  ISNULL(@RunForYear,YEAR(D.RCV_DATE_))
			          AND MONTH(D.RCV_DATE_) = ISNULL(@RunForMonth,MONTH(D.RCV_DATE_))
                    GROUP BY U.ITEM_ID
                         ,BU.CMD_ID_
                         ,D.DST_BU_ID_
                         ,D.DST_L2_ID_
						 ,YEAR(D.RCV_DATE_)
						 ,MONTH(D.RCV_DATE_)
				         ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.RCV_DATE_),0))
						 ,PLTFRM.PLTF_ID_
                         ) AS SOURCE
               ON (    TARGET.ITEM_ID = SOURCE.ITEM_ID
                   AND TARGET.CMD_ID = SOURCE.CMD_ID_
                   AND TARGET.BU_ID_ = SOURCE.BU_ID_
                   AND TARGET.L2_ID_ = SOURCE.L2_ID_				  
                   AND TARGET.[YEAR] = SOURCE.QueryYear
                   AND TARGET.[MONTH_] = SOURCE.QueryMonth
				    AND TARGET.PLTF_ID_ = SOURCE.PLTF_ID_
                  )
             WHEN MATCHED THEN UPDATE SET TARGET.TOTAL_TURN_IN_ = SOURCE.TOTAL_TURN_IN_
             WHEN NOT MATCHED THEN INSERT (
                  ITEM_ID
                 ,CMD_ID
                 ,BU_ID_
                 ,L2_ID_
                 ,YEAR
				 ,MONTH_
				 ,FIRST_DAY_
                 ,TOTAL_ISSUE_
                 ,TOTAL_TURN_IN_
				 ,PLTF_ID_
				  ,TOTAL_SCHEDULE_ISSUE_
				  ,REGULARIZED_QTY_
                  )
            VALUES (
                   SOURCE.ITEM_ID
                  ,SOURCE.CMD_ID_
                  ,SOURCE.BU_ID_
                  ,SOURCE.L2_ID_
                  ,SOURCE.QueryYear
				  ,SOURCE.QueryMonth
				  ,SOURCE.QueryFirstDay
                  ,0
                  ,SOURCE.TOTAL_TURN_IN_
				  ,SOURCE.PLTF_ID_
				  ,0
				  ,0
                   );




            --De facto "Serviceable turn-in" done to store through Work Order
            MERGE #TblTempConsumption AS TARGET
            USING (SELECT U.ITEM_ID
                         ,BuDest.CMD_ID_
                         ,D.DST_BU_ID_ BU_ID_
                         ,D.DST_L2_ID_ L2_ID_
                         ,YEAR(D.RCV_DATE_) AS QueryYear
				         ,MONTH(D.RCV_DATE_) AS QueryMonth
				         ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.RCV_DATE_),0)) AS QueryFirstDay
                         ,SUM(DI.QTY_) AS TOTAL_TURN_IN_
						 ,PLTFRM.PLTF_ID_ AS PLTF_ID_
                     FROM LOG_TRN_TRF_TRANSFER_DATA AS D 
                          INNER JOIN LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON (D.ID_ = DI.TRF_ID AND DI.TAG_COND_ID_ = @tagColorId_Serviceable) 
						INNER JOIN LOG_TRN_TRM_TRANSFER_INFO AS TRFINFO ON TRFINFO.TRF_DATA_ID_ = D.ID_
						INNER  JOIN LOG_TRN_TIN_TURN_IN  AS TURNIN ON TURNIN.TURN_IN_NO_ = D.DOC_REF_NO_
						LEFT JOIN ADM_MST_PLATFORM_L2 AS PLTFRM ON PLTFRM.L2_ID_ = D.ORG_L2_ID_ AND PLTFRM.PLTF_ID_ = TURNIN.PLTF_ID_

                          INNER JOIN ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ 
                          INNER JOIN ADM_MST_BUSINESS_UNITS BuDest ON D.DST_BU_ID_ = BuDest.ID_ AND BuDest.BU_TYPE_ = 'Store' 
                          INNER JOIN MNT_TRN_WOTS_WORK_ORDER WO ON WO.WO_NO_ = D.DOC_REF_NO_ 
                          INNER JOIN ADM_MST_BUSINESS_UNITS BuOrg ON WO.ORG_CODE_ = BuOrg.CODE_ AND BuOrg.BU_TYPE_ <> 'Store'                 
                    WHERE (D.PROC_REF_TYPE_ = 'WO')
                      AND D.DST_BU_ID_ = @storeId
                      AND D.DST_L2_ID_ = @L2Id                  
					  AND D.RCV_DATE_ IS NOT NULL
                      AND YEAR(D.RCV_DATE_) =  ISNULL(@RunForYear,YEAR(D.RCV_DATE_))
			          AND MONTH(D.RCV_DATE_) = ISNULL(@RunForMonth,MONTH(D.RCV_DATE_))
                    GROUP BY U.ITEM_ID
                         ,BuDest.CMD_ID_
                         ,D.DST_BU_ID_
                         ,D.DST_L2_ID_
                         ,YEAR(D.RCV_DATE_)
				         ,MONTH(D.RCV_DATE_)
				         ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.RCV_DATE_),0))
						 ,PLTFRM.PLTF_ID_
                         ) AS SOURCE
               ON (    TARGET.ITEM_ID = SOURCE.ITEM_ID
                   AND TARGET.CMD_ID = SOURCE.CMD_ID_
                   AND TARGET.BU_ID_ = SOURCE.BU_ID_
                   AND TARGET.L2_ID_ = SOURCE.L2_ID_				  
                   AND TARGET.[YEAR] = SOURCE.QueryYear
                   AND TARGET.[MONTH_] = SOURCE.QueryMonth
				   AND TARGET.PLTF_ID_ = SOURCE.PLTF_ID_
                  )
             WHEN MATCHED THEN UPDATE SET TARGET.TOTAL_TURN_IN_ = isnull(TARGET.TOTAL_TURN_IN_,0)+SOURCE.TOTAL_TURN_IN_
             WHEN NOT MATCHED THEN INSERT (
                  ITEM_ID
                 ,CMD_ID
                 ,BU_ID_
                 ,L2_ID_
                 ,YEAR
				 ,MONTH_
				 ,FIRST_DAY_
                 ,TOTAL_ISSUE_
                 ,TOTAL_TURN_IN_
				 ,PLTF_ID_
				 ,TOTAL_SCHEDULE_ISSUE_
				 ,REGULARIZED_QTY_
                  )
            VALUES (
                   SOURCE.ITEM_ID
                  ,SOURCE.CMD_ID_
                  ,SOURCE.BU_ID_
                  ,SOURCE.L2_ID_
                  ,SOURCE.QueryYear
                  ,SOURCE.QueryMonth
                  ,SOURCE.QueryFirstDay
                  ,0
                  ,SOURCE.TOTAL_TURN_IN_
				  ,SOURCE.PLTF_ID_
				  ,0
				  ,0
                   );


			--Schedule Issue --FAULT
            MERGE #TblTempConsumption AS TARGET
            USING ( SELECT U.ITEM_ID 
                  ,TR_REQ.RI_CMD_ID_ AS CMD_ID_
                  ,D.ORG_BU_ID_ AS BU_ID_
                  ,D.ORG_L2_ID_ AS L2_ID_
                  ,YEAR(D.TRF_DATE_) AS QueryYear
				  ,MONTH(D.TRF_DATE_) AS QueryMonth
				  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.TRF_DATE_),0)) AS QueryFirstDay
                  ,0 TOTAL_ISSUE_
                  ,0 TOTAL_TURN_IN_
				  ,PLTFRM.PLTF_ID_
				  ,ISNULL(SUM(DI.QTY_), 0) AS TOTAL_SCHEDULE_ISSUE_
				  ,0 REGULARIZED_QTY_
              FROM LOG_TRN_TRF_TRANSFER_DATA AS D 
                   INNER JOIN LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON D.ID_ = DI.TRF_ID 
                   INNER JOIN ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ 
				    INNER JOIN LOG_TRN_TRM_TRANSFER_INFO AS TRFINFO ON TRFINFO.TRF_DATA_ID_ = D.ID_
				   INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST AS TR_REQ ON TR_REQ.ID_ = TRFINFO.TRF_REQ_ID_ and TR_REQ.TR_NO_ = D.DOC_REF_NO_ AND TR_REQ.REF_TYPE_ = 'FAULT'
				   LEFT JOIN ADM_MST_PLATFORM_L2 AS PLTFRM ON PLTFRM.L2_ID_ = D.ORG_L2_ID_ AND PLTFRM.PLTF_ID_ = TR_REQ.PLATFORM_ID_ AND PLTFRM.CMD_ID_ = @cmdId

					--INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST AS TR ON TR.TR_NO_ = D.DOC_REF_NO_ AND TR.REF_TYPE_ = 'FAULT'
					LEFT JOIN MNT_TRN_FAULT_UNITS FU ON FU.FAULT_NO_ = TR_REQ.REF_NO_
					LEFT JOIN MNT_TRN_D16_FAULT_ASSIGNED AS FA ON FA.FAULT_ID_ = FU.ID_
					LEFT JOIN MNT_TRN_D16_1_GENERATED_FAULT AS GF ON  GF.FAULT_UNIT_ID = FU.ID_
					--LEFT JOIN (select KL.INSP_MST_ID ,KL_ITM.ITEM_ID as ItemId from MNT_TRN_IKT_INSPECTION_KITLIST_ITEM AS KL_ITM
					--inner JOIN MNT_TRN_IKT_INSPECTION_KITLIST AS KL ON KL.ID_ = KL_ITM.IK_ID AND KL.IS_PUBLISHED_ = 1 AND KL.IS_ACTIVE_ = 1
					--  group by KL.INSP_MST_ID ,KL_ITM.ITEM_ID
					--) as KL ON KL.ItemId = U.ITEM_ID
					LEFT JOIN MNT_TRN_INSPECTION_ASSIGNMENTS AS ASSIGN ON ASSIGN.ID_ = FU.INSP_ID  --AND  ASSIGN.INSP_MST_ID = KL.INSP_MST_ID
	        WHERE (D.PROC_REF_TYPE_ = 'REQ' ) 
			-- AND (FA.ID_ IS NOT NULL  OR GF.ID_ IS NOT NULL OR ASSIGN.INSP_MST_ID IS NOT NULL)  
			    and ( (ASSIGN.INSP_MST_ID is not null AND TR_REQ.KITLIST_VERSION_ is not null AND exists(
							  select top 1 * from MNT_TRN_IKT_KITLIST_DETAIL AS KL_ITM
							inner JOIN MNT_TRN_IKT_KITLIST AS KL ON KL.ID_ = KL_ITM.KIT_ID 
							inner join MNT_TRN_IKT_KITLIST_D18_LINK d18 on d18.KIT_ID=KL.ID_
							where  KL.REG_NO_=TR_REQ.GEN_REF_NO_ and KL.KITLIST_VERSION_=TR_REQ.KITLIST_VERSION_ and d18.D18_MASTER_ID=ASSIGN.INSP_MST_ID
							and KL_ITM.ITEM_ID= U.ITEM_ID
					)) OR FA.ID_ IS NOT NULL  OR GF.ID_ IS NOT NULL)
               AND D.ORG_BU_ID_ = @storeId
               AND D.ORG_L2_ID_ = @L2Id
			   AND D.TRF_DATE_ IS NOT NULL
               AND YEAR(D.TRF_DATE_) =  ISNULL(@RunForYear,YEAR(D.TRF_DATE_))
			   AND MONTH(D.TRF_DATE_) = ISNULL(@RunForMonth,MONTH(D.TRF_DATE_))
             GROUP BY U.ITEM_ID ,TR_REQ.RI_CMD_ID_
                  ,D.ORG_BU_ID_
                  ,D.ORG_L2_ID_
                  ,YEAR(D.TRF_DATE_)
				  ,MONTH(D.TRF_DATE_)
				  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.TRF_DATE_),0))
				  ,PLTFRM.PLTF_ID_
                         ) AS SOURCE
               ON (    TARGET.ITEM_ID = SOURCE.ITEM_ID
                   AND TARGET.CMD_ID = SOURCE.CMD_ID_
                   AND TARGET.BU_ID_ = SOURCE.BU_ID_
                   AND TARGET.L2_ID_ = SOURCE.L2_ID_				  
                   AND TARGET.[YEAR] = SOURCE.QueryYear
                   AND TARGET.[MONTH_] = SOURCE.QueryMonth
				   AND TARGET.PLTF_ID_ = SOURCE.PLTF_ID_
                  )
             WHEN MATCHED THEN UPDATE SET TARGET.TOTAL_SCHEDULE_ISSUE_ = SOURCE.TOTAL_SCHEDULE_ISSUE_
             WHEN NOT MATCHED THEN INSERT (
                  ITEM_ID
                 ,CMD_ID
                 ,BU_ID_
                 ,L2_ID_
                 ,YEAR
				 ,MONTH_
				 ,FIRST_DAY_
                 ,TOTAL_ISSUE_
                 ,TOTAL_TURN_IN_
				 ,PLTF_ID_
				 ,TOTAL_SCHEDULE_ISSUE_
				 ,REGULARIZED_QTY_
                  )
            VALUES (
                   SOURCE.ITEM_ID
                  ,SOURCE.CMD_ID_
                  ,SOURCE.BU_ID_
                  ,SOURCE.L2_ID_
                  ,SOURCE.QueryYear
                  ,SOURCE.QueryMonth
                  ,SOURCE.QueryFirstDay
                  ,0
                  ,0
				  ,SOURCE.PLTF_ID_
				  ,SOURCE.TOTAL_SCHEDULE_ISSUE_
				  ,0
                   );

				   

			--Schedule Issue --WORKORDER
            MERGE #TblTempConsumption AS TARGET
            USING (SELECT U.ITEM_ID 
                  ,TR.RI_CMD_ID_ AS CMD_ID_
                  ,D.ORG_BU_ID_ AS BU_ID_
                  ,D.ORG_L2_ID_ AS L2_ID_
                  ,YEAR(D.TRF_DATE_) AS QueryYear
				  ,MONTH(D.TRF_DATE_) AS QueryMonth
				  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.TRF_DATE_),0)) AS QueryFirstDay
                  ,0 TOTAL_ISSUE_
                  ,0 TOTAL_TURN_IN_
				  ,PLTFRM.PLTF_ID_
				  ,ISNULL(SUM(DI.QTY_), 0) AS TOTAL_SCHEDULE_ISSUE_
				  ,0 REGULARIZED_QTY_
              FROM LOG_TRN_TRF_TRANSFER_DATA AS D 
                   INNER JOIN LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON D.ID_ = DI.TRF_ID 
                   INNER JOIN ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ 
				    INNER JOIN LOG_TRN_TRM_TRANSFER_INFO AS TRFINFO ON TRFINFO.TRF_DATA_ID_ = D.ID_
				   INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST AS TR_REQ ON TR_REQ.ID_ = TRFINFO.TRF_REQ_ID_
				   LEFT JOIN ADM_MST_PLATFORM_L2 AS PLTFRM ON PLTFRM.L2_ID_ = D.ORG_L2_ID_ AND PLTFRM.PLTF_ID_ = TR_REQ.PLATFORM_ID_ AND PLTFRM.CMD_ID_ = @cmdId
					INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST AS TR ON TR.TR_NO_ = D.DOC_REF_NO_ AND TR.REF_TYPE_ = 'WORKORDER'
					INNER JOIN MNT_TRN_WOTS_WORK_ORDER AS WO ON WO.WO_NO_ = TR.REF_NO_ AND WO.WO_TYPE_  = 'SCHEDULED'
             WHERE (D.PROC_REF_TYPE_ = 'REQ')
               AND D.ORG_BU_ID_ = @storeId
               AND D.ORG_L2_ID_ = @L2Id
			   AND D.TRF_DATE_ IS NOT NULL
               AND YEAR(D.TRF_DATE_) =  ISNULL(@RunForYear,YEAR(D.TRF_DATE_))
			   AND MONTH(D.TRF_DATE_) = ISNULL(@RunForMonth,MONTH(D.TRF_DATE_))
             GROUP BY U.ITEM_ID ,TR.RI_CMD_ID_
                  ,D.ORG_BU_ID_
                  ,D.ORG_L2_ID_
                  ,YEAR(D.TRF_DATE_)
				  ,MONTH(D.TRF_DATE_)
				  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.TRF_DATE_),0))
				  ,PLTFRM.PLTF_ID_
                         ) AS SOURCE
               ON (    TARGET.ITEM_ID = SOURCE.ITEM_ID
                   AND TARGET.CMD_ID = SOURCE.CMD_ID_
                   AND TARGET.BU_ID_ = SOURCE.BU_ID_
                   AND TARGET.L2_ID_ = SOURCE.L2_ID_				  
                   AND TARGET.[YEAR] = SOURCE.QueryYear
				   AND TARGET.[MONTH_] = SOURCE.QueryMonth
				   AND TARGET.PLTF_ID_ = SOURCE.PLTF_ID_
                  )
             WHEN MATCHED THEN UPDATE SET TARGET.TOTAL_SCHEDULE_ISSUE_ = (TARGET.TOTAL_SCHEDULE_ISSUE_ + SOURCE.TOTAL_SCHEDULE_ISSUE_)
             WHEN NOT MATCHED THEN INSERT (
                  ITEM_ID
                 ,CMD_ID
                 ,BU_ID_
                 ,L2_ID_
                 ,YEAR
				 ,MONTH_
				 ,FIRST_DAY_
                 ,TOTAL_ISSUE_
                 ,TOTAL_TURN_IN_
				 ,PLTF_ID_
				 ,TOTAL_SCHEDULE_ISSUE_
				 ,REGULARIZED_QTY_
                  )
            VALUES (
                   SOURCE.ITEM_ID
                  ,SOURCE.CMD_ID_
                  ,SOURCE.BU_ID_
                  ,SOURCE.L2_ID_
                  ,SOURCE.QueryYear
                  ,SOURCE.QueryMonth
                  ,SOURCE.QueryFirstDay
                  ,0
                  ,0
				  ,SOURCE.PLTF_ID_
				  ,SOURCE.TOTAL_SCHEDULE_ISSUE_
				  ,0
                   );

			--Schedule Issue --'GSE', 'TOOLS', 'POL', 'OTHER'
            MERGE #TblTempConsumption AS TARGET
            USING (SELECT U.ITEM_ID 
                  ,TR.RI_CMD_ID_ AS CMD_ID_
                  ,D.ORG_BU_ID_ AS BU_ID_
                  ,D.ORG_L2_ID_ AS L2_ID_
                  ,YEAR(D.TRF_DATE_) AS QueryYear
				  ,MONTH(D.TRF_DATE_) AS QueryMonth
				  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.TRF_DATE_),0)) AS QueryFirstDay
                  ,0 TOTAL_ISSUE_
                  ,0 TOTAL_TURN_IN_
				  ,PLTFRM.PLTF_ID_
				  ,ISNULL(SUM(DI.QTY_), 0) AS TOTAL_SCHEDULE_ISSUE_
				  ,0 REGULARIZED_QTY_
              FROM LOG_TRN_TRF_TRANSFER_DATA AS D 
                   INNER JOIN LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON D.ID_ = DI.TRF_ID 
                   INNER JOIN ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ 
				    INNER JOIN LOG_TRN_TRM_TRANSFER_INFO AS TRFINFO ON TRFINFO.TRF_DATA_ID_ = D.ID_
				   INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST AS TR_REQ ON TR_REQ.ID_ = TRFINFO.TRF_REQ_ID_
				   LEFT JOIN ADM_MST_PLATFORM_L2 AS PLTFRM ON PLTFRM.L2_ID_ = D.ORG_L2_ID_ AND PLTFRM.PLTF_ID_ = TR_REQ.PLATFORM_ID_ AND PLTFRM.CMD_ID_ = @cmdId
					INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST AS TR ON TR.TR_NO_ = D.DOC_REF_NO_ AND TR.REF_TYPE_ IN ('GSE', 'TOOLS', 'POL', 'OTHER' )
					INNER JOIN MNT_TRN_WOTS_WORK_ORDER AS WO ON WO.WO_NO_ = TR.REF_NO_ AND WO.WO_TYPE_  = 'SCHEDULED'
             WHERE (D.PROC_REF_TYPE_ = 'REQ')
               AND D.ORG_BU_ID_ = @storeId
               AND D.ORG_L2_ID_ = @L2Id
			   AND D.TRF_DATE_ IS NOT NULL
               AND YEAR(D.TRF_DATE_) =  ISNULL(@RunForYear,YEAR(D.TRF_DATE_))
			   AND MONTH(D.TRF_DATE_) = ISNULL(@RunForMonth,MONTH(D.TRF_DATE_))
             GROUP BY U.ITEM_ID ,TR.RI_CMD_ID_
                  ,D.ORG_BU_ID_
                  ,D.ORG_L2_ID_
                  ,YEAR(D.TRF_DATE_)
				  ,MONTH(D.TRF_DATE_)
				  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,D.TRF_DATE_),0))
				  ,PLTFRM.PLTF_ID_
                         ) AS SOURCE
               ON (    TARGET.ITEM_ID = SOURCE.ITEM_ID
                   AND TARGET.CMD_ID = SOURCE.CMD_ID_
                   AND TARGET.BU_ID_ = SOURCE.BU_ID_
                   AND TARGET.L2_ID_ = SOURCE.L2_ID_				  
                   AND TARGET.[YEAR] = SOURCE.QueryYear
				   AND TARGET.[MONTH_] = SOURCE.QueryMonth
				   AND TARGET.PLTF_ID_ = SOURCE.PLTF_ID_
                  )
             WHEN MATCHED THEN UPDATE SET TARGET.TOTAL_SCHEDULE_ISSUE_ = (TARGET.TOTAL_SCHEDULE_ISSUE_ + SOURCE.TOTAL_SCHEDULE_ISSUE_)
             WHEN NOT MATCHED THEN INSERT (
                  ITEM_ID
                 ,CMD_ID
                 ,BU_ID_
                 ,L2_ID_
                 ,YEAR
				 ,MONTH_
				 ,FIRST_DAY_
                 ,TOTAL_ISSUE_
                 ,TOTAL_TURN_IN_
				 ,PLTF_ID_
				 ,TOTAL_SCHEDULE_ISSUE_
				 ,REGULARIZED_QTY_
                  )
            VALUES (
                   SOURCE.ITEM_ID
                  ,SOURCE.CMD_ID_
                  ,SOURCE.BU_ID_
                  ,SOURCE.L2_ID_
                  ,SOURCE.QueryYear
                  ,SOURCE.QueryMonth
                  ,SOURCE.QueryFirstDay
                  ,0
                  ,0
				  ,SOURCE.PLTF_ID_
				  ,SOURCE.TOTAL_SCHEDULE_ISSUE_
				  ,0
                   );
				   


		--Reqularized Qty
            MERGE #TblTempConsumption AS TARGET
            USING (SELECT U.ITEM_ID 
                  , TR_REQ.FI_CMD_ID_ AS CMD_ID_
                  ,D.ORG_BU_ID_ AS BU_ID_
                  ,D.ORG_L2_ID_ AS L2_ID_
                  ,YEAR(TRFINFO.CREATED_ON_) AS QueryYear
				  ,MONTH(TRFINFO.CREATED_ON_) AS QueryMonth
				  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,TRFINFO.CREATED_ON_),0)) AS QueryFirstDay
                  ,0 AS TOTAL_ISSUE_
                  ,0 TOTAL_TURN_IN_
				  ,PLTFRM.PLTF_ID_ AS PLTF_ID_
				  ,0 TOTAL_SCHEDULE_ISSUE_
				  , ISNULL(SUM( TII.REGULARIZED_QTY_), 0) AS REGULARIZED_QTY_
              FROM LOG_TRN_TRF_TRANSFER_DATA AS D 
                   INNER JOIN LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON D.ID_ = DI.TRF_ID 
                   INNER JOIN ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ 
				   INNER JOIN LOG_TRN_TRM_TRANSFER_INFO AS TRFINFO ON TRFINFO.TRF_DATA_ID_ = D.ID_
				   INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST AS TR_REQ ON TR_REQ.ID_ = TRFINFO.TRF_REQ_ID_
				   INNER JOIN LOG_TRN_TRM_TRANSFER_INFO_ITEM TII ON TRFINFO.ID_ = TII.TRF_INFO_ID AND TII.UNIT_ID_ = DI.UNIT_ID_
				   LEFT JOIN ADM_MST_PLATFORM_L2 AS PLTFRM ON PLTFRM.L2_ID_ = D.ORG_L2_ID_ AND PLTFRM.PLTF_ID_ = TR_REQ.PLATFORM_ID_ AND PLTFRM.CMD_ID_ = @cmdId
             WHERE (D.PROC_REF_TYPE_ = 'REQ')			  
					AND D.ORG_BU_ID_ = @storeId
					AND D.ORG_L2_ID_ = @L2Id
					AND TR_REQ.FI_CMD_ID_ = @cmdId
					AND TRFINFO.CREATED_ON_ IS NOT NULL
					AND YEAR(TRFINFO.CREATED_ON_) =  ISNULL(@RunForYear,YEAR(TRFINFO.CREATED_ON_))
					AND MONTH(TRFINFO.CREATED_ON_) = ISNULL(@RunForMonth,MONTH(TRFINFO.CREATED_ON_))
					  GROUP BY U.ITEM_ID,TR_REQ.FI_CMD_ID_
						  ,D.ORG_BU_ID_
						  ,D.ORG_L2_ID_
						  ,PLTFRM.PLTF_ID_
						  ,YEAR(TRFINFO.CREATED_ON_)
						  ,MONTH(TRFINFO.CREATED_ON_)
						  ,CONVERT(DATE,DATEADD(MONTH, DATEDIFF(MONTH,0,TRFINFO.CREATED_ON_),0))          
				  HAVING ISNULL(SUM(TII.REGULARIZED_QTY_ ), 0) > 0
                         ) AS SOURCE
               ON (    TARGET.ITEM_ID = SOURCE.ITEM_ID
                   AND TARGET.CMD_ID = SOURCE.CMD_ID_
                   AND TARGET.BU_ID_ = SOURCE.BU_ID_
                   AND TARGET.L2_ID_ = SOURCE.L2_ID_				  
                   AND TARGET.[YEAR] = SOURCE.QueryYear
				   AND TARGET.[MONTH_] = SOURCE.QueryMonth
				   AND ISNULL(TARGET.PLTF_ID_,0) = ISNULL(SOURCE.PLTF_ID_,0)
                  )
			 WHEN MATCHED THEN UPDATE SET TARGET.REGULARIZED_QTY_ = SOURCE.REGULARIZED_QTY_
             WHEN NOT MATCHED THEN INSERT (
                  ITEM_ID
                 ,CMD_ID
                 ,BU_ID_
                 ,L2_ID_
                 ,YEAR
				 ,MONTH_
				 ,FIRST_DAY_
                 ,TOTAL_ISSUE_
                 ,TOTAL_TURN_IN_
				 ,PLTF_ID_
				 ,TOTAL_SCHEDULE_ISSUE_
				 ,REGULARIZED_QTY_
                  )
            VALUES (
                   SOURCE.ITEM_ID
                  ,SOURCE.CMD_ID_
                  ,SOURCE.BU_ID_
                  ,SOURCE.L2_ID_
                  ,SOURCE.QueryYear
                  ,SOURCE.QueryMonth
                  ,SOURCE.QueryFirstDay
                  ,0
                  ,0
				  ,SOURCE.PLTF_ID_
				  ,0
				  ,SOURCE.REGULARIZED_QTY_
                   );

            FETCH NEXT FROM StoreCursor
            INTO @storeId, @cmdId, @L2Id; 
      END

      CLOSE StoreCursor;
      DEALLOCATE StoreCursor;

      SET NOCOUNT OFF;



      -- Audit log: Insert only modified records + new records
      INSERT INTO LOG_TRN_RPT_CONSUMPTION_HISTORY_LOG (
             ID_
            ,VERSION_
            ,DATE_
            ,ITEM_ID
            ,CMD_ID
            ,BU_ID_
            ,L2_ID_
            ,YEAR
			,MONTH_
            ,TOTAL_ISSUE_
            ,TOTAL_TURN_IN_
			,PLTF_ID_
            ,EXE_STATUS_
			,TOTAL_SCHEDULE_ISSUE_
			,REGULARIZED_QTY_
             )
      SELECT (select NEWID())
            ,1
            ,@pExecutionDate
            ,TblTempConsumption.ITEM_ID
            ,TblTempConsumption.CMD_ID
            ,TblTempConsumption.BU_ID_
            ,TblTempConsumption.L2_ID_
            ,TblTempConsumption.YEAR
			,TblTempConsumption.MONTH_
            ,TblTempConsumption.TOTAL_ISSUE_
            ,TblTempConsumption.TOTAL_TURN_IN_
			,TblTempConsumption.PLTF_ID_
            ,'Success'
			,TblTempConsumption.TOTAL_SCHEDULE_ISSUE_
			,TblTempConsumption.REGULARIZED_QTY_
        FROM #TblTempConsumption as TblTempConsumption
             left JOIN LOG_TRN_ITEM_CONSUMPTION_HISTORY TblHistory ON TblTempConsumption.CMD_ID = TblHistory.CMD_ID 
                                                                  AND TblTempConsumption.BU_ID_ = TblHistory.BU_ID_ 
                                                                  AND TblTempConsumption.L2_ID_ = TblHistory.L2_ID_ 
                                                                  AND TblTempConsumption.YEAR = TblHistory.YEAR 
                                                                  AND TblTempConsumption.MONTH_ = TblHistory.MONTH_
                                                                  AND TblTempConsumption.ITEM_ID = TblHistory.ITEM_ID
																  AND TblTempConsumption.PLTF_ID_ = TblHistory.PLTF_ID_
       WHERE (
               (     TblTempConsumption.ITEM_ID = TblHistory.ITEM_ID
                 AND (   TblTempConsumption.TOTAL_ISSUE_<> TblHistory.TOTAL_ISSUE_
                      OR TblTempConsumption.TOTAL_TURN_IN_ <> TblHistory.TOTAL_TURN_IN_
					  OR TblTempConsumption.TOTAL_SCHEDULE_ISSUE_ <> TblHistory.TOTAL_SCHEDULE_ISSUE_
					  OR TblTempConsumption.REGULARIZED_QTY_ <> TblHistory.REGULARIZED_QTY_
                     )
               )
             OR (TblHistory.ITEM_ID IS NULL)
             );



      -- Clear old history records
      BEGIN TRY
          DELETE 
		  FROM	LOG_TRN_ITEM_CONSUMPTION_HISTORY 
		  WHERE YEAR = ISNULL(@RunForYear, YEAR) 
		  AND	ISNULL(MONTH_, 13) = ISNULL(@RunForMonth, ISNULL(MONTH_, 13));
      END TRY

      BEGIN CATCH
          PRINT ''
          PRINT 'Please run the script to create table: LOG_TRN_ITEM_CONSUMPTION_HISTORY'
          PRINT 'Execution stopped!'
          RETURN;
      END CATCH

      

      -- Dump temporary table to history
      INSERT INTO LOG_TRN_ITEM_CONSUMPTION_HISTORY (
             ITEM_ID
            ,CMD_ID
            ,BU_ID_
            ,L2_ID_
            ,YEAR
			,MONTH_
			,FIRST_DAY_
            ,TOTAL_ISSUE_
            ,TOTAL_TURN_IN_
			,PLTF_ID_
			,TOTAL_SCHEDULE_ISSUE_
			,REGULARIZED_QTY_
             )
      SELECT TblTempConsumption.ITEM_ID
            ,TblTempConsumption.CMD_ID
            ,TblTempConsumption.BU_ID_
            ,TblTempConsumption.L2_ID_
            ,TblTempConsumption.YEAR
            ,TblTempConsumption.MONTH_
            ,TblTempConsumption.FIRST_DAY_
            ,ISNULL(TblTempConsumption.TOTAL_ISSUE_, 0)
            ,ISNULL(TblTempConsumption.TOTAL_TURN_IN_, 0)
			,TblTempConsumption.PLTF_ID_
			 ,ISNULL(TblTempConsumption.TOTAL_SCHEDULE_ISSUE_, 0)
			  ,ISNULL(TblTempConsumption.REGULARIZED_QTY_, 0)
        FROM #TblTempConsumption as TblTempConsumption;

      DROP TABLE #TblTempConsumption;


      BEGIN TRY
          DELETE 
		  FROM	LOG_TRN_ITEM_CONSUMPTION_HISTORY_ROLLUP 
		  WHERE YEAR = ISNULL(@RunForYear, YEAR)
		  AND	ISNULL(MONTH_, 13) = ISNULL(@RunForMonth, ISNULL(MONTH_, 13));
      END TRY

      BEGIN CATCH
          PRINT ''
          PRINT 'Please run the script to create table: LOG_TRN_ITEM_CONSUMPTION_HISTORY'
          PRINT 'Execution stopped!'
          RETURN;
      END CATCH

      
      --Consumption Data for Current Year
      INSERT INTO LOG_TRN_ITEM_CONSUMPTION_HISTORY_ROLLUP(
             ITEM_ID
            ,CMD_ID
            ,BU_ID_
            ,L2_ID_
            ,YEAR
			,MONTH_
			,FIRST_DAY_
            ,TOTAL_ISSUE_
            ,TOTAL_TURN_IN_
			,PLTF_ID_
			,TOTAL_SCHEDULE_ISSUE_
			,REGULARIZED_QTY_
            )
      SELECT itemAssoc.PRIMARY_ITEM_ID
            ,consumption.ParamCmdId
            ,consumption.ParamBu
            ,consumption.ParamAgl2
            ,consumption.ConsYear
            ,consumption.ConsMonth
            ,consumption.ConsFirstDay
            ,SUM(consumption.TotIssue) TotIssue
            ,SUM(consumption.TotTurnIn) TotTurnIn
			,consumption.ParamPlatform
			,SUM(consumption.TotScheduleIssue) TotScheduleIssue
			,SUM(consumption.TotReqularizedQty) TotReqularizedQty
        FROM (SELECT ISNULL(Consumption.ItemId, consumptionBase.ItemId) AS ItemId
                    ,ISNULL(Consumption.TotIssue, 0) + ISNULL(consumptionBase.TotIssue, 0) AS TotIssue
                    ,ISNULL(Consumption.TotTurnIn, 0) + ISNULL(consumptionBase.TotTurnIn, 0) AS TotTurnIn
                    ,ISNULL(Consumption.ParamBu, consumptionBase.ParamBu) AS ParamBu
                    ,ISNULL(Consumption.ParamAgl2, consumptionBase.ParamAgl2) AS ParamAgl2
                    ,ISNULL(Consumption.ParamCmdId, consumptionBase.ParamCmdId) AS ParamCmdId
                    ,ISNULL(Consumption.ConsYear, consumptionBase.ConsYear) AS ConsYear
                    ,ISNULL(Consumption.ConsMonth, consumptionBase.ConsMonth) AS ConsMonth
                    ,ISNULL(Consumption.ConsFirstDay, consumptionBase.ConsFirstDay) AS ConsFirstDay
					,ISNULL(Consumption.ParamPlatform, consumptionBase.ParamPlatform) AS ParamPlatform
					,ISNULL(Consumption.TotScheduleIssue, 0) + ISNULL(consumptionBase.TotScheduleIssue, 0) AS TotScheduleIssue
					,ISNULL(Consumption.TotReqularizedQty, 0) + ISNULL(consumptionBase.TotReqularizedQty, 0) AS TotReqularizedQty
                FROM (SELECT CH.ITEM_ID AS ItemId
                            ,CH.CMD_ID AS ParamCmdId
                            ,ISNULL(BU.PARENT_STORE_ID_, CH.BU_ID_) AS ParamBu
                            ,CH.L2_ID_ AS ParamAgl2
                            ,CH.YEAR AS ConsYear
							,CH.MONTH_ AS ConsMonth
							,CH.FIRST_DAY_ AS ConsFirstDay
                            ,SUM(TOTAL_ISSUE_) AS TotIssue
                            ,SUM(TOTAL_TURN_IN_ )AS TotTurnIn
							,CH.PLTF_ID_ AS ParamPlatform
							,SUM(TOTAL_SCHEDULE_ISSUE_) AS TotScheduleIssue
							,SUM(REGULARIZED_QTY_) AS TotReqularizedQty
                        FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY AS CH 
                             INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_
                       WHERE CH.YEAR = ISNULL(@RunForYear, CH.YEAR)
						 AND CH.MONTH_ = ISNULL(@RunForMonth, CH.MONTH_)
                         AND (BU.BU_TYPE_ = 'Store')
                       GROUP BY CH.ITEM_ID
                            ,CH.CMD_ID
                            ,CH.BU_ID_
                            ,BU.PARENT_STORE_ID_
                            ,CH.L2_ID_
							,CH.PLTF_ID_
							,CH.YEAR
							,CH.MONTH_
							,CH.FIRST_DAY_
                            ) AS Consumption FULL 
                     OUTER JOIN (
                      SELECT CHB.ITEM_ID AS ItemId
                            ,CHB.CMD_ID AS ParamCmdId
                            ,ISNULL(BU.PARENT_STORE_ID_, CHB.BU_ID_) AS ParamBu
                            ,CHB.L2_ID_ AS ParamAgl2
                            ,CHB.YEAR AS ConsYear
							,CHB.MONTH_ AS ConsMonth
							,CHB.FIRST_DAY_ AS ConsFirstDay
                            ,SUM(TOTAL_ISSUE_) AS TotIssue
                            ,SUM(TOTAL_TURN_IN_) AS TotTurnIn
							, CHB.PLTF_ID_ ParamPlatform
							,SUM(TOTAL_SCHEDULE_ISSUE_) AS TotScheduleIssue
							,SUM(REGULARIZED_QTY_) AS TotReqularizedQty
                        FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE AS CHB 
                             INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CHB.BU_ID_ = BU.ID_
                       WHERE CHB.YEAR = ISNULL(@RunForYear, CHB.YEAR)
					     AND CHB.MONTH_ = ISNULL(@RunForMonth, CHB.MONTH_)
                         AND (BU.BU_TYPE_ = 'Store')
                       GROUP BY CHB.ITEM_ID
                            ,CHB.CMD_ID
                            ,CHB.BU_ID_
                            ,BU.PARENT_STORE_ID_
                            ,CHB.L2_ID_
							,CHB.PLTF_ID_
                            ,CHB.YEAR
							,CHB.MONTH_
							,CHB.FIRST_DAY_
                     ) AS consumptionBase ON Consumption.ParamAgl2 = consumptionBase.ParamAgl2 
                                         AND Consumption.ParamBu = consumptionBase.ParamBu 
                                         AND Consumption.ParamCmdId = consumptionBase.ParamCmdId 
                                         AND Consumption.ItemId = consumptionBase.ItemId
										 AND Consumption.ParamPlatform = consumptionBase.ParamPlatform
										 AND Consumption.ConsYear = consumptionBase.ConsYear
										 AND Consumption.ConsMonth = consumptionBase.ConsMonth
              ) as consumption 
              join ( select itemAssoc.ITEM_ID
                           ,itemAssoc.L2_ID 
                           ,itemAssoc.ITEM_ID PRIMARY_ITEM_ID
                       from ADM_TRN_ITEM_ASSOCS itemAssoc
                      where itemAssoc.IN_LIEU_CODE_ is null
                        and itemAssoc.PRIMARY_PART_ = 1
                      union all
                     select itemAssoc.ITEM_ID
                           ,itemAssoc.L2_ID 
                           ,(select a.ITEM_ID
                               from ADM_TRN_ITEM_ASSOCS a 
                              where a.IN_LIEU_CODE_ = itemAssoc.IN_LIEU_CODE_ 
                                and a.PRIMARY_PART_ = 1
                               ) PRIMARY_ITEM_ID
                       from ADM_TRN_ITEM_ASSOCS itemAssoc
                      where itemAssoc.IN_LIEU_CODE_ is not null
                        and (select COUNT(1)
                               from ADM_TRN_ITEM_ASSOCS a 
                              where a.IN_LIEU_CODE_ = itemAssoc.IN_LIEU_CODE_ 
                                and a.PRIMARY_PART_ = 1
                                ) = 1
                   ) as itemAssoc on itemAssoc.ITEM_ID = consumption.ItemId
                                 and itemAssoc.L2_ID = consumption.ParamAgl2
      group by 
            itemAssoc.PRIMARY_ITEM_ID
           ,consumption.ParamCmdId
           ,consumption.ParamBu
           ,consumption.ParamAgl2
           ,consumption.ConsYear
           ,consumption.ConsMonth
           ,consumption.ConsFirstDay
		   ,consumption.ParamPlatform
      order by 
            consumption.ParamCmdId
           ,consumption.ParamBu
           ,consumption.ParamAgl2
		   ,consumption.ParamPlatform;
      

                        

      --start populating dues and stock values
	  truncate table [dbo].[LOG_TRN_ITEM_QUANTITY_SNAPSHOT];
      
	  --first insert all parts with stock
	  insert into LOG_TRN_ITEM_QUANTITY_SNAPSHOT (
	         VERSION_
	  	    ,ITEM_ID_
	  	    ,PRIMARY_PART_ITEM_ID_
	  	    ,CMD_ID_
	  	    ,BU_ID_
	  	    ,L2_ID_
	  	    ,NEW_DUES_IN_CONF_
	  	    ,NEW_DUES_IN_NOT_CONF_
	  	    ,RPR_DUES_IN_CONF_
	  	    ,RPR_DUES_IN_NOT_CONF_
	  	    ,STOCK_AWAITING_RECEPTION_
	  	    ,STOCK_AWAITING_LOCATION_
			,EXPIRED_STOCK
	  	    ,TOTAL_STOCK_
	  	    ,CREATED_BY_
	  	    ,PID_CREATED_BY_
	  	    ,FULL_NAME_CREATED_BY_
	  	    ,CREATED_ON_
	  	    ,TERM_
	  	     )
      select 1 --version
            ,src.ITEM_ID_
            ,src.PRIMARY_PART_ITEM_ID_
            ,src.CMD_ID_
            ,src.BU_ID_
            ,src.L2_ID_
            ,0 NEW_DUES_IN_CONF_
            ,0 NEW_DUES_IN_NOT_CONF_
            ,0 RPR_DUES_IN_CONF_
            ,0 RPR_DUES_IN_NOT_CONF_
            ,SUM(src.STOCK_AWAITING_RECEPTION_) STOCK_AWAITING_RECEPTION_
            ,SUM(src.STOCK_AWAITING_LOCATION_) STOCK_AWAITING_LOCATION_
			,SUM(src.EXPIRED_STOCK) EXPIRED_STOCK
            ,SUM(src.TOTAL_STOCK_) TOTAL_STOCK_
	  	    ,@createdBy
	  	    ,@pidCreatedBy
	  	    ,@fullNameCreatedBy
	  	    ,GETDATE()
	  	    ,@term
       from (select units.ITEM_ID ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = units.ITEM_ID
                               and itemAssoc.L2_ID = stock.OWNED_BY_L2_ID_
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
	  						   )
                           ,units.ITEM_ID) PRIMARY_PART_ITEM_ID_
                   ,store.CMD_ID_
                   ,ISNULL(store.PARENT_STORE_ID_, store.ID_) BU_ID_
                   ,stock.OWNED_BY_L2_ID_ L2_ID_
                   ,(case when loc.LOC_TYPE_ = 'InTransit' then stock.QTY_ else 0 end) STOCK_AWAITING_RECEPTION_
                   ,(case when loc.LOC_TYPE_ = 'Receiving' then stock.QTY_ else 0 end) STOCK_AWAITING_LOCATION_
				   ,(case when isnull(units.EXP_DATE_, DATEADD(DAY, 1, GETDATE())) < GETDATE() then stock.QTY_ else 0 end) EXPIRED_STOCK
                   ,stock.QTY_ TOTAL_STOCK_
               from LOG_TRN_STOCK stock
                    join ADM_MST_UNITS units on stock.UNIT_ID = units.ID_
                    join ADM_MST_BUSINESS_UNITS store on stock.STORE_ID = store.ID_
                    join ADM_MST_UNIT_LOCATION loc on stock.LOC_ID = loc.ID_
              where stock.TAG_COLOR_COND_ID_ = 1 --Serviceable
            ) src
      group by src.ITEM_ID_
           ,src.PRIMARY_PART_ITEM_ID_
           ,src.CMD_ID_
           ,src.BU_ID_
           ,src.L2_ID_;
      
      


      --then merge into the table with dues in information
	  --existing records will be updated and new records are inserted
      merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT as target
      using (select 1 VERSION_
                   ,SUMA.ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = SUMA.ITEM_ID_
                               and itemAssoc.L2_ID = SUMA.L2_ID_
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
	  						   )
                           ,SUMA.ITEM_ID_) PRIMARY_PART_ITEM_ID_
                   ,STORE.CMD_ID_
                   ,ISNULL(store.PARENT_STORE_ID_, store.ID_) BU_ID_
                   ,SUMA.L2_ID_
                   ,sum(SUMA.NEW_DUES_IN_CONF_) NEW_DUES_IN_CONF_
                   ,sum(SUMA.NEW_DUES_IN_NOT_CONF_) NEW_DUES_IN_NOT_CONF_
                   ,sum(SUMA.RPR_DUES_IN_CONF_) RPR_DUES_IN_CONF_
                   ,sum(SUMA.RPR_DUES_IN_NOT_CONF_) RPR_DUES_IN_NOT_CONF_
                   ,0 STOCK_AWAITING_RECEPTION_
                   ,0 STOCK_AWAITING_LOCATION_
				   ,0 EXPIRED_STOCK
                   ,0 TOTAL_STOCK_
                              FROM VW_DUES_IN_SUMMARY AS SUMA 
								JOIN ADM_MST_BUSINESS_UNITS AS STORE ON SUMA.BU_ID_ = STORE.ID_
              where (SUMA.NEW_DUES_IN_CONF_ + SUMA.NEW_DUES_IN_NOT_CONF_ + SUMA.RPR_DUES_IN_CONF_ + SUMA.RPR_DUES_IN_NOT_CONF_) > 0
              group by SUMA.ITEM_ID_
                   ,STORE.CMD_ID_
                   ,ISNULL(store.PARENT_STORE_ID_, store.ID_) 
                   ,SUMA.L2_ID_
	  	    ) as source
         on (     target.ITEM_ID_ = source.ITEM_ID_
              and target.CMD_ID_ = source.CMD_ID_
              and target.BU_ID_ = source.BU_ID_
              and target.L2_ID_ = source.L2_ID_
            )
       when matched then update 
                             set target.NEW_DUES_IN_CONF_ = source.NEW_DUES_IN_CONF_
                                ,target.NEW_DUES_IN_NOT_CONF_ = source.NEW_DUES_IN_NOT_CONF_
                                ,target.RPR_DUES_IN_CONF_ = source.RPR_DUES_IN_CONF_
                                ,target.RPR_DUES_IN_NOT_CONF_ = source.RPR_DUES_IN_NOT_CONF_
	  						    ,target.MOD_BY_ = @createdBy
	  						    ,target.PID_MOD_BY_ = @pidCreatedBy
	  						    ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
	  						    ,target.MOD_ON_ = GETDATE()
	  						    ,target.TERM_ = @term
       when not matched then insert ( 
                                 VERSION_
	                            ,ITEM_ID_
	  							,PRIMARY_PART_ITEM_ID_
	  							,CMD_ID_
	  							,BU_ID_
	  							,L2_ID_
	  							,NEW_DUES_IN_CONF_
	  							,NEW_DUES_IN_NOT_CONF_
	  							,RPR_DUES_IN_CONF_
	  							,RPR_DUES_IN_NOT_CONF_
	  							,STOCK_AWAITING_RECEPTION_
	  							,STOCK_AWAITING_LOCATION_
								,EXPIRED_STOCK
	  							,TOTAL_STOCK_
                                ,CREATED_BY_
                                ,PID_CREATED_BY_
                                ,FULL_NAME_CREATED_BY_
                                ,CREATED_ON_
                                ,TERM_
	  							 )
                          values (
                                 source.VERSION_
	  						    ,source.ITEM_ID_
	  						    ,source.PRIMARY_PART_ITEM_ID_
	  							,source.CMD_ID_
	  							,source.BU_ID_
	  							,source.L2_ID_
	  							,source.NEW_DUES_IN_CONF_
	  							,source.NEW_DUES_IN_NOT_CONF_
	  							,source.RPR_DUES_IN_CONF_
	  							,source.RPR_DUES_IN_NOT_CONF_
	  							,source.STOCK_AWAITING_RECEPTION_
	  							,source.STOCK_AWAITING_LOCATION_
								,source.EXPIRED_STOCK
	  							,source.TOTAL_STOCK_
                                ,@createdBy
                                ,@pidCreatedBy
                                ,@fullNameCreatedBy
                                ,GETDATE()
                                ,@term
	  							 );
      
      
      -- Merge avg TAT

      merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT as target
      using (select 1 VERSION_
                   ,ItemId as ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = PoSummary.ItemId
                               and itemAssoc.L2_ID = PoSummary.L2Id
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
	  						   )
                           ,PoSummary.ItemId) PRIMARY_PART_ITEM_ID_
				   ,bu.CMD_ID_ as CMD_ID_
				   ,StoreId as BU_ID_
				   ,L2Id as L2_ID_
				   ,0 NEW_DUES_IN_CONF_
                   ,0 NEW_DUES_IN_NOT_CONF_
                   ,0 RPR_DUES_IN_CONF_
                   ,0 RPR_DUES_IN_NOT_CONF_
				   ,0 STOCK_AWAITING_RECEPTION_
                   ,0 STOCK_AWAITING_LOCATION_
				   ,0 EXPIRED_STOCK
                   ,0 TOTAL_STOCK_
				   ,AvgTat as AVG_TAT 
			   from (select po.STORE_ID StoreId
                           ,po.L2_ID L2Id
                           ,isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID) as ItemId 
                           ,isnull(avg(isnull(datediff(day,po.VALIDATED_ON_,dlv.DELIVERY_DATE_),0) ),0) AvgTat
                       from LOG_TRN_PRC_PURCHASE_ORDER_ITEM POI 
                            inner join LOG_TRN_PRC_PROCUREMENT_ITEM proc_item on POI.PROC_ITEM_ID=proc_item.ID_ 
                            inner join LOG_TRN_PRC_PURCHASE_ORDER po on POI.PO_ID=po.ID_ 
                            left join LOG_TRN_REC_DELIVERY_NOTE_ITEM dlv_item on dlv_item.PO_ITEM_ID_=POI.ID_ 
                            left join LOG_TRN_REC_DELIVERY_NOTE dlv on dlv_item.DN_ID=dlv.ID_
                      where po.STATUS_ not in('Created','Canceled') 
                        and dlv_item.DN_ID is not null
                      group by isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID),po.STORE_ID,po.L2_ID
                      ) as PoSummary 
                    left join ADM_MST_BUSINESS_UNITS bu on bu.ID_=PoSummary.StoreId 
              where AvgTat is not null
		    ) as source
         on (    target.ITEM_ID_ = source.ITEM_ID_
             and target.CMD_ID_ = source.CMD_ID_
             and target.BU_ID_ = source.BU_ID_
             and target.L2_ID_ = source.L2_ID_
            )
       when matched then update set 
                                target.AVG_TAT = source.AVG_TAT
	  						   ,target.MOD_BY_ = @createdBy
	  						   ,target.PID_MOD_BY_ = @pidCreatedBy
	  						   ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
	  						   ,target.MOD_ON_ = GETDATE()
					           ,target.TERM_ = @term
       when not matched then insert ( 
                                VERSION_
	                           ,ITEM_ID_
							   ,PRIMARY_PART_ITEM_ID_
							   ,CMD_ID_
							   ,BU_ID_
							   ,L2_ID_
							   ,NEW_DUES_IN_CONF_
							   ,NEW_DUES_IN_NOT_CONF_
							   ,RPR_DUES_IN_CONF_
							   ,RPR_DUES_IN_NOT_CONF_
							   ,STOCK_AWAITING_RECEPTION_
							   ,STOCK_AWAITING_LOCATION_
							   ,EXPIRED_STOCK
							   ,TOTAL_STOCK_
							   ,AVG_TAT
                               ,CREATED_BY_
                               ,PID_CREATED_BY_
                               ,FULL_NAME_CREATED_BY_
                               ,CREATED_ON_
                               ,TERM_
								)
                         values (
                                 source.VERSION_
							    ,source.ITEM_ID_
							    ,source.PRIMARY_PART_ITEM_ID_
								,source.CMD_ID_
								,source.BU_ID_
								,source.L2_ID_
								,source.NEW_DUES_IN_CONF_
								,source.NEW_DUES_IN_NOT_CONF_
								,source.RPR_DUES_IN_CONF_
								,source.RPR_DUES_IN_NOT_CONF_
								,source.STOCK_AWAITING_RECEPTION_
								,source.STOCK_AWAITING_LOCATION_
								,source.EXPIRED_STOCK
								,source.TOTAL_STOCK_
								,source.AVG_TAT
                                ,@createdBy
                                ,@pidCreatedBy
                                ,@fullNameCreatedBy
                                ,GETDATE()
                                ,@term
								);

      -- Merge average price
	  merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT as target
      using (select 1 VERSION_
                   ,ItemId as ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = PoSummary.ItemId
                               and itemAssoc.L2_ID = PoSummary.L2Id
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
	  						   )
                           ,PoSummary.ItemId) PRIMARY_PART_ITEM_ID_
				   ,bu.CMD_ID_ as CMD_ID_
				   ,StoreId as BU_ID_
				   ,L2Id as L2_ID_
				   ,0 NEW_DUES_IN_CONF_
                   ,0 NEW_DUES_IN_NOT_CONF_
                   ,0 RPR_DUES_IN_CONF_
                   ,0 RPR_DUES_IN_NOT_CONF_
				   ,0 STOCK_AWAITING_RECEPTION_
                   ,0 STOCK_AWAITING_LOCATION_
				   ,0 EXPIRED_STOCK
                   ,0 TOTAL_STOCK_
				   ,0 as AVG_TAT
				   ,avergePrice as AVG_PRICE  
               from (select po.STORE_ID StoreId,po.L2_ID L2Id
                           ,isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID) as ItemId 
                           ,isnull(avg(CAST(((ISNULL(POI.SHIPPING_COST_,0) + ISNULL(POI.HANDLING_COST_,0) - ISNULL(POI.DISCOUNT_,0)) * 0.01 + 1) * POI.UNIT_PRICE_VAL_ AS decimal(18, 2)) ),0) as avergePrice
                       from LOG_TRN_PRC_PURCHASE_ORDER_ITEM POI 
                            inner join LOG_TRN_PRC_PROCUREMENT_ITEM proc_item on POI.PROC_ITEM_ID=proc_item.ID_ 
                            inner join LOG_TRN_PRC_PURCHASE_ORDER po on POI.PO_ID=po.ID_
                      where po.STATUS_ not in('Created','Canceled') and POI.UNIT_PRICE_VAL_ > 0
                      group by isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID)
                           ,po.STORE_ID
                           ,po.L2_ID
                            ) as PoSummary 
                    left join ADM_MST_BUSINESS_UNITS bu on bu.ID_=PoSummary.StoreId  
		            ) as source
         on (    target.ITEM_ID_ = source.ITEM_ID_
             and target.CMD_ID_ = source.CMD_ID_
             and target.BU_ID_ = source.BU_ID_
             and target.L2_ID_ = source.L2_ID_
            )
       when matched then update 
                            set target.AVG_PRICE = source.AVG_PRICE
  						       ,target.MOD_BY_ = @createdBy
	  						   ,target.PID_MOD_BY_ = @pidCreatedBy
	  						   ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
	  						   ,target.MOD_ON_ = GETDATE()
							   ,target.TERM_ = @term
       when not matched then insert (
                                VERSION_
	                            ,ITEM_ID_
								,PRIMARY_PART_ITEM_ID_
								,CMD_ID_
								,BU_ID_
								,L2_ID_
								,NEW_DUES_IN_CONF_
								,NEW_DUES_IN_NOT_CONF_
								,RPR_DUES_IN_CONF_
								,RPR_DUES_IN_NOT_CONF_
								,STOCK_AWAITING_RECEPTION_
								,STOCK_AWAITING_LOCATION_
								,EXPIRED_STOCK
								,TOTAL_STOCK_
								,AVG_TAT 
								,AVG_PRICE
                                ,CREATED_BY_
                                ,PID_CREATED_BY_
                                ,FULL_NAME_CREATED_BY_
                                ,CREATED_ON_
                                ,TERM_
								 )
                          values (
                                 source.VERSION_
							    ,source.ITEM_ID_
							    ,source.PRIMARY_PART_ITEM_ID_
								,source.CMD_ID_
								,source.BU_ID_
								,source.L2_ID_
								,source.NEW_DUES_IN_CONF_
								,source.NEW_DUES_IN_NOT_CONF_
								,source.RPR_DUES_IN_CONF_
								,source.RPR_DUES_IN_NOT_CONF_
								,source.STOCK_AWAITING_RECEPTION_
								,source.STOCK_AWAITING_LOCATION_
								,source.EXPIRED_STOCK
								,source.TOTAL_STOCK_
								,source.AVG_TAT
								,source.AVG_PRICE
                                ,@createdBy
                                ,@pidCreatedBy
                                ,@fullNameCreatedBy
                                ,GETDATE()
                                ,@term
								 );

      -- Merge Last price
      merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT as target
      using (select 1 VERSION_
                   ,ItemId as ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = PoSummary.ItemId
                               and itemAssoc.L2_ID = PoSummary.L2Id
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
	  						   )
                          ,PoSummary.ItemId) PRIMARY_PART_ITEM_ID_
				   ,bu.CMD_ID_ as CMD_ID_
				   ,StoreId as BU_ID_
				   ,L2Id as L2_ID_
				   ,0 NEW_DUES_IN_CONF_
                   ,0 NEW_DUES_IN_NOT_CONF_
                   ,0 RPR_DUES_IN_CONF_
                   ,0 RPR_DUES_IN_NOT_CONF_
				   ,0 STOCK_AWAITING_RECEPTION_
                   ,0 STOCK_AWAITING_LOCATION_
				   ,0 EXPIRED_STOCK
                   ,0 TOTAL_STOCK_
				   ,0 as AVG_TAT
				   ,0 as AVG_PRICE
				   ,lastPrice as LAST_PROC_PRICE  
               from (select STORE_ID StoreId
                           ,L2_ID L2Id
                           ,ItemId
                           ,max(lastPrice) lastPrice 
                       from (select isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID) as ItemId 
                                   ,po.VALIDATED_ON_
                                   ,po.STORE_ID
                                   ,po.L2_ID
                                   --,isnull(CAST(((ISNULL(POI.SHIPPING_COST_,0) + ISNULL(POI.HANDLING_COST_,0) - ISNULL(POI.DISCOUNT_,0)) * 0.01 + 1) * POI.UNIT_PRICE_VAL_  AS decimal(18, 2)),0) as lastPrice
								   ,ISNULL(CAST(POI.UNIT_PRICE_VAL_  AS decimal(18, 2)),0) as lastPrice
                                   ,ROW_NUMBER() over (partition by isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID),STORE_ID,L2_ID order by po.VALIDATED_ON_ desc) as rn
                               from LOG_TRN_PRC_PURCHASE_ORDER_ITEM POI 
                                    inner join LOG_TRN_PRC_PROCUREMENT_ITEM proc_item on POI.PROC_ITEM_ID=proc_item.ID_ 
                                    inner join LOG_TRN_PRC_PURCHASE_ORDER po on POI.PO_ID=po.ID_
                              where po.STATUS_ not in('Created','Canceled') and POI.UNIT_PRICE_VAL_ > 0
                              ) t 
                      where t.rn=1
                      group by ItemId
                           ,STORE_ID
                           ,L2_ID
                            ) as PoSummary 
                    left join ADM_MST_BUSINESS_UNITS bu on bu.ID_=PoSummary.StoreId  
		  ) as source
         on (    target.ITEM_ID_ = source.ITEM_ID_
             and target.CMD_ID_ = source.CMD_ID_
             and target.BU_ID_ = source.BU_ID_
             and target.L2_ID_ = source.L2_ID_
            )
       when matched then update 
                            set target.LAST_PROC_PRICE = source.LAST_PROC_PRICE
	  						   ,target.MOD_BY_ = @createdBy
	  						   ,target.PID_MOD_BY_ = @pidCreatedBy
	  						   ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
	  						   ,target.MOD_ON_ = GETDATE()
							   ,target.TERM_ = @term
       when not matched then insert (
                                 VERSION_
	                            ,ITEM_ID_
								,PRIMARY_PART_ITEM_ID_
								,CMD_ID_
								,BU_ID_
								,L2_ID_
								,NEW_DUES_IN_CONF_
								,NEW_DUES_IN_NOT_CONF_
								,RPR_DUES_IN_CONF_
								,RPR_DUES_IN_NOT_CONF_
								,STOCK_AWAITING_RECEPTION_
								,STOCK_AWAITING_LOCATION_
								,EXPIRED_STOCK
								,TOTAL_STOCK_
								,AVG_TAT 
								,AVG_PRICE
								,LAST_PROC_PRICE
                                ,CREATED_BY_
                                ,PID_CREATED_BY_
                                ,FULL_NAME_CREATED_BY_
                                ,CREATED_ON_
                                ,TERM_
								 )
                          values (
                                 source.VERSION_
							    ,source.ITEM_ID_
							    ,source.PRIMARY_PART_ITEM_ID_
								,source.CMD_ID_
								,source.BU_ID_
								,source.L2_ID_
								,source.NEW_DUES_IN_CONF_
								,source.NEW_DUES_IN_NOT_CONF_
								,source.RPR_DUES_IN_CONF_
								,source.RPR_DUES_IN_NOT_CONF_
								,source.STOCK_AWAITING_RECEPTION_
								,source.STOCK_AWAITING_LOCATION_
								,source.EXPIRED_STOCK
								,source.TOTAL_STOCK_
								,source.AVG_TAT
								,source.AVG_PRICE
								,source.LAST_PROC_PRICE
                                ,@createdBy
                                ,@pidCreatedBy
                                ,@fullNameCreatedBy
                                ,GETDATE()
                                ,@term
							     );

      --Dues out quantity

      merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT as target
      using (select 1 VERSION_
                   ,ItemId as ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = DuesOutSummary.ItemId
                               and itemAssoc.L2_ID = DuesOutSummary.L2Id
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
	  						   )
                            ,DuesOutSummary.ItemId) PRIMARY_PART_ITEM_ID_
				   ,bu.CMD_ID_ as CMD_ID_
				   ,StoreId as BU_ID_
				   ,L2Id as L2_ID_
				   ,0 NEW_DUES_IN_CONF_
                   ,0 NEW_DUES_IN_NOT_CONF_
                   ,0 RPR_DUES_IN_CONF_
                   ,0 RPR_DUES_IN_NOT_CONF_
				   ,0 STOCK_AWAITING_RECEPTION_
                   ,0 STOCK_AWAITING_LOCATION_
				   ,0 EXPIRED_STOCK
                   ,0 TOTAL_STOCK_
				   ,DuesOutUser as USER_DUES_OUT_QTY 
		       from (select do.ITEM_ID_ as ItemId
                           ,do.FF_L2_ID_ as L2Id
                           ,do.FF_BU_ID_ as StoreId
                           ,SUM(do.QTY_) DuesOutUser
                       from VW_DUES_OUT do
                      where do.DUES_OUT_TO_ = 'User'
                      group by do.ITEM_ID_
                           ,do.FF_L2_ID_
                           ,do.FF_BU_ID_
                           ) as DuesOutSummary 
                    left join ADM_MST_BUSINESS_UNITS bu on bu.ID_ = DuesOutSummary.StoreId
		    ) as source
         on (    target.ITEM_ID_ = source.ITEM_ID_
             and target.CMD_ID_ = source.CMD_ID_
             and target.BU_ID_ = source.BU_ID_
             and target.L2_ID_ = source.L2_ID_
            )
       when matched then update 
                            set target.USER_DUES_OUT_QTY = source.USER_DUES_OUT_QTY
	  						   ,target.MOD_BY_ = @createdBy
	  						   ,target.PID_MOD_BY_ = @pidCreatedBy
	  						   ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
	  						   ,target.MOD_ON_ = GETDATE()
							   ,target.TERM_ = @term
       when not matched then insert ( 
                                VERSION_
	                            ,ITEM_ID_
								,PRIMARY_PART_ITEM_ID_
								,CMD_ID_
								,BU_ID_
								,L2_ID_
								,NEW_DUES_IN_CONF_
								,NEW_DUES_IN_NOT_CONF_
								,RPR_DUES_IN_CONF_
								,RPR_DUES_IN_NOT_CONF_
								,STOCK_AWAITING_RECEPTION_
								,STOCK_AWAITING_LOCATION_
								,EXPIRED_STOCK
								,TOTAL_STOCK_
								,USER_DUES_OUT_QTY
                                ,CREATED_BY_
                                ,PID_CREATED_BY_
                                ,FULL_NAME_CREATED_BY_
                                ,CREATED_ON_
                                ,TERM_
							    )
                         values (source.VERSION_
							    ,source.ITEM_ID_
							    ,source.PRIMARY_PART_ITEM_ID_
								,source.CMD_ID_
								,source.BU_ID_
								,source.L2_ID_
								,source.NEW_DUES_IN_CONF_
								,source.NEW_DUES_IN_NOT_CONF_
								,source.RPR_DUES_IN_CONF_
								,source.RPR_DUES_IN_NOT_CONF_
								,source.STOCK_AWAITING_RECEPTION_
								,source.STOCK_AWAITING_LOCATION_
								,source.EXPIRED_STOCK
								,source.TOTAL_STOCK_
								,source.USER_DUES_OUT_QTY
                                ,@createdBy
                                ,@pidCreatedBy
                                ,@fullNameCreatedBy
                                ,GETDATE()
                                ,@term
								);
 


      --previous section prepared snapshot table at parent store level
      --below section prepares shapshot table at store level

      --start populating dues and stock values
    truncate table [dbo].[LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE];
      
    --first insert all parts with stock
    insert into LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE (
           VERSION_
          ,ITEM_ID_
          ,PRIMARY_PART_ITEM_ID_
          ,CMD_ID_
          ,BU_ID_
          ,PARENT_BU_ID_
          ,L2_ID_
          ,NEW_DUES_IN_CONF_
          ,NEW_DUES_IN_NOT_CONF_
          ,RPR_DUES_IN_CONF_
          ,RPR_DUES_IN_NOT_CONF_
          ,STOCK_AWAITING_RECEPTION_
          ,STOCK_AWAITING_LOCATION_
          ,UNDER_STOCK_TAKING_
          ,EXPIRED_STOCK
          ,TOTAL_STOCK_
          ,CREATED_BY_
          ,PID_CREATED_BY_
          ,FULL_NAME_CREATED_BY_
          ,CREATED_ON_
          ,TERM_
           )
      select 1 --version
            ,src.ITEM_ID_
            ,src.PRIMARY_PART_ITEM_ID_
            ,src.CMD_ID_
            ,src.BU_ID_
            ,src.PARENT_BU_ID_
            ,src.L2_ID_
            ,0 NEW_DUES_IN_CONF_
            ,0 NEW_DUES_IN_NOT_CONF_
            ,0 RPR_DUES_IN_CONF_
            ,0 RPR_DUES_IN_NOT_CONF_
            ,SUM(src.STOCK_AWAITING_RECEPTION_) STOCK_AWAITING_RECEPTION_
            ,SUM(src.STOCK_AWAITING_LOCATION_) STOCK_AWAITING_LOCATION_
            ,SUM(src.UNDER_STOCK_TAKING_) UNDER_STOCK_TAKING_
            ,SUM(src.EXPIRED_STOCK) EXPIRED_STOCK
            ,SUM(src.TOTAL_STOCK_) TOTAL_STOCK_
            ,@createdBy
            ,@pidCreatedBy
            ,@fullNameCreatedBy
            ,GETDATE()
            ,@term
       from (select units.ITEM_ID ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = units.ITEM_ID
                               and itemAssoc.L2_ID = stock.OWNED_BY_L2_ID_
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
                               )
                           ,units.ITEM_ID) PRIMARY_PART_ITEM_ID_
                   ,store.CMD_ID_
                   ,store.ID_ BU_ID_
                   ,ISNULL(store.PARENT_STORE_ID_, store.ID_) PARENT_BU_ID_
                   ,stock.OWNED_BY_L2_ID_ L2_ID_
                   ,(case when loc.LOC_TYPE_ = 'InTransit' then stock.QTY_ else 0 end) STOCK_AWAITING_RECEPTION_
                   ,(case when loc.LOC_TYPE_ = 'Receiving' then stock.QTY_ else 0 end) STOCK_AWAITING_LOCATION_
                   ,(case when exists (
										SELECT        1 AS Expr1
										FROM            LOG_TRN_STM_SUB_STOCKTAKING2_LOC AS SSL INNER JOIN
																 LOG_TRN_STM_SUB_STOCKTAKING2 AS SST ON SST.ID_ = SSL.SST_ID INNER JOIN
																 LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM AS LITM ON LITM.SST_LOC_ID = SSL.ID_ INNER JOIN
																 LOG_TRN_STM_STOCKTAKING2 AS ST ON ST.ID_ = SST.ST_ID
										WHERE        (SST.STATE_ IN ('Created', 'InProgress', 'Confirmed', 'AwaitingValidation', 'AwaitingApproval', 'AwaitingStockAdjustment')) 
										AND (SSL.LOC_ID = stock.LOC_ID) AND (ST.STORE_ID = stock.STORE_ID) AND 
																 (ST.L2_ID = stock.OWNED_BY_L2_ID_)
                                  ) 
                               then stock.QTY_ else 0 end ) UNDER_STOCK_TAKING_
                   ,(case when isnull(units.EXP_DATE_, DATEADD(DAY, 1, GETDATE())) < GETDATE() then stock.QTY_ else 0 end) EXPIRED_STOCK
                   ,stock.QTY_ TOTAL_STOCK_
               from LOG_TRN_STOCK stock
                    join ADM_MST_UNITS units on stock.UNIT_ID = units.ID_
                    join ADM_MST_BUSINESS_UNITS store on stock.STORE_ID = store.ID_
                    join ADM_MST_UNIT_LOCATION loc on stock.LOC_ID = loc.ID_
              where stock.TAG_COLOR_COND_ID_ = 1 --Serviceable
            ) src
      group by src.ITEM_ID_
           ,src.PRIMARY_PART_ITEM_ID_
           ,src.CMD_ID_
           ,src.BU_ID_
           ,src.PARENT_BU_ID_
           ,src.L2_ID_;
      
      


      --then merge into the table with dues in information
    --existing records will be updated and new records are inserted
      merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE as target
      using (select 1 VERSION_
                   ,SUMA.ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = SUMA.ITEM_ID_
                               and itemAssoc.L2_ID = SUMA.L2_ID_
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
                               )
                           ,SUMA.ITEM_ID_) PRIMARY_PART_ITEM_ID_
                   ,STORE.CMD_ID_
                   ,store.ID_ BU_ID_
                   ,ISNULL(store.PARENT_STORE_ID_, store.ID_) PARENT_BU_ID_
                   ,SUMA.L2_ID_
                   ,sum(SUMA.NEW_DUES_IN_CONF_) NEW_DUES_IN_CONF_
                   ,sum(SUMA.NEW_DUES_IN_NOT_CONF_) NEW_DUES_IN_NOT_CONF_
                   ,sum(SUMA.RPR_DUES_IN_CONF_) RPR_DUES_IN_CONF_
                   ,sum(SUMA.RPR_DUES_IN_NOT_CONF_) RPR_DUES_IN_NOT_CONF_
                   ,0 STOCK_AWAITING_RECEPTION_
                   ,0 STOCK_AWAITING_LOCATION_
                   ,0 UNDER_STOCK_TAKING_
                   ,0 EXPIRED_STOCK
                   ,0 TOTAL_STOCK_
               FROM VW_DUES_IN_SUMMARY AS SUMA 
								JOIN ADM_MST_BUSINESS_UNITS AS STORE ON SUMA.BU_ID_ = STORE.ID_
              where (SUMA.NEW_DUES_IN_CONF_ + SUMA.NEW_DUES_IN_NOT_CONF_ + SUMA.RPR_DUES_IN_CONF_ + SUMA.RPR_DUES_IN_NOT_CONF_) > 0
              group by SUMA.ITEM_ID_
                   ,STORE.CMD_ID_
                   ,store.ID_
                   ,ISNULL(store.PARENT_STORE_ID_, store.ID_) 
                   ,SUMA.L2_ID_
          ) as source
         on (     target.ITEM_ID_ = source.ITEM_ID_
              and target.CMD_ID_ = source.CMD_ID_
              and target.BU_ID_ = source.BU_ID_
              and target.L2_ID_ = source.L2_ID_
            )
       when matched then update 
                            set target.NEW_DUES_IN_CONF_ = source.NEW_DUES_IN_CONF_
                               ,target.NEW_DUES_IN_NOT_CONF_ = source.NEW_DUES_IN_NOT_CONF_
                               ,target.RPR_DUES_IN_CONF_ = source.RPR_DUES_IN_CONF_
                               ,target.RPR_DUES_IN_NOT_CONF_ = source.RPR_DUES_IN_NOT_CONF_
                               ,target.MOD_BY_ = @createdBy
                               ,target.PID_MOD_BY_ = @pidCreatedBy
                               ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
                               ,target.MOD_ON_ = GETDATE()
                               ,target.TERM_ = @term
       when not matched then insert ( 
                   VERSION_
                  ,ITEM_ID_
                  ,PRIMARY_PART_ITEM_ID_
                  ,CMD_ID_
                  ,BU_ID_
                  ,PARENT_BU_ID_
                  ,L2_ID_
                  ,NEW_DUES_IN_CONF_
                  ,NEW_DUES_IN_NOT_CONF_
                  ,RPR_DUES_IN_CONF_
                  ,RPR_DUES_IN_NOT_CONF_
                  ,STOCK_AWAITING_RECEPTION_
                  ,STOCK_AWAITING_LOCATION_
                  ,UNDER_STOCK_TAKING_
                  ,EXPIRED_STOCK
                  ,TOTAL_STOCK_
                  ,CREATED_BY_
                  ,PID_CREATED_BY_
                  ,FULL_NAME_CREATED_BY_
                  ,CREATED_ON_
                  ,TERM_
                   )
            values (
                   source.VERSION_
                  ,source.ITEM_ID_
                  ,source.PRIMARY_PART_ITEM_ID_
                  ,source.CMD_ID_
                  ,source.BU_ID_
                  ,source.PARENT_BU_ID_
                  ,source.L2_ID_
                  ,source.NEW_DUES_IN_CONF_
                  ,source.NEW_DUES_IN_NOT_CONF_
                  ,source.RPR_DUES_IN_CONF_
                  ,source.RPR_DUES_IN_NOT_CONF_
                  ,source.STOCK_AWAITING_RECEPTION_
                  ,source.STOCK_AWAITING_LOCATION_
                  ,source.UNDER_STOCK_TAKING_
                  ,source.EXPIRED_STOCK
                  ,source.TOTAL_STOCK_
                  ,@createdBy
                  ,@pidCreatedBy
                  ,@fullNameCreatedBy
                  ,GETDATE()
                  ,@term
                   );
      
      
      -- Merge avg TAT

      merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE as target
      using (select 1 VERSION_
                   ,ItemId as ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = PoSummary.ItemId
                               and itemAssoc.L2_ID = PoSummary.L2Id
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
                               )
                           ,PoSummary.ItemId) PRIMARY_PART_ITEM_ID_
                    ,bu.CMD_ID_ as CMD_ID_
                    ,bu.ID_ as BU_ID_
                    ,isnull(bu.PARENT_STORE_ID_, bu.ID_) PARENT_BU_ID_
                    ,PoSummary.L2Id as L2_ID_
                    ,0 NEW_DUES_IN_CONF_
                    ,0 NEW_DUES_IN_NOT_CONF_
                    ,0 RPR_DUES_IN_CONF_
                    ,0 RPR_DUES_IN_NOT_CONF_
                    ,0 STOCK_AWAITING_RECEPTION_
                    ,0 STOCK_AWAITING_LOCATION_
                    ,0 UNDER_STOCK_TAKING_
                    ,0 EXPIRED_STOCK
                    ,0 TOTAL_STOCK_
                    ,AvgTat as AVG_TAT 
                from (select po.STORE_ID StoreId
                            ,po.L2_ID L2Id
                            ,isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID) as ItemId 
                            ,isnull(avg(isnull(datediff(day,po.VALIDATED_ON_,dlv.DELIVERY_DATE_),0) ),0) AvgTat
                       from LOG_TRN_PRC_PURCHASE_ORDER_ITEM POI 
                            inner join LOG_TRN_PRC_PROCUREMENT_ITEM proc_item on POI.PROC_ITEM_ID=proc_item.ID_ 
                            inner join LOG_TRN_PRC_PURCHASE_ORDER po on POI.PO_ID=po.ID_ 
                            left join LOG_TRN_REC_DELIVERY_NOTE_ITEM dlv_item on dlv_item.PO_ITEM_ID_=POI.ID_ 
                            left join LOG_TRN_REC_DELIVERY_NOTE dlv on dlv_item.DN_ID=dlv.ID_
                      where po.STATUS_ not in('Created','Canceled') 
                        and dlv_item.DN_ID is not null
                      group by isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID),po.STORE_ID,po.L2_ID
                      ) as PoSummary 
                    join ADM_MST_BUSINESS_UNITS bu on bu.ID_=PoSummary.StoreId 
              where AvgTat is not null
        ) as source
         on (    target.ITEM_ID_ = source.ITEM_ID_
             and target.CMD_ID_ = source.CMD_ID_
             and target.BU_ID_ = source.BU_ID_
             and target.L2_ID_ = source.L2_ID_
            )
       when matched then update set 
                    target.AVG_TAT = source.AVG_TAT
                    ,target.MOD_BY_ = @createdBy
                    ,target.PID_MOD_BY_ = @pidCreatedBy
                    ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
                    ,target.MOD_ON_ = GETDATE()
                    ,target.TERM_ = @term
       when not matched then insert ( 
                    VERSION_
                    ,ITEM_ID_
                    ,PRIMARY_PART_ITEM_ID_
                    ,CMD_ID_
                    ,BU_ID_
                    ,PARENT_BU_ID_
                    ,L2_ID_
                    ,NEW_DUES_IN_CONF_
                    ,NEW_DUES_IN_NOT_CONF_
                    ,RPR_DUES_IN_CONF_
                    ,RPR_DUES_IN_NOT_CONF_
                    ,STOCK_AWAITING_RECEPTION_
                    ,STOCK_AWAITING_LOCATION_
                    ,UNDER_STOCK_TAKING_
                    ,EXPIRED_STOCK
                    ,TOTAL_STOCK_
                    ,AVG_TAT
                    ,CREATED_BY_
                    ,PID_CREATED_BY_
                    ,FULL_NAME_CREATED_BY_
                    ,CREATED_ON_
                    ,TERM_
                    )
            values (
                    source.VERSION_
                    ,source.ITEM_ID_
                    ,source.PRIMARY_PART_ITEM_ID_
                    ,source.CMD_ID_
                    ,source.BU_ID_
                    ,source.PARENT_BU_ID_
                    ,source.L2_ID_
                    ,source.NEW_DUES_IN_CONF_
                    ,source.NEW_DUES_IN_NOT_CONF_
                    ,source.RPR_DUES_IN_CONF_
                    ,source.RPR_DUES_IN_NOT_CONF_
                    ,source.STOCK_AWAITING_RECEPTION_
                    ,source.STOCK_AWAITING_LOCATION_
                    ,source.UNDER_STOCK_TAKING_
                    ,source.EXPIRED_STOCK
                    ,source.TOTAL_STOCK_
                    ,source.AVG_TAT
                    ,@createdBy
                    ,@pidCreatedBy
                    ,@fullNameCreatedBy
                    ,GETDATE()
                    ,@term
                );



      -- Merge average price
    merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE as target
      using (select 1 VERSION_
                    ,ItemId as ITEM_ID_
                    ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = PoSummary.ItemId
                               and itemAssoc.L2_ID = PoSummary.L2Id
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
                                )
                           ,PoSummary.ItemId) PRIMARY_PART_ITEM_ID_
                    ,bu.CMD_ID_ as CMD_ID_
                    ,bu.ID_ as BU_ID_
                    ,isnull(bu.PARENT_STORE_ID_, bu.ID_) PARENT_BU_ID_
                    ,L2Id as L2_ID_
                    ,0 NEW_DUES_IN_CONF_
                    ,0 NEW_DUES_IN_NOT_CONF_
                    ,0 RPR_DUES_IN_CONF_
                    ,0 RPR_DUES_IN_NOT_CONF_
                    ,0 STOCK_AWAITING_RECEPTION_
                    ,0 STOCK_AWAITING_LOCATION_
                    ,0 UNDER_STOCK_TAKING_
                    ,0 EXPIRED_STOCK
                    ,0 TOTAL_STOCK_
                    ,0 as AVG_TAT
                    ,avergePrice as AVG_PRICE  
               from (select po.STORE_ID StoreId
                           ,po.L2_ID L2Id
                           ,isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID) as ItemId 
                           ,isnull(avg(CAST(((ISNULL(POI.SHIPPING_COST_,0) + ISNULL(POI.HANDLING_COST_,0) - ISNULL(POI.DISCOUNT_,0)) * 0.01 + 1) * POI.UNIT_PRICE_VAL_ AS decimal(18, 2)) ),0) as avergePrice
                       from LOG_TRN_PRC_PURCHASE_ORDER_ITEM POI 
                            inner join LOG_TRN_PRC_PROCUREMENT_ITEM proc_item on POI.PROC_ITEM_ID=proc_item.ID_ 
                            inner join LOG_TRN_PRC_PURCHASE_ORDER po on POI.PO_ID=po.ID_
                      where po.STATUS_ not in('Created','Canceled') and POI.UNIT_PRICE_VAL_ > 0
                      group by isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID)
                           ,po.STORE_ID
                           ,po.L2_ID
                            ) as PoSummary 
                    join ADM_MST_BUSINESS_UNITS bu on bu.ID_=PoSummary.StoreId  
                ) as source
         on (    target.ITEM_ID_ = source.ITEM_ID_
             and target.CMD_ID_ = source.CMD_ID_
             and target.BU_ID_ = source.BU_ID_
             and target.L2_ID_ = source.L2_ID_
            )
       when matched then update 
                            set target.AVG_PRICE = source.AVG_PRICE
                                ,target.MOD_BY_ = @createdBy
                                ,target.PID_MOD_BY_ = @pidCreatedBy
                                ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
                                ,target.MOD_ON_ = GETDATE()
                                ,target.TERM_ = @term
       when not matched then insert (
                VERSION_
                ,ITEM_ID_
                ,PRIMARY_PART_ITEM_ID_
                ,CMD_ID_
                ,BU_ID_
                ,PARENT_BU_ID_
                ,L2_ID_
                ,NEW_DUES_IN_CONF_
                ,NEW_DUES_IN_NOT_CONF_
                ,RPR_DUES_IN_CONF_
                ,RPR_DUES_IN_NOT_CONF_
                ,STOCK_AWAITING_RECEPTION_
                ,STOCK_AWAITING_LOCATION_
                ,UNDER_STOCK_TAKING_
                ,EXPIRED_STOCK
                ,TOTAL_STOCK_
                ,AVG_TAT 
                ,AVG_PRICE
                ,CREATED_BY_
                ,PID_CREATED_BY_
                ,FULL_NAME_CREATED_BY_
                ,CREATED_ON_
                ,TERM_
                )
        values (
                source.VERSION_
                ,source.ITEM_ID_
                ,source.PRIMARY_PART_ITEM_ID_
                ,source.CMD_ID_
                ,source.BU_ID_
                ,source.PARENT_BU_ID_
                ,source.L2_ID_
                ,source.NEW_DUES_IN_CONF_
                ,source.NEW_DUES_IN_NOT_CONF_
                ,source.RPR_DUES_IN_CONF_
                ,source.RPR_DUES_IN_NOT_CONF_
                ,source.STOCK_AWAITING_RECEPTION_
                ,source.STOCK_AWAITING_LOCATION_
                ,source.UNDER_STOCK_TAKING_
                ,source.EXPIRED_STOCK
                ,source.TOTAL_STOCK_
                ,source.AVG_TAT
                ,source.AVG_PRICE
                ,@createdBy
                ,@pidCreatedBy
                ,@fullNameCreatedBy
                ,GETDATE()
                ,@term
                 );

      -- Merge Last price
      merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE as target
      using (select 1 VERSION_
                    ,ItemId as ITEM_ID_
                    ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = PoSummary.ItemId
                               and itemAssoc.L2_ID = PoSummary.L2Id
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
                                )
                          ,PoSummary.ItemId) PRIMARY_PART_ITEM_ID_
                    ,bu.CMD_ID_ as CMD_ID_
                    ,bu.ID_ as BU_ID_
                    ,isnull(bu.PARENT_STORE_ID_, bu.ID_) PARENT_BU_ID_
                    ,L2Id as L2_ID_
                    ,0 NEW_DUES_IN_CONF_
                    ,0 NEW_DUES_IN_NOT_CONF_
                    ,0 RPR_DUES_IN_CONF_
                    ,0 RPR_DUES_IN_NOT_CONF_
                    ,0 STOCK_AWAITING_RECEPTION_
                    ,0 STOCK_AWAITING_LOCATION_
                    ,0 UNDER_STOCK_TAKING_
                    ,0 EXPIRED_STOCK
                    ,0 TOTAL_STOCK_
                    ,0 as AVG_TAT
                    ,0 as AVG_PRICE
                    ,lastPrice as LAST_PROC_PRICE  
               from (select STORE_ID StoreId
                           ,L2_ID L2Id
                           ,ItemId
                           ,max(lastPrice) lastPrice 
                       from (select isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID) as ItemId 
                                   ,po.VALIDATED_ON_
                                   ,po.STORE_ID
                                   ,po.L2_ID
                                   --,isnull(CAST(((ISNULL(POI.SHIPPING_COST_,0) + ISNULL(POI.HANDLING_COST_,0) - ISNULL(POI.DISCOUNT_,0)) * 0.01 + 1) * POI.UNIT_PRICE_VAL_  AS decimal(18, 2)),0) as lastPrice
								   ,ISNULL(CAST(POI.UNIT_PRICE_VAL_  AS decimal(18, 2)),0) as lastPrice
                                   ,ROW_NUMBER() over (partition by isnull(POI.INLIEU_ITEM_ID,proc_item.ITEM_ID),STORE_ID,L2_ID order by po.VALIDATED_ON_ desc) as rn
                               from LOG_TRN_PRC_PURCHASE_ORDER_ITEM POI 
                                    inner join LOG_TRN_PRC_PROCUREMENT_ITEM proc_item on POI.PROC_ITEM_ID=proc_item.ID_ 
                                    inner join LOG_TRN_PRC_PURCHASE_ORDER po on POI.PO_ID=po.ID_
                              where po.STATUS_ not in('Created','Canceled') and POI.UNIT_PRICE_VAL_ > 0
                              ) t 
                      where t.rn=1
                      group by ItemId
                           ,STORE_ID
                           ,L2_ID
                            ) as PoSummary 
                    join ADM_MST_BUSINESS_UNITS bu on bu.ID_=PoSummary.StoreId  
      ) as source
         on (    target.ITEM_ID_ = source.ITEM_ID_
             and target.CMD_ID_ = source.CMD_ID_
             and target.BU_ID_ = source.BU_ID_
             and target.L2_ID_ = source.L2_ID_
            )
       when matched then update 
                            set target.LAST_PROC_PRICE = source.LAST_PROC_PRICE
                            ,target.MOD_BY_ = @createdBy
                            ,target.PID_MOD_BY_ = @pidCreatedBy
                            ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
                            ,target.MOD_ON_ = GETDATE()
                            ,target.TERM_ = @term
       when not matched then insert (
                VERSION_
                ,ITEM_ID_
                ,PRIMARY_PART_ITEM_ID_
                ,CMD_ID_
                ,BU_ID_
                ,PARENT_BU_ID_
                ,L2_ID_
                ,NEW_DUES_IN_CONF_
                ,NEW_DUES_IN_NOT_CONF_
                ,RPR_DUES_IN_CONF_
                ,RPR_DUES_IN_NOT_CONF_
                ,STOCK_AWAITING_RECEPTION_
                ,STOCK_AWAITING_LOCATION_
                ,UNDER_STOCK_TAKING_
                ,EXPIRED_STOCK
                ,TOTAL_STOCK_
                ,AVG_TAT 
                ,AVG_PRICE
                ,LAST_PROC_PRICE
                ,CREATED_BY_
                ,PID_CREATED_BY_
                ,FULL_NAME_CREATED_BY_
                ,CREATED_ON_
                ,TERM_
                 )
        values (
                source.VERSION_
                ,source.ITEM_ID_
                ,source.PRIMARY_PART_ITEM_ID_
                ,source.CMD_ID_
                ,source.BU_ID_
                ,source.PARENT_BU_ID_
                ,source.L2_ID_
                ,source.NEW_DUES_IN_CONF_
                ,source.NEW_DUES_IN_NOT_CONF_
                ,source.RPR_DUES_IN_CONF_
                ,source.RPR_DUES_IN_NOT_CONF_
                ,source.STOCK_AWAITING_RECEPTION_
                ,source.STOCK_AWAITING_LOCATION_
                ,source.UNDER_STOCK_TAKING_
                ,source.EXPIRED_STOCK
                ,source.TOTAL_STOCK_
                ,source.AVG_TAT
                ,source.AVG_PRICE
                ,source.LAST_PROC_PRICE
                ,@createdBy
                ,@pidCreatedBy
                ,@fullNameCreatedBy
                ,GETDATE()
                ,@term
                );

      --Dues out quantity

      merge LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE as target
      using (select 1 VERSION_
                   ,ItemId as ITEM_ID_
                   ,isnull((select top(1) il_itemAssoc.ITEM_ID
                              from ADM_TRN_ITEM_ASSOCS itemAssoc
                                   join ADM_TRN_ITEM_ASSOCS il_itemAssoc on itemAssoc.IN_LIEU_CODE_ = il_itemAssoc.IN_LIEU_CODE_
                             where itemAssoc.ITEM_ID = DuesOutSummary.ItemId
                               and itemAssoc.L2_ID = DuesOutSummary.L2Id
                               and itemAssoc.IN_LIEU_CODE_ is not null
                               and il_itemAssoc.PRIMARY_PART_ = 1
                                )
                            ,DuesOutSummary.ItemId) PRIMARY_PART_ITEM_ID_
                    ,bu.CMD_ID_ as CMD_ID_
                    ,bu.ID_ as BU_ID_
                    ,isnull(bu.PARENT_STORE_ID_, bu.ID_) PARENT_BU_ID_
                    ,L2Id as L2_ID_
                    ,0 NEW_DUES_IN_CONF_
                    ,0 NEW_DUES_IN_NOT_CONF_
                    ,0 RPR_DUES_IN_CONF_
                    ,0 RPR_DUES_IN_NOT_CONF_
                    ,0 STOCK_AWAITING_RECEPTION_
                    ,0 STOCK_AWAITING_LOCATION_
                    ,0 UNDER_STOCK_TAKING_
                    ,0 EXPIRED_STOCK
                    ,0 TOTAL_STOCK_
                    ,DuesOutUser as USER_DUES_OUT_QTY 
                from (select do.ITEM_ID_ as ItemId
                            ,do.FF_L2_ID_ as L2Id
                            ,do.FF_BU_ID_ as StoreId
                            ,SUM(do.QTY_) DuesOutUser
                        from VW_DUES_OUT do
                       where do.DUES_OUT_TO_ = 'User'
                       group by do.ITEM_ID_
                            ,do.FF_L2_ID_
                            ,do.FF_BU_ID_
                             ) as DuesOutSummary 
                     join ADM_MST_BUSINESS_UNITS bu on bu.ID_ = DuesOutSummary.StoreId
        ) as source
         on (    target.ITEM_ID_ = source.ITEM_ID_
             and target.CMD_ID_ = source.CMD_ID_
             and target.BU_ID_ = source.BU_ID_
             and target.L2_ID_ = source.L2_ID_
            )
       when matched then update 
                            set target.USER_DUES_OUT_QTY = source.USER_DUES_OUT_QTY
                                ,target.MOD_BY_ = @createdBy
                                ,target.PID_MOD_BY_ = @pidCreatedBy
                                ,target.FULL_NAME_MOD_BY_ = @fullNameCreatedBy
                                ,target.MOD_ON_ = GETDATE()
                                ,target.TERM_ = @term
       when not matched then insert ( 
                 VERSION_
                ,ITEM_ID_
                ,PRIMARY_PART_ITEM_ID_
                ,CMD_ID_
                ,BU_ID_
                ,PARENT_BU_ID_
                ,L2_ID_
                ,NEW_DUES_IN_CONF_
                ,NEW_DUES_IN_NOT_CONF_
                ,RPR_DUES_IN_CONF_
                ,RPR_DUES_IN_NOT_CONF_
                ,STOCK_AWAITING_RECEPTION_
                ,STOCK_AWAITING_LOCATION_
                ,UNDER_STOCK_TAKING_
                ,EXPIRED_STOCK
                ,TOTAL_STOCK_
                ,USER_DUES_OUT_QTY
                ,CREATED_BY_
                ,PID_CREATED_BY_
                ,FULL_NAME_CREATED_BY_
                ,CREATED_ON_
                ,TERM_
                )
        values (source.VERSION_
                ,source.ITEM_ID_
                ,source.PRIMARY_PART_ITEM_ID_
                ,source.CMD_ID_
                ,source.BU_ID_
                ,source.PARENT_BU_ID_
                ,source.L2_ID_
                ,source.NEW_DUES_IN_CONF_
                ,source.NEW_DUES_IN_NOT_CONF_
                ,source.RPR_DUES_IN_CONF_
                ,source.RPR_DUES_IN_NOT_CONF_
                ,source.STOCK_AWAITING_RECEPTION_
                ,source.STOCK_AWAITING_LOCATION_
                ,source.UNDER_STOCK_TAKING_
                ,source.EXPIRED_STOCK
                ,source.TOTAL_STOCK_
                ,source.USER_DUES_OUT_QTY
                ,@createdBy
                ,@pidCreatedBy
                ,@fullNameCreatedBy
                ,GETDATE()
                ,@term
                );   

 

      --start populating MifUnitPrice

					truncate table dbo.LOG_TRN_ITEM_CATALOG_PRICE_SNAPSHOT
    
					insert into LOG_TRN_ITEM_CATALOG_PRICE_SNAPSHOT (
					   VERSION_
					  ,ITEM_ID_
					  ,CMD_ID_
					  ,L2_ID_
					  ,CATALOG_PRICE_
					  ,CREATED_BY_
					  ,PID_CREATED_BY_
					  ,FULL_NAME_CREATED_BY_
					  ,CREATED_ON_
					  ,TERM_
					)
					select 1 version_
						  ,mif.ITEM_ID
						  ,pl2.CMD_ID_
						  ,pl2.L2_ID_
						  ,isnull(MAX(mif.UNIT_PRICE_ * ISNULL(curr.RATE_, 1)), 0) 
						  ,@createdBy
						  ,@pidCreatedBy
						  ,@fullNameCreatedBy
						  ,GETDATE()
						  ,@term
					  from ADM_MST_ITEM_MIF_EXTENSION mif
						   left outer join ADM_MST_MONEY_CURRENCY curr on mif.UNIT_PRICE_CUR_ID = curr.ID_
						   LEFT join ADM_MST_PLATFORM_L2 pl2 on mif.CMD_ID = pl2.CMD_ID_ and mif.PLTF_ID = pl2.PLTF_ID_
					 group by mif.ITEM_ID, pl2.CMD_ID_, pl2.L2_ID_



      COMMIT;

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
      ROLLBACK TRAN;

    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;
    SELECT @ErrorMessage = ERROR_MESSAGE()
          ,@ErrorSeverity = ERROR_SEVERITY()
          ,@ErrorState = ERROR_STATE();
    RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

END CATCH;
go

