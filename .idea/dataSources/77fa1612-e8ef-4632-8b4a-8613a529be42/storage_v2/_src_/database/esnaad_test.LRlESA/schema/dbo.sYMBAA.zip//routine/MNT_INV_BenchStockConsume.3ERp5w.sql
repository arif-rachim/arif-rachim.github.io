CREATE PROC [dbo].[MNT_INV_BenchStockConsume] (@consumeItems MNT_INV_TYPE_BenchStockMovement READONLY, @refType nvarchar(255), @refNo nvarchar(255), @remarks nvarchar(MAX), @userProfileId bigint, @terminal nvarchar(255))
AS 
BEGIN
	DECLARE @userId nvarchar(255), @fullname nvarchar(1000), @pid nvarchar(255)
	DECLARE @createdOn datetime = getdate()
	
	IF EXISTS (
		SELECT BS.ID_
		FROM MNT_TRN_INV_BENCH_STOCK_SPEC BS
		JOIN @consumeItems IM ON BS.ID_ = IM.bsId
		WHERE IM.bsVersion <> BS.VERSION_
	) 
	BEGIN
		RAISERROR('Bench Stock you are trying to consume was modified by another user. Please refresh and retry.',16,1)
		RETURN
	END

	IF EXISTS (
		SELECT BS.ID_
		FROM MNT_TRN_INV_BENCH_STOCK_SPEC BS
		JOIN @consumeItems IM ON BS.ID_ = IM.bsId
		WHERE BS.QTY_ < IM.qty
	)
	BEGIN
		RAISERROR('You are trying to consume more than available quantity. Process aborted.',16,1)
		RETURN
	END
	

	SELECT @userId = UserId, @fullname=FullName, @pid=Pid FROM dbo.GetUserInfo(@userProfileId)

	INSERT MNT_TRN_INV_BENCH_STOCK_CONSUMPTION(VERSION_, QTY_, REF_TYPE_, REF_NO_, REMARKS_,UNIT_ID, LOC_ID, L2_ID, CREATED_BY_,PID_CREATED_BY_,FULL_NAME_CREATED_BY_,CREATED_ON_)
	SELECT 1, qty, @refType, @refNo, @remarks, BS.UNIT_ID, BS.LOC_ID, BS.L2_ID, @userId, @pid, @fullname, @createdOn 
	FROM @consumeItems CI
	JOIN MNT_TRN_INV_BENCH_STOCK_SPEC BS ON CI.bsId = BS.ID_

	UPDATE ADM_TRN_IMV_ITEMS_IN_LOCATION SET QTY_ = ADM_TRN_IMV_ITEMS_IN_LOCATION.QTY_ - CI.qty, VERSION_= ADM_TRN_IMV_ITEMS_IN_LOCATION.VERSION_ + 1
	, MOD_BY_ = @userId, PID_MOD_BY_ = @pid, FULL_NAME_MOD_BY_ = @fullname, MOD_ON_ =@createdOn, TERM_ = @terminal
	FROM MNT_TRN_INV_BENCH_STOCK_SPEC BS 
	JOIN @consumeItems CI ON BS.ID_ = CI.bsId
	WHERE TYPE_ = 'Logistic'
	AND BS.UNIT_ID = ADM_TRN_IMV_ITEMS_IN_LOCATION.UNIT_ID_
	AND BS.LOC_ID = ADM_TRN_IMV_ITEMS_IN_LOCATION.LOC_ID_
	AND 1 = ADM_TRN_IMV_ITEMS_IN_LOCATION.TC_ID_
	AND BS.L2_ID = ADM_TRN_IMV_ITEMS_IN_LOCATION.OWNED_L2_ID_

	UPDATE MNT_TRN_INV_BENCH_STOCK_SPEC SET QTY_ = BS.QTY_ - IM.qty, VERSION_ = VERSION_+1
	, MOD_BY_ = @userId, PID_MOD_BY_ = @pid, FULL_NAME_MOD_BY_ = @fullname, MOD_ON_ = @createdOn, TERM_ = @terminal
	FROM @consumeItems IM
	JOIN MNT_TRN_INV_BENCH_STOCK_SPEC  BS ON BS.ID_ = IM.bsId
	WHERE IM.bsVersion = BS.VERSION_

	-- history
	INSERT MNT_HST_INV_AUDIT_TRAIL(ID_, VERSION_, BU_ID, PART_NO_, CAGE_CODE_, NSN_, NOMENCLATURE_, CLASS_, L2_, SERIAL_NO_, LG_, LOC_, QTY_, UOM_, ACT_TYPE_, REMARKS_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_)
	SELECT dbo.GenerateTimebasedGuid() ID_, 1 VERSION_, IMV.BU_ID_, PART_NO_, CAGE_CODE_, NSN_, NOMENCLATURE_, CLASS_, L2_, SERIAL_NO_
	, LG_NAME_, LOC_NAME_
	, CI.qty, UOM_, 'Consumed Bench Stock', @remarks, @userId, @pid, @fullname, @createdOn, @terminal
	FROM VW_MNT_INV_BENCH_STOCK IMV
	JOIN @consumeItems CI ON CI.bsId = IMV.BS_ID_

	-- item transaction history
	INSERT ADM_HST_ITEM_TX(ID_, VERSION_, ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, IS_SERIALIZED_, MOV_TYPE_, QTY_, BU_ID_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, CREATED_ON_, TERM_, COND_ID_, DOC_REF_, L2_ID_, REMARKS_, PERF_USER_PROFILE_ID_, PERF_USER_ID_, PERF_PID_, PERF_FULL_NAME_, PERF_ON_, BASE_UOM)
	SELECT dbo.GenerateTimebasedGuid() AS ID_, 1 AS VERSION_,  IMV.ITEM_ID AS ITEM_ID_, PART_NO_, CAGE_CODE_, NOMENCLATURE_, SERIAL_NO_, SERIALIZED_ AS IS_SERIALIZED_,'MI_CSM' AS MOV_TYPE_, CI.qty, BU_ID_
	, @userId AS CREATED_BY_, @pid AS PID_CREATED_BY_, @fullname AS  FULL_NAME_CREATED_BY_, @createdOn AS CREATED_ON_, @terminal
	, TC_ID_, NULL, IMV.L2_ID_, @remarks, @userProfileId, @userId, @pid AS PERF_PID_, @fullname AS PERF_FULL_NAME_, @createdOn AS PERF_ON_, IMV.UOM_
	FROM VW_MNT_INV_BENCH_STOCK IMV
	JOIN @consumeItems CI ON CI.bsId = IMV.BS_ID_

	-- Clean bench stock and items in location
	DELETE imv 
	FROM ADM_TRN_IMV_ITEMS_IN_LOCATION imv
	JOIN MNT_TRN_INV_BENCH_STOCK_SPEC BS ON BS.UNIT_ID = imv.UNIT_ID_ AND BS.LOC_ID = imv.LOC_ID_ AND 1 = imv.TC_ID_ AND BS.L2_ID = imv.OWNED_L2_ID_
	JOIN @consumeItems CI ON BS.ID_ = CI.bsId
	WHERE imv.QTY_ = 0

	DELETE MNT_TRN_INV_BENCH_STOCK_SPEC
	WHERE QTY_ = 0


END
go

