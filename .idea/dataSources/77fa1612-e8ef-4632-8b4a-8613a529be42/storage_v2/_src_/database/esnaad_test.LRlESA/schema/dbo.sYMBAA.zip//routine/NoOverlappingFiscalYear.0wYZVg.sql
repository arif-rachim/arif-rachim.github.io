CREATE FUNCTION NoOverlappingFiscalYear
(
    @Id uniqueidentifier,
	@startDate dateTime,
	@endDate dateTime
)
RETURNS bit
AS
BEGIN
	DECLARE @valid bit = 1;
 
	IF exists(SELECT * 
	          FROM PMO_TRN_BM_FISCAL_YEAR fy
			  WHERE @Id != ID_ and @startDate <= fy.END_DATE_ and fy.START_DATE_ <= @endDate)

		set @valid = 0
 
	RETURN @Valid
 
 end
go

