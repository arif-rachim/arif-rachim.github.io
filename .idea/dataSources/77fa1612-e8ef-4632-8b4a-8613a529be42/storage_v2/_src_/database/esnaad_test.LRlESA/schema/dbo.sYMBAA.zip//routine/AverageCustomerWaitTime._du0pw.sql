CREATE FUNCTION [dbo].[AverageCustomerWaitTime]
(
      @StartDate	date,
      @EndDate	date,
      @CommandIds nvarchar(max),
      @StoreIds	nvarchar(max)
)
RETURNS int
AS
BEGIN
	DECLARE @sum int
	DECLARE @count int
	DECLARE @result int

	set @sum = 0
	set @count = 0
	set @result = 0

	BEGIN
		SELECT @sum =  SUM((
		CASE 
			WHEN WFAPPR.APRDATE IS NOT NULL THEN 
				CASE 
					WHEN WFAPPR.APRDATE < @StartDate AND TI.CREATED_ON_ <= @EndDate THEN  DATEDIFF(day,  @StartDate, TI.CREATED_ON_)
					WHEN WFAPPR.APRDATE < @StartDate AND (TI.CREATED_ON_ > @EndDate OR TI.CREATED_ON_ IS NULL) THEN DATEDIFF(day,  @StartDate, @EndDate)
					WHEN WFAPPR.APRDATE >= @StartDate AND TI.CREATED_ON_ <= @EndDate THEN DATEDIFF(day,  WFAPPR.APRDATE, TI.CREATED_ON_)
					WHEN WFAPPR.APRDATE >= @StartDate AND (TI.CREATED_ON_ > @EndDate OR TI.CREATED_ON_ IS NULL) THEN DATEDIFF(day,  WFAPPR.APRDATE, @EndDate)
				END
		ELSE 
				CASE 
					WHEN WFVAL.VALDATE < @StartDate AND TI.CREATED_ON_ <= @EndDate THEN  DATEDIFF(day,  @StartDate, TI.CREATED_ON_)
					WHEN WFVAL.VALDATE < @StartDate AND (TI.CREATED_ON_ > @EndDate OR TI.CREATED_ON_ IS NULL) THEN DATEDIFF(day,  @StartDate, @EndDate)
					WHEN WFVAL.VALDATE >= @StartDate AND TI.CREATED_ON_ <= @EndDate THEN DATEDIFF(day,  WFVAL.VALDATE, TI.CREATED_ON_)
					WHEN WFVAL.VALDATE >= @StartDate AND (TI.CREATED_ON_ > @EndDate OR TI.CREATED_ON_ IS NULL) THEN DATEDIFF(day,  WFVAL.VALDATE, @EndDate)
				END
		END))
		FROM LOG_TRN_TRM_TRANSFER_REQUEST AS req 
			INNER JOIN WF_TRN_INSTANCE AS wfinst ON req.WF_ID = wfinst.ID_ 
			LEFT JOIN LOG_TRN_TRM_TRANSFER_INFO AS TI ON req.ID_ = TI.TRF_REQ_ID_
			LEFT JOIN MNT_MST_REQUISITION_CONFIGURATION AS rconfig ON rconfig.CMD_ID_ = req.FI_CMD_ID_
			LEFT JOIN (
				select WF_INST_ID AS VALWFINSTID, MAX(PROC_ON) AS VALDATE  from WF_TRN_TRACKING WHERE TRANS_ = 'Validate'
				GROUP BY WF_INST_ID
				) AS WFVAL ON WFVAL.VALWFINSTID =  wfinst.ID_
			LEFT JOIN (
				select WF_INST_ID AS APRWFINSTID, MAX(PROC_ON) AS APRDATE  from WF_TRN_TRACKING WHERE TRANS_ = 'Approve'
				GROUP BY WF_INST_ID
				) AS WFAPPR ON WFAPPR.APRWFINSTID =  wfinst.ID_
			WHERE (req.TR_TYPE_ = 'Requisition') AND (wfinst.WF_DEF_ID_ = 'RequisitionWorkflow') 
	            AND wfinst.WF_STATE_  NOT IN ('Rejected', 'Canceled', 'Deleted')
	            AND (CASE 
						WHEN WFAPPR.APRDATE IS NOT NULL THEN WFAPPR.APRDATE 
						ELSE WFVAL.VALDATE
					 END) <=  @EndDate AND (TI.CREATED_ON_ IS NULL OR TI.CREATED_ON_ >= @StartDate) 
	            AND req.FI_CMD_ID_ IN (SELECT Item from dbo.SplitInts(@CommandIds, ','))
	            AND req.FI_BU_ID_ IN (SELECT Item from dbo.SplitInts(@StoreIds, ','))
	END
	BEGIN
		SELECT @count = COUNT(*) FROM LOG_TRN_TRM_TRANSFER_REQUEST AS req 
	            INNER JOIN WF_TRN_INSTANCE AS wfinst ON req.WF_ID = wfinst.ID_ 
	            LEFT JOIN LOG_TRN_TRM_TRANSFER_INFO AS TI ON req.ID_ = TI.TRF_REQ_ID_
				LEFT JOIN MNT_MST_REQUISITION_CONFIGURATION AS rconfig ON rconfig.CMD_ID_ = req.FI_CMD_ID_
				LEFT JOIN (
					select WF_INST_ID AS VALWFINSTID, MAX(PROC_ON) AS VALDATE  from WF_TRN_TRACKING WHERE TRANS_ = 'Validate'
					GROUP BY WF_INST_ID
					) AS WFVAL ON WFVAL.VALWFINSTID =  wfinst.ID_
				LEFT JOIN (
					select WF_INST_ID AS APRWFINSTID, MAX(PROC_ON) AS APRDATE  from WF_TRN_TRACKING WHERE TRANS_ = 'Approve'
					GROUP BY WF_INST_ID
					) AS WFAPPR ON WFAPPR.APRWFINSTID =  wfinst.ID_
	            WHERE (req.TR_TYPE_ = 'Requisition') AND (wfinst.WF_DEF_ID_ = 'RequisitionWorkflow') 
	            AND wfinst.WF_STATE_  NOT IN ('Rejected', 'Canceled', 'Deleted')
				AND (CASE 
						WHEN WFAPPR.APRDATE IS NOT NULL THEN WFAPPR.APRDATE 
						ELSE WFVAL.VALDATE
					END) <=  @EndDate AND (TI.CREATED_ON_ IS NULL OR TI.CREATED_ON_ >= @StartDate) 
                AND req.FI_CMD_ID_ IN (SELECT Item from dbo.SplitInts(@CommandIds, ','))
                AND req.FI_BU_ID_ IN (SELECT Item from dbo.SplitInts(@StoreIds, ','))
	END

	BEGIN
		IF (@sum > 0 AND @count > 0)
			   SELECT @result = @sum/@count;		
	END

	RETURN @result;
END
go

