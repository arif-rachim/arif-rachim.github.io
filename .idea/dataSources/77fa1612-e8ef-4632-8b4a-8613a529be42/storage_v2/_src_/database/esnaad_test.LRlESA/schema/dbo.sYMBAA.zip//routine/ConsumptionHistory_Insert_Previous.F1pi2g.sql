CREATE PROCEDURE ConsumptionHistory_Insert_Previous
	@pExecutionDate datetime
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @storeId BIGINT;
	DECLARE @cmdId BIGINT;
	DECLARE @L2Id BIGINT;

	DECLARE @tagColorId_Serviceable BIGINT = (SELECT ID_ FROM dbo.ADM_MST_TAG_COLOR_CONDITION WHERE CONDITION_ = 'Serviceable');

	DECLARE StoreCursor CURSOR FOR
	SELECT ID_, CMD_ID_, L2_ID_
	FROM ADM_MST_BUSINESS_UNITS BU
	JOIN ADM_MST_BUSINESS_UNITS_L2 BUL2
		ON BU.ID_ = BUL2.BU_ID_
	WHERE
		BU_TYPE_ = 'Store'
		AND IS_ACTIVE_ = 1;

	OPEN StoreCursor;

	FETCH NEXT FROM StoreCursor
	INTO @storeId, @cmdId, @L2Id;
	
	-- create empty table
	SELECT * INTO #TblTempConsumption FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY WHERE 1=0

	WHILE @@FETCH_STATUS = 0
	BEGIN
--		INSERT INTO LOG_TRN_ITEM_CONSUMPTION_HISTORY
		INSERT INTO #TblTempConsumption
		(
			 ITEM_ID
			,CMD_ID
			,BU_ID_
			,L2_ID_
			,YEAR
			,TOTAL_ISSUE_
			,TOTAL_TURN_IN_
		)
		SELECT
			 Items.ID_ AS ITEM_ID
			,@cmdId AS CMD_ID_
			,@storeId AS BU_ID_
			
			,@L2Id AS L2_ID
	--		,TblReqFulfill.ORG_L2_ID_
			
			,CASE
				WHEN TblReqFulfill.TOTAL_ISSUE_ IS NOT NULL THEN TblReqFulfill.QueryYear 
				WHEN TblServiceableTurnin.TOTAL_TURN_IN_ IS NOT NULL THEN TblServiceableTurnin.QueryYear 
				WHEN TblDeFactoServiceableTurnin.TOTAL_TURN_IN_ IS NOT NULL THEN TblDeFactoServiceableTurnin.QueryYear 
			END 

			,ISNULL(TblReqFulfill.TOTAL_ISSUE_, 0)
			,	ISNULL(TblServiceableTurnin.TOTAL_TURN_IN_, 0) + 
				ISNULL(TblDeFactoServiceableTurnin.TOTAL_TURN_IN_, 0) AS TOTAL_TURN_IN_Combined
			
		FROM ADM_MST_ITEMS Items
		
		LEFT JOIN
		(
			-- 1) Requisition fulfillment
			SELECT
				U.ITEM_ID , D.ORG_BU_ID_, D.ORG_L2_ID_, YEAR(TRF_DATE_) AS QueryYear, 
				ISNULL(SUM(DI.QTY_), 0) AS TOTAL_ISSUE_			
			FROM
				LOG_TRN_TRF_TRANSFER_DATA AS D INNER JOIN
				LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON D.ID_ = DI.TRF_ID INNER JOIN
				ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ 
			WHERE
				(D.PROC_REF_TYPE_ = 'REQ')
				AND D.ORG_BU_ID_ = @storeId
				AND D.ORG_L2_ID_ = @L2Id
				AND YEAR(TRF_DATE_) =  YEAR(GETDATE()) - 1	-- Only current year
			GROUP BY 
				U.ITEM_ID, D.ORG_BU_ID_, D.ORG_L2_ID_, YEAR(TRF_DATE_)
		) AS TblReqFulfill
		ON
			Items.ID_ = TblReqFulfill.ITEM_ID

		LEFT JOIN
		(
			-- 2) Real Serviceable turn-in
			SELECT
				U.ITEM_ID, BU.CMD_ID_, D.DST_BU_ID_, D.DST_L2_ID_, YEAR(D.RCV_DATE_) AS QueryYear, SUM(DI.QTY_) AS TOTAL_TURN_IN_			
			FROM
				LOG_TRN_TRF_TRANSFER_DATA AS D INNER JOIN
				LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON D.ID_ = DI.TRF_ID INNER JOIN
				ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ INNER JOIN
				ADM_MST_BUSINESS_UNITS BU ON D.DST_BU_ID_ = BU.ID_ AND BU.BU_TYPE_ = 'Store'
			WHERE
				(D.PROC_REF_TYPE_ = 'TI')
				AND D.DST_BU_ID_ = @storeId
				AND D.DST_L2_ID_ = @L2Id			
				AND YEAR(D.RCV_DATE_) =  YEAR(GETDATE()) - 1	-- Only current year
			GROUP BY
				U.ITEM_ID, BU.CMD_ID_, D.DST_BU_ID_, D.DST_L2_ID_, YEAR(D.RCV_DATE_)
		) AS TblServiceableTurnin
		ON
			Items.ID_ = TblServiceableTurnin.ITEM_ID
		
		LEFT JOIN
		(
			-- 3) De facto "Serviceable turn-in" done to store through Work Order
			SELECT
				U.ITEM_ID, BuDest.CMD_ID_, D.DST_BU_ID_, D.DST_L2_ID_, YEAR(D.RCV_DATE_) AS QueryYear, SUM(DI.QTY_) AS TOTAL_TURN_IN_
			FROM
				LOG_TRN_TRF_TRANSFER_DATA AS D INNER JOIN
				LOG_TRN_TRF_TRANSFER_DATA_ITEM AS DI ON (D.ID_ = DI.TRF_ID AND DI.TAG_COND_ID_ = @tagColorId_Serviceable) INNER JOIN
				ADM_MST_UNITS AS U ON DI.UNIT_ID_ = U.ID_ INNER JOIN
				ADM_MST_BUSINESS_UNITS BuDest ON D.DST_BU_ID_ = BuDest.ID_ AND BuDest.BU_TYPE_ = 'Store' INNER JOIN
--				ADM_MST_BUSINESS_UNITS BuOrg ON D.ORG_BU_ID_ = BuOrg.ID_ AND BuOrg.BU_TYPE_ <> 'Store'
				MNT_TRN_WOTS_WORK_ORDER WO ON WO.WO_NO_ = D.DOC_REF_NO_ INNER JOIN 
				ADM_MST_BUSINESS_UNITS BuOrg ON WO.ORG_CODE_ = BuOrg.CODE_ AND BuOrg.BU_TYPE_ <> 'Store'
			WHERE
				(D.PROC_REF_TYPE_ = 'WO')
				AND D.DST_BU_ID_ = @storeId
				AND D.DST_L2_ID_ = @L2Id			
				AND YEAR(D.RCV_DATE_) =  YEAR(GETDATE()) - 1	-- Only current year
			GROUP BY 
				U.ITEM_ID, BuDest.CMD_ID_, D.DST_BU_ID_, D.DST_L2_ID_, YEAR(D.RCV_DATE_)
		) AS TblDeFactoServiceableTurnin
		ON
			Items.ID_ = TblDeFactoServiceableTurnin.ITEM_ID
		WHERE
		-- Exclude recs if all 3 tables have no related records
		(
			TblReqFulfill.ITEM_ID IS NOT NULL
			OR TblServiceableTurnin.ITEM_ID IS NOT NULL
			OR TblDeFactoServiceableTurnin.ITEM_ID IS NOT NULL
		)

		FETCH NEXT FROM StoreCursor
		INTO @storeId, @cmdId, @L2Id;	

	END

	CLOSE StoreCursor;
	DEALLOCATE StoreCursor;

	SET NOCOUNT OFF;




    --DELETE LOG_TRN_ITEM_CONSUMPTION_HISTORY_AUDIT_LOG
    
    -- Audit log: Insert only modified records + new records
	INSERT INTO LOG_TRN_RPT_CONSUMPTION_HISTORY_LOG
	(    ID_
	    ,VERSION_
	    ,DATE_
		,ITEM_ID
		,CMD_ID
		,BU_ID_
		,L2_ID_
		,YEAR
		,TOTAL_ISSUE_
		,TOTAL_TURN_IN_
		,EXE_STATUS_
	)
	SELECT 
	     (select NEWID())
		 ,1
		 ,@pExecutionDate
		,TblTempConsumption.ITEM_ID
		,TblTempConsumption.CMD_ID
		,TblTempConsumption.BU_ID_
		,TblTempConsumption.L2_ID_
		,TblTempConsumption.YEAR
		,TblTempConsumption.TOTAL_ISSUE_
		,TblTempConsumption.TOTAL_TURN_IN_
		,'Success'
		FROM #TblTempConsumption as TblTempConsumption
		left JOIN
		LOG_TRN_ITEM_CONSUMPTION_HISTORY TblHistory ON 	
		TblTempConsumption.CMD_ID = TblHistory.CMD_ID AND
		TblTempConsumption.BU_ID_ = TblHistory.BU_ID_ AND
		TblTempConsumption.L2_ID_ = TblHistory.L2_ID_ AND
		TblTempConsumption.YEAR = TblHistory.YEAR AND
		TblTempConsumption.ITEM_ID = TblHistory.ITEM_ID
	WHERE
	(
		(
			TblTempConsumption.ITEM_ID = TblHistory.ITEM_ID
			AND
			(
				TblTempConsumption.TOTAL_ISSUE_<> TblHistory.TOTAL_ISSUE_
				OR TblTempConsumption.TOTAL_TURN_IN_ <> TblHistory.TOTAL_TURN_IN_
			)
		)
		
		OR
		
		(TblHistory.ITEM_ID IS NULL)
	)
	;
	
	-- Clear old history records
	BEGIN TRY
	--	TRUNCATE TABLE LOG_TRN_ITEM_CONSUMPTION_HISTORY;
		DELETE FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY WHERE YEAR = YEAR(GETDATE()) - 1	-- Only current year
	END TRY
	BEGIN CATCH
		PRINT ''
		PRINT 'Please run the script to create table: LOG_TRN_ITEM_CONSUMPTION_HISTORY'
		PRINT 'Execution stopped!'
		RETURN;
	END CATCH
	
	-- Dump temporary table to history
	INSERT INTO LOG_TRN_ITEM_CONSUMPTION_HISTORY
	(
		 ITEM_ID
		,CMD_ID
		,BU_ID_
		,L2_ID_
		,YEAR
		,TOTAL_ISSUE_
		,TOTAL_TURN_IN_
	)
	SELECT
		 TblTempConsumption.ITEM_ID
		,TblTempConsumption.CMD_ID
		,TblTempConsumption.BU_ID_
		,TblTempConsumption.L2_ID_
		,TblTempConsumption.YEAR
		,TblTempConsumption.TOTAL_ISSUE_
		,TblTempConsumption.TOTAL_TURN_IN_	
	FROM #TblTempConsumption as TblTempConsumption
	
	DROP TABLE #TblTempConsumption;


END

/*
select * from LOG_TRN_ITEM_CONSUMPTION_HISTORY
select * from LOG_TRN_RPT_CONSUMPTION_HISTORY_LOG

EXEC ConsumptionHistory_Insert_Previous '12-29-2016'
*/
go

