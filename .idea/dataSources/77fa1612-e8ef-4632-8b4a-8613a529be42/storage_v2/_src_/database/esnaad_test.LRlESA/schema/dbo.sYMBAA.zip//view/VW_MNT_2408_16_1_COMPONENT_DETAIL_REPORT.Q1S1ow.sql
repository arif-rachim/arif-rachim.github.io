CREATE VIEW [dbo].[VW_MNT_2408_16_1_COMPONENT_DETAIL_REPORT]
AS 
SELECT  
		pu.SERIAL_NO_	AS ParentSerialNo 
		, CASE WHEN engine.ComponentType='HR' THEN pi.NOMENCLATURE_ ELSE engine.CompNomenclature END AS CompNomenclature
		, CASE WHEN engine.ComponentType='HR' THEN pi.PART_NO_ ELSE engine.CompPartNo END AS CompPartNo
		, CASE WHEN engine.ComponentType='HR' THEN t.T_NUM_ ELSE engine.CompSerialNo END AS CompSerialNo
		, hu.SERIAL_NO_ AS HistoryRecorderSerialNo

		, hr.CR_LCF1_ AS LcfOneThree
		, hr.CI_LCF1_ AS LcfOneTwoMinus
		, (hr.CR_LCF1_ - hr.CI_LCF1_) AS LcfOneFourEqual
		, hr.PC_LCF1_ AS LcfOneOnePlus
		, ((hr.CR_LCF1_ - hr.CI_LCF1_) + hr.PC_LCF1_) AS LcfOneFiveEqual

		, hr.CR_LCF2_ AS LcfTwoThree
		, hr.CI_LCF2_ AS LcfTwoTwoMinus
		, (hr.CR_LCF2_ - hr.CI_LCF2_) AS LcfTwoFourEqual
		, hr.PC_LCF2_ AS LcfTwoOnePlus
		, ((hr.CR_LCF2_ - hr.CI_LCF2_) + hr.PC_LCF2_) AS LcfTwoFiveEqual

		, hr.CR_TTI_ AS TimeOrTempIndexThree
		, hr.CI_TTI_ AS TimeOrTempIndexTwoMinus
		, (hr.CR_TTI_ - hr.CI_TTI_) AS TimeOrTempIndexFourEqual
		, hr.PC_TTI_ AS TimeOrTempIndexOnePlus
		, ((hr.CR_TTI_ - hr.CI_TTI_) + hr.PC_TTI_) AS TimeOrTempIndexFiveEqual

		, hr.CR_OP_HRS_ AS OperatingHoursThree
		, hr.CI_OP_HRS_ AS OperatingHoursTwoMinus
		, (hr.CR_OP_HRS_ - hr.CI_OP_HRS_) AS OperatingHoursFourEqual
		, hr.PC_OP_HRS_ AS OperatingHoursOnePlus
		, ((hr.CR_OP_HRS_ - hr.CI_OP_HRS_) + hr.PC_OP_HRS_) AS OperatingHoursFiveEqual

		, hr.END_ACFT_UNIT_ID AS AircraftUnitId
		, engine.EngineUnitId
		, engine.EndUnitId
		, '' AS SignificantHistoricalData
		, engine.HasSubComponents
		, engine.ComponentType
		, engine.Level
		, engine.ComponentUnitId
		, hr.REM_DATE_ AS HRRemovalDate

		, (SELECT TOP(1) H_CODE_ FROM MNT_TRN_D16_1_ASSIGNMENT WHERE END_UNIT_ID = EndUnitId and COMP_UNIT_ID = ComponentUnitId) AS HCode
FROM (
	SELECT DISTINCT
		CASE WHEN ca.COMP_TYPE_ = 'NHR' THEN ci.NOMENCLATURE_ ELSE '' END AS CompNomenclature
		, CASE WHEN ca.COMP_TYPE_ = 'NHR' THEN ci.PART_NO_ ELSE '' END AS CompPartNo
		, CASE WHEN ca.COMP_TYPE_ = 'NHR' THEN cu.SERIAL_NO_ ELSE '' END AS CompSerialNo
		, ca.END_UNIT_ID AS EndUnitId
		, CASE WHEN (SELECT COUNT(ca_c.ID_)
					 FROM MNT_TRN_D16_1_ASSIGNMENT ca_c
						JOIN MNT_TRN_D16_1_MASTER mc_c ON mc_c.ID_ = ca_c.MASTER_ID
					 WHERE mc_c.CMD_ID = mc.CMD_ID
						AND mc_c.PLTF_ID = mc.PLTF_ID
						AND ca_c.END_UNIT_ID = ca.COMP_UNIT_ID) > 0
			THEN CAST(1 AS BIT)
			ELSE CAST(0 AS BIT)
		END AS HasSubComponents
		, ca.COMP_TYPE_ AS ComponentType
		, mc.LEVEL_ AS Level
		, ISNULL((SELECT TOP(1) COMP_UNIT_ID FROM MNT_TRN_D16_1_ASSIGNMENT WHERE H_CODE_ = [dbo].[D161_GetParentHCodeByLevel](ca.ID_, 0)), ca.END_UNIT_ID) AS EngineUnitId
		, ISNULL((SELECT TOP(1) END_UNIT_ID FROM MNT_TRN_D16_1_ASSIGNMENT WHERE END_UNIT_ID=ca.COMP_UNIT_ID), ca.END_UNIT_ID) AS ComponentUnitId
		--, CASE WHEN cab.COMP_UNIT_ID IS NULL THEN ca.END_UNIT_ID ELSE cab.COMP_UNIT_ID END AS EngineUnitId
		--, CASE WHEN caa.END_UNIT_ID IS NULL THEN ca.END_UNIT_ID ELSE caa.END_UNIT_ID END as ComponentUnitId
	FROM 
		MNT_TRN_D16_1_ASSIGNMENT ca 
		JOIN MNT_TRN_D16_1_MASTER mc ON mc.ID_ = ca.MASTER_ID
		JOIN ADM_MST_UNITS cu ON cu.ID_ = ca.COMP_UNIT_ID
		JOIN ADM_MST_ITEMS ci ON ci.ID_ = cu.ITEM_ID
		--LEFT JOIN MNT_TRN_D16_1_ASSIGNMENT caa ON caa.END_UNIT_ID = ca.COMP_UNIT_ID
		--LEFT JOIN MNT_TRN_D16_1_ASSIGNMENT cab ON cab.H_CODE_ = [dbo].[D161_GetParentHCodeByLevel](ca.ID_, 0)
) AS engine
	LEFT JOIN MNT_TRN_D16_1_ASSIGNMENT hr ON hr.END_UNIT_ID = engine.EngineUnitId and hr.COMP_TYPE_ = 'HR'
	JOIN ADM_MST_UNITS hu ON hu.ID_ = hr.COMP_UNIT_ID
	JOIN ADM_MST_UNITS pu ON pu.ID_ = engine.EngineUnitId
	JOIN ADM_MST_ITEMS pi ON pi.ID_ = pu.ITEM_ID
	LEFT JOIN ADM_MST_TAILS t ON t.UNIT_ID = hr.END_ACFT_UNIT_ID
WHERE (engine.Level = 1 AND engine.ComponentType = 'HR') OR (engine.Level >= 1 AND engine.HasSubComponents = 1)
go

