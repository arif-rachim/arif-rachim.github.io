CREATE FUNCTION    [dbo].[ReturnTailHeader](@TailIds     varchar(max)) RETURNS TABLE
AS
RETURN
(
      SELECT 
			TAILS.ID_							As TailId,
            TAILS.T_NUM_                        As TailNo,
            PLATFORMS.CODE_                     As ACType,
            BATT.CODE_                          As Battalion,
            BATT.NAME_                          As BattalionName,
            COMMAND.CODE_                       As Command,
            COMMAND.NAME_                       As CommandName,
			ISNULL(CAT.NAME_,ITEMS.NOMENCLATURE_)    As Nomenclature
      FROM 
            ADM_MST_TAILS TAILS INNER JOIN ADM_MST_RESTRICTIONS BATT          ON TAILS.BATLN_ID = BATT.ID_ 
                                          INNER JOIN ADM_MST_RESTRICTIONS COMMAND         ON BATT.PRNT_ID = COMMAND.ID_ 
                                          INNER JOIN ADM_MST_UNITS UNITS                        ON TAILS.UNIT_ID = UNITS.ID_
                                          INNER JOIN ADM_MST_ITEMS ITEMS                        ON UNITS.ITEM_ID = ITEMS.ID_
                                          INNER JOIN ADM_MST_PLATFORMS PLATFORMS          ON ITEMS.ID_ = PLATFORMS.ID_ 
										  LEFT JOIN ADM_MST_PLTF_CATEGORY CAT   ON PLATFORMS.PLTF_CAT_ID=CAT.ID_
      WHERE
            TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',') )                             
)
go

