
CREATE FUNCTION [dbo].[D16_GetReplaceDue] (@compId AS UNIQUEIDENTIFIER)
  RETURNS @overhaulDue TABLE
  (
    _hours    REAL,
    _landings INT,
    _cycles   INT,
    _date     DATETIME
  )
AS
  BEGIN
    DECLARE
    @due_hours NUMERIC(10, 2),
    @due_landings INT,
    @due_cycles INT,
    @due_date DATETIME,
	@comp_id uniqueidentifier

	set @comp_id = @compId;

    SELECT
      @due_hours = CASE WHEN mc.REP_HRS_ > 0
        THEN mc.REP_HRS_ - (SELECT Hours
                            FROM dbo.D16_GetComponentUsage(c.ID_)) + round(isnull(uu.TOT_FLIGHT_MINS_, 0) / 60.0, 1)
             + CASE WHEN mspu.MSPU_FLAG_ = 1
          THEN ISNULL(mc.MSPU_HRS_, 0)
               ELSE 0 END
			 + ISNULL(ac.REP_DUE_HRS_EXT_, 0)
                   ELSE NULL END
      , @due_landings = CASE WHEN mc.REP_LDGS_ > 0
      THEN mc.REP_LDGS_ - (SELECT Landings
                           FROM dbo.D16_GetComponentUsage(c.ID_)) + isnull(uu.LANDINGS_, 0)
                        ELSE NULL END
      , @due_cycles = CASE WHEN mc.REP_CYCLES_ > 0
      THEN mc.REP_CYCLES_ - (SELECT Cycles
                           FROM dbo.D16_GetComponentUsage(c.ID_)) + isnull(e.OPERATING_HRS_, 0)
                        ELSE NULL END
      , @due_date =
        dbo.GetD16ComponentDueDate(mc.REP_CAL_VALUE_, mc.REP_CAL_UNIT_, mc.TSI_VALUE_, mc.TSI_UNIT_, ac.INST_DATE_,
                                   u.MANF_DATE_)
    FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
      INNER JOIN MNT_MST_D16_COMPONENT c ON c.id_ = ac.COMP_ID_
      INNER JOIN MNT_MST_D16_MASTER_COMPONENT mc ON mc.ID_ = ac.MASTER_COMP_ID_
      INNER JOIN ADM_MST_UNITS u ON U.ID_ = c.UNIT_ID_
      INNER JOIN ADM_TRN_UNIT_USAGE uu ON uu.UNIT_ID_ = ac.ACFT_UNIT_ID_
      INNER JOIN ADM_MST_TAILS t ON t.UNIT_ID = ac.ACFT_UNIT_ID_
      LEFT JOIN MNT_MST_D16_MSPU_TAIL_CONFIG mspu ON mspu.ID_ = t.ID_
      LEFT JOIN (
        SELECT
        TOP (1)
            rg.ENG_UNIT_ID, rd.OPERATING_HRS_
        FROM MNT_D193_ENGINE_READINGS rd
                 JOIN MNT_D193_ENGINE_REGISTER rg ON rg.ID_ = rd.ENGINE_ID
                 JOIN MNT_TRN_D16_ASSIGNED_COMPONENT ac_2 on ac_2.ENGINE_UNIT_ID = rg.ENG_UNIT_ID
                 JOIN MNT_MST_D16_COMPONENT c_2 ON c_2.ID_ = ac_2.COMP_ID_
         WHERE ac_2.IS_ACTIVE_ = 1 and c_2.ID_ = @comp_id
        ORDER BY READING_DATE_ DESC) e ON e.ENG_UNIT_ID = ac.ENGINE_UNIT_ID
    WHERE ac.COMP_ID_ = @comp_id AND ac.IS_ACTIVE_ = 1 AND ac.REM_DATE_ is null

    INSERT @overhaulDue
      SELECT
        @due_hours
        , @due_landings
        , @due_cycles
        , @due_date;
    RETURN;
  END;
go

