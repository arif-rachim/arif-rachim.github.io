CREATE VIEW [dbo].[VW_MNT_FLEET_STATUS_COUNT141] AS
            SELECT fu.UNIT_ID as UnitId, COUNT(1) over (partition by fu.UNIT_ID) as Tcount 
            FROM MNT_TRN_FAULT_UNITS fu 
            WHERE FAULT_STS_ = 'Open' and fu.FAULT_UNCORRECTED_DT_BEGIN_ is not null and fu.FAULT_UNCORRECTED_DT_END is null
go

