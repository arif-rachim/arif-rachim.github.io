create    VIEW [dbo].[VW_ADM_USER_PROFILE_SORTED] 
as (
	select up.ID_, 
		up.USER_ID_,
		up.PID_,
		up.F_NAME_ + ISNULL(' ' + up.M_NAME_,'') + ISNULL(' ' + up.L_NAME_,'') as NAME_,
		rnk.CODE_ as RANK_,
		rnk.ID_ as RANK_ID,
		rnk.DESC_ as RANK_DESC,
		up.DOB_,
		UP.MOBILE_,
		UP.MIL_UNIT_ID,
		up.COUNTRY_ID,
		up.USR_TYPE_,
		up.ACTIVE_PERSONNEL_,
		UP.REG_STS_,
		ROW_NUMBER() over(
			order by 
				up.IS_MILITARY_ desc,
				jrnk.JAC_RANK_ORDER desc, 
				(isnull(up.LAST_PROMOTION_DATE_, getdate())) asc,
				(CASE WHEN rnk.ID_=21 then 1 ELSE 0 END) ASC, 
				CONVERT(bigint, (
					CASE WHEN PATINDEX('%[0-9]%' ,up.USER_ID_)=0 THEN '999999' 
					when PATINDEX('%[0-9][a-z]%', UP.USER_ID_) > 0 then '888888'
					else SUBSTRING(up.USER_ID_, PATINDEX('%[0-9]%' ,up.USER_ID_),  LEN(up.USER_ID_)) 
					END
				)) ASC,
				up.USER_ID_ ASC
		) as ORDER_
	from ADM_TRN_USER_PROFILES up
	left join ADM_MST_SIMPLE_REF rnk ON up.RANK_ID = rnk.ID_
	left join (
		select distinct(RANK_ID), JAC_RANK_ORDER from  BIZ_JAC_MAP_RANK
	) as jrnk on jrnk.RANK_ID = up.RANK_ID
)
go

