CREATE FUNCTION [dbo].[GetLf1value]
(
          -- Add the parameters for the function here
          @engineId bigint
          
)
RETURNS decimal(18,2)
AS
BEGIN         
          
DECLARE @LF1VALUE decimal(18,2)  

SELECT @LF1VALUE=TempLCF.LCF1 FROM (
  SELECT   top 1  VAL_ as LCF1
    FROM         MNT_TRN_CS_ENGINE_COMPONENT_STAT AS ECS 
    WHERE     (ENGINE_ID_ = @engineId) AND (TYPE_ = 'Lcf1')
order by READING_DATE_ desc ) AS TempLCF

RETURN @LF1VALUE


END
go

