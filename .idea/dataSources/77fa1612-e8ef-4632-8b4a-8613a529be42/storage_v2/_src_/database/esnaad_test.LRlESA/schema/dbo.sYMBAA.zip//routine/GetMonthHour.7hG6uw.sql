CREATE FUNCTION [dbo].[GetMonthHour] 
(
	-- Add the parameters for the function here
	@month		int,
	@year		int
)
RETURNS DECIMAL(5,1)
AS
BEGIN
    DECLARE @TOTAL_HRS DECIMAL(5,1)
	
	DECLARE @end_day int , @start_date  smalldatetime,  @end_date smalldatetime
	
	SET @start_date = convert(smalldatetime,(SELECT dateadd(mm, (@year - 1900) * 12 + @month - 1 , 1 - 1)),100)    
	SET @end_date = DATEADD(mi, -1, DATEADD(M, 1, @start_date))     
	IF @end_date > getdate()    
	BEGIN
	  SET @end_date = GETDATE()    
	END
	select @TOTAL_HRS= DATEDIFF(hour, @start_date, @end_date) + 1	 
	RETURN ISNULL(@TOTAL_HRS ,0)

END
go

