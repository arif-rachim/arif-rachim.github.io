CREATE FUNCTION [dbo].[GetPlatfromCrewseatCount]
(
	-- Add the parameters for the function here
	@Platform_Config_id		uniqueidentifier
	
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @result int
    
    -- Add the T-SQL statements to compute the return value here
    
    
    SELECT @result =(SELECT  COUNT(*) AS Expr1 FROM ADM_MST_PFC_SEAT_CONFIG 
            WHERE     PLTF_CFG_ID = @Platform_Config_id)
   
	-- Return the result of the function
	RETURN @result
END
go

