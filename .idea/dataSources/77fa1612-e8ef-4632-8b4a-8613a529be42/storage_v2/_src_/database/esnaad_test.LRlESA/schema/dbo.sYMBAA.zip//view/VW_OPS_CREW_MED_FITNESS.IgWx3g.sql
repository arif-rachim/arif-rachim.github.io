CREATE view [dbo].[VW_OPS_CREW_MED_FITNESS]
-- Update 3 : Task #94785
-- Update 2 : US #53294
-- Update 1 : US #43414
as 
select distinct fc.ID_ as CREW_ID_
	, case 
		when cc.ID_ is null
			or (cc.ID_ is not null and cc.IS_EXEMPTED_ = 0 and isnull(DATEDIFF(day, GETDATE(), ISNULL(cc.EXT_UNTIL_, cc.NEXT_DUE_ON_)), -1) < 0)
			or (fit.DAILY_FITNESS_ = 'UnFit')
			then 'UnFit'
		else 'Fit'
	end as DAILY_FITNESS_
	, fit.LAST_UPDATE_
	, fit.LIMITATIONS_
from OPS_TRN_CM_CREW_CURRENCY cc 
inner join OPS_TRN_ANNUAL_MEDICAL_CURRENCY amc on amc.CURRENCY_ID = cc.CURRENCY_ID_
join OPS_XRF_CURRENCY_COY coy ON coy.CURR_ID_ = amc.CURRENCY_ID
join OPS_XRF_CURRENCY_PQ pq ON pq.CURR_ID_ = amc.CURRENCY_ID 
join OPS_XRF_OPS_MST_CURRENCY_ADM_MST_PLATFORMS p on p.CURR_ID = amc.CURRENCY_ID
right join OPS_MST_FLIGHT_CREWS fc on fc.ID_ = cc.FLIGHT_CREW_ID_ and p.PLTF_ID_ = fc.PRI_PLTF_ID_ and pq.PQ_ID_ = fc.QUALF_ID  and coy.COY_ID_ = fc.COMPANY_ID
left join ADM_TRN_USER_PROFILES up on up.ID_ = fc.PERSON_ID
left join BIZ_MEDICAL_FITNESS fit on fit.MILITARY_ID_ = up.USER_ID_
left join ADM_MST_RESTRICTIONS cmp on cmp.ID_ = fc.COMPANY_ID
left join ADM_MST_RESTRICTIONS bat on bat.ID_ = cmp.PRNT_ID
left join OPS_TRN_MEDICAL_CURRENCY_CONFIG cfg  on cfg.COMMAND_ID = bat.PRNT_ID
--select distinct fc.ID_ as CREW_ID_
--	, case 
--		when cc.ID_ is null
--			or (cc.ID_ is not null and cc.IS_EXEMPTED_ = 0 and isnull(DATEDIFF(day, GETDATE(), ISNULL(cc.EXT_UNTIL_, cc.NEXT_DUE_ON_)), -1) < 0)
--			or (fit.DAILY_FITNESS_ = 'UnFit')
--			then 'UnFit'
--		else 'Fit'
--	end as DAILY_FITNESS_
--	, fit.LAST_UPDATE_
--	, fit.LIMITATIONS_
--from OPS_TRN_CM_CREW_CURRENCY cc 
--inner join OPS_TRN_ANNUAL_MEDICAL_CURRENCY amc on amc.CURRENCY_ID = cc.CURRENCY_ID_
--inner join OPS_TRN_CM_CURRENCY_ASSIGNMENT asg on asg.CURR_ID_ = cc.CURRENCY_ID_
--right join OPS_MST_FLIGHT_CREWS fc on fc.ID_ = cc.FLIGHT_CREW_ID_ and asg.PLTF_ID_ = fc.PRI_PLTF_ID_ and asg.PQ_ID_ = fc.QUALF_ID and asg.COY_ID_ = fc.COMPANY_ID
--left join ADM_TRN_USER_PROFILES up on up.ID_ = fc.PERSON_ID
--left join BIZ_MEDICAL_FITNESS fit on fit.MILITARY_ID_ = up.USER_ID_
--left join ADM_MST_RESTRICTIONS cmp on cmp.ID_ = fc.COMPANY_ID
--left join ADM_MST_RESTRICTIONS bat on bat.ID_ = cmp.PRNT_ID
--left join OPS_TRN_MEDICAL_CURRENCY_CONFIG cfg  on cfg.COMMAND_ID = bat.PRNT_ID
go

