CREATE FUNCTION [dbo].[OPS_AreCrewsAssignedInTimeslot] (
	@flightTimes dbo.OPS_Type_FlightTime READONLY,
    @crewIds dbo.OPS_Type_CrewId READONLY
) RETURNS @assignedCrews TABLE  (
	FC_ID_ bigint, ETDZ_ datetime, ETAZ_ datetime
) AS
BEGIN
	INSERT @assignedCrews
	SELECT F.* 
	FROM dbo.OPS_GetCrewsAssignedInTimeslot(@flightTimes) F
	JOIN @crewIds CI ON CI.FlightCrewId = F.FC_ID_
	--AND EXISTS (
	--	SELECT 1 FROM @flightTimes FT
	--	WHERE (FT.ETDZ <= F.ETAZ_ AND FT.ETAZ >= F.ETDZ_ ) OR (FT.ETDZ >= F.ETD_ AND FT.ETDZ <= F.ETA_)
	--)	
	RETURN;
END
go

