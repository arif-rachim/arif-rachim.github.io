CREATE function [dbo].[GetPriceReferenceAndAvg]()
returns table
RETURN (
with cte as (
		select PRI.ITEM_ID as ItemId
		, po.PO_DATE_                                             as PoDate
        , cast(POI.UNIT_PRICE_VAL_ / CUR.RATE_ as decimal(18, 2)) as Price
        FROM LOG_TRN_PRC_PURCHASE_ORDER po
                 JOIN LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi ON poi.PO_ID = po.ID_
                 JOIN LOG_TRN_PRC_PROCUREMENT_ITEM pri ON poi.PROC_ITEM_ID = pri.ID_
                 JOIN ADM_MST_MONEY_CURRENCY cur ON cur.ID_ = poi.UNIT_PRICE_CUR_ID
        WHERE PO.STATUS_ IN ('Validated', 'PartiallyDelivered', 'Closed')
          and PO.PRIORITY_ in ('NOR', 'IOR')
          AND POI.UNIT_PRICE_VAL_ > 0
          and po.PO_DATE_ >= dateadd(year, -5, getdate())
	), y3 as (
		select cte.ItemId, AVG(cte.Price) avg3y from cte
		where cte.PoDate >= dateadd(year, -3, getdate())
		group by cte.ItemId
	), y5 as (
		select cte.ItemId, AVG(cte.Price) avg5y from cte
		where cte.PoDate >= dateadd(year, -5, getdate())
		group by cte.ItemId
	), ap as (
		select coalesce(y3.ItemId,y5.ItemId) ItemId, cast(coalesce(y3.avg3y,y5.avg5y) as decimal(18,2)) AvgPrice
		from y5
		full outer join y3 on y5.ItemId = y3.ItemId
	), fr as (
        select i.ID_ AS ItemId
        , ia.L2_ID AS L2Id
        , il2.IS_FMS_
        , cast(i.UNIT_PRICE_ * c.RATE_ as decimal(18,2)) AS ItemCatalogUnitPrice
		, ap.AvgPrice AS AveragePrice
        , (select
            top (1)
            cast(POI.UNIT_PRICE_VAL_ * CUR.RATE_ as decimal(18, 2))
            FROM LOG_TRN_PRC_PURCHASE_ORDER po
                    JOIN LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi ON poi.PO_ID = po.ID_
                    JOIN LOG_TRN_PRC_PROCUREMENT_ITEM pri ON poi.PROC_ITEM_ID = pri.ID_
                    JOIN ADM_MST_MONEY_CURRENCY cur ON cur.ID_ = poi.UNIT_PRICE_CUR_ID
            WHERE PO.STATUS_ IN ('Validated', 'PartiallyDelivered', 'Closed')
            and PO.PRIORITY_ in ('NOR')
            and pri.ITEM_ID = i.ID_
            order by po.PO_DATE_ desc) as LastNor
        , (select
            top (1)
            cast(POI.UNIT_PRICE_VAL_ * CUR.RATE_ as decimal(18, 2))
            FROM LOG_TRN_PRC_PURCHASE_ORDER po
                    JOIN LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi ON poi.PO_ID = po.ID_
                    JOIN LOG_TRN_PRC_PROCUREMENT_ITEM pri ON poi.PROC_ITEM_ID = pri.ID_
                    JOIN ADM_MST_MONEY_CURRENCY cur ON cur.ID_ = poi.UNIT_PRICE_CUR_ID
            WHERE PO.STATUS_ IN ('Validated', 'PartiallyDelivered', 'Closed')
            and PO.PRIORITY_ in ('IOR')
            and pri.ITEM_ID = i.ID_
            order by po.PO_DATE_ desc) as LastIor
        from ADM_MST_ITEMS i
            join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = i.ID_ --and ia.L2_ID = @l2Id
            left join LOG_TRN_ITEM_L2_ATTRIBUTES il2 on il2.ITEM_ID = ia.ITEM_ID and il2.L2_ID = ia.L2_ID
            left join ADM_MST_MONEY_CURRENCY c on c.ID_ = i.UNIT_PRICE_CUR_ID
			left join ap on ap.ItemId = i.ID_
	)
	
	SELECT ItemId, L2Id
    , CASE
        WHEN IS_FMS_ = 1 THEN COALESCE(ItemCatalogUnitPrice, AveragePrice, LastNor, LastIor)
        ELSE COALESCE(AveragePrice, ItemCatalogUnitPrice, lastNor, LastIor) 
	  END AS ReferencePrice
	, AveragePrice
	FROM fr
)
go

