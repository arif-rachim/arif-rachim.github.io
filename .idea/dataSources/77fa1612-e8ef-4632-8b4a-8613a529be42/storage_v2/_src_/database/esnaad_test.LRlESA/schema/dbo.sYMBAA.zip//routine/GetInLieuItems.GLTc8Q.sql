CREATE FUNCTION [dbo].[GetInLieuItems]
(
	-- Add the parameters for the function here
	@item_id bigint
)
RETURNS INT
AS
BEGIN
	
	DECLARE @INLIEU_ITEMS INT
	
	SELECT    @INLIEU_ITEMS=count(ID_)
              FROM         ADM_MST_ITEMS
              where  IN_LIEU_ITEM_ID=@item_id
	 
	RETURN @INLIEU_ITEMS

END
go

