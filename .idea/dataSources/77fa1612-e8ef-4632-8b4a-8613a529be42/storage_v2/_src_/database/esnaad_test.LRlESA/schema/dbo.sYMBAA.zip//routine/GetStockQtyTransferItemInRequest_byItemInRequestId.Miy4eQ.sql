CREATE FUNCTION [dbo].[GetStockQtyTransferItemInRequest_byItemInRequestId]
(
	@TransferRequestId		int,
	@FulfillingBuId			int,
	@ItemInRequestId		int
)
RETURNS int
AS
BEGIN
	DECLARE @result int
   
	SELECT @result = ISNULL(SUM(S.QTY_),0) 
					 FROM LOG_TRN_ITEM_IN_REQUEST IIR
					 INNER JOIN ADM_MST_ITEMS I ON IIR.ITEM_ID = I.ID_
					 INNER JOIN ADM_MST_UNITS U ON U.ITEM_ID = I.ID_
					 INNER JOIN LOG_TRN_STOCK S ON S.UNIT_ID = U.ID_
					 INNER JOIN ADM_MST_UNIT_LOCATION L ON S.LOC_ID = L.ID_
					 INNER JOIN ADM_MST_UNIT_LOCATION_GROUP LG ON LG.ID_ = L.LG_ID		
					 WHERE IIR.SM_ID = @TransferRequestId AND LG.BU_ID = @FulfillingBuId
					 AND IIR.ID_ = @ItemInRequestId
					 AND      (L.LOC_TYPE_ <> N'Receiving' AND L.LOC_TYPE_ <> N'InTransit')
	RETURN @result
END
go

