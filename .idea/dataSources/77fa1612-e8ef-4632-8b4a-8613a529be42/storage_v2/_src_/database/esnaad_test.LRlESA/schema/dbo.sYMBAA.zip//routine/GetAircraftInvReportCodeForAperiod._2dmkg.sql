CREATE FUNCTION [dbo].[GetAircraftInvReportCodeForAperiod] 
(
	-- Add the parameters for the function here
	@start_date smalldatetime,
	@end_date smalldatetime,
	@aircraft_id bigint,
	@code_condition_id bigint,
	@hrs_condition_id bigint
)
RETURNS VARCHAR(10)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @CODE VARCHAR(10)

	-- Get code for a condition
	SELECT 
		@CODE = codequery.CODE_ 
	FROM 
		dbo.MNT_TRN_AIRCRAFT_INVENTORIES codequery
	WHERE 
		codequery.DATE_ = 
		(
			SELECT 
				top 1 hrsrow.DATE_
			FROM 
				dbo.MNT_TRN_AIRCRAFT_INVENTORIES hrsrow
			WHERE 
				hrsrow.HOURS_ = 
				(
					SELECT  
						MAX(mxhrs.HOURS_) 
					FROM 
						dbo.MNT_TRN_AIRCRAFT_INVENTORIES as mxhrs
					WHERE 
						convert(smalldatetime, mxhrs.DATE_, 100) BETWEEN @start_date AND @end_date
						AND mxhrs.AIRCRAFT_ID = @aircraft_id AND mxhrs.COND_ID = @hrs_condition_id
				)
				AND convert(smalldatetime, hrsrow.DATE_, 100) BETWEEN @start_date AND @end_date
				AND hrsrow.AIRCRAFT_ID = @aircraft_id AND hrsrow.COND_ID = @hrs_condition_id
			ORDER BY DATE_ 
		)
		AND codequery.AIRCRAFT_ID = @aircraft_id AND codequery.COND_ID = @code_condition_id	



	--SELECT top 1 @CODE = CODE_ FROM dbo.MNT_TRN_AIRCRAFT_INVENTORIES
	--	WHERE 
	--		convert(smalldatetime,DATE_,100) BETWEEN @start_date AND @end_date
	--		AND COND_ID = @condition_id
	--		AND AIRCRAFT_ID = @aircraft_id


	-- Return the result of the function
	RETURN ISNULL(@CODE , '')

END
go

