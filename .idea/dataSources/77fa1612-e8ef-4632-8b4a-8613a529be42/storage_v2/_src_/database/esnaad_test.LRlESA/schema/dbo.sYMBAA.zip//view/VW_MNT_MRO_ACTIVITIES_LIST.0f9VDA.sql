CREATE VIEW [dbo].[VW_MNT_MRO_ACTIVITIES_LIST] AS

SELECT Id, 
DurationEquipmentCycles, DurationEquipmentCyclesString,
D16Id, Version, CommandId, Command , InspectionNumber as InspectionNumber, Orders,
                    LinkedTail, InspectionName, DisplayPlatform, DurationString, DurationUnit, DurationHours, DurationHoursString,
                    DurationLandings, DurationLandingsString, DurationCycles, DurationCyclesString, DurationRounds, DurationRoundsString, 
					
					DurationOther, ReviewStatus, HasKitList, ReferenceType,
					ComponentItem, ComponentManufacture, ComponentNomenclature,
					CreatedBy, FullNameCreatedBy, CreatedOn, ModifiedBy, FullNameModifiedBy, ModifiedOn 
                    FROM (
	                    SELECT INSPECTION.ID_ AS Id, NULL AS D16Id, INSPECTION.VERSION_ AS Version, INSPECTION.CMD_ID AS CommandId, CMD.CODE_ AS Command,
	                    INSPECTION.INSP_NUMBER_ AS InspectionNumber, INSPECTION.ORDER_ + 1 AS Orders, INSPECTION.INSP_NAME_ AS InspectionName,
	                    INSPECTION.VF_LINKED_TAILS_ AS LinkedTail, PLTFRM.CODE_ AS DisplayPlatform,
	                    INSPECTION.INT_DUR_VALUE_ AS DurationValue, INSPECTION.INT_DUR_UNIT_ AS DurationUnit,
	                    CONVERT(VARCHAR(100), ISNULL(INT_DUR_VALUE_,'')) + ' ' + LEFT(INT_DUR_UNIT_,1) AS DurationString,
	                    INSPECTION.INT_DUR_HOURS_ AS DurationHours, FORMAT(CAST(INSPECTION.INT_DUR_HOURS_ AS DECIMAL(10, 1)), 'N1') + ' H' AS DurationHoursString,
	                    INSPECTION.INT_DUR_LANDINGS_ AS DurationLandings, FORMAT(INSPECTION.INT_DUR_LANDINGS_, 'N1') + ' L' AS DurationLandingsString,
	                    INSPECTION.INT_DUR_CYCLES_ AS DurationCycles, FORMAT(INSPECTION.INT_DUR_CYCLES_, 'N1') + ' L' AS DurationCyclesString,
	                    INSPECTION.INT_DUR_ROUNDS_ AS DurationRounds, FORMAT(INSPECTION.INT_DUR_ROUNDS_, 'N1') + ' R' AS DurationRoundsString,						
						INSPECTION.INT_DUR_EQP_CYCLES_ AS DurationEquipmentCycles, FORMAT(INSPECTION.INT_DUR_EQP_CYCLES_, 'N1') + ' EC' AS DurationEquipmentCyclesString,
	                    (
		                    CASE  INT_OTHER_
			                    WHEN 'BeforeFlight' THEN 'BEFORE FLIGHT'  
			                    WHEN 'AfterEveryFlight' THEN 'AFTER EVERY FLIGHT'  
			                    WHEN 'BeforeEveryFlight' THEN 'BEFORE EVERY FLIGHT'  
			                    WHEN 'AfterFlight' THEN 'AFTER FLIGHT'  
		                    END
	                    ) AS DurationOther,
	                    INSPECTION.CREATED_BY_ AS CreatedBy, USERPROFC.F_NAME_ + ' ' + USERPROFC.L_NAME_ AS FullNameCreatedBy, INSPECTION.CREATED_ON_ AS CreatedOn,
	                    INSPECTION.MOD_BY_ AS ModifiedBy, USERPROF.F_NAME_ + ' ' + USERPROF.L_NAME_ AS FullNameModifiedBy, INSPECTION.MOD_ON_ AS ModifiedOn,
	                    UPPER(INSPECTION.KIT_LIST_REVIEW_STATUS_) AS ReviewStatus, IIF(KIT.ISKITLIST IS NULL, CONVERT(BIT,0), KIT.ISKITLIST) AS HasKitList,
                        '2408-18' AS ReferenceType, NULL AS ComponentItem, NULL AS ComponentManufacture, NULL AS ComponentNomenclature
	                    FROM MNT_TRN_INSPECTION_MASTERS AS INSPECTION 
	                    INNER JOIN ADM_MST_RESTRICTIONS CMD ON CMD.ID_ = INSPECTION.CMD_ID 
	                    LEFT JOIN ADM_MST_PLATFORMS AS PLTFRM ON INSPECTION.PLTF_ID = PLTFRM.ID_ 
	                    LEFT JOIN ADM_TRN_USER_PROFILES AS USERPROF ON INSPECTION.MOD_BY_ = USERPROF.USER_ID_ 
	                    LEFT JOIN ADM_TRN_USER_PROFILES AS USERPROFC ON INSPECTION.CREATED_BY_ = USERPROFC.USER_ID_  
	                    OUTER APPLY (
		                    SELECT (CASE WHEN  KIT.ID_ IS NOT NULL THEN CONVERT(BIT,1) ELSE CONVERT(BIT,0) END) AS IsKitList 
		                    FROM MNT_TRN_IKT_KITLIST_D18_LINK D18LINK 
		                    INNER JOIN MNT_TRN_IKT_KITLIST KIT ON KIT.ID_=D18LINK.KIT_ID AND D18LINK.D18_MASTER_ID=INSPECTION.ID_ AND KIT.IS_ACTIVE_=1
	                    ) KIT 

	                    UNION ALL

	                    SELECT NULL AS Id, D16.ID_ AS D16Id, D16.VERSION_ AS Version, D16C.ID_ AS CommandId, D16C.CODE_ AS Command,
	                    D16.MASTER_NO_ AS InspectionNumber,	0 AS Orders, (D16I.PART_NO_+', '+ D16M.CAGE_CODE_ + ', ' + DWUC.CODE_ + ', ' + D16I.NOMENCLATURE_) AS InspectionName,
	                    0 AS LinkedTail, D16P.CODE_ AS DisplayPlatform,
	                    NULL AS DurationValue, NULL AS DurationUnit,
	                    (CASE 
		                    WHEN D16.TSI_VALUE_ > 0 AND REP_CAL_VALUE_ > 0
			                    THEN 'R TSI ' + CAST(D16.TSI_VALUE_ AS VARCHAR) + ' ' +  SUBSTRING(D16.TSI_UNIT_, 1, 1) + ', R TSM ' + CAST(D16.REP_CAL_VALUE_ AS VARCHAR) + ' ' +  SUBSTRING(D16.REP_CAL_UNIT_, 1, 1)
		                    WHEN D16.TSI_VALUE_ > 0
			                    THEN 'R TSI ' + CAST(D16.TSI_VALUE_ AS VARCHAR) + ' ' +  SUBSTRING(D16.TSI_UNIT_, 1, 1)
		                    WHEN REP_CAL_VALUE_ > 0
			                    THEN 'R TSM ' + CAST(D16.REP_CAL_VALUE_ AS VARCHAR) + ' ' +  SUBSTRING(D16.REP_CAL_UNIT_, 1, 1)
		                    ELSE NULL
	                    END) AS DurationString,
	                    0 as DurationHours,
	                    (CASE 
		                    WHEN D16.OVR_HRS_ > 0 AND D16.REP_HRS_ > 0 
			                    THEN 'OH ' + FORMAT(CAST(D16.OVR_HRS_ AS DECIMAL(10, 1)), 'N1') + ' H' + ' / R ' + FORMAT(CAST(D16.REP_HRS_ AS DECIMAL(10, 1)), 'N1') + ' H'
		                    WHEN D16.OVR_HRS_ > 0
			                    THEN 'OH ' + FORMAT(CAST(D16.OVR_HRS_ AS DECIMAL(10, 1)), 'N1') + ' H'
		                    WHEN D16.REP_HRS_ > 0
			                    THEN 'R ' + FORMAT(CAST(D16.REP_HRS_ AS DECIMAL(10, 1)), 'N1') + ' H'
		                    ELSE NULL
	                    END) AS DurationHoursString,
	                    0 AS DurationLandings,
	                    (CASE 
		                    WHEN D16.OVR_LDGS_ > 0 AND D16.REP_LDGS_ > 0 
			                    THEN 'OH ' + FORMAT(D16.OVR_LDGS_, 'N1') + ' L' + ' / R ' + FORMAT(D16.REP_LDGS_, 'N1') + ' L'
		                    WHEN D16.OVR_LDGS_ > 0
			                    THEN 'OH ' + FORMAT(D16.OVR_LDGS_, 'N1') + ' L'
		                    WHEN D16.REP_LDGS_ > 0 
			                    THEN 'R ' + FORMAT(D16.REP_LDGS_, 'N1') + ' L'
		                    ELSE NULL
	                    END) AS DurationLandingsString,
	                    0 AS DurationCycles,
	                    (CASE 
		                    WHEN D16.OVR_CYCLES_ > 0 AND D16.REP_CYCLES_ > 0 
			                    THEN 'OH ' + FORMAT(D16.OVR_CYCLES_, 'N1') + ' C' + ' / R ' + FORMAT(D16.REP_CYCLES_, 'N1') + ' C'
		                    WHEN D16.OVR_HRS_ > 0
			                    THEN 'OH ' + FORMAT(D16.OVR_CYCLES_, 'N1') + ' C'
		                    WHEN D16.REP_HRS_ > 0
			                    THEN 'R ' + FORMAT(D16.REP_CYCLES_, 'N1') + ' C'
		                    ELSE NULL
	                    END) AS DurationCyclesString,
	                    NULL AS DurationRounds, NULL AS DurationRoundsString,
						NULL AS DurationEquipmentCycles, NULL AS DurationEquipmentCyclesString,
	                    (CASE WHEN D16.PART_TYPE_ = 'CC' THEN D16.PART_TYPE_ ELSE NULL END) AS DurationOther,
	                    D16.CREATED_BY_  AS CreatedBy, D16.FULL_NAME_CREATED_BY_ AS FullNameCreatedBy, D16.CREATED_ON_ AS CreatedOn,
	                    D16.MOD_BY_ AS ModifiedBy, D16.FULL_NAME_MOD_BY_ AS FullNameModifiedBy, D16.MOD_ON_ AS ModifiedOn,
	                    UPPER(D16.KIT_LIST_REVIEW_STATUS_) AS ReviewStatus, IIF(KIT.ISKITLIST IS NULL, CONVERT(BIT,0), KIT.ISKITLIST) AS HasKitList,
                        '2408-16' AS ReferenceType, D16I.PART_NO_ AS ComponentItem, D16M.CAGE_CODE_ AS ComponentManufacture, D16I.NOMENCLATURE_ AS ComponentNomenclature
	                    FROM MNT_MST_D16_MASTER_COMPONENT AS D16 
	                    INNER JOIN ADM_MST_RESTRICTIONS D16C ON D16C.ID_ = D16.CMD_ID_ 
	                    LEFT JOIN ADM_MST_PLATFORMS AS D16P ON D16P.ID_ = D16.PLTF_ID 
	                    INNER JOIN ADM_MST_ITEMS AS D16I ON D16I.ID_ = D16.COMP_ITEM_ID_ 
	                    INNER JOIN ADM_MST_MANUFACTURES AS D16M ON D16M.ID_ = D16I.MNF_ID 
	                    INNER JOIN MNT_MST_D16_WORK_UNIT_CODE AS DWUC ON DWUC.ID_ = D16.WUC_ID_ 
	                    OUTER APPLY (
		                    SELECT (CASE WHEN KIT.ID_ IS NOT NULL THEN CONVERT(BIT,1) ELSE CONVERT(BIT,0) END) AS IsKitList 
		                    FROM MNT_TRN_IKT_KITLIST_D18_LINK AS D16LINK 
		                    INNER JOIN MNT_TRN_IKT_KITLIST KIT ON KIT.ID_= D16LINK.KIT_ID AND D16LINK.D16_MASTER_ID = D16.ID_ AND KIT.IS_ACTIVE_ = 1 
	                    ) KIT 

	                    UNION ALL

	                    SELECT D161.ID_ AS Id, NULL AS D16Id, D161.VERSION_ AS Version, D161C.ID_ AS CommandId, D161C.CODE_ AS Command,
	                    D161.MASTER_NO_ AS InspectionNumber,	0 AS Orders, (D161I.PART_NO_+', '+ D161M.CAGE_CODE_ + ', ' + D161WUC.CODE_ + ', ' + D161I.NOMENCLATURE_) AS InspectionName,
	                    0 AS LinkedTail, D161P.CODE_ AS DisplayPlatform,
	                    0 AS DurationValue, NULL AS DurationUnit, NULL AS DurationString,
	                    0 as DurationHours,
	                    (
	                    CASE 
		                    WHEN D161.OVERHAUL_ > 0 AND D161.REPLACE_ > 0 
			                    THEN 'OH ' + FORMAT(CAST(D161.OVERHAUL_ AS DECIMAL(10, 1)), 'N1') + ' H' + ' / R ' + FORMAT(CAST(D161.REPLACE_ AS DECIMAL(10, 1)), 'N1') + ' H'
		                    WHEN D161.OVERHAUL_ > 0
			                    THEN 'OH ' + FORMAT(CAST(D161.OVERHAUL_ AS DECIMAL(10, 1)), 'N1') + ' H'
		                    WHEN D161.REPLACE_ > 0
			                    THEN 'R ' + FORMAT(CAST(D161.REPLACE_ AS DECIMAL(10, 1)), 'N1') + ' H'
		                    ELSE NULL
	                    END 
	                    ) AS DurationHoursString,
	                    NULL AS DurationLandings, NULL AS DurationLandingsString,
	                    NULL AS DurationCycles, NULL AS DurationCyclesString,
	                    NULL AS DurationRounds, NULL AS DurationRoundsString,
						NULL AS DurationEquipmentCycles, NULL AS DurationEquipmentCyclesString,
	                    (CASE WHEN D161.INTERVAL_CAT_ = 'CC' THEN D161.INTERVAL_CAT_ ELSE NULL END) AS DurationOther,
	                    D161.CREATED_BY_  AS CreatedBy, D161.FULL_NAME_CREATED_BY_ AS FullNameCreatedBy, D161.CREATED_ON_ AS CreatedOn,
	                    D161.MOD_BY_ AS ModifiedBy, D161.FULL_NAME_MOD_BY_ AS FullNameModifiedBy, D161.MOD_ON_ AS ModifiedOn,
	                    UPPER(D161.KIT_LIST_REVIEW_STATUS_) AS ReviewStatus, IIF(KIT.ISKITLIST IS NULL, CONVERT(BIT,0), KIT.ISKITLIST) AS HasKitList,
                        '2408-16-1' AS ReferenceType, D161I.PART_NO_ AS ComponentItem, D161M.CAGE_CODE_ AS ComponentManufacture, D161I.NOMENCLATURE_ AS ComponentNomenclature
	                    FROM MNT_TRN_D16_1_MASTER AS D161 
	                    INNER JOIN ADM_MST_RESTRICTIONS D161C ON D161C.ID_ = D161.CMD_ID 
	                    LEFT JOIN ADM_MST_PLATFORMS AS D161P ON D161P.ID_ = D161.PLTF_ID 
	                    INNER JOIN ADM_MST_ITEMS AS D161I ON D161I.ID_ = D161.COMP_ID 
	                    INNER JOIN ADM_MST_MANUFACTURES AS D161M ON D161M.ID_ = D161I.MNF_ID 
	                    INNER JOIN MNT_MST_D16_WORK_UNIT_CODE AS D161WUC ON D161WUC.ID_ = D161.WORK_UNIT_ID 
	                    OUTER APPLY (
		                    SELECT (CASE WHEN KIT.ID_ IS NOT NULL THEN CONVERT(BIT,1) ELSE CONVERT(BIT,0) END) AS IsKitList 
		                    FROM MNT_TRN_IKT_KITLIST_D18_LINK AS D161LINK 
		                    INNER JOIN MNT_TRN_IKT_KITLIST KIT ON KIT.ID_= D161LINK.KIT_ID AND D161LINK.D161_MASTER_ID = D161.ID_ AND KIT.IS_ACTIVE_ = 1
	                    ) KIT 
                    ) AS SRC WHERE 1 = 1
go

