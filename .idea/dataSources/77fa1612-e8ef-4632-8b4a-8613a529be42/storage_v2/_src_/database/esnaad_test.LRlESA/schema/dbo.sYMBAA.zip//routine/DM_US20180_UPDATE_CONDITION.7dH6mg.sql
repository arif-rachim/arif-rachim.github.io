
CREATE PROCEDURE DM_US20180_UPDATE_CONDITION
	  @buid				bigint	
	, @esnaad_unit_id_	bigint	
	, @tagcolor			bigint	
	, @agl2				bigint	
	, @createduserid	bigint	
	, @changetotagcolor	bigint	
	, @message nvarchar(max) out
AS
BEGIN

	/*
	print '@buid' + cast(@buid as nvarchar(100))
	print '@agl2' + cast(@agl2 as nvarchar(100))
	print '@esnaad_unit_id_' + cast(@esnaad_unit_id_ as nvarchar(100))
	print '@tagcolor' + cast(@tagcolor as nvarchar(100))
	print '@changetotagcolor' + cast(@changetotagcolor  as nvarchar(100))
	*/

	SET @message =''

	declare @createdby nvarchar(255) 
	declare @createdpid nvarchar(255) 
	declare @createdfullname nvarchar(255) 
	select @createdby=USER_ID_, @createdpid=PID_, @createdfullname= (F_NAME_ + L_NAME_) from ADM_TRN_USER_PROFILES WHERE ID_ = @createduserid

	--source item in location
	declare @sourceimvid uniqueidentifier
	declare @cmdId bigint
	declare @buType nvarchar(20)
	declare @sourceimvqty bigint
	declare @sourcelocgroup bigint
	declare @sourcelocation bigint
	;
	with cte
	as
	(
	select distinct LOC_TYPE_, case LOC_TYPE_ when  'Regular' then 1 when  'Receiving' then 2  when  'InTransit' then 3 else 4 end as LOC_TYP_ORD_  from ADM_MST_UNIT_LOCATION
	)
	select top 1 @sourceimvid = imv.id_, @sourceimvqty = imv.QTY_ , @sourcelocgroup = imv.LG_ID_, @sourcelocation = imv.LOC_ID_, @cmdId = imv.CMD_ID_, @buType = bu.BU_TYPE_
	from ADM_TRN_IMV_ITEMS_IN_LOCATION imv 
	join ADM_MST_UNIT_LOCATION loc on loc.ID_ = imv.LOC_ID_
	join ADM_MST_UNIT_LOCATION_GROUP lg on lg.ID_ = loc.LG_ID
	join ADM_MST_BUSINESS_UNITS bu on bu.ID_ = lg.BU_ID
	join cte on cte.LOC_TYPE_ = loc.LOC_TYPE_ 
	where imv.UNIT_ID_ = @esnaad_unit_id_ and imv.BU_ID_ = @buid and imv.OWNED_L2_ID_ = @agl2 and imv.TC_ID_ = @tagcolor and imv.TC_ID_ <> @changetotagcolor
	order by cte.LOC_TYP_ORD_
	;
	
	--source item stock
	declare @sourcestockid uniqueidentifier
	declare @sourcestockqty bigint
	select top 1 @sourcestockid=Id_, @sourcestockqty = QTY_ 
	from LOG_TRN_STOCK where UNIT_ID = @esnaad_unit_id_ and STORE_ID = @buid and OWNED_BY_L2_ID_ = @agl2 and TAG_COLOR_COND_ID_ = @tagcolor and LOC_ID = @sourcelocation


	if(@sourceimvid is not null)
	begin
		if(@sourceimvqty >= 1)
		begin
			--destination
			declare @destinationimvid uniqueidentifier
			declare @destlocgroup bigint
			declare @destlocation bigint
			
			;
			with cte
			as
			(
			select distinct LOC_TYPE_, case LOC_TYPE_ when  'Regular' then 1 when  'Receiving' then 2  when  'InTransit' then 3 else 4 end as LOC_TYP_ORD_  from ADM_MST_UNIT_LOCATION
			)
			select top 1 @destinationimvid= imv.Id_ , @destlocgroup = imv.LG_ID_, @destlocation = imv.LOC_ID_
			from ADM_TRN_IMV_ITEMS_IN_LOCATION imv 
			join ADM_MST_UNIT_LOCATION loc on loc.ID_ = imv.LOC_ID_
			join cte on cte.LOC_TYPE_ = loc.LOC_TYPE_ 
			where imv.UNIT_ID_ = @esnaad_unit_id_ and imv.BU_ID_ = @buid and imv.OWNED_L2_ID_ = @agl2 and imv.TC_ID_ = @changetotagcolor 
			order by cte.LOC_TYP_ORD_
			;

			--destination item stock
			declare @deststockid uniqueidentifier
			declare @deststockqty bigint
			select top 1 @deststockid=Id_, @deststockqty = QTY_ 
			from LOG_TRN_STOCK where UNIT_ID = @esnaad_unit_id_ and STORE_ID = @buid and OWNED_BY_L2_ID_ = @agl2 and TAG_COLOR_COND_ID_ = @changetotagcolor and LOC_ID = @destlocation

			if(@destinationimvid is null )
			begin
				
				if(@sourceimvqty > 1)
				begin
					
					INSERT INTO [ADM_TRN_IMV_ITEMS_IN_LOCATION]
						   ([ID_]
						   ,[VERSION_]
						   ,[BU_ID_]
						   ,[UNIT_ID_]
						   ,[QTY_]
						   ,[LG_ID_]
						   ,[LOC_ID_]
						   ,[OWNED_L2_ID_]
						   ,[TC_ID_]
						   ,[CREATED_BY_]
						   ,[PID_CREATED_BY_]
						   ,[FULL_NAME_CREATED_BY_]
						   ,[CREATED_ON_]
						   ,[CMD_ID_]
						   ,[TYPE_]
						   )
					 VALUES
						   ((select newid())
						   ,1
						   ,@buid
						   ,@esnaad_unit_id_
						   ,1
						   ,@sourcelocgroup
						   ,@sourcelocation
						   ,@agl2
						   ,@changetotagcolor
						   ,@createdby
						   ,@createdpid
						   ,@createdfullname
						   ,getdate()
						   ,@cmdId
						   ,'Logistic'
						   )
					update ADM_TRN_IMV_ITEMS_IN_LOCATION set QTY_ = QTY_ -1 where ID_ = @sourceimvid
					SET @message = 'destination items in location not exists and srcqty more than 1, new items in location creatd and source qty reduced.'
									
					if(@buType = 'Store')	
					begin			
						INSERT INTO [LOG_TRN_STOCK]
						   ([ID_]
						   ,[VERSION_]
						   ,[UNIT_ID]
						   ,[LOC_ID]
						   ,[STORE_ID]
						   ,[QTY_]
						   ,[TAG_COLOR_COND_ID_]
						   ,[CREATED_BY_]
						   ,[PID_CREATED_BY_]
						   ,[FULL_NAME_CREATED_BY_]
						   ,[CREATED_ON_]
						   ,[OWNED_BY_L2_ID_]
						   ,[UOM_ID_]
						   ,[TYPE_]
						   )
					 VALUES
						   (NEWID()
						   ,1
						   ,@esnaad_unit_id_
						   ,@sourcelocation
						   ,@buid
						   ,1
						   ,@changetotagcolor
						   ,@createdby
						   ,@createdpid
						   ,@createdfullname
						   ,getdate()
						   ,@agl2
						   ,'A86DC8CB-3635-4E3A-8028-47FE8C4C4E19'
						   ,'Logistic'
						   )
						update LOG_TRN_STOCK set QTY_ = QTY_ -1 where ID_ = @sourcestockid
						
						SET @message = @message + '   destination stock not exists and srcqty more than 1, new stock creatd'
					end
					
				end
				else if(@sourceimvqty = 1)
				begin
					SET @message =  'destination items in location not exists and srcqty is 1, source IMV condition updated'
					update ADM_TRN_IMV_ITEMS_IN_LOCATION set TC_ID_ = @changetotagcolor where ID_ = @sourceimvid
					if(@buType = 'Store')	
					begin
						SET @message = @message + 'destination stock not exists and srcqty is 1, source STOCK condition updated'
						update LOG_TRN_STOCK set TAG_COLOR_COND_ID_ = @changetotagcolor where ID_ = @sourcestockid
					end
				end
				
			end
			else
			begin
				if(@sourceimvqty > 1)
				begin
					SET @message =  'destination items in location exists and srcqty more than 1, adjust stock'
					update ADM_TRN_IMV_ITEMS_IN_LOCATION set QTY_ = QTY_ +1 where ID_ = @destinationimvid
					update ADM_TRN_IMV_ITEMS_IN_LOCATION set QTY_ = QTY_ -1 where ID_ = @sourceimvid
					if(@buType = 'Store')	
					begin
						SET @message = @message +  'destination stock exists and srcqty more than 1, adjust stock'
						update LOG_TRN_STOCK set QTY_ = QTY_ +1 where ID_ = @deststockid
						update LOG_TRN_STOCK set QTY_ = QTY_ -1 where ID_ = @sourcestockid
					end
				end
				else if(@sourceimvqty = 1)
				begin
					SET @message = 'destination items in location exists and srcqty = 1, add destination IMV QTY and remove source'
					update ADM_TRN_IMV_ITEMS_IN_LOCATION set QTY_ = QTY_ +1 where ID_ = @destinationimvid
					delete from ADM_TRN_IMV_ITEMS_IN_LOCATION where ID_ = @sourceimvid
					if(@buType = 'Store')	
					begin
						SET @message = @message +  'destination stock exists and srcqty = 1, add destination stock QTY and remove source'
						update LOG_TRN_STOCK set QTY_ = QTY_ +1 where ID_ = @deststockid
						delete from LOG_TRN_STOCK where ID_ = @sourcestockid
					end
				end
			end

		end

	end
	else
	begin
		SET @message = 'source items in location not exists'
	end

END



go

