
-- ==========================================================================
-- Author:		GAL2723
-- Create date: 01-Apr-2014
-- Description:	Get [Int value] User ID from user master for a given PID
-- ==========================================================================
create FUNCTION [dbo].[getUserIdInt_forPid] (@pid VARCHAR(255))
RETURNS VARCHAR(255)
AS
BEGIN
	DECLARE @userID BIGINT = NULL;
	
	SELECT @userID = ID_
	FROM ADM_TRN_USER_PROFILES
	WHERE PID_ = @pid	      
	
	RETURN @userID;
END

-- SELECT dbo.getUserIdInt_forPid('PP2723');
-- ############################################################################################################

go

