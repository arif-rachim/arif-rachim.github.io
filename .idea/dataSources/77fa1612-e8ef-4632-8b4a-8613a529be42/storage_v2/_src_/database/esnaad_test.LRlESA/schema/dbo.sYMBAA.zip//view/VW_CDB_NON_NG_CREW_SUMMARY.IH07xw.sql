CREATE view VW_CDB_NON_NG_CREW_SUMMARY
as (
	 SELECT ltrim(rtrim(crew.CREWDASHBOARD_SUMMARY_ID_)) as MILITARY_ID_,
									cmd.ID_ as NG_COMMAND_ID_, crew.COMMAND_ as COMMAND_
					from TCSV_CREWDASHBOARD_SUMMARY crew
					inner join CIS_NG_COMMAND_MAP cmap on cmap.CIS_COMMAND_ = crew.COMMAND_
					inner join ADM_MST_RESTRICTIONS cmd on cmd.TYPE_NAME_='Command' and cmd.CODE_ = cmap.NG_COMMAND_
	                
					where crew.COMMAND_ not in(select CIS_COMMAND_ from CIS_EXCLUDE_COMMAND)
	 
	 union all
	 
	 select usr.user_id_ as MILITARY_ID_, usr.MIL_UNIT_ID as NG_COMMAND_ID_, null as COMMAND_
	 from adm_trn_user_profiles usr
	 inner join OPS_MST_FLIGHT_CREWS crew on crew.PERSON_ID = usr.ID_ 
)
go

