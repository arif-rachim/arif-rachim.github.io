CREATE FUNCTION [dbo].[GetAircraftLandingsForAPeriodFromUnitUsageDetails] 
(
	@start_date datetime,
	@end_date datetime,
	@tail_id bigint
)
RETURNS bigint -- landings
AS
BEGIN
	-- Declare variables
	DECLARE @landings bigint 

	if(@start_date is not null)
	begin

		SELECT 
			@landings = SUM(LANDINGS_)
		FROM ADM_TRN_UNIT_USAGE_DETAIL
		WHERE 
				DATE_ BETWEEN @start_date AND @end_date
			AND
				UNIT_ID_ = @tail_id
			

	end
	
	RETURN ISNULL(@landings ,0)

END
go

