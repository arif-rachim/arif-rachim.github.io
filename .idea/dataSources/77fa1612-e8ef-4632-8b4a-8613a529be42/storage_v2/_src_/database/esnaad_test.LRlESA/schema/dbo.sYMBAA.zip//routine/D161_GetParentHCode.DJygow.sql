CREATE FUNCTION [dbo].[D161_GetParentHCode](@hCode nvarchar(900)) RETURNS nvarchar(450) AS
BEGIN
	DECLARE @revHCode nvarchar(450)
	SELECT @revHCode = REVERSE(@hCode)
	RETURN REVERSE(RIGHT(@revHCode,LEN(@revHCode) - CHARINDEX('.',@revHCode,2)+1))
END
go

