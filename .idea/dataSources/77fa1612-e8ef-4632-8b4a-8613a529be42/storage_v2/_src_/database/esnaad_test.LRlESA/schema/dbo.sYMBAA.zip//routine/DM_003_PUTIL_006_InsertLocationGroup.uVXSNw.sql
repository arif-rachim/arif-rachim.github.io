
CREATE PROCEDURE DM_003_PUTIL_006_InsertLocationGroup
	@VERSION_ bigint,
	@NAME_ nvarchar(255),
	@DESC_ nvarchar(255),	
	@BU_ID bigint,
	@L2_ID_ bigint,
	@LOC_COUNT_ int,
	@IS_ACTIVE_ bit,
	@IS_SYSTEM_ bit,
	@COND_COUNT_ int,

	@CREATED_BY_ nvarchar(255),
	@PID_CREATED_BY_ nvarchar(255),
	@FULL_NAME_CREATED_BY_ nvarchar(255),
	@CREATED_ON_ datetime,

	@TERM_ nvarchar(255)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @insertedRecordID BIGINT = NULL;

	IF NOT EXISTS(SELECT NAME_ FROM ADM_MST_UNIT_LOCATION_GROUP WHERE NAME_ = @NAME_ AND BU_ID = @BU_ID)
	BEGIN
		INSERT INTO ADM_MST_UNIT_LOCATION_GROUP
		(
			VERSION_,
			NAME_,
			DESC_,
			BU_ID,
			L2_ID_,
			LOC_COUNT_,
			IS_ACTIVE_,
			IS_SYSTEM_,
			COND_COUNT_,
			CREATED_BY_,
			PID_CREATED_BY_,
			FULL_NAME_CREATED_BY_,
			CREATED_ON_,
			TERM_
		)
		VALUES
		(
			@VERSION_,
			@NAME_,
			@DESC_,
			@BU_ID,
			@L2_ID_,
			@LOC_COUNT_,
			@IS_ACTIVE_,
			@IS_SYSTEM_,
			@COND_COUNT_,
			@CREATED_BY_,
			@PID_CREATED_BY_,
			@FULL_NAME_CREATED_BY_,
			@CREATED_ON_,
			@TERM_
		)
	
		DECLARE @insertedLocationGroupID BIGINT = SCOPE_IDENTITY();
					
		-- ###################### Create 2 System-Locations linked to the created System-Warehouse ###################### _START
		DECLARE
			@location_VERSION_ bigint = 1,
			@location_NAME_ nvarchar(255),
			@LOC_TYPE_ nvarchar(255),
			@location_IS_ACTIVE_ bit,
			@IS_LOCKED_ bit
		;
	
		SET @location_VERSION_ = 1;
		SET @location_IS_ACTIVE_ = 1;
		SET @IS_LOCKED_ = 0;

		IF @NAME_ LIKE 'SYST_%' --Insert only for default location group so that there is only one Receiving and InTransit location per BU
		BEGIN
			SET @location_NAME_ = 'RCV_' + CAST(NEWID() AS VARCHAR(1024));
			EXEC DM_003_PUTIL_005_InsertLocation @insertedRecordID OUTPUT, @location_VERSION_, @location_NAME_, 'Receiving', @insertedLocationGroupID, @location_IS_ACTIVE_, @IS_LOCKED_, 'Regular', @CREATED_BY_, @PID_CREATED_BY_, @FULL_NAME_CREATED_BY_, @CREATED_ON_, @TERM_;
			
			SET @location_NAME_ = 'ITR_' + CAST(NEWID() AS VARCHAR(1024));
			EXEC DM_003_PUTIL_005_InsertLocation @insertedRecordID OUTPUT, @location_VERSION_, @location_NAME_, 'InTransit', @insertedLocationGroupID, @location_IS_ACTIVE_, @IS_LOCKED_, 'Regular', @CREATED_BY_, @PID_CREATED_BY_, @FULL_NAME_CREATED_BY_, @CREATED_ON_, @TERM_;
		END
		-- ###################### Create 2 System-Locations linked to the created System-Warehouse ###################### _END

		-- ###################### Insert tag color conditions ###################### _START
		IF @IS_SYSTEM_ = 0 --Only insert this for non-system records
		BEGIN
			INSERT INTO ADM_XRF_UNIT_LOCATION_GROUP_ITEM_CONDITION (LG_ID_, COND_ID_) 
				VALUES(@insertedLocationGroupID, (SELECT ID_ FROM ADM_MST_TAG_COLOR_CONDITION WHERE TAG_COLOR_ = 'YELLOW'))
				
			INSERT INTO ADM_XRF_UNIT_LOCATION_GROUP_ITEM_CONDITION (LG_ID_, COND_ID_)
				VALUES(@insertedLocationGroupID, (SELECT ID_ FROM ADM_MST_TAG_COLOR_CONDITION WHERE TAG_COLOR_ = 'BLUE'))
				
			INSERT INTO ADM_XRF_UNIT_LOCATION_GROUP_ITEM_CONDITION (LG_ID_, COND_ID_)
				VALUES(@insertedLocationGroupID, (SELECT ID_ FROM ADM_MST_TAG_COLOR_CONDITION WHERE TAG_COLOR_ = 'GREEN'))
				
			INSERT INTO ADM_XRF_UNIT_LOCATION_GROUP_ITEM_CONDITION (LG_ID_, COND_ID_)
				VALUES(@insertedLocationGroupID, (SELECT ID_ FROM ADM_MST_TAG_COLOR_CONDITION WHERE TAG_COLOR_ = 'RED'))
				
			INSERT INTO ADM_XRF_UNIT_LOCATION_GROUP_ITEM_CONDITION (LG_ID_, COND_ID_)
				VALUES(@insertedLocationGroupID, (SELECT ID_ FROM ADM_MST_TAG_COLOR_CONDITION WHERE TAG_COLOR_ = 'BROWN'))
		END
		-- ###################### Insert tag color conditions ###################### _END
	
		-- ###################### Update count of tag color conditions in LOCATION_GROUP ###################### _START
		UPDATE ADM_MST_UNIT_LOCATION_GROUP
		SET
			COND_COUNT_ = (SELECT COUNT(*) FROM ADM_XRF_UNIT_LOCATION_GROUP_ITEM_CONDITION WHERE LG_ID_ = @insertedLocationGroupID),
			LOC_COUNT_ = (SELECT COUNT(*) FROM ADM_MST_UNIT_LOCATION WHERE LG_ID = @insertedLocationGroupID)
		WHERE
			ID_ = @insertedLocationGroupID
		-- ###################### Update count of tag color conditions in LOCATION_GROUP ###################### _END
	END
END

go

