CREATE PROC GetUncorrectedFaultReport
      @DateFrom   Datetime,
      @DateTo           DateTime,
      @TailIds    varchar(max)
AS
BEGIN
SELECT 
      FAULTUNIT.ID_                       As FaultId,
      TAILS.T_NUM_                        As TailNo,
      PLATFORMS.CODE_                     As ACType,
      FAULTUNIT.FAULT_NO_                 As FaultNo,
      FAULTUNIT.FAULT_INFO_DATE_  As FaultDate,
      FAULTUNIT.FAULT_INFO_STS_ID As FaultStatus,
      FAULTUNIT.FAULT_INFO_REMARKS_ As FaultRemarks,
      dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_SYS_ID, 'code') As FaultSystem,
      dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_UNCORRECTED_DLY_RSN_ID, 'name') As DelayReason,
      FAULTUNIT.FAULT_UNCORRECTED_DT_BEGIN_ As DateFrom,
      dbo.ReturnPID(FAULTUNIT.FAULT_UNCORRECTED_USR_ID) As ApprovedBy,
      FAULTUNIT.FAULT_UNCORRECTED_DT_END As DateTo
FROM  
      ADM_MST_TAILS TAILS INNER JOIN ADM_MST_UNITS UNITS                      ON TAILS.UNIT_ID = UNITS.ID_
                                    INNER JOIN ADM_MST_ITEMS ITEMS                        ON UNITS.ITEM_ID = ITEMS.ID_
                                    INNER JOIN ADM_MST_PLATFORMS PLATFORMS          ON ITEMS.ID_ = PLATFORMS.ID_
                                    INNER JOIN MNT_TRN_FAULT_UNITS FAULTUNIT  ON UNITS.ID_ =       FAULTUNIT.UNIT_ID
WHERE
      FAULTUNIT.FAULT_UNCORRECTED_DLY_RSN_ID IS NOT NULL          
      AND TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',')   )     
      AND FAULTUNIT.FAULT_UNCORRECTED_DT_BEGIN_ < @DateTo
      AND (FAULTUNIT.FAULT_UNCORRECTED_DT_END IS NULL OR FAULTUNIT.FAULT_UNCORRECTED_DT_END >= @DateFrom)

SELECT * FROM dbo.ReturnTailHeader(@TailIds)    
END
go

