CREATE FUNCTION [dbo].[ReturnPCStatusAllTails]	(@month varchar(255) = '0', @year int = 0) 
RETURNS @ACStatus TABLE
(
	AircraftId		bigint,
	CommandId		bigint,
	Command			varchar(255),
	BattalionId		bigint,
	Battalion		varchar(255),
	CompanyId		bigint,
	Company			varchar(255),
	TailId			bigint, 
	TailNo			varchar(255),
	PlatformId		bigint,
	[Platform]		varchar(255),
	OrRequired		Decimal(10, 2),
	HourSpan		Decimal(10, 1),
	TotalAcHours	Decimal(10, 1),
	FMC				Decimal(10, 1),
	PMCM			Decimal(10, 1),
	PMCS			Decimal(10, 1),
	NMCS1			Decimal(10, 1),
	NMCS2			Decimal(10, 1),
	DEPOT			Decimal(10, 1),
	NMCM1			Decimal(10, 1),
	NMCM2			Decimal(10, 1),
	NRT			    Decimal(10, 1)

)
AS
BEGIN 	
	DECLARE @end_day int , @start_date  smalldatetime,  @end_date smalldatetime

	DECLARE @FMC int = 220    
	DECLARE @PMCM int = 221    
	DECLARE @PMCS int = 222    
	DECLARE @NMCS_1st int = 223    
	DECLARE @NMCM_1st int = 224    
	DECLARE @DEPOT int = 225    
	DECLARE @NMCS_2nd int = 226    
	DECLARE @NMCM_2nd int = 227    
	DECLARE @TOTAL int = 228    
	DECLARE @FLT_HRS int = 229    
	DECLARE @LNDGS int = 230    
	DECLARE @AUTOS int = 231   
	DECLARE @NRT int = 232   
	DECLARE @HOURS_SPAN DECIMAL(8,1)

	 select  @HOURS_SPAN=sum([dbo].[GetMonthHour] (item,@year)) 
                 from
                 dbo.SplitInts(@month,',')

	--IF (@month = '0')    
	--  SET @month = Month(getdate())    
	--IF (@year = 0)    
	--  SET @year = Year(getdate())    
	--SET @end_day = DATEPART(day, @end_date)    

	--SET @start_date = convert(smalldatetime,(SELECT dateadd(mm, (@year - 1900) * 12 + @month - 1 , 1 - 1)),100)    
	--SET @end_date = DATEADD(mi, -1, DATEADD(M, 1, @start_date))     
	--IF @end_date > getdate()    
	--BEGIN
	--  SET @end_date = GETDATE()    
	--END


	INSERT INTO @ACStatus 
	SELECT  DISTINCT       
	  Tail.UNIT_ID		AircraftId,
	  Command.ID_				CommandId,
	  Command.CODE_				Command,
	  Battalion.ID_				BattalionId,
	  Battalion.CODE_			Battalion,
	  --Company.ID_				CompanyId,
	  --Company.CODE_			Company,
	  0							CompanyId,
	  ''						Company,
	  Tail.ID_					TailId,  
	  Tail.T_NUM_				TailNo, 
	  [Platform].ID_			PlatformId,
	  (case when PVariant.ID_ is null then Platform.CODE_ else  PVariant.PLTF_ALIAS_CODE_ end) AS [Platform],
	--  [Platform].CODE_			[Platform],   ,   
	  80						OrRequired,
	  @HOURS_SPAN HourSpan,
	-- DATEDIFF(hour, @start_date, @end_date) + 1														HourSpan,
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, 0))			TotalAcHours,    
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, @FMC))			FMC,    
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, @PMCM))		PMCM,    
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, @PMCS))		PMCS,    
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, @NMCS_1st))	NMCS1,    
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, @NMCS_2nd))	NMCS2,    
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, @DEPOT))		DEPOT,    
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, @NMCM_1st))	NMCM1,    
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, @NMCM_2nd))	NMCM2,
	  (select dbo.GetAircraftInvReportHrsForMonths(@month, @year, Tail.UNIT_ID, @NRT))	NRT
	FROM         
		dbo.ADM_MST_TAILS Tail	INNER JOIN  ADM_MST_UNITS Unit ON Tail.UNIT_ID = Unit.ID_ 
								INNER JOIN  ADM_MST_ITEMS Item ON Item.ID_ =  Unit.ITEM_ID 
								INNER JOIN  ADM_MST_PLATFORMS [Platform] ON Item.ID_ = [Platform].ID_ 
								INNER JOIN	ADM_MST_RESTRICTIONS Battalion ON Tail.BATLN_ID = Battalion.ID_
								INNER JOIN	ADM_MST_RESTRICTIONS Command ON Command.ID_ = Battalion.PRNT_ID
								LEFT JOIN ADM_MST_TAIL_VARIANT Tvariant on Tvariant.ID_ = Tail.UNIT_ID
							    LEFT JOIN ADM_MST_PLATFORM_VARIANT PVariant on PVariant.ID_ = Tvariant.PLTF_VARIANT_ID
								--INNER JOIN	ADM_MST_RESTRICTIONS Company ON Battalion.ID_ = Company.PRNT_ID
								--LEFT JOIN	MNT_TRN_AIRCRAFT_INVENTORIES AcStatus ON Unit.ID_ = AcStatus.AIRCRAFT_ID  
	
	RETURN 
END
go

