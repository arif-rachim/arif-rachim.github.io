CREATE VIEW [dbo].[VW_MISSION_AUTHORIZATION_ALREADY_PROCESSED_LIST]
AS
SELECT BTN.PRNT_ID AS CommandId, COY.ID_ AS CompanyId, MSN.ID_ AS MissionId, WF.ID_ AS WorkFlowInstanceId,
                            DATEADD(MINUTE, 240, T1.ETD_) AS MissionDateLocal, T1.ETD_ AS MissionDateGmt, MSN.MISSION_NO_ AS MissionNo, 
                                                 COY.CODE_ AS CompanyCode, PLF.CODE_ AS Platform, TAILS.T_NUM_ AS TailNumber, MT.DESC_ AS MissionType, MST.DESC_ AS MissionSubType,
                                                 SUBSTRING(CONVERT(VARCHAR, DATEADD(MINUTE, 240, T1.ETD_), 108), 1, 5) AS EtdLocal,
                                                 SUBSTRING(CONVERT(VARCHAR, T1.ETD_, 108), 1, 5) AS EtdGmt,                            
                            dbo.ConvertMinutesToHHMM(60 * DATEDIFF(MINUTE, T1.ETD_, T3.ETA_) ) AS Duration,
                            T4.BRFNAME AS Pilot1, T5.BRFNAME AS Pilot2,
                            (CASE WHEN len(ltrim(rtrim(coalesce(BCS.SHORT_NAME_, '')))) = 0 OR len(ltrim(rtrim(coalesce(T4.P1CallSign, '')))) = 0 THEN ''
                            ELSE RTRIM(BCS.SHORT_NAME_) + '-' + T4.P1CallSign END) AS CallSign, UNITS.IS_LOCKED_ AS TailIsLocked,
                            CASE WHEN MSN.MISS_PLAN_TYPE_ = 'Scheduled' THEN 'REGULAR' ELSE 'URGENT' END AS Category, 
                            CASE WF.WF_STATE_
                                                 WHEN 'OnMission' THEN 'ON MISSION'
                                                 WHEN 'InCorrection' THEN 'IN CORRECTION'
                                                 ELSE UPPER(WF.WF_STATE_) END AS Status,
                                                 TCV.PLATFORM_VARIANT_ AS Variant, TCV.IS_READY_ACTUAL_TAIL_ AS IsReady, TCV.IS_EQUIPPED_ACTUAL_TAIL AS IsEquipped,
                            MSN.CREATED_BY_ AS CreatedBy, UPC.F_NAME_ + ' ' + UPC.L_NAME_ AS FullNameCreatedBy,
                            MSN.CREATED_ON_ AS CreatedOn, NULL AS ModifiedBy, 
                                                 NULL AS FullNameModifiedBy,  NULL AS ModifiedOn
                            FROM OPS_TRN_MISSIONS AS MSN
                            INNER JOIN WF_TRN_INSTANCE AS WF ON MSN.WF_ID = WF.ID_ AND WF.WF_DEF_ID_='MissionWorkflow'
                                                 LEFT JOIN (SELECT WT.WF_INST_ID AS WorkflowInstanceId,
                                                 WT.ST_FROM_ AS StateFrom, MAX(WT.PROC_ON) AS TransactionDate FROM WF_TRN_TRACKING AS WT 
                                                 WHERE WT.ST_FROM_ = 'Authorized' AND WT.ST_CURR_ = 'Canceled'
                                                 GROUP BY WT.WF_INST_ID, WT.ST_FROM_) AS WFT ON WFT.WorkflowInstanceId = WF.ID_                                         

                            INNER JOIN OPS_TRN_WINGS AS WINGS ON WINGS.MISSION_ID = MSN.ID_
                            INNER JOIN ADM_MST_RESTRICTIONS AS COY ON COY.ID_ = WINGS.COY_ID
                            INNER JOIN ADM_MST_RESTRICTIONS AS BTN ON BTN.ID_ = COY.PRNT_ID
                            INNER JOIN ADM_MST_PLATFORMS AS PLF ON PLF.ID_ = WINGS.PLTF_ID
                            INNER JOIN OPS_TRN_TAIL_CREWS AS TC ON TC.WING_ID = WINGS.ID_
                                                 LEFT JOIN OPS_TRN_TAIL_CREW_VARIANTS AS TCV ON TCV.TAIL_CREW_ID_ = TC.ID_
                            INNER JOIN ADM_MST_TAILS AS TAILS ON TAILS.ID_ = TC.TAIL_ID
                            INNER JOIN ADM_MST_UNITS AS UNITS ON UNITS.ID_ = TAILS.UNIT_ID
                            INNER JOIN OPS_MST_MISSION_SUB_TYPES AS MST ON MST.ID_ = MSN.MISS_SUB_TYPE_ID
                            INNER JOIN OPS_MST_MISSION_TYPES AS MT ON MT.ID_ = MST.MISS_TYPE_ID
                            INNER JOIN ADM_TRN_USER_PROFILES AS UPC ON UPC.USER_ID_ = MSN.CREATED_BY_
                                                 LEFT JOIN ADM_TRN_USER_PROFILES AS MBUP ON MBUP.USER_ID_ = MSN.MOD_BY_
                            LEFT JOIN
                            ( 
                            SELECT MISSION_ID, ETD_, GMT_DIFF_, ROWNUM FROM (
                            SELECT MISSION_ID, OPS_TRN_FLIGHTS.ETD_, ADM_MST_AIR_BASES.GMT_DIFF_, ROW_NUMBER() 
                            OVER (PARTITION BY MISSION_ID ORDER BY OPS_TRN_FLIGHTS.ID_) AS ROWNUM
                            FROM OPS_TRN_FLIGHTS 
                            INNER JOIN ADM_MST_AIR_BASES ON ADM_MST_AIR_BASES.ID_ = OPS_TRN_FLIGHTS.BASE_FROM_ID
                            ) X WHERE ROWNUM = 1
                            ) AS T1 ON T1.MISSION_ID = MSN.ID_
                            LEFT JOIN 
                            (
                            SELECT MISSION_ID, ETA_, ROWNUM FROM (
                            SELECT MISSION_ID, ETA_, ROW_NUMBER() OVER (PARTITION BY MISSION_ID ORDER BY OPS_TRN_FLIGHTS.ID_ DESC) AS ROWNUM
                            FROM OPS_TRN_FLIGHTS
                            ) X WHERE ROWNUM = 1
                            ) AS T3 ON T3.MISSION_ID = MSN.ID_
                            LEFT JOIN
                            (
                            SELECT WING_ID, BRFNAME, ROWNUM, P1CallSign FROM (
                            SELECT OPS_TRN_TAIL_CREWS.WING_ID, OPS_MST_FLIGHT_CREWS.BRF_NAME_ AS BRFNAME, 
                            ROW_NUMBER() OVER (PARTITION BY TAIL_CREW_ID ORDER BY (CASE WHEN OPS_MST_DUTY_SYMBOL.TYPE_ = 'Pilot' THEN 0 ELSE 1 END), 
                            OPS_TRN_MISSION_CREW_PLAN.ID_) AS ROWNUM, OPS_MST_FLIGHT_CREWS.CALL_SIGN_ AS P1CallSign
                            FROM OPS_TRN_MISSION_CREW_PLAN 
                            INNER JOIN OPS_MST_FLIGHT_CREWS ON OPS_MST_FLIGHT_CREWS.ID_ = FLIGHT_CREW_ID
                            INNER JOIN OPS_TRN_TAIL_CREWS ON OPS_TRN_TAIL_CREWS.ID_ = TAIL_CREW_ID
                            LEFT JOIN OPS_MST_DUTY_SYMBOL ON OPS_MST_DUTY_SYMBOL.ID_ = DUTY_SYMBOL_ID 
                            ) X WHERE ROWNUM = 1
                            ) AS T4 ON T4.WING_ID = WINGS.ID_
                            LEFT JOIN
                            (
                            SELECT WING_ID, BRFNAME, ROWNUM FROM (
                            SELECT OPS_TRN_TAIL_CREWS.WING_ID, OPS_MST_FLIGHT_CREWS.BRF_NAME_ AS BRFNAME,
                            ROW_NUMBER() OVER (PARTITION BY TAIL_CREW_ID ORDER BY (CASE WHEN OPS_MST_DUTY_SYMBOL.TYPE_ = 'Pilot' THEN 0 ELSE 1 END),
                            OPS_TRN_MISSION_CREW_PLAN.ID_) AS ROWNUM
                            FROM OPS_TRN_MISSION_CREW_PLAN 
                            INNER JOIN OPS_MST_FLIGHT_CREWS ON OPS_MST_FLIGHT_CREWS.ID_ = FLIGHT_CREW_ID
                            INNER JOIN OPS_TRN_TAIL_CREWS ON OPS_TRN_TAIL_CREWS.ID_ = TAIL_CREW_ID
                            LEFT JOIN OPS_MST_DUTY_SYMBOL ON OPS_MST_DUTY_SYMBOL.ID_ = DUTY_SYMBOL_ID 
                            ) X WHERE ROWNUM = 2
                            ) AS T5 ON T5.WING_ID = WINGS.ID_
                            LEFT JOIN OPS_MST_CALL_SIGNS AS BCS ON BCS.UNIT_ID = COY.ID_ AND BCS.PLTF_ID = PLF.ID_
                                                 LEFT JOIN ADM_MST_TAIL_VARIANT AS TVR ON TVR.ID_ = UNITS.ID_
                                                 LEFT JOIN ADM_MST_PLATFORM_VARIANT AS PVR ON PVR.ID_ = TVR.PLTF_VARIANT_ID
                            WHERE MSN.MISS_PLAN_TYPE_ IN ('Scheduled', 'Unscheduled') 
                                                 AND (WF.WF_STATE_ NOT IN ('InAssignment', 'Assigned', 'Canceled')
                                                 OR (WF.WF_STATE_ = 'Canceled' AND WFT.StateFrom = 'Authorized')
                                                 )
go

