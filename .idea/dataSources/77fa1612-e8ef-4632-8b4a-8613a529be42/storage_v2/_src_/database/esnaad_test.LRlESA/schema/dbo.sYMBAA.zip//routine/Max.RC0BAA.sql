create function [dbo].[Max](@val1 int, @val2 int) RETURNS int
as 
begin
	if @val1 >= @val2 return @val1
	return @val2
end
go

