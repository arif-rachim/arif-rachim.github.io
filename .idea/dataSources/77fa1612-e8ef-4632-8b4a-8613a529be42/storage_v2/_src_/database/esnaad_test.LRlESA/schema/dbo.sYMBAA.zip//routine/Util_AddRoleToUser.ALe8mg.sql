CREATE PROCEDURE Util_AddRoleToUser
	@roleName NVARCHAR(MAX),
	@existingUserName NVARCHAR(MAX)
AS
BEGIN
	DECLARE @sqlTxt NVARCHAR(MAX);
	SET @sqlTxt = '
	IF NOT EXISTS(SELECT 1 FROM sys.database_principals WHERE name = ''' + @roleName + ''' AND type = ''R'')
		CREATE ROLE ' + @roleName
	;

	EXEC sp_executesql @sqlTxt;

	SET @sqlTxt = 'GRANT EXECUTE TO ' + @roleName;
	EXEC sp_executesql @sqlTxt;
	
	SET @sqlTxt = 'ALTER ROLE ' + @roleName + ' ADD MEMBER ' + @existingUserName;
	EXEC sp_executesql @sqlTxt;
END
go

