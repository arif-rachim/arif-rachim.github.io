
-- ======================================================================
-- Author:		GAL2723
-- Create date: 01-Apr-2014
-- Description:	Get ID of a given code from ADM_MST_SIMPLE_REF
-- ======================================================================
create FUNCTION [dbo].[getSimpleRefIdForCode] (@group VARCHAR(255), @code VARCHAR(255))
RETURNS BIGINT
AS
BEGIN
	DECLARE @simpleRefId BIGINT = NULL;
	
	SELECT @simpleRefId = ID_
	FROM ADM_MST_SIMPLE_REF
	WHERE GRP_ = @group AND CODE_ = @code
	
	RETURN @simpleRefId;
END

-- SELECT dbo.getSimpleRefIdForCode('MNT.STS', 'A');
-- ############################################################################################################

go

