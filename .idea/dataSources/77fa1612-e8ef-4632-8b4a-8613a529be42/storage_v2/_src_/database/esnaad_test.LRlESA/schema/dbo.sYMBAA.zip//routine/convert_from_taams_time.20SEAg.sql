CREATE FUNCTION [dbo].[convert_from_taams_time] 
(
	@time decimal(18,1) 
)
RETURNS decimal(18,2)
AS
BEGIN
	-- Declare variables
	DECLARE @return_time decimal(18,2) 
	DECLARE @hourPart decimal(18,2) 
	DECLARE @minutePart decimal(18,2) 

	if(@time is not null)
	begin

		SELECT @return_time = 0
		

		SET @hourPart = floor(@time)
		SET @minutePart = (@time - floor(@time)) * 10
		SET @minutePart = @minutePart * 6
		SET @minutePart = @minutePart - (@minutePart % 6)
			
		SET @return_time = @hourPart + (@minutePart /100)
		--SET @return_time = @minutePart /100
		
	end
	
	RETURN @return_time  

END
go

