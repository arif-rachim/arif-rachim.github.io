
CREATE FUNCTION [dbo].[D16_ListInLieuHasDiscrepancies](@itemId bigint,
                                                       @commandId bigint,
                                                       @platformId bigint,
                                                       @majorEndItemId bigint,
                                                       @parentWucId uniqueidentifier,
                                                       @wucId uniqueidentifier,
                                                       @allowed int,
                                                       @required int)
    RETURNS nvarchar(max)
AS
BEGIN
    DECLARE @result nvarchar(max),
			@_itemId bigint,
			@_commandId bigint,
			@_platformId bigint,
			@_majorEndItemId bigint,
			@_parentWucId uniqueidentifier,
			@_wucId uniqueidentifier,
			@_allowed int,
			@_required int

			SET @_itemId = @itemId;
			SET @_commandId = @commandId;
			SET @_platformId = @platformId;
			SET @_majorEndItemId = @majorEndItemId;
			SET @_parentWucId = @parentWucId;
			SET @_wucId = @wucId;
			SET @_allowed = @allowed;
			SET @_required = @required;

    select
            @result = STUFF(
                (
                    select ', ' + i.PART_NO_
                    from MNT_MST_D16_MASTER_COMPONENT m
                             join ADM_MST_ITEMS i on i.ID_ = m.COMP_ITEM_ID_
                             join ADM_MST_PLATFORM_L2 pl2 on pl2.CMD_ID_ = m.CMD_ID_ and pl2.PLTF_ID_ = m.PLTF_ID
                             join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = m.COMP_ITEM_ID_ and ia.L2_ID = pl2.L2_ID_
                    where m.CMD_ID_ = @_commandId
                      and m.PLTF_ID = @_platformId
                      and m.MAJOR_END_ITEM_ID_ = @_majorEndItemId
                      and (m.PRNT_WUC_ID_ = @_parentWucId or (@_parentWucId is null and m.PRNT_WUC_ID_ is null))
                      and m.WUC_ID_ = @_wucId
                      and (m.ASSIGNMENT_ALLOWED_ <> @_allowed or m.ASSIGNMENT_REQUIRED_ <> @_required)
                      and ia.IN_LIEU_CODE_ is not null
                      and ia.IN_LIEU_CODE_ = (select ia_2.IN_LIEU_CODE_
                                              from ADM_TRN_ITEM_ASSOCS ia_2
                                              where ia_2.ITEM_ID = @_itemId
                                                and ia_2.L2_ID = ia.L2_ID)
                    FOR XML PATH ('')
                )
            , 1, 2, '')

    RETURN @result
END
go

