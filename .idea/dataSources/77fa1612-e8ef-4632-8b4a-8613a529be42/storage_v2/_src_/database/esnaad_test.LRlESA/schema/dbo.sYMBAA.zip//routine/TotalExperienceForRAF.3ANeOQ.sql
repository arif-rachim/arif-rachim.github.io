CREATE FUNCTION TotalExperienceForRAF(@missionId bigint) 
RETURNS @result TABLE (
	MissionId bigint,
	FlightCrewId bigint,
	FlyingMinutes int
)
AS
BEGIN
	INSERT @result
	SELECT @missionId MissionId, X.FLIGHT_CREW_ID FlightCrewId, SUM(x.fminutes) FlyingMinutes FROM (
		 select M.FLIGHT_CREW_ID, M.DS_CODE_
		 ,sum(
		case when (convert(date, bsl.EFFECTIVE_DATE_) <= convert(date, DATEADD(HOUR, 4, record.RTD_))) then flying_minutes_
		when bsl.EFFECTIVE_DATE_ is null then flying_minutes_
		else 0 end
		) as fminutes
		from OPS_TRN_TAIL_CREW_FLIGHT_DETAILS flightdetals 
		inner join OPS_TRN_TAIL_CREW_FLIGHT cflight on flightdetals.tail_crew_flight_id = cflight.id_
		inner join OPS_TRN_TAIL_FLIGHT_RECORD record on cflight.tail_flight_record_id = record.id_
		inner join OPS_TRN_TAIL_FLIGHT flight on record.tail_flight_id = flight.id_ 
		inner join OPS_TRN_TAIL_CREWS tcrews on flight.tail_crew_id = tcrews.id_
		inner join OPS_TRN_WINGS wings on tcrews.wing_id = wings.id_
		join (
			SELECT CP.FLIGHT_CREW_ID, CP.DUTY_SYMBOL_ID, W.PLTF_ID, DS.CODE_ AS DS_CODE_
			FROM OPS_TRN_TAIL_CREWS TC
			JOIN OPS_TRN_WINGS W ON TC.WING_ID = W.ID_
			JOIN OPS_TRN_MISSION_CREW_PLAN CP ON CP.TAIL_CREW_ID = TC.ID_
			JOIN OPS_MST_DUTY_SYMBOL DS ON DS.ID_ = CP.DUTY_SYMBOL_ID
			WHERE W.MISSION_ID = @missionId 
		) M ON M.PLTF_ID = wings.PLTF_ID AND M.FLIGHT_CREW_ID = cflight.FLIGHT_CREW_ID
		join OPS_MST_DUTY_SYMBOL DS ON DS.ID_ = flightdetals.DUTY_SYMBOL_ID
		left outer join OPS_TRN_CREW_BASELINES bsl on cflight.flight_crew_id = bsl.CREW_ID AND wings.pltf_id = bsl.PLATFORM_ID
		WHERE (M.DS_CODE_ IN ('PC','IP','SP','MP','ME','IE') AND DS.CODE_ IN ('PC','IP','SP','MP','ME','IE')) OR (M.DS_CODE_ NOT IN ('PC','IP','SP','MP','ME','IE') AND DS.CODE_ NOT IN ('PC','IP','SP','MP','ME','IE'))
		group by M.FLIGHT_CREW_ID, M.DS_CODE_

		union all

		select M.FLIGHT_CREW_ID, M.DS_CODE_
		,sum(baselindet.flying_minutes_) as fminutes
		from OPS_TRN_CREW_BASELINES baseline 
		inner join OPS_TRN_CREW_BASLINE_EXPERIENCE_DETAILS baselindet on baselindet.base_line_id = baseline.id_
		join OPS_MST_DUTY_SYMBOL DS ON DS.ID_ = baselindet.duty_symbol_id
		join (
			SELECT CP.FLIGHT_CREW_ID, CP.DUTY_SYMBOL_ID, W.PLTF_ID, DS.CODE_ AS DS_CODE_
			FROM OPS_TRN_TAIL_CREWS TC
			JOIN OPS_TRN_WINGS W ON TC.WING_ID = W.ID_
			JOIN OPS_TRN_MISSION_CREW_PLAN CP ON CP.TAIL_CREW_ID = TC.ID_
			JOIN OPS_MST_DUTY_SYMBOL DS ON DS.ID_ = CP.DUTY_SYMBOL_ID
			WHERE W.MISSION_ID = @missionId 
		) M ON M.PLTF_ID = baseline.platform_id AND M.FLIGHT_CREW_ID = baseline.crew_id
		WHERE (M.DS_CODE_ IN ('PC','IP','SP','MP','ME','IE') AND DS.CODE_ IN ('PC','IP','SP','MP','ME','IE')) OR (M.DS_CODE_ NOT IN ('PC','IP','SP','MP','ME','IE') AND DS.CODE_ NOT IN ('PC','IP','SP','MP','ME','IE'))
		group by baselindet.duty_symbol_id, DS.CODE_,M.FLIGHT_CREW_ID, M.DS_CODE_
	) X
	GROUP BY X.FLIGHT_CREW_ID

RETURN
END
go

