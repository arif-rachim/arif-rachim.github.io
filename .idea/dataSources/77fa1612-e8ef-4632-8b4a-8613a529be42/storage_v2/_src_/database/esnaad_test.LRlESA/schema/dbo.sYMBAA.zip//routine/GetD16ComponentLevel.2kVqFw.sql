CREATE FUNCTION [dbo].[GetD16ComponentLevel](@compId AS UNIQUEIDENTIFIER)
  RETURNS BIGINT
AS
  BEGIN
    DECLARE
    @installedAircraftId BIGINT = 0
    , @parentTailId BIGINT = 0
    , @idx BIGINT = -1;

    WHILE (@installedAircraftId IS NOT NULL OR @parentTailId IS NULL)
      BEGIN
        SELECT
          @installedAircraftId = ac.ACFT_UNIT_ID_
          , @parentTailId = t.ID_
          , @compId = pc.ID_
        FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
          JOIN MNT_MST_D16_COMPONENT pc ON pc.ID_ = ac.PARENT_COMP_ID_
          JOIN MNT_MST_D16_COMPONENT cc ON cc.ID_ = ac.COMP_ID_
          LEFT JOIN ADM_MST_TAILS t ON pc.UNIT_ID_ = t.UNIT_ID
        WHERE cc.ID_ = @compId

        SELECT @idx = @idx + 1;

        IF (@installedAircraftId = 0)
          RETURN NULL;

        IF (@parentTailId IS NOT NULL)
          RETURN @idx;

        IF @idx >= 20
          RETURN NULL;

      END;
    RETURN @idx;
  END;
go

