CREATE FUNCTION [dbo].[GetIssuableInLieuStockInBusinessUnit]
(
      @itemId					bigint,
      @agl2Id					int,
      @buId						int, 
	  @includeItemStock			bit = 0,
	  @includeAllStoreStock		bit = 0
)
RETURNS int
AS
BEGIN
      
	DECLARE @stockInBu int
	DECLARE @stockInSubStore int = 0
	DECLARE @stockInParentStore int = 0
	DECLARE @stockInAllRelatedStore int = 0
	DECLARE @TagcolorConditionId tinyint = 1 --seviceable 

	DECLARE @IsParentStore bit = 1 --
	DECLARE @ParentStoreId bigint = 1  

	select @ParentStoreId = bu.PARENT_STORE_ID_  from ADM_MST_BUSINESS_UNITS bu where ID_ = @buId

	--select stock for the @buid
	SELECT    
		@stockInBu= SUM(imv.QTY_) 
	FROM  
					ADM_TRN_ITEM_ASSOCS ia 
		INNER JOIN  ADM_TRN_ITEM_ASSOCS il ON il.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_ AND il.L2_ID = ia.L2_ID 
		INNER JOIN  ADM_MST_UNITS AS un ON un.ITEM_ID = il.ITEM_ID
		INNER JOIN  ADM_TRN_IMV_ITEMS_IN_LOCATION AS imv ON imv.UNIT_ID_ = un.ID_ AND  (imv.TC_ID_		=	1) 
		INNER JOIN  ADM_MST_UNIT_LOCATION AS ul ON imv.LOC_ID_ = ul.ID_ AND ul.LOC_TYPE_ in ('Regular','Receiving')

	WHERE 
			 (imv.OWNED_L2_ID_	=	@agl2Id) 
		AND  (imv.BU_ID_		=	@buId) 
		AND  (imv.TC_ID_		=	@TagcolorConditionId) 
		AND  ia.ITEM_ID			=	@itemId 
		AND  ia.L2_ID			=	@agl2Id
		AND  (ia.ITEM_ID <> case  when @includeItemStock = 1 then  0 else il.ITEM_ID end)

		AND NOT EXISTS (SELECT 1 FROM LOG_TRN_TOM_TOOLS_REGISTER AS UNIT_CAL WHERE (UNIT_CAL.ACTIVE_ = 1) AND UNIT_CAL.UNIT_ID = imv.UNIT_ID_)
		AND NOT EXISTS (SELECT 1 FROM LOG_TRN_SII_INSTORE_UNIT_INSPECTION AS UN_INSP WHERE (IS_ACTIVE_ = 1) AND (WO_NO_ IS NOT NULL) AND UN_INSP.UNIT_ID = imv.UNIT_ID_)
		AND dateadd(d, datediff(d,0,ISNULL(un.EXP_DATE_, getdate() +1)),0) >= dateadd(d, datediff(d,0,getdate()),0)


	GROUP BY
		imv.BU_ID_,  imv.OWNED_L2_ID_, imv.TC_ID_
    
	--print '@stockInBu ' + cast(@stockInBu as nvarchar(10))
	if(@includeAllStoreStock = 1)
	BEGIN

		if(@ParentStoreId is null)
		begin
			--select stock for the substores of @buid 
			SELECT    
				@stockInAllRelatedStore= SUM(imv.QTY_) 
			 FROM  
							ADM_TRN_ITEM_ASSOCS ia 
				INNER JOIN  ADM_TRN_ITEM_ASSOCS il ON il.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_ AND il.L2_ID = ia.L2_ID 
				INNER JOIN  ADM_MST_UNITS AS un ON un.ITEM_ID = il.ITEM_ID
				INNER JOIN  ADM_TRN_IMV_ITEMS_IN_LOCATION AS imv ON imv.UNIT_ID_ = un.ID_ AND  (imv.TC_ID_		=	1) 
				INNER JOIN  ADM_MST_UNIT_LOCATION AS ul ON imv.LOC_ID_ = ul.ID_ AND ul.LOC_TYPE_ = 'Regular'
				INNER JOIN	ADM_MST_BUSINESS_UNITS sst ON sst.ID_ = imv.BU_ID_

			 WHERE 
					 (imv.OWNED_L2_ID_		=	@agl2Id) 
				AND  (sst.PARENT_STORE_ID_	=	@buId) 
				AND  (imv.TC_ID_			=	@TagcolorConditionId) 
				AND  ia.ITEM_ID				=	@itemId 
				AND  ia.L2_ID				=	@agl2Id
				AND  (ia.ITEM_ID <> case  when @includeItemStock = 1 then  0 else il.ITEM_ID end)

				AND NOT EXISTS (SELECT 1 FROM LOG_TRN_TOM_TOOLS_REGISTER AS UNIT_CAL WHERE (UNIT_CAL.ACTIVE_ = 1) AND UNIT_CAL.UNIT_ID = imv.UNIT_ID_)
				AND NOT EXISTS (SELECT 1 FROM LOG_TRN_SII_INSTORE_UNIT_INSPECTION AS UN_INSP WHERE (IS_ACTIVE_ = 1) AND (WO_NO_ IS NOT NULL) AND UN_INSP.UNIT_ID = imv.UNIT_ID_)
				AND dateadd(d, datediff(d,0,ISNULL(un.EXP_DATE_, getdate() +1)),0) >= dateadd(d, datediff(d,0,getdate()),0)

			GROUP BY
				 imv.OWNED_L2_ID_, imv.TC_ID_

		end
		else
		begin
			--select stock for the related substores of @buid , @ParentStoreId of @buid
			SELECT    
					@stockInSubStore= SUM(imv.QTY_) 
			FROM  
							ADM_TRN_ITEM_ASSOCS ia 
				INNER JOIN  ADM_TRN_ITEM_ASSOCS il ON il.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_ AND il.L2_ID = ia.L2_ID 
				INNER JOIN  ADM_MST_UNITS AS un ON un.ITEM_ID = il.ITEM_ID
				INNER JOIN  ADM_TRN_IMV_ITEMS_IN_LOCATION AS imv ON imv.UNIT_ID_ = un.ID_ AND  (imv.TC_ID_		=	1) 
				INNER JOIN  ADM_MST_UNIT_LOCATION AS ul ON imv.LOC_ID_ = ul.ID_ AND ul.LOC_TYPE_ = 'Regular'
				INNER JOIN	ADM_MST_BUSINESS_UNITS sst ON sst.ID_ = imv.BU_ID_

			WHERE 
						(imv.OWNED_L2_ID_	=	@agl2Id) 
				AND  (sst.PARENT_STORE_ID_	=	@ParentStoreId) 
				AND  (imv.TC_ID_			=	@TagcolorConditionId) 
				AND  ia.ITEM_ID				=	@itemId 
				AND  ia.L2_ID				=	@agl2Id
				AND  sst.ID_				<>	@buId 
				AND  (ia.ITEM_ID <> case  when @includeItemStock = 1 then  0 else il.ITEM_ID end)

				AND NOT EXISTS (SELECT 1 FROM LOG_TRN_TOM_TOOLS_REGISTER AS UNIT_CAL WHERE (UNIT_CAL.ACTIVE_ = 1) AND UNIT_CAL.UNIT_ID = imv.UNIT_ID_)
				AND NOT EXISTS (SELECT 1 FROM LOG_TRN_SII_INSTORE_UNIT_INSPECTION AS UN_INSP WHERE (IS_ACTIVE_ = 1) AND (WO_NO_ IS NOT NULL) AND UN_INSP.UNIT_ID = imv.UNIT_ID_)
				AND dateadd(d, datediff(d,0,ISNULL(un.EXP_DATE_, getdate() +1)),0) >= dateadd(d, datediff(d,0,getdate()),0)

			GROUP BY
				imv.OWNED_L2_ID_, imv.TC_ID_

			

			--select stock for the parent store @buid , @ParentStoreId of @buid
			SELECT    
				@stockInParentStore = SUM(imv.QTY_) 
			FROM  
							ADM_TRN_ITEM_ASSOCS ia 
				INNER JOIN  ADM_TRN_ITEM_ASSOCS il ON il.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_ AND il.L2_ID = ia.L2_ID 
				INNER JOIN  ADM_MST_UNITS AS un ON un.ITEM_ID = il.ITEM_ID
				INNER JOIN  ADM_TRN_IMV_ITEMS_IN_LOCATION AS imv ON imv.UNIT_ID_ = un.ID_ AND  (imv.TC_ID_		=	1) 
				INNER JOIN  ADM_MST_UNIT_LOCATION AS ul ON imv.LOC_ID_ = ul.ID_ AND ul.LOC_TYPE_ = 'Regular'
				INNER JOIN	ADM_MST_BUSINESS_UNITS sst ON sst.ID_ = imv.BU_ID_

			WHERE 
						(imv.OWNED_L2_ID_	=	@agl2Id) 
				AND  (sst.ID_				=	@ParentStoreId) 
				AND  (imv.TC_ID_			=	@TagcolorConditionId) 
				AND  ia.ITEM_ID				=	@itemId 
				AND  ia.L2_ID				=	@agl2Id
				AND  sst.ID_				<>	@buId 
				AND  (ia.ITEM_ID <> case  when @includeItemStock = 1 then  0 else il.ITEM_ID end)

				AND NOT EXISTS (SELECT 1 FROM LOG_TRN_TOM_TOOLS_REGISTER AS UNIT_CAL WHERE (UNIT_CAL.ACTIVE_ = 1) AND UNIT_CAL.UNIT_ID = imv.UNIT_ID_)
				AND NOT EXISTS (SELECT 1 FROM LOG_TRN_SII_INSTORE_UNIT_INSPECTION AS UN_INSP WHERE (IS_ACTIVE_ = 1) AND (WO_NO_ IS NOT NULL) AND UN_INSP.UNIT_ID = imv.UNIT_ID_)
				AND dateadd(d, datediff(d,0,ISNULL(un.EXP_DATE_, getdate() +1)),0) >= dateadd(d, datediff(d,0,getdate()),0)

			GROUP BY
				imv.BU_ID_,  imv.OWNED_L2_ID_, imv.TC_ID_

			SET @stockInAllRelatedStore = ISNULL(@stockInSubStore,0) + ISNULL(@stockInParentStore,0)				
		end
		SET @stockInBu = ISNULL(@stockInBu,0) + ISNULL(@stockInAllRelatedStore,0)
	END

     RETURN ISNULL(@stockInBu,0)
END
go

