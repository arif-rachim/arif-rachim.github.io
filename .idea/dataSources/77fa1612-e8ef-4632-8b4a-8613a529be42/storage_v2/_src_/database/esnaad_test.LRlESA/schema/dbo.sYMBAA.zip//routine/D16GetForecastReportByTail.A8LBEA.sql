CREATE FUNCTION [dbo].[D16GetForecastReportByTail]
  (
    @commandId int,
    @platformId int,
    @battalionId int,
    @tailId bigint,
    @itemId bigint,
    @nomenclature varchar(250),
    @hrs real,
    @landing int,
    @cValueMonth int,
    @cValueYear int
    )
  RETURNS TABLE
    AS
    RETURN
    WITH cte AS (
     SELECT TAILS.T_NUM_                                                              AS TailNo
           ,dbo.ReturnTAAMSTime(USAGE.TOT_FLIGHT_MINS_)                               AS Hrs
           ,USAGE.LANDINGS_                                                           AS Landing
           ,ISNULL(nha_item.NOMENCLATURE_, COMPITEM.NOMENCLATURE_)                    AS Part_Desc
           ,ISNULL(nha_item.PART_NO_, COMPITEM.PART_NO_)                              AS Part_No
           ,ISNULL(nha_unit.SERIAL_NO_, COMPUNIT.SERIAL_NO_)                          AS Unit_Serial_No
           ,ISNULL(nha_item.ID_, COMPITEM.ID_)                                        AS Item_Id
           ,c_due._hours                                                              AS FltHours
           ,c_due._date                                                               AS caldate1
           ,c_due._landings                                                           AS FltLdgs
           ,PL2.L2_ID_                                                                AS L2Id
           ,CASE WHEN (((c_due._hours < dbo.ReturnTAAMSTime(USAGE.TOT_FLIGHT_MINS_))
                                      OR (c_due._date < convert(date, GETDATE()))
                                      OR (c_due._landings < USAGE.LANDINGS_)
                                      )
                              ) 
                 THEN 'Overdue' 
                 ELSE 'NotYetDue' 
             END                                                                      AS DueStatus
			, COMNPONENT.ID_														  AS AssignmentId
			, mc.REPLACE_NHA_														  AS ReplaceNha

       FROM MNT_TRN_D16_ASSIGNED_COMPONENT AS COMNPONENT
            INNER JOIN MNT_MST_D16_MASTER_COMPONENT mc ON mc.ID_ = COMNPONENT.MASTER_COMP_ID_
            INNER JOIN MNT_MST_D16_COMPONENT CMP ON CMP.ID_ = COMNPONENT.COMP_ID_
            INNER JOIN ADM_MST_UNITS AS COMPUNIT ON COMPUNIT.ID_ = CMP.UNIT_ID_
            INNER JOIN ADM_MST_ITEMS AS COMPITEM ON COMPITEM.ID_ = COMPUNIT.ITEM_ID
            INNER JOIN ADM_MST_MANUFACTURES AS COMPSMFR ON COMPSMFR.ID_ = COMPITEM.MNF_ID
			INNER JOIN ADM_MST_TAILS AS TAILS ON TAILS.UNIT_ID IN (
				SELECT IIF(P_AC.REM_DATE_ IS NULL, AC.ACFT_UNIT_ID_, NULL)
				FROM MNT_TRN_D16_ASSIGNED_COMPONENT AC
					LEFT JOIN MNT_TRN_D16_ASSIGNED_COMPONENT P_AC ON P_AC.COMP_ID_ = AC.PARENT_COMP_ID_
				WHERE AC.ID_ = COMNPONENT.ID_
			) AND TAILS.END_DATE_ = '9999-12-31 00:00:00.000'
            INNER JOIN ADM_MST_RESTRICTIONS AS RST ON RST.ID_ = TAILS.BATLN_ID
            INNER JOIN ADM_MST_RESTRICTIONS AS CMD ON RST.PRNT_ID = CMD.ID_
            INNER JOIN ADM_MST_UNITS AS units1 ON units1.ID_ = TAILS.UNIT_ID
            INNER JOIN ADM_MST_ITEMS AS items1 ON items1.ID_ = units1.ITEM_ID
            INNER JOIN ADM_MST_PLATFORMS AS PLATFORMS ON items1.ID_ = PLATFORMS.ID_
            INNER JOIN ADM_MST_PLATFORM_L2 AS PL2 ON PL2.CMD_ID_ = mc.CMD_ID_ AND PL2.PLTF_ID_ = PLATFORMS.ID_
            LEFT JOIN ADM_TRN_UNIT_USAGE AS USAGE ON USAGE.UNIT_ID_ = units1.ID_
			LEFT JOIN MNT_TRN_D16_ASSIGNED_COMPONENT nha ON nha.COMP_ID_ = COMNPONENT.PARENT_COMP_ID_ and mc.REPLACE_NHA_=1
            LEFT JOIN MNT_MST_D16_COMPONENT nha_comp ON nha_comp.ID_ = nha.COMP_ID_
            LEFT JOIN ADM_MST_UNITS nha_unit ON nha_unit.ID_ = nha_comp.UNIT_ID_
            LEFT JOIN ADM_MST_ITEMS nha_item ON nha_item.ID_ = nha_unit.ITEM_ID
            CROSS APPLY dbo.D16GetComponentDue(CMP.ID_) c_due
      WHERE CMD.ID_ = @commandId
        AND COMNPONENT.IS_ACTIVE_ = 1
        AND Tails.ID_ = (CASE WHEN @tailId > 0 THEN @tailId ELSE Tails.ID_ END)
        AND (@battalionId = 0 OR EXISTS (SELECT 1 
                                       FROM ADM_MST_TAILS 
                      WHERE ADM_MST_TAILS.BATLN_ID = RST.ID_ 
                        AND ADM_MST_TAILS.UNIT_ID = Tails.UNIT_ID
                      )
        )
        AND (@platformId = 0 OR EXISTS (SELECT 1
                                          FROM ADM_MST_TAILS
                                               INNER JOIN ADM_MST_RESTRICTIONS ON ADM_MST_TAILS.BATLN_ID = ADM_MST_RESTRICTIONS.ID_
                                               INNER JOIN ADM_MST_UNITS AS ADM_MST_UNITS_1 ON ADM_MST_TAILS.UNIT_ID = ADM_MST_UNITS_1.ID_
                                               INNER JOIN ADM_MST_ITEMS AS ADM_MST_ITEMS_1 ON ADM_MST_UNITS_1.ITEM_ID = ADM_MST_ITEMS_1.ID_
                                         WHERE (ADM_MST_RESTRICTIONS.PRNT_ID = CMD.ID_)
                                           AND (ADM_MST_ITEMS_1.ID_ = PLATFORMS.ID_)
                                           AND (ADM_MST_TAILS.UNIT_ID = Tails.UNIT_ID)
                                           )
            )
       AND RST.ID_ = (CASE WHEN @battalionId > 0 THEN @battalionId  ELSE RST.ID_ END)
       AND PLATFORMs.ID_ = (CASE WHEN @platformId > 0 THEN @platformId ELSE PLATFORMs.ID_ END)
       AND (   ISNULL(nha_item.ID_, COMPITEM.ID_) = (CASE WHEN @itemId > 0 THEN @itemId ELSE ISNULL(nha_item.ID_, COMPITEM.ID_) END) 
          OR COMPITEM.ID_ = (CASE WHEN @itemId > 0 THEN @itemId ELSE COMPITEM.ID_ END))
       --AND ISNULL(nha_item.NOMENCLATURE_, compitem.NOMENCLATURE_) LIKE
       --             (CASE WHEN @nomenclature IS NOT NULL THEN ('%' + @nomenclature + '%') ELSE ISNULL(nha_item.NOMENCLATURE_, compitem.NOMENCLATURE_) END)
       
	   AND ( ( (@nomenclature IS NOT NULL or @nomenclature!='No-Value') and ISNULL(nha_item.NOMENCLATURE_, compitem.NOMENCLATURE_) LIKE '%\' + @nomenclature + '%' escape '\') or ((@nomenclature IS  NULL or @nomenclature='No-Value') and ISNULL(nha_item.NOMENCLATURE_, compitem.NOMENCLATURE_) = ISNULL(nha_item.NOMENCLATURE_, compitem.NOMENCLATURE_)))
	   )
	SELECT 
			TailNo,
			Hrs,
			Landing,
			OverDueDescription, 
			OverDuePartNo,
			OverDueSerialBatchNo,
			MIN(OverDueDueOnHrs) as OverDueDueOnHrs,
			MIN(OverDueDueOnCalender) as OverDueDueOnCalender,
			MIN(OverDueDueOnLanding) as OverDueDueOnLanding,
			DueNextDescription,
			DueNextPartNo,
			DueNextSerialBatchNo,
			MIN(DueNextDueOnHrs) as DueNextDueOnHrs,
			MIN(DueNextDueOnCalender) as DueNextDueOnCalender,
			MIN(DueNextDueOnLanding) as DueNextDueOnLanding,
			MIN(DueNextRemainingHrs) as DueNextRemainingHrs,
			MIN(DueNextRemainingDays) as DueNextRemainingDays,
			MIN(DueNextRemainingLandings) as DueNextRemainingLandings,
			RequestNo,
			MIN(OnHandQty) as OnHandQty
	FROM (
     SELECT cte.AssignmentId
		   ,cte.TailNo
           ,cte.Hrs
           ,cte.Landing
           ,CASE WHEN cte.DueStatus = 'Overdue' THEN cte.Part_Desc      ELSE null END AS OverDueDescription
           ,CASE WHEN cte.DueStatus = 'Overdue' THEN cte.Part_No        ELSE null END AS OverDuePartNo
           ,CASE WHEN cte.DueStatus = 'Overdue' THEN cte.Unit_Serial_No ELSE null END AS OverDueSerialBatchNo
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN NULL
                 WHEN (cte.FltHours < cte.Hrs AND cte.FltHours IS NOT NULL) THEN cte.FltHours
                 ELSE NULL 
             END AS OverDueDueOnHrs
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN NULL
                 WHEN (cte.caldate1 < convert(date, GETDATE()) AND cte.caldate1 IS NOT NULL) THEN cte.caldate1
                 ELSE NULL 
             END AS OverDueDueOnCalender
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN NULL
                 WHEN (cte.FltLdgs < cte.Landing AND cte.FltLdgs IS NOT NULL) THEN cte.FltLdgs
                 ELSE NULL 
             END AS OverDueDueOnLanding
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN cte.Part_Desc      ELSE NULL END AS DueNextDescription
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN cte.Part_No        ELSE NULL END AS DueNextPartNo
           ,CASE WHEN cte.DueStatus = 'NotYetDue' THEN cte.Unit_Serial_No ELSE NULL END AS DueNextSerialBatchNo
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(cte.FltHours) END AS DueNextDueOnHrs
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(cte.caldate1) END AS DueNextDueOnCalender
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(cte.FltLdgs)  END AS DueNextDueOnLanding
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(round((cte.FltHours - cte.Hrs), 1)) END AS DueNextRemainingHrs
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(DATEDIFF(DAY, GETDATE(), caldate1)) END AS DueNextRemainingDays
           ,CASE WHEN cte.DueStatus = 'Overdue'   THEN NULL ELSE MIN(cte.FltLdgs - cte.Landing)          END AS DueNextRemainingLandings
           ,(SELECT STUFF((SELECT ',' + TRNREQUEST1.TR_NO_
               FROM dbo.ADM_MST_TAILS AS TAILS1
                    INNER JOIN dbo.LOG_TRN_TRM_TRANSFER_REQUEST AS TRNREQUEST1 ON TRNREQUEST1.END_ITEM_UNIT_ID_ = TAILS1.UNIT_ID
                    INNER JOIN dbo.LOG_TRN_TRM_TRANSFER_REQUEST_ITEM AS RequestItem1 ON RequestItem1.TR_ID_ = TRNREQUEST1.ID_
					INNER JOIN WF_TRN_CURR_STATE AS Workflow ON Workflow.WF_INST_ID = TRNREQUEST1.WF_ID
              WHERE (TAILS1.T_NUM_ = cte.TailNo)
                AND RequestItem1.ITEM_ID = cte.Item_Id
				AND Workflow.NAME_ NOT IN ('Fulfilled','Deleted')
                AND RequestItem1.FF_STATUS_ IN ('NotFulfilled', 'PartiallyFulfilled')
              ORDER BY TRNREQUEST1.TR_NO_ FOR XML PATH ('')), 1, 1, '')) AS RequestNo
           ,(SELECT ISNULL(SUM(STOCK1.QTY_), 0) AS Qty
			 FROM ADM_MST_UNITS AS UNIT1
				INNER JOIN LOG_TRN_STOCK AS STOCK1 ON UNIT1.ID_ = STOCK1.UNIT_ID
				INNER JOIN ADM_MST_UNIT_LOCATION ON STOCK1.LOC_ID = ADM_MST_UNIT_LOCATION.ID_
              WHERE (UNIT1.ITEM_ID = cte.Item_Id)
                AND (ADM_MST_UNIT_LOCATION.LOC_TYPE_ = 'Regular' OR ADM_MST_UNIT_LOCATION.LOC_TYPE_='Receiving')
                AND STOCK1.OWNED_BY_L2_ID_ = cte.L2Id
				AND STOCK1.TAG_COLOR_COND_ID_ = 1
				AND (UNIT1.EXP_DATE_ is null or UNIT1.EXP_DATE_ >= GETDATE()) )                   AS OnHandQty
       FROM cte
      WHERE ( cte.DueStatus = 'Overdue'
         OR (    (1 <> 1 OR (@hrs > 0 OR @cValueYear > 0 OR @cValueMonth > 0 OR @landing > 0))
             AND ((@hrs > 0 AND cte.FltHours - cte.Hrs <= @hrs) OR
                  (@landing > 0 AND cte.FltLdgs - cte.Landing <= @landing) OR
                  (@cValueYear > 0 AND
                   (DATEADD(YEAR, @cValueYear, convert(date, GETDATE())) >= cte.caldate1)) OR
                  (@cValueMonth > 0 AND
                   (DATEADD(MONTH, @cValueMonth, convert(date, GETDATE())) >= cte.caldate1))
                 )
            ))

   GROUP BY cte.TailNo
        ,cte.Hrs
        ,cte.Landing
        ,cte.DueStatus
        ,cte.Part_Desc
        ,cte.Part_No
        ,cte.Item_Id
        ,cte.Unit_Serial_No
        ,cte.FltHours
        ,cte.caldate1
        ,cte.FltLdgs
        ,cte.L2Id
		,cte.AssignmentId
	) AS X
	GROUP BY
			TailNo,
			Hrs,
			Landing,
			OverDueDescription, 
			OverDuePartNo,
			OverDueSerialBatchNo,
			DueNextDescription,
			DueNextPartNo,
			DueNextSerialBatchNo,
			RequestNo,
			AssignmentId
go

