CREATE PROC [dbo].[GetACFaultReport]
       @DateFrom     Datetime,
       @DateTo              DateTime,
       @TailIds      varchar(max),
       @IncludeCloseFault bit = 1
AS

DECLARE @TailIdsTable TABLE (TAIL_ID BIGINT);

INSERT @TailIdsTable
SELECT Item 
  FROM dbo.SplitInts(@TailIds, ',');

SELECT 
       TAILS.T_NUM_                      As TailNo,
       PLATFORMS.CODE_                          As ACType,
       BATT.CODE_                               As Battalion,
       FAULTUNIT.FAULT_NO_               As FaultNo,
       FAULTUNIT.FAULT_INFO_DATE_  As FaultDate,
       FAULTUNIT.FAULT_INFO_STS_ID As FaultStatus,
       dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_SYS_ID, 'code') As FaultSystem,
       dbo.ReturnPID(FAULTUNIT.FAULT_INFO_USR_ID) As FaultPID,
       FAULTUNIT.FAULT_INFO_REMARKS_ As FaultRemarks,
       FAULTUNIT.FAULT_INFO_AIRCRAFT_HR_ As FaultACHours,
       dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_DISC_ID, 'code') As WhenDisc,
       dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_REC_ID, 'code') As HowRec,
       dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_MEFF_ID, 'code') As MalEff,
       dbo.ReturnDisplyStringForSimpleRef(FAULTUNIT.FAULT_INFO_FG_ID, 'code') As FaultFGC,
       CASE CONVERT(varchar, CORRECTS.DATE_, 103)
              WHEN CONVERT(varchar, @DateFrom, 103) THEN      dbo.ReturnPID(FAULTUNIT.FAULT_TI_VAL_USR_ID)
              ELSE NULL
       END  As TIPID, 
       CASE CONVERT(varchar, CORRECTS.DATE_, 103)
              WHEN CONVERT(varchar, @DateFrom, 103) THEN      FAULTUNIT.FAULT_TI_VAL_VAL_
              ELSE NULL
       END As TIManHours,                       
       
       CORRECTS.ID_                      As CorrectingInfoId,
       CORRECTS.DATE_                           As CorrectingDate,
       CORRECTS.AIRCRAFT_HR_             As CorrectingACHours,
       CORRECTS.AIRCRAFT_ROUNDS_  As CorrectingRounds,
       dbo.ReturnDisplyStringForSimpleRef(CORRECTS.ACT_ID, 'code') As CorectingActionCode,
       dbo.ReturnDisplyStringForSimpleRef(CORRECTS.FG_ID, 'code') As CorectingFGC,
       CORRECTS.ACT_DESC_                As CorrectingActionRemarks
FROM @TailIdsTable AS TailsTable 
                           INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                        INNER JOIN ADM_MST_RESTRICTIONS BATT         ON TAILS.BATLN_ID = BATT.ID_ 
                                         INNER JOIN ADM_MST_UNITS UNITS                         ON TAILS.UNIT_ID = UNITS.ID_
                                         INNER JOIN ADM_MST_ITEMS ITEMS                         ON UNITS.ITEM_ID = ITEMS.ID_
                                         INNER JOIN ADM_MST_PLATFORMS PLATFORMS          ON ITEMS.ID_ = PLATFORMS.ID_
                                         INNER JOIN MNT_TRN_FAULT_UNITS FAULTUNIT ON UNITS.ID_ =        FAULTUNIT.UNIT_ID
                                         LEFT JOIN MNT_TRN_FAULT_CORRECTS CORRECTS       ON FAULTUNIT.ID_ = CORRECTS.FAULT_UNIT_ID  AND CORRECTS.DATE_ < @DateTo
                                         
WHERE 1=1
       --TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',') )
       AND FAULTUNIT.FAULT_INFO_DATE_ < @DateTo
       AND  (
              (@IncludeCloseFault = 1 and (FAULTUNIT.CLOSE_DATE_ IS NULL OR FAULTUNIT.CLOSE_DATE_ > @DateFrom)) 
              or 
              (@IncludeCloseFault = 0 and FAULTUNIT.CLOSE_DATE_ IS NULL)
       )      AND ((FAULT_UNCORRECTED_DT_BEGIN_ IS NOT NULL AND FAULTUNIT.FAULT_UNCORRECTED_DT_END IS NOT NULL) OR (FAULT_UNCORRECTED_DT_BEGIN_ IS NULL)) 
ORDER BY 
       TAILS.T_NUM_, FAULTUNIT.FAULT_INFO_DATE_
OPTION (FORCE ORDER);

SELECT
       CORRECTITEMS.FLT_CORR_ID As CorrectingInfoId, dbo.ReturnPID(CORRECTITEMS.USR_ID) As PID, dbo.ReturnDisplyStringForSimpleRef(CORRECTITEMS.CAT_ID, 'code') As Category, SUM(CORRECTITEMS.MNT_MAIN_HRS) As ManHours
FROM @TailIdsTable AS TailsTable 
                           INNER JOIN ADM_MST_TAILS TAILS ON TAILS.ID_ = TailsTable.TAIL_ID
                           INNER JOIN ADM_MST_UNITS UNITS                                              ON TAILS.UNIT_ID = UNITS.ID_
                                         INNER JOIN MNT_TRN_FAULT_UNITS FAULTUNIT                      ON UNITS.ID_ =   FAULTUNIT.UNIT_ID
                                         INNER JOIN MNT_TRN_FAULT_CORRECTS CORRECTS                           ON FAULTUNIT.ID_ = CORRECTS.FAULT_UNIT_ID
                                         INNER JOIN MNT_TRN_FAULT_CORRECTING_ITEMS CORRECTITEMS ON CORRECTS.ID_  = CORRECTITEMS.FLT_CORR_ID 
WHERE 1=1
       --TAILS.ID_ IN (SELECT Item from dbo.SplitInts(@TailIds, ',') )
       AND FAULTUNIT.FAULT_INFO_DATE_ < @DateTo
       and  ((@IncludeCloseFault = 1 and FAULTUNIT.ID_ is not null) or (@IncludeCloseFault = 0 and FAULTUNIT.CLOSE_DATE_ IS NULL))   
GROUP BY 
       FLT_CORR_ID, USR_ID, CAT_ID
ORDER BY 
       FLT_CORR_ID  
OPTION (FORCE ORDER);
       
       
--Getting data to set heading disregarding above query returns data or not
SELECT * FROM dbo.ReturnTailHeader(@TailIds)
go

