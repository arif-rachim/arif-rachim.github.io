CREATE FUNCTION [dbo].[GetWorkingDays]
(
	@StartDate as DATETIME,
	@EndDate as DATETIME
)
RETURNS INT
AS
BEGIN

DECLARE @res INT

SET @res = ((DATEDIFF(dd, @StartDate, @EndDate) + 1)
- 
(DATEDIFF(wk, @StartDate, @EndDate) * 2))
+ 
(
	(CASE WHEN DATEPART(WEEKDAY, @StartDate +1) = 7 THEN 1 ELSE 0 END) -
	(CASE WHEN DATEPART(WEEKDAY, @EndDate +1) = 6 THEN 1 ELSE 0 END) -
	(CASE WHEN DATEPART(WEEKDAY, @EndDate +1) = 7 THEN 2 ELSE 0 END)
)

IF (@res < 0)
	SELECT @res = 0

RETURN @res
END
go

