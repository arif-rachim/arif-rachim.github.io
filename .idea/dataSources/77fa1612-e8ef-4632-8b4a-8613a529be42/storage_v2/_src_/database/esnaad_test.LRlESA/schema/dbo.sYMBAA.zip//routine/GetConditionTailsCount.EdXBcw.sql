CREATE FUNCTION [dbo].[GetConditionTailsCount] 
(
      @CommandId		int,
      @PlatformId       int,
	  @PlatformVar		varchar(3),
	  @Condition		varchar(5),
	  @IsDeploy			bit
)
RETURNS int
AS
BEGIN
	DECLARE @result int

	DECLARE @FMC int = 32
    DECLARE @PMCM int = 36
    DECLARE @PMCS int = 37
    DECLARE @DEPOT int = 33
    DECLARE @NMCM int = 34
    DECLARE @NMCS int = 35

	IF @IsDeploy = 0
	BEGIN
		IF @Condition = 'SAT'
		BEGIN
			IF @PlatformVar IS NULL
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NULL
						AND (SR.ID_ = @FMC OR SR.ID_ = @PMCM OR SR.ID_ = @PMCS)	AND isnull(srv.IS_DEPLOYED_,0) = 0
			END
			ELSE
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NOT NULL
						AND (SR.ID_ = @FMC OR SR.ID_ = @PMCM OR SR.ID_ = @PMCS)	AND isnull(srv.IS_DEPLOYED_,0) = 0
			END
		END
		ELSE IF @Condition = 'UNSAT'
		BEGIN
			IF @PlatformVar IS NULL
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NULL
						AND (SR.ID_ = @NMCM OR SR.ID_ = @NMCS OR (SR.ID_ = @DEPOT AND (srv.DEPOT_CONDITION_ <> 'MODIFICATION' OR srv.DEPOT_CONDITION_ IS NULL))) AND isnull(srv.IS_DEPLOYED_,0) = 0 
			END
			ELSE
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NOT NULL
						AND (SR.ID_ = @NMCM OR SR.ID_ = @NMCS OR (SR.ID_ = @DEPOT AND (srv.DEPOT_CONDITION_ <> 'MODIFICATION' OR srv.DEPOT_CONDITION_ IS NULL))) AND isnull(srv.IS_DEPLOYED_,0) = 0
			END
		END
		ELSE
		BEGIN
			IF @PlatformVar IS NULL
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NULL
						AND (SR.ID_ = @DEPOT) AND srv.DEPOT_CONDITION_ = 'MODIFICATION' AND isnull(srv.IS_DEPLOYED_,0) = 0
			END
			ELSE
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NOT NULL
						AND (SR.ID_ = @DEPOT) AND srv.DEPOT_CONDITION_ = 'MODIFICATION' AND isnull(srv.IS_DEPLOYED_,0) = 0
			END
		END
	END
	ELSE
	BEGIN
		IF @Condition = 'SAT'
		BEGIN
			IF @PlatformVar IS NULL
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NULL
						AND (SR.ID_ = @FMC OR SR.ID_ = @PMCM OR SR.ID_ = @PMCS)	AND isnull(srv.IS_DEPLOYED_,0) = 1
			END
			ELSE
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NOT NULL
						AND (SR.ID_ = @FMC OR SR.ID_ = @PMCM OR SR.ID_ = @PMCS)	AND isnull(srv.IS_DEPLOYED_,0) = 1
			END
		END
		ELSE IF @Condition = 'UNSAT'
		BEGIN
			IF @PlatformVar IS NULL
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NULL
						AND (SR.ID_ = @NMCM OR SR.ID_ = @NMCS) AND isnull(srv.IS_DEPLOYED_,0) = 1
			END
			ELSE
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NOT NULL
						AND (SR.ID_ = @NMCM OR SR.ID_ = @NMCS) AND isnull(srv.IS_DEPLOYED_,0) = 1
			END
		END
		ELSE
		BEGIN
			IF @PlatformVar IS NULL
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NULL
						AND (SR.ID_ = @DEPOT) AND isnull(srv.IS_DEPLOYED_,0) = 1
			END
			ELSE
			BEGIN
				SELECT @result = COUNT(*) 
				FROM ADM_MST_TAILS as t
					JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
					JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
					JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
					LEFT JOIN MNT_TRN_AIRCRAFT_SERVS as srv on srv.UNIT_ID = u.ID_ 
					LEFT JOIN ADM_MST_STATUS_CONDITIONS as sc ON sc.ID_ = srv.STSCND_ID
					LEFT JOIN ADM_MST_SIMPLE_REF as sr ON sr.ID_ = sc.COND_ID
					LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
					LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
				WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NOT NULL
						AND (SR.ID_ = @DEPOT) AND isnull(srv.IS_DEPLOYED_,0) = 1
			END
		END
	END

	RETURN @result
END
go

