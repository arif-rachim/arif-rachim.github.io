CREATE proc [dbo].[STK_Confirmation] (
	@sstId uniqueidentifier,
	@selectedLocItems STK_Type_SelectedLocationItem readonly, 
	@userProfileId bigint,
	@term nvarchar(255),
	@isConfirmed bit,
	@isAllConfirmed bit OUT) AS
BEGIN
	DECLARE @selectedCount int
	set @isAllConfirmed = 0
	DECLARE @userId nvarchar(255), @userPid nvarchar(255), @userFullName nvarchar(765)
	
	SELECT @userId = USER_ID_, @userPid = PID_, @userFullName = F_NAME_ + ' ' + ISNULL(L_NAME_, '')
	FROM ADM_TRN_USER_PROFILES 
	WHERE ID_ = @userProfileId


	SELECT @selectedCount=COUNT(*) FROM @selectedLocItems

	UPDATE LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM
	SET IS_CONFIRMED_ = @isConfirmed, VERSION_ = LI.VERSION_ + 1, DISC_LEVEL_ = ISNULL(LI.DISC_LEVEL_, 'Nil')
	, MOD_BY_ = @userId, FULL_NAME_MOD_BY_ = @userFullName, MOD_ON_ = GETDATE(), PID_MOD_BY_ = @userPid, TERM_ = @term
	FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
	JOIN LOG_TRN_STM_SUB_STOCKTAKING2_LOC SL ON SL.ID_ = LI.SST_LOC_ID
	JOIN @selectedLocItems L ON L.LocationItemId = LI.ID_ AND L.Version = LI.VERSION_
	WHERE SL.SST_ID = @sstId

	IF @@ROWCOUNT <> @selectedCount
	BEGIN
		RAISERROR('LOG.029.012', 16, 1)
		RETURN
	END

	SELECT @isAllConfirmed = CASE WHEN COUNT(LI.ID_) > 0 THEN 0 ELSE 1 END FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC SL
	JOIN LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI ON LI.SST_LOC_ID = SL.ID_
	WHERE SL.SST_ID = @sstId AND LI.IS_CONFIRMED_ = 0

	-- Log history
	INSERT LOG_HST_STM_SUB_STOCKTAKING2(VERSION_, SST_ID, ACTION_, CREATED_BY_, PID_CREATED_BY_, FULL_NAME_CREATED_BY_, 
		CREATED_ON_, TERM_, ITEM_ID_, LOC_ID_, SERIAL_NO_)
	SELECT 1, SST_ID, 'CONFIRM', @userId, @userPid, @userFullName, GETDATE(), @term, LI.ITEM_ID, SL.LOC_ID, ISNULL(LI.NEW_SERIAL_NO_, U.SERIAL_NO_)
	FROM LOG_TRN_STM_SUB_STOCKTAKING2_LOC_ITEM LI
	JOIN LOG_TRN_STM_SUB_STOCKTAKING2_LOC SL ON SL.ID_ = LI.SST_LOC_ID
	LEFT JOIN ADM_MST_UNITS AS U ON U.ID_ = LI.UNIT_ID
	JOIN @selectedLocItems L ON L.LocationItemId = LI.ID_ 
	WHERE SL.SST_ID = @sstId
END
go

