CREATE FUNCTION [dbo].[StripChars]
(
	@Result NVARCHAR(MAX),
	@MatchParam VARCHAR(255)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	SET @MatchParam = '%[' + @MatchParam + ']%'

	WHILE PATINDEX(@MatchParam, @Result) > 0
		SET @Result = STUFF(@Result, PATINDEX(@MatchParam, @Result), 1, '')

	RETURN @Result
END
go

