CREATE FUNCTION [dbo].[ConstructSequenceNumbers] (
	@prefix nvarchar(255),
	@padFormat nvarchar(255),
	@lastSeq int,
	@seqCount int,
	@year int, 
	@month int)
RETURNS @result TABLE(prefix nvarchar(255), year int, month int, formattedNo nvarchar(510))
AS
BEGIN
	declare @curSeq int = isnull(@lastseq, 0);
	declare @paddedMonth varchar(2) = case when @month is not null then right('00' + cast(@month as varchar(2)),2) else '' end
	declare @paddingLen int = cast(substring(@padFormat,2,len(@padFormat)) as int)
	declare @padding varchar(10) = replicate('0',@paddingLen)

	declare @i int = 0;
	while @i < @seqCount 
	begin
		set @curSeq = @curSeq + 1
		insert @result values (@prefix,@year,@month, @prefix + cast(@year as varchar(4)) + @paddedMonth + right(@padding + cast(@curSeq as varchar(10)), @paddingLen))
		set @i = @i + 1;
	end;
	return
END
go

