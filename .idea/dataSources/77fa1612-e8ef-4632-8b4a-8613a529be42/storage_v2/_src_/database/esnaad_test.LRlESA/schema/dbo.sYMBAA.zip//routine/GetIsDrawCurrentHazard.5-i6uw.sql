CREATE FUNCTION [dbo].[GetIsDrawCurrentHazard]
(
  @assessmentId uniqueidentifier
)
  RETURNS bit
AS
BEGIN
  DECLARE @result bit;

  select @result = cast(iif(ra.ASSESSMENT_NO_=x.ASSESSMENT_NO_, 1, 0) as bit)
  from ADM_TRN_RA_RISK_ASSESSMENT ra
	    left join ADM_TRN_RA_RISK_DETAILS_DRAW m on m.ASSESSMENT_ID_ = ra.ID_
	    left join (
		    select m1.BUILDING_ID,  max(ra1.ASSESSMENT_NO_) as ASSESSMENT_NO_
		    from ADM_TRN_RA_RISK_ASSESSMENT ra1
			    join ADM_TRN_RA_RISK_DETAILS_DRAW m1 on m1.ASSESSMENT_ID_ = ra1.ID_
                join ADM_TRN_RA_RISK_HAZARD hz on hz.ASSESSMENT_ID_ = ra1.ID_
            where upper(ra1.STATUS_) NOT IN ('DRAFTED','REJECTED')
		    group by m1.BUILDING_ID
	    ) x on x.BUILDING_ID = m.BUILDING_ID
  where ra.ID_ = @assessmentId;

  RETURN @result
END;
go

