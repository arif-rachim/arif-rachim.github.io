CREATE PROCEDURE [dbo].[AcslPrepareItemConsumptionCalculation]
(
  @acslId                 bigint = 0,
  @refId                  uniqueidentifier,
  @itemId                 bigint = 0,
  @consumptionOnly		  bit = 0
  )
  
AS
BEGIN

-- 2024-08-07 : Bug 90299 : Considering inlieu group on calculation
-- 2024-09-04 : Bug 90726 :  Factors are missing for the items not having consumption history

declare @acslItems TABLE
                     (
                       ItemId                           bigint,
					   MaxConsumption					int,
					   MinConsumption					int,
					   AvgLeadTime						decimal(10, 3), 
					   LongLeadTime						decimal(10, 3),
					   ExpiryFactor						decimal(10, 2),
					   MinLevel							int,
					   SafetyLevel						int,
					   MaxLevel							int,
					   WarLevel							int
                     )
	

	declare @buId bigint;
	declare @l2Id bigint;
	declare @itemClassCodes varchar(20)

	declare @currentYear datetime = datepart(year, getdate());
	declare @minDataForQuartiles int = 3;

	select @buId=STORE_ID, @l2Id=L2_ID, @itemClassCodes=ITEM_CLASS_ from LOG_TRN_SLM_AUTO_STOCK_LEVEL where ID_=@acslId;

	declare @t_item_class table(ClassId bigint)
	insert into @t_item_class 
	select cls.ID_ from ADM_MST_SIMPLE_REF cls where cls.GRP_='LOG.ICL' and cls.CODE_ in (select value from string_split(@itemClassCodes, ','))

	-- populate consumption history staging table

	insert into LOG_TRN_SLM_STAGING_CONSUM_HST
		select dbo.GenerateTimebasedGuid(), @acslId, @refId, CH.ITEM_ID as ItemId, i.CREATED_ON_ as ItemCreatedOn, CH.YEAR as ConsumptionYear, CH.TOTAL_ISSUE_ - (isnull(CH.REGULARIZED_QTY_, 0) + isnull(CH.TOTAL_TURN_IN_, 0)) as Consumption
		from LOG_TRN_ITEM_CONSUMPTION_HISTORY CH
		join ADM_MST_ITEMS i on i.ID_ = ch.ITEM_ID
		INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_ AND ((BU.PARENT_STORE_ID_ = @buId OR BU.ID_ = @buId) or @buId = 0)
		WHERE (CH.L2_ID_ = @l2Id or @l2Id = 0 ) 
			and (BU.BU_TYPE_ = 'Store') 
			and (i.ID_ = @itemId or @itemId = 0)
			and i.CLS_ID_ in (select ClassId from @t_item_class)
		GROUP BY CH.ITEM_ID, CH.YEAR, i.CREATED_ON_, ch.TOTAL_ISSUE_, ch.REGULARIZED_QTY_, CH.TOTAL_TURN_IN_

	if(@itemId is not null and @itemId > 0 and 0 = (select count(1) from LOG_TRN_SLM_STAGING_CONSUM_HST))
	begin
		insert into LOG_TRN_SLM_STAGING_CONSUM_HST 
		select dbo.GenerateTimebasedGuid(), @acslId, @refId, @itemId, i.CREATED_ON_ as ItemCreatedOn, null as ConsumptionYear, 0 as Consumption
		from ADM_MST_ITEMS i where i.ID_ = @itemId
	end;
	
	if @consumptionOnly = 1 
	begin
		--insert into @acslItems (ItemId) select ItemId from LOG_TRN_SLM_STAGING_CONSUM_HST where RefId = @refId group by ItemId
		select ItemId from LOG_TRN_SLM_STAGING_CONSUM_HST where RefId = @refId group by ItemId
		return;
	end

	-- update consumption history staging item created on to consider inlieu group to determine created on
	update hst
		set ItemCreatedOn = cri.MinCreatedOn 
	from LOG_TRN_SLM_STAGING_CONSUM_HST hst
	join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = hst.ItemId		
	join (
		select ia0.IN_LIEU_CODE_, min(hst0.ItemCreatedOn) as MinCreatedOn
		from LOG_TRN_SLM_STAGING_CONSUM_HST hst0
		join ADM_TRN_ITEM_ASSOCS ia0 on ia0.ITEM_ID = hst0.ItemId
		where ia0.IN_LIEU_CODE_ is not null
			and ia0.L2_ID = @l2Id
		group by ia0.IN_LIEU_CODE_
	) cri on cri.IN_LIEU_CODE_ = ia.IN_LIEU_CODE_
	where hst.RefId = @refId and ia.L2_ID=@l2Id
	and ia.PRIMARY_PART_ = 1
	and hst.ItemId in(@itemId, @itemId +1)
	
	-- prepare yearly consumption data
	declare @t_max_yearly_consumption as table(ItemId bigint, Year int, MaxConsumption bigint)
	insert into @t_max_yearly_consumption
		
		-- items created older than current years
		select ItemId, Year, max(Consumption) MaxConsumption
		from (
			select hst.ItemId, hst.Year, iif(ia.PRIMARY_PART_ is null, sum(hst.Consumption), max(sug.SumConsumption)) as Consumption 
			from LOG_TRN_SLM_STAGING_CONSUM_HST hst
			left join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = hst.ItemId and ia.IN_LIEU_CODE_ is not null and ia.PRIMARY_PART_ = 1
			left join (
				select
					ia.IN_LIEU_CODE_ as InLieuCode, hst0.Year, sum(hst0.Consumption) as SumConsumption
				from LOG_TRN_SLM_STAGING_CONSUM_HST hst0
				join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = hst0.ItemId
				where hst0.RefId = @refId and ia.L2_ID = @l2Id and IN_LIEU_CODE_ is not null						
				group by ia.IN_LIEU_CODE_, hst0.Year
			) sug on sug.InLieuCode = ia.IN_LIEU_CODE_
			where RefId=@refId and datepart(Year, ItemCreatedOn) < @currentYear
			group by hst.ItemId, hst.Year, ia.PRIMARY_PART_ 
		) t
		group by ItemId, Year
		having max(Consumption) > 0	
	
		union all
		
		-- items created current years
		
		select ItemId, Year, Consumptions/(iif(NoOfDays = 0, 1, NoOfDays)/365.000) as Consumption from 
		(
			select hst.ItemId, hst.Year, iif(ia.PRIMARY_PART_ is null, sum(hst.Consumption), max(sug.SumConsumption)) as Consumptions, datediff(day, ItemCreatedOn, getdate()) as NoOfDays
			from LOG_TRN_SLM_STAGING_CONSUM_HST hst
			left join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = hst.ItemId and ia.IN_LIEU_CODE_ is not null and ia.PRIMARY_PART_ = 1
			left join (
				select
					ia.IN_LIEU_CODE_ as InLieuCode, hst0.Year, sum(hst0.Consumption) as SumConsumption
				from LOG_TRN_SLM_STAGING_CONSUM_HST hst0
				join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = hst0.ItemId
				where hst0.RefId = @refId and ia.L2_ID = @l2Id and IN_LIEU_CODE_ is not null						
				group by ia.IN_LIEU_CODE_, hst0.Year
			) sug on sug.InLieuCode = ia.IN_LIEU_CODE_
			where RefId=@refId and datepart(Year, ItemCreatedOn) = @currentYear
			group by ItemId, ItemCreatedOn, hst.Year, ia.PRIMARY_PART_ 
		) t

	-- list of item id used in calculation
	
	declare @t_item as table(ItemId bigint)
	insert into @t_item
		select ItemId from LOG_TRN_SLM_STAGING_CONSUM_HST where RefId = @refId group by ItemId

	-- quartiles data
	declare @t_quartiles table(ItemId int, q1 int, q3 int)
	insert into @t_quartiles
		select ItemId, PERCENTILE_CONT(0.25) within group (order by MaxConsumption) over (partition by ItemId) as q1,
						PERCENTILE_CONT(0.75) within group (order by MaxConsumption) over (partition by ItemId) as q3
		from   @t_max_yearly_consumption where MaxConsumption > 0
	
	-- outlier range
	declare @t_outlierrange table(ItemId int, val decimal(11,2))
		insert into @t_outlierrange
		select q.ItemId, q3 + 1.5*(q3-q1) as upperbound
		from   @t_quartiles q
		join (
			select ItemId, count(Consumption) as Count 
			from LOG_TRN_SLM_STAGING_CONSUM_HST
			where RefId=@refId and Consumption > 0
			group by ItemId
		) c on q.ItemId = c.ItemId
		where c.Count >= @minDataForQuartiles
		group by q.ItemId, q.q3, q.q1

		-- populate max consumption stating table
		insert into LOG_TRN_SLM_STAGING_CONSUM_MAX
		select dbo.GenerateTimebasedGuid(), @acslId, @refId, tm.ItemId, max(tm.MaxConsumption) from (
			select co.ItemId, co.MaxConsumption
			from @t_max_yearly_consumption co
			left join @t_outlierrange ou on ou.ItemId = co.ItemId 
			where co.MaxConsumption > 0
			and (ou.ItemId is null or co.MaxConsumption <= ou.val)
		) tm
		group by tm.ItemId
	
	-- populate minimum consumption staging table
	insert into LOG_TRN_SLM_STAGING_CONSUM_MIN
		select dbo.GenerateTimebasedGuid(), @acslId, @refId, ItemId, min(Consumption) MinConsumption
		from (
			select hst.ItemId, hst.Year, iif(ia.PRIMARY_PART_ is null, sum(hst.Consumption), min(sug.SumConsumption)) as Consumption, ItemCreatedOn 
			from LOG_TRN_SLM_STAGING_CONSUM_HST hst
			left join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = hst.ItemId and ia.IN_LIEU_CODE_ is not null and ia.PRIMARY_PART_ = 1
			left join (
				select
					ia.IN_LIEU_CODE_ as InLieuCode, hst0.Year, sum(hst0.Consumption) as SumConsumption
				from LOG_TRN_SLM_STAGING_CONSUM_HST hst0
				join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = hst0.ItemId
				where hst0.RefId = @refId and ia.L2_ID = @l2Id and IN_LIEU_CODE_ is not null						
				group by ia.IN_LIEU_CODE_, hst0.Year
			) sug on sug.InLieuCode = ia.IN_LIEU_CODE_
			where RefId = @refId
			group by ItemId, hst.Year, ItemCreatedOn, ia.PRIMARY_PART_
		) t
		group by ItemId
		having min(Consumption) > 0

	-- populate delivery note staging table
	insert into LOG_TRN_SLM_STAGING_DNOTE_PART

		--'PurchaseOrder', 'PoFmsDocument'

		select dbo.GenerateTimebasedGuid(), @acslId, @refId,
			PRI.ITEM_ID as ItemId,
			dni.SERIAL_NO_ as SerialNo,
			dn.DELIVERY_DATE_ as DeliveryDate,
			dni.EXP_DATE_ as ExpiryDate,
			dn.REC_TYPE_ as ReceivingType,
			dn.ID_ as DeliveryId,
			dn.BU_ID as BuId,
			dn.L2_ID as L2Id
		from LOG_TRN_REC_DELIVERY_NOTE_ITEM dni
		join LOG_TRN_REC_DELIVERY_NOTE dn on dn.ID_ = dni.DN_ID
		right join LOG_TRN_PRC_PURCHASE_ORDER_ITEM POI ON DNI.PO_ITEM_ID_ = POI.ID_
		join LOG_TRN_PRC_PROCUREMENT_ITEM PRI ON POI.PROC_ITEM_ID = PRI.ID_
		where dn.STATUS_ <> 'Created' 
			and dn.REC_TYPE_ in('PurchaseOrder', 'PoFmsDocument')
			and PRI.ITEM_ID in (select ItemId from @t_item)

		union all

		select dbo.GenerateTimebasedGuid(), @acslId, @refId,
			ROI.ITEM_ID as ItemId,
			dni.SERIAL_NO_ as SerialNo,
			dn.DELIVERY_DATE_ as DeliveryDate,
			dni.EXP_DATE_ as ExpiryDate,
			dn.REC_TYPE_ as ReceivingType,
			dn.ID_ as DeliveryId,
			dn.TRF_TO_BU_ID as BuId,
			dn.L2_ID as L2Id
		from LOG_TRN_REC_DELIVERY_NOTE_ITEM dni
		join LOG_TRN_REC_DELIVERY_NOTE dn on dn.ID_ = dni.DN_ID
		RIGHT JOIN LOG_TRN_ROM_REPAIR_ORDER_ITEM ROI ON DNI.ROI_ID_ = ROI.ID_
		where dn.STATUS_ <> 'Created'
			and dn.REC_TYPE_ = 'RepairOrder'
			and ROI.ITEM_ID in (select ItemId from @t_item)		

		union all

		select dbo.GenerateTimebasedGuid(), @acslId, @refId,
			U.ITEM_ID as ItemId,
			dni.SERIAL_NO_ as SerialNo,
			dn.DELIVERY_DATE_ as DeliveryDate,
			dni.EXP_DATE_ as ExpiryDate,
			dn.REC_TYPE_ as ReceivingType,
			dn.ID_ as DeliveryId,
			dn.TRF_TO_BU_ID as BuId,
			dn.L2_ID as L2Id
		from LOG_TRN_REC_DELIVERY_NOTE_ITEM dni
		join LOG_TRN_REC_DELIVERY_NOTE dn on dn.ID_ = dni.DN_ID
		JOIN LOG_TRN_WM_WARRANTY W ON W.ID_ = DNI.WRTY_ID_
		JOIN LOG_TRN_RPR_REPAIR_FILE RF ON RF.REPAIR_FILE_NO_ = W.REPAIR_FILE_NO_
		JOIN ADM_MST_UNITS U ON U.ID_ = RF.UNIT_ID
		where dn.STATUS_ <> 'Created'
			and dn.REC_TYPE_ = 'Warranty'
			and U.ITEM_ID in (select ItemId from @t_item)

		union all

		select dbo.GenerateTimebasedGuid(), @acslId, @refId,
			U.ITEM_ID as ItemId,
			dni.SERIAL_NO_ as SerialNo,
			dn.DELIVERY_DATE_ as DeliveryDate,
			dni.EXP_DATE_ as ExpiryDate,
			dn.REC_TYPE_ as ReceivingType,
			dn.ID_ as DeliveryId,
			dn.TRF_TO_BU_ID as BuId,
			dn.L2_ID as L2Id
		from LOG_TRN_REC_DELIVERY_NOTE_ITEM dni
		join LOG_TRN_REC_DELIVERY_NOTE dn on dn.ID_ = dni.DN_ID
		JOIN LOG_TRN_RPR_FMS_DOCUMENT FMS ON FMS.ID_ = DNI.RPR_FMS_DOC_ID
		JOIN LOG_TRN_RPR_REPAIR_FILE RF ON RF.ID_ = fms.REPAIR_FILE_ID
		JOIN ADM_MST_UNITS U ON U.ID_ = RF.UNIT_ID
		where dn.STATUS_ <> 'Created'
			and dn.REC_TYPE_ = 'FmsDocument'
			and U.ITEM_ID in (select ItemId from @t_item)		

	-- get latest delivery
	declare @t_part_latest_delivery table (ItemId bigint, DeliveryDate datetime)	
		insert into @t_part_latest_delivery
		select ItemId, max(DeliveryDate) 
		from LOG_TRN_SLM_STAGING_DNOTE_PART 
		where RefId = @refId 
		group by ItemId
		--select * from  @t_part_latest_delivery
	
	-- get expiry factor	

	-- pupulate expiry factor staging table
	insert into LOG_TRN_SLM_STAGING_EXPIRY_FACTOR
		select dbo.GenerateTimebasedGuid(), @acslId, @refId, ld.ItemId,
			datediff(day, ld.DeliveryDate, e.Expiry) as Days,
			case
				when datediff(day, ld.DeliveryDate, e.Expiry) < 0 then 1
				when datediff(day, ld.DeliveryDate, e.Expiry) <= 90 then 0.25
				when datediff(day, ld.DeliveryDate, e.Expiry) <= 180 then 0.5
				when datediff(day, ld.DeliveryDate, e.Expiry) <= 270 then 0.75
				when datediff(day, ld.DeliveryDate, e.Expiry) > 270 then 1
			else 1.0
			end as Factor
		from @t_part_latest_delivery ld		
		left join (
			-- earliest expiry date
			select d.ItemId, d.DeliveryDate, min(isnull(d.ExpiryDate, convert(datetime, 0))) as Expiry
			from LOG_TRN_SLM_STAGING_DNOTE_PART d
			where d.RefId = @refId
			group by d.ItemId, d.DeliveryDate
		) e on e.ItemId = ld.ItemId and ld.DeliveryDate = e.DeliveryDate

		--select * from @t_expiry_factor

	-- @t_part_latest_delivery is no longer required
	delete from @t_part_latest_delivery

	-- populate procurement lead time staging table
	insert into LOG_TRN_SLM_STAGING_LEAD_TIME_PROC
		select dbo.GenerateTimebasedGuid(), @acslId, @refId, pri.ITEM_ID as itemId, min(datediff(day, isnull(ind.DATE_, ind.CREATED_ON_), dn.DELIVERY_DATE_))
		from LOG_TRN_PRC_INDENT_ITEM indi
		join LOG_TRN_PRC_INDENT ind on ind.id_ = indi.INDENT_ID
		join LOG_XRF_PRC_PROCUREMENT_ITEM_INDENT_ITEM xpoi on xpoi.INDENT_ITEM_ID = indi.ID_
		join LOG_TRN_PRC_PROCUREMENT_ITEM pri on pri.ID_ = xpoi.PROC_ITEM_ID
		join LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi on poi.PROC_ITEM_ID = pri.ID_
		join LOG_TRN_REC_DELIVERY_NOTE_ITEM dni on dni.PO_ITEM_ID_ = poi.ID_
		join LOG_TRN_REC_DELIVERY_NOTE dn on dn.ID_ = dni.DN_ID
		where dn.STATUS_ <> 'Created'
		and pri.ITEM_ID in (select ItemId from @t_item)
		and (dn.BU_ID = @buId or @buId = 0)
		and (dn.L2_ID = @l2Id or @l2Id = 0)
		group by pri.ITEM_ID, ind.ID_

	-- populate repair lead time staging table
	insert into LOG_TRN_SLM_STAGING_LEAD_TIME_REPAIR
	select dbo.GenerateTimebasedGuid(), @acslId, @refId, dp.ItemId, datediff(day, rep.DefectReportDate, dp.DeliveryDate)
		from LOG_TRN_SLM_STAGING_DNOTE_PART dp 
		join 
		(
			select dni.DN_ID, dni.SERIAL_NO_, dr.CREATED_ON_ as DefectReportDate
			from LOG_TRN_REC_DELIVERY_NOTE_ITEM dni
			join LOG_TRN_REC_DELIVERY_NOTE dn on dn.ID_ = dni.DN_ID
			RIGHT JOIN LOG_TRN_ROM_REPAIR_ORDER_ITEM ROI ON DNI.ROI_ID_ = ROI.ID_
			join LOG_TRN_RPR_REPAIR_FILE RF on RF.REPAIR_FILE_NO_=ROI.REPAIR_FILE_REF_
			join MNT_TRN_DFR_DEFECT_REPORT dr on dr.DEFECT_NO_ = RF.DEFECT_REPORT_NO_
			where dni.DN_ID in (select DeliveryId from LOG_TRN_SLM_STAGING_DNOTE_PART where RefId = @refId and ReceivingType ='RepairOrder')
			and (dn.TRF_TO_BU_ID = @buId or @buId = 0)
			and (dn.L2_ID = @l2Id or @l2Id = 0)
	
			union all

			select dni.DN_ID, dni.SERIAL_NO_, dr.CREATED_ON_ as DefectReportDate
			from LOG_TRN_REC_DELIVERY_NOTE_ITEM dni
			join LOG_TRN_REC_DELIVERY_NOTE dn on dn.ID_ = dni.DN_ID
			JOIN LOG_TRN_WM_WARRANTY W ON W.ID_ = DNI.WRTY_ID_
			JOIN LOG_TRN_RPR_REPAIR_FILE RF ON RF.REPAIR_FILE_NO_ = W.REPAIR_FILE_NO_
			join MNT_TRN_DFR_DEFECT_REPORT dr on dr.DEFECT_NO_ = RF.DEFECT_REPORT_NO_
			where dni.DN_ID in (select DeliveryId from LOG_TRN_SLM_STAGING_DNOTE_PART where RefId = @refId and ReceivingType ='Warranty')
			and (dn.TRF_TO_BU_ID = @buId or @buId = 0)
			and (dn.L2_ID = @l2Id or @l2Id = 0)

			union all

			select dni.DN_ID, dni.SERIAL_NO_, dr.CREATED_ON_ as DefectReportDate
			from LOG_TRN_REC_DELIVERY_NOTE_ITEM dni
			join LOG_TRN_REC_DELIVERY_NOTE dn on dn.ID_ = dni.DN_ID
			JOIN LOG_TRN_RPR_FMS_DOCUMENT FMS ON FMS.ID_ = DNI.RPR_FMS_DOC_ID
			JOIN LOG_TRN_RPR_REPAIR_FILE RF ON RF.ID_ = fms.REPAIR_FILE_ID
			join MNT_TRN_DFR_DEFECT_REPORT dr on dr.DEFECT_NO_ = RF.DEFECT_REPORT_NO_
			where dni.DN_ID in (select DeliveryId from LOG_TRN_SLM_STAGING_DNOTE_PART where RefId = @refId and  ReceivingType ='FmsDocument')
			and (dn.TRF_TO_BU_ID = @buId or @buId = 0)
			and (dn.L2_ID = @l2Id or @l2Id = 0)
		) rep on rep.DN_ID = dp.DeliveryId and rep.SERIAL_NO_ = dp.SerialNo
		where dp.refId=@refId
	
	-- populate lead time staging table
	insert into LOG_TRN_SLM_STAGING_LEAD_TIME
		select dbo.GenerateTimebasedGuid(), @acslId, @refId, i.ItemId, 
			isnull(avg(cast (iif(rle.LeadTime = 0, 1, rle.LeadTime) as decimal(10, 3))/365), avg(cast (iif(ple.LeadTime = 0, 1, ple.LeadTime) as decimal(10, 3))/365)) as AvgLeadTime,
			isnull(max(cast (iif(rle.LeadTime = 0, 1, rle.LeadTime) as decimal(10, 3))/365), max(cast (iif(ple.LeadTime = 0, 1, ple.LeadTime) as decimal(10, 3))/365)) as LongLeadTime 
		from @t_item i
		left join LOG_TRN_SLM_STAGING_LEAD_TIME_REPAIR rle on i.ItemId = rle.ItemId and rle.RefId=@refId
		left join LOG_TRN_SLM_STAGING_LEAD_TIME_PROC ple on i.ItemId = ple.ItemId and ple.RefId=@refId
		group by i.ItemId
	
  RETURN;
END;
go

