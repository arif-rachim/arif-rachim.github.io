CREATE VIEW [dbo].[VW_DAS_EPM_PROJECT_KPI]
AS
SELECT     PRJ.NAME_ AS ProjectName, PRJ.CUR_STATE_ AS Phase, MAX(VCNT.ContractValue) AS Value, VSCH.PlanningStartDate, VSCH.PlanningEndDate, 
                      VSCH.ActualStartDate, VSCH.ActualEndDate, VSCH.Progress, VSCH.OffSchedule, CASE WHEN VSCH.OffSchedule = 0 OR
                      PRJ.CUR_STATE_ = 'NotStarted' THEN 1 WHEN VSCH.OffSchedule > 10 OR
                      VSCH.PlanningStartDate IS NULL OR
                      VSCH.PlanningEndDate IS NULL THEN 3 ELSE 2 END AS Kpi
FROM         PMO_TRN_PROJECT PRJ LEFT OUTER JOIN
                          (SELECT     SCH.PRJ_ID, SCH.PLAN_START_DATE_ AS PlanningStartDate, SCH.PLAN_END_DATE_ AS PlanningEndDate, 
                                                   SCH.ACTUAL_START_DATE_ AS ActualStartDate, SCH.ACTUAL_END_DATE_ AS ActualEndDate, 
 CEILING(CONVERT(DECIMAL(18, 0), DATEDIFF(DAY, SCH.ACTUAL_START_DATE_, GETDATE())) / CONVERT(DECIMAL(18, 
                      0), (CASE WHEN SCH.PLAN_START_DATE_ = SCH.PLAN_END_DATE_ THEN 1 ELSE DATEDIFF(DAY, SCH.PLAN_START_DATE_, SCH.PLAN_END_DATE_) END)) 
                      * 100) AS Progress,
 ((DATEDIFF(DAY, SCH.ACTUAL_START_DATE_, GETDATE()) 
                                                   - DATEDIFF(DAY, SCH.PLAN_START_DATE_, SCH.PLAN_END_DATE_)) 
                                                   / (CASE WHEN SCH.PLAN_START_DATE_ = SCH.PLAN_END_DATE_ THEN 1 ELSE DATEDIFF(DAY, SCH.PLAN_START_DATE_, SCH.PLAN_END_DATE_) 
                                                   END)) AS OffSchedule
                             FROM         PMO_TRN_SCHEDULE SCH INNER JOIN
                                                   PMO_TRN_PROJECT VPRJ ON SCH.PRJ_ID = VPRJ.ID_
                             WHERE     SCH.STATE_ = VPRJ.CUR_STATE_ AND VPRJ.CUR_STATE_ <> 'NotStarted') AS VSCH ON VSCH.PRJ_ID = PRJ.ID_ LEFT OUTER JOIN
                          (SELECT     CNT.ID_, CNT.PROJ_ID, SUM(fin.CONT_VAL_CURR_VAL_ + 0) AS ContractValue
                             FROM         PMO_TRN_CONTRACT CNT LEFT OUTER JOIN
                                                   PMO_TRN_CONTRACT_FINANCIAL_INFO FIN ON FIN.CONTRACT_ID = CNT.ID_
                             GROUP BY CNT.ID_, CNT.PROJ_ID) AS VCNT ON VCNT.PROJ_ID = PRJ.ID_
WHERE     PRJ.CUR_STATE_ <> 'NotStarted'
GROUP BY PRJ.NAME_, PRJ.CUR_STATE_, VSCH.PlanningStartDate, VSCH.PlanningEndDate, VSCH.ActualStartDate, VSCH.ActualEndDate, VSCH.Progress, 
                      VSCH.OffSchedule
UNION
SELECT     PRJ.NAME_ AS ProjectName, PRJ.CUR_STATE_ AS Phase, MAX(VCNT.ContractValue) AS Value, VSCH.PlanningStartDate, VSCH.PlanningEndDate, 
                      VSCH.ActualStartDate, VSCH.ActualEndDate, 0 AS Progress, NULL AS OffSchedule, 1 AS Kpi
FROM         PMO_TRN_PROJECT PRJ LEFT OUTER JOIN
                          (SELECT     SCH.STATE_, SCH.PRJ_ID, SCH.PLAN_START_DATE_ AS PlanningStartDate, SCH.PLAN_END_DATE_ AS PlanningEndDate, 
                                                   SCH.ACTUAL_START_DATE_ AS ActualStartDate, SCH.ACTUAL_END_DATE_ AS ActualEndDate
                             FROM         PMO_TRN_SCHEDULE SCH INNER JOIN
                                                   PMO_TRN_PROJECT VPRJ ON SCH.PRJ_ID = VPRJ.ID_ AND SCH.STATE_ = 'Initiating') AS VSCH ON VSCH.PRJ_ID = PRJ.ID_ LEFT OUTER JOIN
                          (SELECT     CNT.ID_, CNT.PROJ_ID, SUM(fin.CONT_VAL_CURR_VAL_ + 0) AS ContractValue
                             FROM         PMO_TRN_CONTRACT CNT LEFT OUTER JOIN
                                                   PMO_TRN_CONTRACT_FINANCIAL_INFO FIN ON FIN.CONTRACT_ID = CNT.ID_
                             GROUP BY CNT.ID_, CNT.PROJ_ID) AS VCNT ON VCNT.PROJ_ID = PRJ.ID_
WHERE     VSCH.STATE_ = 'Initiating' AND PRJ.CUR_STATE_ = 'NotStarted'
GROUP BY PRJ.NAME_, PRJ.CUR_STATE_, VSCH.PlanningStartDate, VSCH.PlanningEndDate, VSCH.ActualStartDate, VSCH.ActualEndDate



go

