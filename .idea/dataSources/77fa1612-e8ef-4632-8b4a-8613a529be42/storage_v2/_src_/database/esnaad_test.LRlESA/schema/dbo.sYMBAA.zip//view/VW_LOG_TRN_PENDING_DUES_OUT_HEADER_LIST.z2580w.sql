CREATE VIEW [dbo].[VW_LOG_TRN_PENDING_DUES_OUT_HEADER_LIST]
AS
SELECT     Id, PartNumber, Nomenclature, CageCode, Nsn, Serialized, Ui, AvailableQty, InLieuQty, TotalPendingQty, RequestingBuId
FROM         (SELECT     I.ID_ AS Id, I.PART_NO_ AS PartNumber, I.NOMENCLATURE_ AS Nomenclature, M.CAGE_CODE_ AS CageCode, I.NSN_ AS Nsn, 
                                              I.SERIALIZED_ AS Serialized, SR.CODE_ AS Ui, NULL AS AvailableQty, NULL AS InLieuQty, NULL AS TotalPendingQty, BU.ID_ AS RequestingBuId
                        FROM         dbo.ADM_MST_ITEMS AS I LEFT OUTER JOIN
                                              dbo.ADM_MST_UNITS AS U ON I.ID_ = U.ITEM_ID INNER JOIN
                                              dbo.ADM_TRN_ITEM_ASSOCS AS IA ON I.ID_ = IA.ITEM_ID INNER JOIN
                                              dbo.ADM_TRN_ASSOC_GROUPS AS AG ON IA.ASSOC_ID = AG.ID_ INNER JOIN
                                              dbo.ADM_XRF_ADM_MST_BUSINESS_GROUP_ADM_TRN_ASSOC_GROUPS AS BGAG ON AG.ID_ = BGAG.AG_ID INNER JOIN
                                              dbo.ADM_MST_BUSINESS_GROUP AS BG ON BGAG.BUG_ID = BG.ID_ INNER JOIN
                                              dbo.ADM_MST_BUSINESS_UNITS AS BU ON BG.ID_ = BU.BUG_ID LEFT OUTER JOIN
                                              dbo.ADM_MST_SIMPLE_REF AS SR ON I.UI_ID = SR.ID_ LEFT OUTER JOIN
                                              dbo.ADM_MST_MANUFACTURES AS M ON I.MNF_ID = M.ID_
                        GROUP BY I.ID_, I.PART_NO_, I.NOMENCLATURE_, I.NSN_, I.SERIALIZED_, SR.CODE_, M.CAGE_CODE_, BU.ID_) AS X
go

