CREATE VIEW [dbo].[VW_KIT_LIST_ALLOCATION_LIST]
AS 
SELECT AllocationId, Version, InspectionAssignmentId, D161AssignmentId, D16AssignmentId, 
CommandId, Command, PlatformId, Platform, MroType, TailNo,
InspId, InspNo, D16MasterId, D161MasterId, D16TailUnitId, D16MajorEndItemId, D161EndUnitId, D161ComponentUnitId, D161MajorEndItemId,
InspDesc, KitListRegNo, KitListVersion, PublishedOn,		
RemainingHour, RemainingCal, RemainingLandings, RemainingCycles, Status,	
FilterHours, FilterDays, FilterMonths, FilterYears, FilterLandings, FilterCycles
FROM (
	SELECT AllocationId, Version, InspectionAssignmentId, D161AssignmentId, D16AssignmentId, 
	CommandId, Command, PlatformId, Platform, MroType, TailNo,
	InspId, InspNo, D16MasterId, D161MasterId, D16TailUnitId, D16MajorEndItemId, D161EndUnitId, D161ComponentUnitId, D161MajorEndItemId,
	InspDesc, KitListRegNo, KitListVersion, PublishedOn,		
	RemainingHour, RemainingCal, RemainingLandings, RemainingCycles, Status,	
	FilterHours, FilterDays, FilterMonths, FilterYears, FilterLandings, FilterCycles
	FROM (
		SELECT Kit_Alloc.ID_ AS AllocationId, Kit_Alloc.VERSION_ AS Version,
		a.ID_ AS InspectionAssignmentId, NULL AS D161AssignmentId, NULL AS D16AssignmentId, 
		m.CMD_ID AS CommandId, cmd.CODE_ AS Command, ADM_MST_PLATFORMS.ID_ AS PlatformId, ADM_MST_PLATFORMS.CODE_ AS Platform,
		'2408-18' AS MroType, ADM_MST_TAILS.T_NUM_ AS TailNo,
		m.ID_ AS InspId, m.INSP_NUMBER_ AS InspNo,
		NULL AS D16MasterId, NULL AS D161MasterId,  NULL AS D16TailUnitId, NULL AS D16MajorEndItemId, 
		NULL AS D161EndUnitId, NULL AS D161ComponentUnitId, NULL AS D161MajorEndItemId,
		m.INSP_NAME_ AS InspDesc,
		Kit_Alloc.REG_NO_ AS KitListRegNo, Kit_Alloc.KITLIST_VERSION_ AS KitListVersion, Kit_Alloc.PUBLISHED_ON_ AS PublishedOn,		
		(CASE 
			WHEN a.DUE_MAX_HOURS_ IS NOT NULL AND f.INSP_ID IS NOT NULL AND f.FAULT_STS_ = 'Open' THEN 'IN FM' 
			WHEN a.DUE_MAX_HOURS_ - dbo.GetUnitEffectiveUsageHours(a.UNIT_ID) < 0 THEN 'OVERDUE' 
			ELSE CONVERT(VARCHAR, CONVERT(DECIMAL(18, 1), a.DUE_HOURS_ - dbo.GetUnitEffectiveUsageHours(a.UNIT_ID))) + ' H' 
		END) AS RemainingHour, 
		(CASE 
			WHEN a.DUE_MAX_DATE_ IS NOT NULL AND f.INSP_ID IS NOT NULL AND f.FAULT_STS_ = 'Open' THEN 'IN FM' 
			WHEN DATEDIFF(DAY, GETDATE(), a.DUE_MAX_DATE_) < 0 THEN 'OVERDUE' 
			ELSE CONVERT(VARCHAR, DATEDIFF(DAY, GETDATE(), a.DUE_DATE_)) + ' D' 
		END) AS RemainingCal, 
		(CASE 
			WHEN a.DUE_LANDINGS_ IS NOT NULL AND f.INSP_ID IS NOT NULL AND f.FAULT_STS_ = 'Open' THEN 'IN FM' 
			WHEN a.DUE_MAX_LANDINGS_ - us.LANDINGS_ < 0 THEN 'OVERDUE' 
			ELSE CONVERT(VARCHAR, a.DUE_LANDINGS_ - us.LANDINGS_) + ' L' 
		END) AS RemainingLandings,
		(CASE 
			WHEN a.DUE_CYCLES_ IS NOT NULL AND f.INSP_ID IS NOT NULL AND f.FAULT_STS_ = 'Open' THEN 'IN FM' 
			WHEN a.DUE_MAX_CYCLES_ - us.CYCLES_ < 0 THEN 'OVERDUE' 
			ELSE CONVERT(VARCHAR, a.DUE_CYCLES_ - us.CYCLES_) + ' LC' 
		END) AS RemainingCycles,	
		CASE Kit_Alloc.STATUS_ WHEN 'PartiallyAllocated' THEN 'PARTIALLY ALLOCATED' ELSE UPPER(Kit_Alloc.STATUS_) END AS Status,	
		CONVERT(DECIMAL(18, 2),
		(CASE WHEN a.DUE_MAX_HOURS_ IS NOT NULL THEN CONVERT(DECIMAL(18,1), a.DUE_HOURS_ - dbo.GetUnitEffectiveUsageHours(a.UNIT_ID)) END)) AS FilterHours,
		(CASE WHEN a.DUE_MAX_DATE_ IS NOT NULL THEN DATEDIFF(DAY, GETDATE(), a.DUE_DATE_) END) AS FilterDays,
		(CASE WHEN a.DUE_MAX_DATE_ IS NOT NULL THEN DATEDIFF(MONTH, GETDATE(), a.DUE_DATE_) END) AS FilterMonths,
		(CASE WHEN a.DUE_MAX_DATE_ IS NOT NULL THEN DATEDIFF(YEAR, GETDATE(), a.DUE_DATE_) END) AS FilterYears,
		(CASE WHEN a.DUE_LANDINGS_ IS NOT NULL THEN (a.DUE_LANDINGS_ - us.LANDINGS_) END) AS FilterLandings,
		(CASE WHEN a.DUE_CYCLES_ IS NOT NULL THEN (a.DUE_CYCLES_ - us.CYCLES_) END) AS FilterCycles

		FROM LOG_TRN_IKT_INSPECTION_KIT_ALLOCATION Kit_Alloc
		INNER JOIN ADM_MST_TAILS ON Kit_Alloc.ACRFT_ID_ = ADM_MST_TAILS.UNIT_ID
		INNER JOIN ADM_MST_UNITS ON ADM_MST_TAILS.UNIT_ID = ADM_MST_UNITS.ID_
		INNER JOIN ADM_MST_ITEMS ON ADM_MST_UNITS.ITEM_ID = ADM_MST_ITEMS.ID_
		INNER JOIN ADM_MST_PLATFORMS ON ADM_MST_ITEMS.ID_ = ADM_MST_PLATFORMS.ID_
		INNER JOIN dbo.MNT_TRN_INSPECTION_MASTERS AS m ON Kit_Alloc.REF_NO_ = m.INSP_NUMBER_
		INNER JOIN ADM_MST_RESTRICTIONS AS cmd ON cmd.ID_ = m.CMD_ID
		INNER JOIN MNT_TRN_INSPECTION_ASSIGNMENTS AS a ON a.INSP_MST_ID = m.ID_ AND a.UNIT_ID = Kit_Alloc.ACRFT_ID_
		LEFT OUTER JOIN MNT_TRN_FAULT_UNITS AS f ON f.INSP_ID = a.ID_ AND f.FAULT_STS_ = 'Open' AND f.PRNT_FAULT_UNIT_ID IS NULL
		LEFT OUTER JOIN dbo.ADM_TRN_UNIT_USAGE AS us ON a.UNIT_ID = us.UNIT_ID_                     
	) AS SRC WHERE 1 = 1

	UNION ALL

	SELECT AllocationId, Version, InspectionAssignmentId, D161AssignmentId, D16AssignmentId, 
	CommandId, Command, PlatformId, Platform, MroType, TailNo,
	InspId, InspNo, D16MasterId, D161MasterId, D16TailUnitId, D16MajorEndItemId, 
	D161EndUnitId, D161ComponentUnitId, D161MajorEndItemId,
	InspDesc, KitListRegNo, KitListVersion, PublishedOn,
	(
		CASE
			WHEN FaultId IS NOT NULL AND FaultStatus = 'Open' THEN 'IN FM'
			WHEN RemainingHour < 0 THEN 'OVERDUE'
			ELSE CONVERT(VARCHAR, RemainingHour) + ' H'
		END
	) AS RemainingHour, 
	RemainingCal, RemainingLandings, RemainingCycles, Status,	
	FilterHours, FilterDays, FilterMonths, FilterYears, FilterLandings, FilterCycles
	FROM (
		SELECT distinct Kit_Alloc.ID_ AS AllocationId, Kit_Alloc.VERSION_ AS Version,
		NULL AS InspectionAssignmentId, a.ID_ As D161AssignmentId, NULL AS D16AssignmentId,
		m.CMD_ID AS CommandId, cmd.CODE_ AS Command, m.PLTF_ID AS PlatformId, ADM_MST_PLATFORMS.CODE_ AS Platform, '2408-16-1' AS MroType, ADM_MST_TAILS.T_NUM_ AS TailNo, 

		NULL AS InspId, m.MASTER_NO_ AS InspNo, NULL AS D16MasterId, m.ID_ AS D161MasterId, NULL AS D16TailUnitId, NULL AS D16MajorEndItemId,
		a.END_UNIT_ID AS D161EndUnitId, a.COMP_UNIT_ID AS D161ComponentUnitId, m.END_ITEM_ID AS D161MajorEndItemId,
		(d161i.PART_NO_+', '+ d161m.CAGE_CODE_ + ', ' + d161w.CODE_ + ', ' + d161i.NOMENCLATURE_) AS InspDesc,
		Kit_Alloc.REG_NO_ AS KitListRegNo, Kit_Alloc.KITLIST_VERSION_ AS KitListVersion, Kit_Alloc.PUBLISHED_ON_ AS PublishedOn,
		F.ID_ AS FaultId, F.FAULT_STS_ AS FaultStatus,
		(CASE
				WHEN m.OVERHAUL_ IS NOT NULL AND m.REPLACE_ IS NOT NULL THEN 
					(CASE
						WHEN ((m.OVERHAUL_ + ISNULL(a.LAST_OH_, 0)) - a.CUR_OP_HRS_) < (m.REPLACE_ - a.CUR_OP_HRS_) 
							THEN (m.OVERHAUL_ + ISNULL(a.LAST_OH_, 0)) - a.CUR_OP_HRS_
						ELSE m.REPLACE_ - a.CUR_OP_HRS_
					END)
				WHEN m.OVERHAUL_ IS NOT NULL THEN m.OVERHAUL_ + ISNULL(a.LAST_OH_, 0) - a.CUR_OP_HRS_
				WHEN m.REPLACE_ IS NOT NULL THEN m.REPLACE_ - a.CUR_OP_HRS_
		END) AS RemainingHour, NULL AS RemainingCal, NULL AS RemainingLandings, NULL AS RemainingCycles,

		CASE Kit_Alloc.STATUS_ WHEN 'PartiallyAllocated' THEN 'PARTIALLY ALLOCATED' ELSE UPPER(Kit_Alloc.STATUS_) END AS Status,

		CONVERT(DECIMAL(18, 2),
		(CASE
				WHEN m.OVERHAUL_ IS NOT NULL AND m.REPLACE_ IS NOT NULL THEN 
					(CASE
						WHEN ((m.OVERHAUL_ + ISNULL(a.LAST_OH_, 0)) - a.CUR_OP_HRS_) < (m.REPLACE_ - a.CUR_OP_HRS_) 
							THEN (m.OVERHAUL_ + ISNULL(a.LAST_OH_, 0)) - a.CUR_OP_HRS_
						ELSE m.REPLACE_ - a.CUR_OP_HRS_
					END)
				WHEN m.OVERHAUL_ IS NOT NULL THEN m.OVERHAUL_ + ISNULL(a.LAST_OH_, 0) - a.CUR_OP_HRS_
				WHEN m.REPLACE_ IS NOT NULL THEN m.REPLACE_ - a.CUR_OP_HRS_
		END)) AS FilterHours,
		NULL AS FilterDays, NULL AS FilterMonths, NULL AS FilterYears, NULL AS FilterLandings, NULL AS FilterCycles	

		FROM LOG_TRN_IKT_INSPECTION_KIT_ALLOCATION Kit_Alloc
		INNER JOIN ADM_MST_TAILS ON Kit_Alloc.ACRFT_ID_ = ADM_MST_TAILS.UNIT_ID
		INNER JOIN ADM_MST_UNITS ON ADM_MST_TAILS.UNIT_ID = ADM_MST_UNITS.ID_
		INNER JOIN ADM_MST_ITEMS ON ADM_MST_UNITS.ITEM_ID = ADM_MST_ITEMS.ID_
		INNER JOIN ADM_MST_PLATFORMS ON ADM_MST_ITEMS.ID_ = ADM_MST_PLATFORMS.ID_
		INNER JOIN MNT_TRN_D16_1_MASTER AS m ON Kit_Alloc.REF_NO_ = m.MASTER_NO_
		INNER JOIN ADM_MST_RESTRICTIONS AS cmd ON cmd.ID_ = m.CMD_ID
		INNER JOIN MNT_TRN_D16_1_ASSIGNMENT AS a ON a.MASTER_ID = m.ID_ AND a.END_ACFT_UNIT_ID = Kit_Alloc.ACRFT_ID_ AND A.ID_ = Kit_Alloc.D161_ASSIGNMENT_ID
		INNER JOIN ADM_MST_ITEMS AS d161i ON d161i.ID_ = m.COMP_ID
		LEFT JOIN ADM_MST_MANUFACTURES AS d161m on d161m.ID_ = d161i.MNF_ID
		LEFT JOIN MNT_MST_D16_WORK_UNIT_CODE AS d161w ON d161w.ID_ = m.WORK_UNIT_ID
		LEFT JOIN MNT_TRN_D16_1_GENERATED_FAULT AS gf on gf.D161_ASSIGN_ID = a.ID_
		LEFT OUTER JOIN MNT_TRN_FAULT_UNITS AS f ON f.ID_ = gf.FAULT_UNIT_ID AND f.FAULT_STS_ = 'Open' AND f.PRNT_FAULT_UNIT_ID IS NULL	
		WHERE M.INTERVAL_CAT_ != 'CC'
	) AS SRC WHERE 1 = 1

	UNION ALL

	SELECT AllocationId, Version, InspectionAssignmentId, D161AssignmentId, D16AssignmentId, 
	CommandId, Command, PlatformId, Platform, MroType, TailNo,
	InspId, InspNo, D16MasterId, D161MasterId,  D16TailUnitId, D16MajorEndItemId, D161EndUnitId, D161ComponentUnitId, D161MajorEndItemId,
	InspDesc, KitListRegNo, KitListVersion, PublishedOn,		
	RemainingHour, RemainingCal, RemainingLandings, RemainingCycles, Status,	
	FilterHours, FilterDays, FilterMonths, FilterYears, FilterLandings, FilterCycles
	FROM (
		SELECT AllocationId, Version, InspectionAssignmentId, D161AssignmentId, D16AssignmentId, 
		CommandId, Command, PlatformId, Platform, MroType, TailNo,
		InspId, InspNo, D16MasterId, D161MasterId, D16TailUnitId, D16MajorEndItemId, D161EndUnitId, D161ComponentUnitId, D161MajorEndItemId,
		InspDesc, KitListRegNo, KitListVersion, PublishedOn,	

		(
			CASE
				WHEN FaultId IS NOT NULL AND FaultStatus = 'Open' THEN 'IN FM'
				WHEN RemainingReplaceAircraftHour < 0 OR RemainingOverhaulAircraftHour < 0 THEN 'OVERDUE'
				ELSE CONVERT(VARCHAR, IIF(RemainingReplaceAircraftHour < RemainingOverhaulAircraftHour, RemainingReplaceAircraftHour, RemainingOverhaulAircraftHour)) + ' H'
			END
		) AS RemainingHour,

		(CASE
			WHEN FaultId IS NOT NULL AND FaultStatus = 'Open'  THEN 'IN FM'
			WHEN RemainingReplaceCalendarDays < 0 OR RemainingOverhaulCalendarDays < 0 THEN 'OVERDUE'
			ELSE CONVERT(VARCHAR, IIF(RemainingReplaceCalendarDays < RemainingOverhaulCalendarDays, RemainingReplaceCalendarDays, RemainingOverhaulCalendarDays)) + ' D'
		END) AS RemainingCal,

		(CASE
			WHEN FaultId IS NOT NULL AND FaultStatus = 'Open'  THEN 'IN FM'
			WHEN RemainingReplaceLanding < 0 OR RemainingOverhaulLanding < 0 THEN 'OVERDUE'
			ELSE CONVERT(VARCHAR, IIF(RemainingReplaceLanding < RemainingOverhaulLanding, RemainingReplaceLanding, RemainingOverhaulLanding)) + ' L'
		END) AS RemainingLandings, 

		(CASE
			WHEN FaultId IS NOT NULL AND FaultStatus = 'Open'  THEN 'IN FM'
			WHEN RemainingReplaceCycle < 0 OR RemainingOverhaulCycles < 0 THEN 'OVERDUE'
			ELSE CONVERT(VARCHAR, IIF(RemainingReplaceCycle < RemainingOverhaulCycles, RemainingReplaceCycle, RemainingOverhaulCycles)) + ' LC'
		END) AS RemainingCycles,

		Status,

		CONVERT(DECIMAL(18, 2),
		IIF(RemainingReplaceAircraftHour < RemainingOverhaulAircraftHour, RemainingReplaceAircraftHour, RemainingOverhaulAircraftHour)) AS FilterHours,
		IIF(RemainingReplaceCalendarDays < RemainingOverhaulCalendarDays, RemainingReplaceCalendarDays, RemainingOverhaulCalendarDays) AS FilterDays,
		IIF(RemainingReplaceCalendarMonths < RemainingOverhaulCalendarMonths, RemainingReplaceCalendarMonths, RemainingOverhaulCalendarMonths) AS FilterMonths,
		IIF(RemainingReplaceCalendarYears < RemainingOverhaulCalendarYears, RemainingReplaceCalendarYears, RemainingOverhaulCalendarYears) AS FilterYears,
		IIF(RemainingReplaceLanding < RemainingOverhaulLanding, RemainingReplaceLanding, RemainingOverhaulLanding) AS FilterLandings,
		CONVERT(DECIMAL(10, 1),
		IIF(RemainingReplaceCycle < RemainingOverhaulCycles, RemainingReplaceCycle, RemainingOverhaulCycles)) AS FilterCycles

		FROM (
			SELECT distinct Kit_Alloc.ID_ AS AllocationId, Kit_Alloc.VERSION_ AS Version,
			NULL AS InspectionAssignmentId, NULL As D161AssignmentId, a.ID_ As D16AssignmentId,
			m.CMD_ID_ AS CommandId, cmd.CODE_ AS Command, m.PLTF_ID AS PlatformId, ADM_MST_PLATFORMS.CODE_ AS Platform, '2408-16' AS MroType, ADM_MST_TAILS.T_NUM_ AS TailNo, 
			NULL AS InspId, m.MASTER_NO_ AS InspNo, m.ID_ AS D16MasterId, NULL AS D161MasterId, 
			(d161i.PART_NO_+', '+ d161m.CAGE_CODE_ + ', ' + d161w.CODE_ + ', ' + d161i.NOMENCLATURE_) AS InspDesc,
			Kit_Alloc.REG_NO_ AS KitListRegNo, Kit_Alloc.KITLIST_VERSION_ AS KitListVersion, Kit_Alloc.PUBLISHED_ON_ AS PublishedOn,
			CASE Kit_Alloc.STATUS_ WHEN 'PartiallyAllocated' THEN 'PARTIALLY ALLOCATED' ELSE UPPER(Kit_Alloc.STATUS_) END AS Status,

			F.ID_ AS FaultId, F.FAULT_STS_ AS FaultStatus,

			(c_r_due._hours - dbo.GetUnitEffectiveUsageHours(a.ACFT_UNIT_ID_)) AS RemainingReplaceAircraftHour,
			(CASE WHEN c_r_due._date IS NOT NULL THEN DATEDIFF(DAY, GETDATE(), c_r_due._date) END) AS RemainingReplaceCalendarDays,
			(CASE WHEN c_r_due._date IS NOT NULL THEN DATEDIFF(MONTH, GETDATE(), c_r_due._date) END) AS RemainingReplaceCalendarMonths,
			(CASE WHEN c_r_due._date IS NOT NULL THEN DATEDIFF(YEAR, GETDATE(), c_r_due._date) END) AS RemainingReplaceCalendarYears,
			(c_r_due._landings - uu.LANDINGS_) AS RemainingReplaceLanding,
		
			(CASE
				WHEN m.REP_CYCLES_ > 0 THEN (m.REP_CYCLES_ - (SELECT Cycles FROM dbo.D16_GetComponentUsage(c.ID_)) + isnull(uu.CYCLES_, 0)) - uu.CYCLES_
				ELSE NULL 
			END) AS RemainingReplaceCycle,

			CONVERT(DECIMAL(10, 1), c_o_due._hours - uu.TOT_FLIGHT_MINS_ / 60.0) AS RemainingOverhaulAircraftHour,
			(c_o_due._landings - uu.LANDINGS_) AS RemainingOverhaulLanding,
			DATEDIFF(DAY, GETDATE(), c_o_due._date) AS RemainingOverhaulCalendarDays,
			DATEDIFF(MONTH, GETDATE(), c_o_due._date) AS RemainingOverhaulCalendarMonths,
			DATEDIFF(YEAR, GETDATE(), c_o_due._date) AS RemainingOverhaulCalendarYears,
			(c_o_due._cycles - isnull(uu.CYCLES_, 0)) AS RemainingOverhaulCycles,

			a.ACFT_UNIT_ID_ AS D16TailUnitId, m.MAJOR_END_ITEM_ID_ AS D16MajorEndItemId,
			NULL AS D161EndUnitId, NULL AS D161ComponentUnitId, NULL AS D161MajorEndItemId

			FROM LOG_TRN_IKT_INSPECTION_KIT_ALLOCATION Kit_Alloc
			INNER JOIN ADM_MST_TAILS ON Kit_Alloc.ACRFT_ID_ = ADM_MST_TAILS.UNIT_ID
			INNER JOIN ADM_MST_UNITS ON ADM_MST_TAILS.UNIT_ID = ADM_MST_UNITS.ID_
			INNER JOIN ADM_MST_ITEMS ON ADM_MST_UNITS.ITEM_ID = ADM_MST_ITEMS.ID_
			INNER JOIN ADM_MST_PLATFORMS ON ADM_MST_ITEMS.ID_ = ADM_MST_PLATFORMS.ID_
			INNER JOIN MNT_MST_D16_MASTER_COMPONENT AS m ON Kit_Alloc.REF_NO_ = m.MASTER_NO_
			INNER JOIN ADM_MST_RESTRICTIONS AS cmd ON cmd.ID_ = m.CMD_ID_
			INNER JOIN MNT_TRN_D16_ASSIGNED_COMPONENT AS a ON a.MASTER_COMP_ID_ = m.ID_ AND a.ACFT_UNIT_ID_ = Kit_Alloc.ACRFT_ID_ AND a.ID_ = Kit_Alloc.D16_ASSIGNMENT_ID
			INNER JOIN MNT_MST_D16_COMPONENT c ON c.ID_ = a.COMP_ID_
			INNER JOIN ADM_MST_ITEMS AS d161i ON d161i.ID_ = m.COMP_ITEM_ID_
			LEFT JOIN ADM_MST_MANUFACTURES AS d161m on d161m.ID_ = d161i.MNF_ID
			LEFT JOIN MNT_MST_D16_WORK_UNIT_CODE AS d161w ON d161w.ID_ = m.WUC_ID_
			LEFT JOIN MNT_TRN_D16_FAULT_ASSIGNED AS gf on gf.ASSIGNED_COMP_ID_ = a.ID_
			LEFT OUTER JOIN MNT_TRN_FAULT_UNITS AS f ON f.ID_ = gf.FAULT_ID_ AND f.FAULT_STS_ = 'Open' AND f.PRNT_FAULT_UNIT_ID IS NULL
			LEFT JOIN ADM_TRN_UNIT_USAGE uu ON uu.UNIT_ID_ = a.ACFT_UNIT_ID_
			CROSS APPLY dbo.D16_GetReplaceDue(c.ID_) as c_r_due
			CROSS APPLY dbo.D16_GetOverhaulDue(c.ID_)as c_o_due	
			WHERE m.PART_TYPE_ != 'CC'
		) AS SRC WHERE 1 = 1
	) AS SRC1 WHERE 1 = 1
) AS SRC2 WHERE 1 = 1
go

