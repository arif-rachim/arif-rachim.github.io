CREATE function [dbo].[GetStockAsOf]
(
	@itemId bigint,
	@dateAsOf datetime2,
	@inLieu bit,
	@commandId bigint
)

RETURNS int
AS
BEGIN
	DECLARE @localDate datetime2
	DECLARE @item bigint
	DECLARE @inLieuYN bit
	DECLARE @command bigint
	DECLARE @result bigint

	set @localDate = DATEADD(SECOND, DATEDIFF(SECOND, GETDATE(), GETUTCDATE()), @dateAsOf)  
	set @item = @itemId
	set @inLieuYN = @inLieu
	set @command = @commandId
	set @result = 0

	IF(@inLieuYN = 1)
		BEGIN
		  SELECT @result = SUM(QTY_) from ADM_TRN_ITEM_ASSOCS IA
			JOIN ADM_TRN_ITEM_ASSOCS IA2 ON IA2.IN_LIEU_CODE_ = IA.IN_LIEU_CODE_
--			JOIN ADM_MST_ITEMS items ON items.ID_ = IA2.ITEM_ID
--			JOIN ADM_MST_MANUFACTURES M ON M.ID_ = items.MNF_ID
--			JOIN LOG_MST_UNIT_OF_MEASURE UOM ON UOM.ID_ = items.UOM_ID_
			join ADM_MST_UNITS FOR SYSTEM_TIME AS OF @localDate units on IA2.ITEM_ID = units.item_id
			join ADM_TRN_IMV_ITEMS_IN_LOCATION FOR SYSTEM_TIME AS OF @localDate imv on units.ID_ = imv.UNIT_ID_
			join ADM_MST_BUSINESS_UNITS bu on imv.BU_ID_ = bu.id_
--			join ADM_MST_UNIT_LOCATION_GROUP lg on imv.LG_ID_ = lg.ID_
			join ADM_MST_UNIT_LOCATION loc on imv.LOC_ID_ = loc.ID_
			--join ADM_MST_TAG_COLOR_CONDITION tag on imv.TC_ID_ = tag.ID_
			WHERE bu.BU_TYPE_ = 'Store' and (loc.LOC_TYPE_='Regular' OR loc.LOC_TYPE_='Receiving')
--			AND items.ITEM_GROUP_ = 'Item' AND items.GRP_TYPE_ = 'NonAircraft' 
			AND imv.TC_ID_ = 1 AND (units.EXP_DATE_ is null or units.EXP_DATE_ >= @localDate) 
			and IA.ITEM_ID = @item AND bu.CMD_ID_ = @command
		END
	ELSE
		BEGIN
		  SELECT @result = SUM(QTY_) from --adm_mst_items items
			ADM_MST_UNITS FOR SYSTEM_TIME AS OF @localDate units 
			join ADM_TRN_IMV_ITEMS_IN_LOCATION FOR SYSTEM_TIME AS OF @localDate imv on units.ID_ = imv.UNIT_ID_
			join ADM_MST_BUSINESS_UNITS bu on imv.BU_ID_ = bu.id_
--			join ADM_MST_UNIT_LOCATION_GROUP lg on imv.LG_ID_ = lg.ID_
			join ADM_MST_UNIT_LOCATION loc on imv.LOC_ID_ = loc.ID_
			--join ADM_MST_TAG_COLOR_CONDITION tag on imv.TC_ID_ = tag.ID_
			WHERE bu.BU_TYPE_ = 'Store' and (loc.LOC_TYPE_='Regular' OR loc.LOC_TYPE_='Receiving')
			--AND items.ITEM_GROUP_ = 'Item' AND items.GRP_TYPE_ = 'NonAircraft' 
			AND imv.TC_ID_ = 1 AND (units.EXP_DATE_ is null or units.EXP_DATE_ >= @localDate) 
			and units.item_id = @item AND bu.CMD_ID_ = @command
		END
	RETURN @result
END
go

