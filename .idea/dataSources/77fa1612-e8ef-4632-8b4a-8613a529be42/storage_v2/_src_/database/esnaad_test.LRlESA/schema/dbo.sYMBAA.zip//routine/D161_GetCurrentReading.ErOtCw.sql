CREATE FUNCTION [dbo].[D161_GetCurrentReading](@assignmentId bigint) 
RETURNS @currentReading TABLE (ASSIGNMENT_ID_ bigint, CUR_OP_HRS_ int, CUR_LCF1_ int, CUR_LCF2_ int, CUR_TTI_ int) 
AS
BEGIN
	DECLARE @compType nvarchar(10)
	DECLARE @opHrs int
	DECLARE @level int
	DECLARE @hCode nvarchar(900)
	--DECLARE @curEngineHrs int
	DECLARE @i int
	DECLARE @curOpHrs int
	DECLARE @curLcf1 int
	DECLARE @curLcf2 int
	DECLARE @curTti int
	DECLARE @compUnitId bigint
	--DECLARE @hrOpHrs int

	--SET @curEngineHrs = 0

	SELECT @level = M.LEVEL_, @compUnitId = COMP_UNIT_ID
	--, @hrOpHrs = CASE WHEN CR_OP_HRS_ IS NULL THEN (CUR_OP_HRS_) ELSE CR_OP_HRS_ - CI_OP_HRS_ END 
		,@compType = COMP_TYPE_
		, @curOpHrs = CASE WHEN CR_OP_HRS_ IS NULL THEN (CUR_OP_HRS_) ELSE CI_OP_HRS_ END
		, @curLcf1 = CASE WHEN CR_LCF1_ IS NULL THEN (CUR_LCF1_) ELSE CI_LCF1_ END
		, @curLcf2 = CASE WHEN CR_LCF2_ IS NULL THEN (CUR_LCF2_) ELSE CI_LCF2_ END
		, @curTti = CASE WHEN CR_TTI_ IS NULL THEN (CUR_TTI_) ELSE CI_TTI_ END	FROM MNT_TRN_D16_1_ASSIGNMENT A 
	JOIN MNT_TRN_D16_1_MASTER M ON M.ID_ = A.MASTER_ID
	WHERE A.ID_ = @assignmentId

	IF (@level = 0) 
	BEGIN
		SELECT @curOpHrs = CASE WHEN CR_OP_HRS_ IS NULL THEN (PC_OP_HRS_ + CUR_OP_HRS_ - CI_OP_HRS_) ELSE PC_OP_HRS_ + CR_OP_HRS_ - CI_OP_HRS_ END
		, @curLcf1 = CASE WHEN CR_LCF1_ IS NULL THEN (PC_LCF1_ + CUR_LCF1_ - CI_LCF1_) ELSE PC_LCF1_ + CR_LCF1_ - CI_LCF1_ END
		, @curLcf2 = CASE WHEN CR_LCF2_ IS NULL THEN (PC_LCF2_ + CUR_LCF2_ - CI_LCF2_) ELSE PC_LCF2_ + CR_LCF2_ - CI_LCF2_ END
		, @curTti = CASE WHEN CR_TTI_ IS NULL THEN (PC_TTI_ + CUR_TTI_ - CI_TTI_) ELSE PC_TTI_ + CR_TTI_ - CI_TTI_ END
		FROM MNT_TRN_D16_1_ASSIGNMENT 
		WHERE COMP_TYPE_='HR' AND IS_LATEST_ = 1 AND END_UNIT_ID = @compUnitId
		
		INSERT @currentReading SELECT @assignmentId, @curOpHrs, @curLcf1, @curLcf2, @curTti
		RETURN;
	END

	IF (@level = 1 AND @compType = 'HR') --RETURN @hrOpHrs
	BEGIN
		INSERT @currentReading SELECT @assignmentId, @curOpHrs, @curLcf1, @curLcf2, @curTti
		RETURN;
	END


	-- Looking for Level 1 NHR
	SET @hCode = dbo.D161_GetParentHCodeByLevel(@assignmentId, 1) 
	IF (@hCode IS NULL) 
	BEGIN
		INSERT @currentReading SELECT @assignmentId, NULL, NULL, NULL, NULL
		RETURN;
	END
	

	--SELECT @curEngineHrs = CASE WHEN CR_OP_HRS_ IS NULL THEN (PC_OP_HRS_ + CUR_OP_HRS_ - CI_OP_HRS_) ELSE PC_OP_HRS_ + CR_OP_HRS_ - CI_OP_HRS_ END
	SELECT @curOpHrs = CASE WHEN CR_OP_HRS_ IS NULL THEN (PC_OP_HRS_ + CUR_OP_HRS_ - CI_OP_HRS_) ELSE PC_OP_HRS_ + CR_OP_HRS_ - CI_OP_HRS_ END
	, @curLcf1 = CASE WHEN CR_LCF1_ IS NULL THEN (PC_LCF1_ + CUR_LCF1_ - CI_LCF1_) ELSE PC_LCF1_ + CR_LCF1_ - CI_LCF1_ END
	, @curLcf2 = CASE WHEN CR_LCF2_ IS NULL THEN (PC_LCF2_ + CUR_LCF2_ - CI_LCF2_) ELSE PC_LCF2_ + CR_LCF2_ - CI_LCF2_ END
	, @curTti = CASE WHEN CR_TTI_ IS NULL THEN (PC_TTI_ + CUR_TTI_ - CI_TTI_) ELSE PC_TTI_ + CR_TTI_ - CI_TTI_ END
	FROM MNT_TRN_D16_1_ASSIGNMENT 
	WHERE COMP_TYPE_='HR' AND IS_LATEST_ = 1 AND END_UNIT_ID = (SELECT N.END_UNIT_ID FROM MNT_TRN_D16_1_ASSIGNMENT N WHERE N.H_CODE_ = @hCode AND N.IS_LATEST_ = 1 AND COMP_TYPE_ = 'NHR')


	IF(@level = 0) --RETURN @curEngineHrs
	BEGIN
		INSERT @currentReading SELECT @assignmentId, @curOpHrs, @curLcf1, @curLcf2, @curTti
		RETURN;
	END

	SET @i = 1
	--SET @curOpHrs = @curEngineHrs
	WHILE(@i <= @level)
	BEGIN
		SET @hCode = dbo.D161_GetParentHCodeByLevel(@assignmentId, @i)
		--SELECT @curOpHrs = CI_OP_HRS_ - PI_OP_HRS_ + @curOpHrs FROM MNT_TRN_D16_1_ASSIGNMENT WHERE H_CODE_ = @hCode AND IS_LATEST_ = 1
		SELECT @curOpHrs = CI_OP_HRS_ - PI_OP_HRS_ + @curOpHrs 
		, @curLcf1 = CI_LCF1_ - PI_LCF1_ + @curLcf1
		, @curLcf2 = CI_LCF2_ - PI_LCF2_ + @curLcf2
		, @curTti = CI_TTI_ - PI_TTI_ + @curTti
		FROM MNT_TRN_D16_1_ASSIGNMENT WHERE H_CODE_ = @hCode AND IS_LATEST_ = 1
		SET @i = @i + 1 
	END

	INSERT @currentReading SELECT @assignmentId, @curOpHrs, @curLcf1, @curLcf2, @curTti
	--RETURN @curOpHrs
	RETURN
END
--select dbo.D161_GetParentHCodeByLevel(126,4)
go

