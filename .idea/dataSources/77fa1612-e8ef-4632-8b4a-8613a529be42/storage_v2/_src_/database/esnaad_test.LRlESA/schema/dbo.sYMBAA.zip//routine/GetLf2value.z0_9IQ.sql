CREATE FUNCTION [dbo].[GetLf2value]
(
          -- Add the parameters for the function here
          @engineId bigint
          
)
RETURNS decimal(18,2)
AS
BEGIN         
          
DECLARE @LF2VALUE decimal(18,2)  

SELECT @LF2VALUE=TempLCF.LCF2 FROM (
  SELECT   top 1  VAL_ as LCF2
    FROM         MNT_TRN_CS_ENGINE_COMPONENT_STAT AS ECS 
    WHERE     (ENGINE_ID_ = @engineId) AND (TYPE_ = 'Lcf2')
order by READING_DATE_ desc ) AS TempLCF

RETURN @LF2VALUE


END
go

