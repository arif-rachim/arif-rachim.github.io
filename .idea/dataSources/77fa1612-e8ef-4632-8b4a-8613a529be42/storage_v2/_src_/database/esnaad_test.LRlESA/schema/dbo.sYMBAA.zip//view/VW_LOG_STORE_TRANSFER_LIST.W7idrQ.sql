CREATE VIEW [dbo].[VW_LOG_STORE_TRANSFER_LIST]
AS
SELECT     ST.ID_ AS Id, ST.RI_BU_ID_ AS RequestingBuId, ST.FI_BU_ID_ AS FulfillingBuId, ST.TR_NO_ AS ReferenceNumber, ST.TR_DATE_ AS TransferDate, 
                      ST.ST_TYPE_ AS Type, BU.NAME_ AS FulfillingBu, ST.PID_CREATED_BY_ AS Requester, WF.REMARKS_ AS Remarks, dbo.GetStoreTransferAvailability(ST.ID_, 
                      ST.FI_BU_ID_) AS AvailabilityStatus, WF.WF_STATE_ AS Status, WF.WF_AVAIL_TRSN_ AS AvailableTransition, ST.PID_CREATED_BY_ AS CreatedPid, 
                      ST.FULL_NAME_CREATED_BY_ AS CreatedUserName, ST.CREATED_ON_ AS CreatedOn, ST.PID_MOD_BY_ AS ModifiedPid, 
                      ST.FULL_NAME_MOD_BY_ AS ModifiedName, ST.MOD_ON_ AS ModifiedOn
FROM         dbo.LOG_TRN_TRM_TRANSFER_REQUEST AS ST INNER JOIN
                      dbo.ADM_MST_BUSINESS_UNITS AS BU ON ST.FI_BU_ID_ = BU.ID_ INNER JOIN
                      dbo.WF_TRN_INSTANCE AS WF ON ST.WF_ID = WF.ID_
WHERE     (ST.TR_TYPE_ = 'StoreTransfer')
go

