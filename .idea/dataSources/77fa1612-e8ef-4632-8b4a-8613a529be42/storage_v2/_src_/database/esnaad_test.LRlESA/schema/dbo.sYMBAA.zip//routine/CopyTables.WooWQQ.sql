CREATE PROCEDURE [dbo].[CopyTables]
	-- Add the parameters for the stored procedure here
	@tableNames nvarchar(4000)
AS
BEGIN
	DECLARE @copyTable AS VARCHAR(1000);
	DECLARE @from AS VARCHAR(100);
	DECLARE @to AS VARCHAR(100);
	DECLARE @separator AS VARCHAR(5) = ',';
	DECLARE @copyToSeparator AS VARCHAR(1) = '=';
	DECLARE @copySeparatorPosition AS INT;
	DECLARE @separatorPosition AS INT;

	SET @tableNames = @tableNames + @separator;

	SET @separator = '%' + @separator + '%';
	SET @separatorPosition = PATINDEX(@separator, @tableNames);

	DECLARE @colList AS NVARCHAR(1000);

	WHILE @separatorPosition <> 0
	BEGIN
		SET @copyTable = LEFT(@tableNames, @separatorPosition - 1);

		SET @copySeparatorPosition = CHARINDEX(@copyToSeparator, @copyTable);

		SET @to = LEFT(@copyTable, @copySeparatorPosition - 1);
		SET @from = RIGHT(@copyTable, LEN(@copyTable)-@copySeparatorPosition);
		
		-- get column list		

		SELECT @colList = COALESCE(@colList + ',', '') + name from sys.columns where object_id=object_id(@from)  
		
		SET @copyTable = 'INSERT INTO ' + @to + '('+@colList+') select '+@colList+' from ' + @from;
		SET @copyTable = 'SET IDENTITY_INSERT ' + @to + ' ON ' + @copyTable
		-- execute
		EXEC(@copyTable);
		
		SET @tableNames = STUFF(@tableNames, 1, @separatorPosition, '')
		SET @separatorPosition = PATINDEX(@separator, @tableNames);
		
		SET @colList = NULL;
		EXEC('SET IDENTITY_INSERT ' + @to + ' OFF')
		

	END;
END
go

