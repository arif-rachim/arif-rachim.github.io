CREATE FUNCTION [dbo].[ItemCatalog_GetPriceTrendData]
(
	 @cmdId bigint, @itemId bigint, @start date, @end date
)
RETURNS TABLE
AS
RETURN
(
	WITH dates AS (
	select @start as DateOn
	union all
	select dateadd(d, 1, DateOn) as date
	from dates
	where dateon < getdate()
	), 
	PO AS (
        SELECT CAST(PO.PO_DATE_ AS DATE) AS PO_DATE_, PO.PRIORITY_ AS PRIORITY_, CAST(AVG(POI.UNIT_PRICE_VAL_ / PO.RATE_) AS DECIMAL(18, 2)) AS UNIT_PRICE
        FROM LOG_TRN_PRC_PURCHASE_ORDER_ITEM POI
                 JOIN LOG_TRN_PRC_PURCHASE_ORDER PO ON PO.ID_ = POI.PO_ID
                 JOIN VW_LOG_TRN_PO_QTY POQTY ON POQTY.PO_ITM_ID_ = POI.ID_
                 JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = PO.STORE_ID
        WHERE PO.PO_DATE_ >= @start
          and PO.STATUS_ in ('Closed', 'PartiallyDelivered', 'Validated')
          AND BU.CMD_ID_ = @cmdId
          AND ISNULL(POQTY.INLIEU_ITEM_ID, POQTY.ITEM_ID) = @itemId
        GROUP BY PO.PO_DATE_, PO.PRIORITY_
	)
	SELECT d.DateOn AS DateOn
	, aog.UNIT_PRICE  AS AogPrice, ior.UNIT_PRICE as IorPrice, nor.UNIT_PRICE as NorPrice
	--, isnull(aog.UNIT_PRICE, (select top(1) UNIT_PRICE from po where po.PO_DATE_ < DateOn and po.PRIORITY_ = 'AOG' order by po.PO_DATE_ desc)) AS AogPrice
	--, isnull(ior.UNIT_PRICE, (select top(1) UNIT_PRICE from po where po.PO_DATE_ < DateOn and po.PRIORITY_ = 'IOR' order by po.PO_DATE_ desc)) AS IorPrice
	--, isnull(nor.UNIT_PRICE, (select top(1) UNIT_PRICE from po where po.PO_DATE_ < DateOn and po.PRIORITY_ = 'NOR' order by po.PO_DATE_ desc)) AS NorPrice
	from dates d 
	left join po aog on aog.PO_DATE_ = CAST(d.DateOn AS DATE) and aog.PRIORITY_ = 'AOG'
	left join po ior on ior.PO_DATE_ = CAST(d.DateOn AS DATE) and ior.PRIORITY_ = 'IOR'
	left join po nor on nor.PO_DATE_ = CAST(d.DateOn AS DATE) and nor.PRIORITY_ = 'NOR'
)
go

