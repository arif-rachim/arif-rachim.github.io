CREATE VIEW [dbo].[VW_MNT_AFM_MONTHLY_RETURN_SUMMARY] AS
select * from 
(
	select 0 as status_id, 'Total' as code_, 100 as order_, sum(dbo.[ReturnTAAMSTime](d.DUR_MINS_)) hours_, 'Hours' as Type_,
	datepart(day, d.BEGIN_ON_) day_,
	datepart(month, d.BEGIN_ON_) month_,
	left(datename(month, d.BEGIN_ON_),3) month_text_,
	year(d.BEGIN_ON_) year_,
	--r.ARCFT_ID_ as tail_id
	t.id_ as tail_id
	
	FROM 
	mnt_trn_mfm_afm_monthly_record_detail d INNER JOIN 
	mnt_trn_mfm_afm_monthly_record r ON r.ID_ = d.AFM_MONTHLY_ID inner join
	adm_mst_units u  ON u.ID_ = r.ARCFT_ID_ inner join
	adm_mst_tails t ON t.UNIT_ID = u.ID_ 
	group by datepart(day, d.BEGIN_ON_), datepart(month, d.BEGIN_ON_) , left(datename(month, d.BEGIN_ON_),3), year(d.BEGIN_ON_), t.id_

) as src
PIVOT
(
	sum(hours_)
	for day_ in ([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15], [16], [17], [18], [19], [20], [21], [22], [23], [24], [25], [26], [27], [28], [29], [30], [31])
) as pivots 

go

