-- =============================================
-- Author:		Subhash
-- Create date: 14-May-2013
-- Description:	convert comma seperated value string 
-- =============================================
CREATE FUNCTION [dbo].[CSVToTable] (@InStr VARCHAR(MAX))
RETURNS @TempTab TABLE
   (id int not null)
AS
BEGIN
    ;-- Ensure input ends with comma
	SET @InStr = REPLACE(@InStr + ',', ',,', ',')
	
	DECLARE @SP INT
	DECLARE @VALUE VARCHAR(1000)
	
	WHILE PATINDEX('%,%', @INSTR ) <> 0 
	BEGIN
	   SELECT  @SP = PATINDEX('%,%',@INSTR)
	   SELECT  @VALUE = LEFT(@INSTR , @SP - 1)
	   SELECT  @INSTR = STUFF(@INSTR, 1, @SP, '')
	   INSERT INTO @TempTab(id) VALUES (@VALUE)
	END
	
	RETURN
END
go

