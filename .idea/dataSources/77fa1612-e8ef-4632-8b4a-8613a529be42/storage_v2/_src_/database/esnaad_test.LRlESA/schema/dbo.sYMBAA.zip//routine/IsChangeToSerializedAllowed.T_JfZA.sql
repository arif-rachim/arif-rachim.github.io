CREATE FUNCTION [dbo].[IsChangeToSerializedAllowed](@itemId bigint)
    RETURNS bit
    AS
    BEGIN
        DECLARE @result bit;

        with cte (UnitId, SerialNo, TotalQty)
                 AS (
                select imv_u.ID_ as unitId, imv_u.SERIAL_NO_ as SerialNo, sum(imv.QTY_) as totalQty
                from ADM_TRN_IMV_ITEMS_IN_LOCATION imv
                         join ADM_MST_UNITS imv_u on imv_u.ID_ = imv.UNIT_ID_
                         join ADM_MST_ITEMS imv_i on imv_i.ID_ = imv_u.ITEM_ID
                where imv_i.ID_ = @itemId
                group by imv_u.ID_, imv_u.SERIAL_NO_
            )
        select @result =
            case
                when count(unitId) = isnull(sum(totalQty), 0)
                    and (select count(SerialNo) from cte where SerialNo = '') = 0
                    then cast(1 as bit)
                else cast(0 as bit) end

        from cte

        RETURN @result
    END
go

