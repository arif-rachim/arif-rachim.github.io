CREATE FUNCTION [dbo].[GetCalculteRemaining]
(
      -- Add the parameters for the function here
      @DueHour          real=null,
      @DueDate          datetime=null,
      @AcftHour       int=null
)
RETURNS int
AS
BEGIN
      -- Declare the return variable here
      DECLARE @result int
   
   
           declare @currentDate  DateTime
           declare @noOfDays  Int
           declare @remainingHour  Int
           set @currentDate=convert(date,getdate())

          -- if date and hour exist then take first expiry   
          if( Not @DueDate is null and Not @DueHour is null)
           begin 
               if( not @AcftHour is null)
                set @remainingHour = @DueHour - @AcftHour / 60
               else
                 set @remainingHour = @DueHour
                 
               set @remainingHour = convert(int,ROUND(@remainingHour, 1))
               
               set @noOfDays = datediff(d,@currentDate,@DueDate)
               
              if(@remainingHour>datediff(hour,@currentDate,@DueDate))
                  set @result=@noOfDays;
              else
                  set @result=@remainingHour;
              
            
           end
          else if(@DueHour>0 and @DueDate is null)
            Begin
            
             if( not @AcftHour is null)
                set @remainingHour = @DueHour - @AcftHour / 60
             else
                set @remainingHour = @DueHour
                 
            
              set @remainingHour = convert(int,ROUND(@remainingHour, 1))
              set @result=@remainingHour;
              
            end
          else if(@DueHour is null or @DueHour=0)
           begin     
             set @noOfDays = datediff(d,@currentDate,@DueDate)
             set @result=@noOfDays;
             
           end
           
          
            
    
      RETURN @result
END

go

