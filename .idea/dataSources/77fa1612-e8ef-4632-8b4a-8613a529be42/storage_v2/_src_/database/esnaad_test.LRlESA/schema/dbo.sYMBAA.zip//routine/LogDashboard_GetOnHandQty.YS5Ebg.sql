CREATE FUNCTION [dbo].[LogDashboard_GetOnHandQty]
    (
        @itemId bigint,
        @includeInLieu bit,
        @businesUnitId bigint
        )
    returns int
    as
    begin
        declare @result int

        if @includeInLieu = 0
            begin
                select @result = isnull(sum(s.QTY_), 0)
                from LOG_TRN_STOCK s
                         join ADM_MST_UNITS u on u.ID_ = s.UNIT_ID
                         join ADM_MST_ITEMS i on i.ID_ = u.ITEM_ID
                where i.ID_ = @itemId
                  and (@businesUnitId is null or s.STORE_ID = @businesUnitId)
            end
        else
            if @includeInLieu = 1
                begin
                    select @result = isnull(sum(s.QTY_), 0)
                    from LOG_TRN_STOCK s
                             join ADM_MST_UNITS u on u.ID_ = s.UNIT_ID
                             join ADM_MST_ITEMS i on i.ID_ = u.ITEM_ID
                    where i.ID_ in (
                        select distinct(i.ID_)
                        from ADM_MST_ITEMS i
                                 join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = i.ID_ and ia.IN_LIEU_CODE_ in (
                            select ia.IN_LIEU_CODE_
                            from ADM_MST_ITEMS i
                                     join ADM_TRN_ITEM_ASSOCS ia on ia.ITEM_ID = i.ID_
                            where i.ID_ = @itemId
                        )
                    )
                      and (@businesUnitId is null or s.STORE_ID = @businesUnitId)
                end

        return @result
    end
go

