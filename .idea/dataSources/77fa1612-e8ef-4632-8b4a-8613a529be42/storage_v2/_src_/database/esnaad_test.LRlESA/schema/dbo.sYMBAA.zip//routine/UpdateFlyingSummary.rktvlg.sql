CREATE PROCEDURE [dbo].[UpdateFlyingSummary]
AS
BEGIN
	DECLARE @crewId varchar(30), @flewDate smalldatetime, @flyingMinutes int, @importTime datetime
	---
	DECLARE crew_flew_hours_cursor CURSOR FOR
		SELECT md.CREW_ID_ as crewId
				, convert(datetime, replace(md.MISSION_DATE_, '-', ' '), 106)  as flewDate
				, sum((left(md.TOTAL_HOURS_, case when len(md.TOTAL_HOURS_)=5 then 2 else 1 end)) * 60 + right(md.TOTAL_HOURS_, 2)) as flyingMinutes
				, convert(datetime, replace(md.TIMESTAMP_, '-', ' '), 113 ) as timestamp
		FROM BIZ_PLT_WGT_CREW_MISSION_DETAILS md
		GROUP BY md.CREW_ID_, md.MISSION_DATE_, md.TIMESTAMP_
	---

	OPEN crew_flew_hours_cursor;
	FETCH NEXT FROM crew_flew_hours_cursor
	INTO @crewId, @flewDate, @flyingMinutes, @importTime
	WHILE @@FETCH_STATUS = 0
	BEGIN
		--PRINT @crewId +'-'+ @flewDate +'-'+ cast(@flyingMinutes as varchar)
		DELETE FROM BIZ_CREW_DAILY_FLYING_HOURS_SUMMARY  WHERE CREW_ID_ = @crewId AND DATE_ = @flewDate
		INSERT INTO BIZ_CREW_DAILY_FLYING_HOURS_SUMMARY VALUES(@crewId, @flewDate, @flyingMinutes, @importTime, getdate())  
		
		FETCH NEXT FROM crew_flew_hours_cursor
		INTO @crewId, @flewDate, @flyingMinutes, @importTime
	END
	CLOSE crew_flew_hours_cursor
	DEALLOCATE crew_flew_hours_cursor
END
go

