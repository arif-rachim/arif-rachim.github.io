--Returns seat code from ADM_MST_PFC_SNAPSHOT_SEAT_CONFIG based on OPS_TRN_TAIL_CREW_FLIGHT_DETAILS.PLATFORM_SEAT_ID
--refered in SP GetTailFligtReport  (13-2 flight pack report)
CREATE FUNCTION ReturnPlatformSeat(@Id uniqueidentifier) RETURNS varchar(100)
BEGIN
	DECLARE @retValue varchar(100)
	SELECT 	@retValue = CODE_ FROM  ADM_MST_PFC_SNAPSHOT_SEAT_CONFIG WHERE ID_ = @Id
	RETURN @retValue
END
go

