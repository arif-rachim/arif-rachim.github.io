CREATE FUNCTION [dbo].[CheckIfRoleCommandExistsInPrimaryDomain]
(
	-- parameters for the function
	@roleId uniqueidentifier, @userProfileId  bigint, @commandId  bigint
)
RETURNS BIT
AS
BEGIN
	DECLARE @primaryDomainCount INT
	DECLARE @checkHasCommandCount INT

	-- return variable	
	DECLARE @roleCommandExists BIT

		--Master Role has Primary Domain. But Primary Domain not included in the role
		SELECT @primaryDomainCount = (SELECT COUNT(*) FROM ADM_TRN_SEC_ROLE AS MROL 
		INNER JOIN ADM_TRN_SEC_ROLE AS ROL ON ROL.MASTER_ID_ = MROL.ID_ 
		INNER JOIN ADM_TRN_SEC_ROLE_ACL AS RACL ON RACL.ROLE_ID = ROL.ID_ 
		INNER JOIN ADM_MST_SECURED_RESOURCES AS MDL ON MDL.ID_ = RACL.MDL_ID 
		WHERE MROL.IS_MASTER_ = 1 AND MROL.PRIMARY_DOMAIN_ID_ IS NOT NULL 
		AND MROL.PRIMARY_DOMAIN_ID_ = MDL.PRNT_ID  
		AND ROL.ID_ = @roleId)

		--Check if Primary Domain Command included in Role Admin or User Admin Command
		SELECT @checkHasCommandCount = (SELECT COUNT(*) 
		FROM ADM_TRN_SEC_USER_ADMIN AS ADM
		INNER JOIN ADM_TRN_SEC_ACCESS_LEVEL AS LVL ON ADM.ACCESS_LEVEL_ID = LVL.ID_
		WHERE ADM.USER_PROFILE_ID = @userProfileId AND CMD_ID = @commandId AND LVL.DOMAIN_ID IN (
			SELECT MROL.PRIMARY_DOMAIN_ID_ FROM ADM_TRN_SEC_ROLE AS MROL 
			INNER JOIN ADM_TRN_SEC_ROLE AS ROL ON ROL.MASTER_ID_ = MROL.ID_ 
			WHERE MROL.IS_MASTER_ = 1 AND MROL.PRIMARY_DOMAIN_ID_ IS NOT NULL 
			AND ROL.ID_ = @roleId)
		)

		IF(@primaryDomainCount = 0 AND @checkHasCommandCount > 0)
		BEGIN
			SET @roleCommandExists = 1
			RETURN @roleCommandExists;
		END		

		IF(@primaryDomainCount = 0 AND @checkHasCommandCount <= 0)
		BEGIN
			SET @roleCommandExists = 0
			RETURN @roleCommandExists;
		END

	SELECT @roleCommandExists = CASE WHEN X.CommandCount > 0 THEN 1 ELSE 0 END FROM
	(		
		SELECT COUNT(*) AS CommandCount 
		FROM ADM_TRN_SEC_USER_ADMIN AS ADM
		INNER JOIN ADM_TRN_SEC_ACCESS_LEVEL AS LVL ON ADM.ACCESS_LEVEL_ID = LVL.ID_
		WHERE ADM.USER_PROFILE_ID = @userProfileId 
		AND LVL.DOMAIN_ID IN (SELECT MROL.PRIMARY_DOMAIN_ID_ FROM ADM_TRN_SEC_ROLE AS MROL 
		INNER JOIN ADM_TRN_SEC_ROLE AS ROL ON ROL.MASTER_ID_ = MROL.ID_ 
		INNER JOIN ADM_TRN_SEC_ROLE_ACL AS RACL ON RACL.ROLE_ID = ROL.ID_ 
		INNER JOIN ADM_MST_SECURED_RESOURCES AS MDL ON MDL.ID_ = RACL.MDL_ID 
		WHERE MROL.IS_MASTER_ = 1 AND MROL.PRIMARY_DOMAIN_ID_ IS NOT NULL 
		AND MROL.PRIMARY_DOMAIN_ID_ = MDL.PRNT_ID  
		AND ROL.ID_ = @roleId) AND LVL.CMD_ID = @commandId 
	) AS X	

	-- Return the result of the function
	RETURN @roleCommandExists

END
go

