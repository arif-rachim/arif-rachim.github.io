CREATE FUNCTION ReturnMissionSymbol(@missionSubTypeId int) RETURNS varchar(100)
BEGIN
	DECLARE @retValue varchar(100)
	SELECT @retValue = SYMBOL_ FROM  OPS_MST_MISSION_SUB_TYPES WHERE ID_ = @missionSubTypeId
	RETURN @retValue
END
go

