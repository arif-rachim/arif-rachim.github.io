CREATE view [dbo].[VW_OPS_MED_CCY_BLOCKING_STATUS]
as 
select distinct fc.ID_  as CrewId
	, cms.CurrencyId
	, cms.IsExempted 
	, cms.LastPerformedDate
	, cms.DaysRemaining
	, cms.IsAnnualBirthMonth
	, cms.WarningStartsOn
	, cms.IsWithinAlertWindow		
	--, case 
	--	when cms.CurrencyId <= 0 then 3
	--	when cms.DaysRemaining < 0 or cms.LastPerformedDate = 0 then 0
	--	when cms.DaysRemaining >= 0 
	--		and (
	--			cms.IsWithinAlertWindow = 1
	--			or (
	--				cms.IsAnnualBirthMonth = 1 
	--				and cms.WarningStartsOn is not null
	--				and getdate() >= cms.WarningStartsOn
	--			)
	--		)
	--		then 1
	--	when cms.DaysRemaining >= 0 then 2
	--	else 0
	--end as MedicalCurrencyStatus
	, case 
		when cms.IsExempted = 1 then 3 --GRAY
		when UPPER(cms.Type) = 'MEDICAL' and UPPER(cms.Category) = 'BLOCKING' and cms.NextDue IS NULL then 0 --RED
		when cms.LastPerformedDate is null then 3
		when cms.DaysRemaining < 0 then 0 
		when cms.IsWithinAlertWindow = 1 then 1 --YELLOW
		when cms.IsAnnualBirthMonth = 1 and (getdate() >= cms.WarningStartsOn) then 1
		else 2 --GREEN
	end as MedicalCurrencyStatus

from OPS_MST_FLIGHT_CREWS fc
left join
(
	select fc.ID_				as CrewId
		, cuIn.CurrencyId		as CurrencyId
		, cuIn.DaysRemaining	as DaysRemaining
		, dateadd(mm, datediff(mm, 0, dateadd(day, -89, ISNULL(cc.EXT_UNTIL_, cc.NEXT_DUE_ON_))), 0) 
								as WarningStartsOn
		, case 
			--when (datediff(day, getdate(), isnull(cc.EXT_UNTIL_, cc.NEXT_DUE_ON_)) < asg.NTF_PRD_) 
			when (datediff(day, getdate(), isnull(cc.EXT_UNTIL_, cc.NEXT_DUE_ON_)) < mst.NTF_PRD_) 
				then CAST(1 as bit) 
			else cast(0 as bit) 
		  end					as IsWithinAlertWindow
		, cc.IS_BIRTH_PERIOD_	as IsAnnualBirthMonth
		, cc.IS_EXEMPTED_		as IsExempted
		, cc.LAST_PERFORMED_ON_ as LastPerformedDate
		, mst.CURRENCY_TYPE_	as Type
		, cc.CAT_				as Category
		, cc.NEXT_DUE_ON_		as NextDue
	from OPS_MST_FLIGHT_CREWS fc
	inner join OPS_TRN_CM_CREW_CURRENCY cc on fc.ID_ = cc.FLIGHT_CREW_ID_
	inner join OPS_MST_CURRENCY as mst on cc.CURRENCY_ID_ = mst.ID_ 
		and mst.CURRENCY_TYPE_='Medical' 
		and cc.CAT_ = 'Blocking'
	left join OPS_XRF_CURRENCY_COY coy ON coy.CURR_ID_ = mst.ID_ and coy.COY_ID_ = fc.COMPANY_ID
	left join OPS_XRF_CURRENCY_PQ pq ON pq.CURR_ID_ = mst.ID_ and pq.PQ_ID_ = fc.QUALF_ID
	left join OPS_XRF_OPS_MST_CURRENCY_ADM_MST_PLATFORMS p on p.CURR_ID = mst.ID_ and p.PLTF_ID_ = fc.PRI_PLTF_ID_
	--left join OPS_TRN_CM_CURRENCY_ASSIGNMENT asg on asg.CURR_ID_ = mst.ID_ 
	--	and asg.COY_ID_ = fc.COMPANY_ID 
	--	and asg.PLTF_ID_ = fc.PRI_PLTF_ID_ 
	--	and asg.PQ_ID_ = fc.QUALF_ID
	inner join (
		select fc1.ID_ as CrewId
			, min(datediff(day, getdate(), isnull(cc1.EXT_UNTIL_, cc1.NEXT_DUE_ON_))) as DaysRemaining
			, cc1.CURRENCY_ID_ as CurrencyId
			, row_number() over (
				partition by fc1.ID_ order by min(datediff(day, getdate(), isnull(cc1.EXT_UNTIL_, cc1.NEXT_DUE_ON_)))
			) as RowNo
		from OPS_MST_FLIGHT_CREWS fc1
		inner join OPS_TRN_CM_CREW_CURRENCY as cc1 on fc1.ID_ = cc1.FLIGHT_CREW_ID_
		inner join OPS_MST_CURRENCY as mst1 on cc1.CURRENCY_ID_ = mst1.ID_ 
			and mst1.CURRENCY_TYPE_='Medical' 
			and cc1.CAT_ = 'Blocking'
		join OPS_XRF_CURRENCY_COY coy ON coy.CURR_ID_ = mst1.ID_ and coy.COY_ID_ = fc1.COMPANY_ID
		join OPS_XRF_CURRENCY_PQ pq ON pq.CURR_ID_ = mst1.ID_ and pq.PQ_ID_ = fc1.QUALF_ID
		join OPS_XRF_OPS_MST_CURRENCY_ADM_MST_PLATFORMS p on p.CURR_ID = mst1.ID_ and p.PLTF_ID_ = fc1.PRI_PLTF_ID_
		--inner join OPS_TRN_CM_CURRENCY_ASSIGNMENT asg1 on asg1.CURR_ID_ = mst1.ID_ 
		--	and asg1.COY_ID_ = fc1.COMPANY_ID 
		--	and asg1.PLTF_ID_ = fc1.PRI_PLTF_ID_ 
		--	and fc1.QUALF_ID = asg1.PQ_ID_
		where cc1.IS_EXEMPTED_ = 0
			and cc1.IS_ACTIVE_ = 1
		group by fc1.ID_, cc1.CURRENCY_ID_
	) as cuIn on cuIn.CrewId = fc.ID_ and cuIn.RowNo=1 and cc.CURRENCY_ID_ = cuIn.CurrencyId	
) cms on cms.CrewId = fc.ID_
where fc.DELETED_ = 0

--select distinct fc.ID_  as CrewId
--	, cms.CurrencyId
--	, cms.IsExempted 
--	, cms.LastPerformedDate
--	, cms.DaysRemaining
--	, cms.IsAnnualBirthMonth
--	, cms.WarningStartsOn
--	, cms.IsWithinAlertWindow		
--	--, case 
--	--	when cms.CurrencyId <= 0 then 3
--	--	when cms.DaysRemaining < 0 or cms.LastPerformedDate = 0 then 0
--	--	when cms.DaysRemaining >= 0 
--	--		and (
--	--			cms.IsWithinAlertWindow = 1
--	--			or (
--	--				cms.IsAnnualBirthMonth = 1 
--	--				and cms.WarningStartsOn is not null
--	--				and getdate() >= cms.WarningStartsOn
--	--			)
--	--		)
--	--		then 1
--	--	when cms.DaysRemaining >= 0 then 2
--	--	else 0
--	--end as MedicalCurrencyStatus
--	, case 
--		when cms.IsExempted = 1 then 3 --GRAY
--		when UPPER(cms.Type) = 'MEDICAL' and UPPER(cms.Category) = 'BLOCKING' and cms.NextDue IS NULL then 0 --RED
--		when cms.LastPerformedDate is null then 3
--		when cms.DaysRemaining < 0 then 0 
--		when cms.IsWithinAlertWindow = 1 then 1 --YELLOW
--		when cms.IsAnnualBirthMonth = 1 and (getdate() >= cms.WarningStartsOn) then 1
--		else 2 --GREEN
--	end as MedicalCurrencyStatus

--from OPS_MST_FLIGHT_CREWS fc
--left join
--(
--	select fc.ID_				as CrewId
--		, cuIn.CurrencyId		as CurrencyId
--		, cuIn.DaysRemaining	as DaysRemaining
--		, dateadd(mm, datediff(mm, 0, dateadd(day, -89, ISNULL(cc.EXT_UNTIL_, cc.NEXT_DUE_ON_))), 0) 
--								as WarningStartsOn
--		, case 
--			when (datediff(day, getdate(), isnull(cc.EXT_UNTIL_, cc.NEXT_DUE_ON_)) < asg.NTF_PRD_) 
--				then CAST(1 as bit) 
--			else cast(0 as bit) 
--		  end					as IsWithinAlertWindow
--		, cc.IS_BIRTH_PERIOD_	as IsAnnualBirthMonth
--		, cc.IS_EXEMPTED_		as IsExempted
--		, cc.LAST_PERFORMED_ON_ as LastPerformedDate
--		, mst.CURRENCY_TYPE_	as Type
--		, cc.CAT_				as Category
--		, cc.NEXT_DUE_ON_		as NextDue
--	from OPS_MST_FLIGHT_CREWS fc
--	inner join OPS_TRN_CM_CREW_CURRENCY cc on fc.ID_ = cc.FLIGHT_CREW_ID_
--	inner join OPS_MST_CURRENCY as mst on cc.CURRENCY_ID_ = mst.ID_ 
--		and mst.CURRENCY_TYPE_='Medical' 
--		and cc.CAT_ = 'Blocking'
--	left join OPS_TRN_CM_CURRENCY_ASSIGNMENT asg on asg.CURR_ID_ = mst.ID_ 
--		and asg.COY_ID_ = fc.COMPANY_ID 
--		and asg.PLTF_ID_ = fc.PRI_PLTF_ID_ 
--		and asg.PQ_ID_ = fc.QUALF_ID
--	inner join (
--		select fc1.ID_ as CrewId
--			, min(datediff(day, getdate(), isnull(cc1.EXT_UNTIL_, cc1.NEXT_DUE_ON_))) as DaysRemaining
--			, cc1.CURRENCY_ID_ as CurrencyId
--			, row_number() over (
--				partition by fc1.ID_ order by min(datediff(day, getdate(), isnull(cc1.EXT_UNTIL_, cc1.NEXT_DUE_ON_)))
--			) as RowNo
--		from OPS_MST_FLIGHT_CREWS fc1
--		inner join OPS_TRN_CM_CREW_CURRENCY as cc1 on fc1.ID_ = cc1.FLIGHT_CREW_ID_
--		inner join OPS_MST_CURRENCY as mst1 on cc1.CURRENCY_ID_ = mst1.ID_ 
--			and mst1.CURRENCY_TYPE_='Medical' 
--			and cc1.CAT_ = 'Blocking'
--		inner join OPS_TRN_CM_CURRENCY_ASSIGNMENT asg1 on asg1.CURR_ID_ = mst1.ID_ 
--			and asg1.COY_ID_ = fc1.COMPANY_ID 
--			and asg1.PLTF_ID_ = fc1.PRI_PLTF_ID_ 
--			and fc1.QUALF_ID = asg1.PQ_ID_
--		where cc1.IS_EXEMPTED_ = 0
--			and cc1.IS_ACTIVE_ = 1
--		group by fc1.ID_, cc1.CURRENCY_ID_
--	) as cuIn on cuIn.CrewId = fc.ID_ and cuIn.RowNo=1 and cc.CURRENCY_ID_ = cuIn.CurrencyId	
--) cms on cms.CrewId = fc.ID_
--where fc.DELETED_ = 0
go

