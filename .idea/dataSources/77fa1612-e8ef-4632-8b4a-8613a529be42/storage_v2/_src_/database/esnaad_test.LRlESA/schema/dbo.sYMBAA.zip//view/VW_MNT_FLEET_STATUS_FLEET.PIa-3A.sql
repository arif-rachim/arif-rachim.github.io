CREATE VIEW [dbo].[VW_MNT_FLEET_STATUS_FLEET] AS
SELECT battalion.PRNT_ID AS CommandId
	,battalion.ID_ AS BattalionId
	,battalion.CODE_ as Battalion
	,Platforms.ID_ as PlatformId
    ,Platforms.code_ AS Platform
    ,tail.t_num_ as TailNumber
    ,Unit.ID_ as UnitId
    ,Tail.ID_ as TailId
    ,dbo.ReturnTAAMSTime(ISNULL(UnitUse.TOT_FLIGHT_MINS_,0)) as TotalFlightHrs
    ,isnull(UnitUse.LANDINGS_,0) as TotalLandings
    ,FlightView.SYSCode
    ,FlightView.StatusCode
    ,FlightView.StatusId
	,FLightView.StatusOrder
    ,FlightView.FCount
    ,isnull(count141.Tcount,0) as NumberOf141
    ,auditby.CREATED_BY_ as PidCreatedBy
    ,auditby.CREATED_ON_ as CreatedOn
    ,auditby.FULL_NAME_CREATED_BY_ as CreatedBy
    ,auditby.MOD_BY_ as PidModifiedBy
    ,auditby.MOD_ON_ as ModifiedOn
    ,auditby.FULL_NAME_MOD_BY_ as ModifiedBy 
FROM adm_mst_tails Tail 
JOIN ADM_MST_UNITS Unit on Unit.ID_ = Tail.UNIT_ID 
JOIN ADM_MST_PLATFORMS Platforms on Platforms.ID_ = Unit.ITEM_ID 
JOIN ADM_MST_RESTRICTIONS battalion on battalion.ID_ = Tail.BATLN_ID 
--JOIN ADM_MST_RESTRICTIONS company on company.PRNT_ID = Tail.BATLN_ID 
LEFT JOIN ADM_TRN_UNIT_USAGE UnitUse on UnitUse.UNIT_ID_ = Unit.ID_ 
LEFT JOIN VW_MNT_FLEET_STATUS_FLIGHT FLightView ON FlightView.Unit = Unit.id_ 
LEFT JOIN VW_MNT_FLEET_STATUS_COUNT141 count141 on count141.UnitId = unit.ID_ 
LEFT JOIN VW_MNT_FLEET_STATUS_FAULT_AUDIT auditby on auditby.UnitId = unit.ID_ and auditby.maxAcSts=1 
WHERE Tail.END_DATE_ = '9999-12-31'
go

