CREATE PROCEDURE [dbo].[SaveGHQFleetServiceabilityReport_TempData]
	@report_id uniqueidentifier,
	@user_profile_id bigint,
	@command_id bigint,
	@command_ nvarchar(255),
	@platform_id bigint,
	@platform_ nvarchar(255),
	@remarks_ nvarchar(255),
	@mto_ int,
	@platform_variantId bigint = 0
AS
BEGIN

	SET NOCOUNT ON;
	
	declare @platformvariantId bigint
	select @platformvariantId = ID_ from ADM_MST_PLATFORM_VARIANT where ID_ = @platform_variantId

    -- Insert statements for procedure here
	INSERT INTO [dbo].[TMP_RPT_MNT_GHQ_FLEET_SERVICEABILITY_REPORT_TEMPDATA]
           ( REPORT_ID_
           ,[COMMAND_ID_]
           ,[USER_PROFILE_ID_]
           ,[COMMAND_]
           ,[PLATFORM_ID_]
           ,[PLATFORM_]
           ,[REMARKS_]
           ,[MTO_]
		   ,[PLTF_VARIANT_ID])
     VALUES
           (@report_id
           ,@command_id
           ,@user_profile_id
           ,@command_
           ,@platform_id
           ,@platform_
           ,@remarks_
           ,@mto_
		   ,@platformvariantId)


END
go

