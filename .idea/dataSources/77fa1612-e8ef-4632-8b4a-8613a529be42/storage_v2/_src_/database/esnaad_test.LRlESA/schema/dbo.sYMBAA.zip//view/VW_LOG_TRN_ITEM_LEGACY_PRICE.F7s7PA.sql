CREATE VIEW [dbo].[VW_LOG_TRN_ITEM_LEGACY_PRICE]
AS
	select	legacy.CMD_ID_ as CMD_ID_,
			legacy.ITEM_ID_ as ITEM_ID_,
			legacy.ORDERED_QTY_ as QTY_,
			legacy.UOM_ as UOM_,
			'N/A' as CONDITION_,
			legacy.UNIT_PRICE_ as PRICE_,
			currency.CODE_ as CURRENCY_,
			legacy.REF_ as REF_,
			legacy.REF_TYPE_ as REF_TYPE_,
			'N/A' as PROC_TYPE_,
			legacy.PRIORITY_ as PRIORITY_,
			legacy.REF_DATE_ as REF_DATE_,
			legacy.VENDOR_ as VENDOR_
	from	AADMIS_LOG_TRN_ORDER_LINE_PRICE_DATA legacy
			join ADM_MST_MONEY_CURRENCY currency on legacy.CURRENCY_ID_ = currency.ID_
go

