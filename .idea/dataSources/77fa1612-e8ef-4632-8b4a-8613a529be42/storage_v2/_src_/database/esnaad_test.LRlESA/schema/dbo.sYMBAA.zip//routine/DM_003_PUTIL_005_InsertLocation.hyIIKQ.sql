
CREATE PROCEDURE DM_003_PUTIL_005_InsertLocation
	@insertedRecordID bigint OUTPUT,
	@VERSION_ bigint,
	@NAME_ nvarchar(255),
	@LOC_TYPE_ nvarchar(255),
	
	@LG_ID bigint,
	@IS_ACTIVE_ bit,
	@IS_LOCKED_ bit,
	@LOC_DISC_TYPE_ nvarchar(20),

	@CREATED_BY_ nvarchar(255),
	@PID_CREATED_BY_ nvarchar(255),
	@FULL_NAME_CREATED_BY_ nvarchar(255),
	@CREATED_ON_ datetime,

	@TERM_ nvarchar(255)
AS
BEGIN
	SET NOCOUNT ON;

	IF NOT EXISTS(SELECT NAME_ FROM ADM_MST_UNIT_LOCATION WHERE NAME_ = @NAME_ AND LG_ID = @LG_ID)
	BEGIN
		INSERT INTO ADM_MST_UNIT_LOCATION
		(
			 VERSION_
			,NAME_
			,LOC_TYPE_
			
			,LG_ID
			,IS_LOCKED_
			,IS_ACTIVE_
			,LOC_DISC_TYPE_

			,CREATED_BY_
			,PID_CREATED_BY_
			,FULL_NAME_CREATED_BY_
			,CREATED_ON_

			,TERM_
		)
		VALUES
		(
			 @VERSION_
			,@NAME_
			,@LOC_TYPE_
			
			,@LG_ID
			,@IS_LOCKED_
			,@IS_ACTIVE_
			,@LOC_DISC_TYPE_

			,@CREATED_BY_
			,@PID_CREATED_BY_
			,@FULL_NAME_CREATED_BY_
			,@CREATED_ON_

			,@TERM_
		)
		
		SET @insertedRecordID = SCOPE_IDENTITY();
	END
END
go

