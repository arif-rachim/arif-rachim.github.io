CREATE FUNCTION [dbo].[GetOpsCrewFlyingRecordStartDate]
(
	@dateVar datetime
)
RETURNS varchar(200)
AS
BEGIN	
	DECLARE @startDate varchar(200)
SELECT
 @startDate = 
	CASE
		WHEN MONTH(GETDATE()) <= MONTH(@dateVar)
			THEN 
				-- 2015-05-01
				CASE WHEN  MONTH(@dateVar) = 12 
					THEN
						CAST( CAST(YEAR(GETDATE())  AS VARCHAR(10)) + '-' + CAST('1' AS VARCHAR(10)) + '-01'  AS DATE)
					ELSE 	
						CAST( CAST(YEAR(GETDATE()) - 1 AS VARCHAR(10)) + '-' + CAST( MONTH(@dateVar) + 1 AS VARCHAR(10)) + '-01'  AS DATE)
				END 
				
			ELSE 
				-- 2016-05-01
				CAST( CAST(YEAR(GETDATE()) AS VARCHAR(10)) + '-' + CAST( MONTH(@dateVar) + 1 AS VARCHAR(10)) + '-01'  AS DATE)
		END 
 RETURN @startDate
END
go

