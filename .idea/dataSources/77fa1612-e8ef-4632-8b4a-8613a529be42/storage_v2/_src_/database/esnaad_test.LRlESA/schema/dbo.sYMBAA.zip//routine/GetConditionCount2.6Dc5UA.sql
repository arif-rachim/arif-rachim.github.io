CREATE FUNCTION [dbo].[GetConditionCount2]
(
      -- Add the parameters for the function here
	  @PlatformVar	varchar,
	  @CommandId       int,
      @PlatformId       int,
      @McCount      int,
      @input_date       datetime
)
RETURNS int
AS
BEGIN
      -- Declare the return variable here
      DECLARE @result int

   
      DECLARE @FMC int = 32
      DECLARE @PMCM int = 36
      DECLARE @PMCS int = 37
      DECLARE @DEPOT int = 33
      DECLARE @NMCM int = 34
      DECLARE @NMCS int = 35
      
      DECLARE @today_date date
      DECLARE @compare_date date

      SET @today_date = CONVERT(date, getdate())
	  SET @compare_date = CONVERT(date, @input_date)
    
      IF DATEDIFF(DAY, @compare_date, @today_date) = 0
      BEGIN
			IF @McCount > 0
			BEGIN
				IF @PlatformVar IS NULL
				BEGIN
					SELECT @result = COUNT(*) 
					FROM MNT_TRN_AIRCRAFT_SERVS S 
							INNER JOIN ADM_MST_UNITS U ON S.UNIT_ID = U.ID_
							INNER JOIN ADM_MST_TAILS T ON T.UNIT_ID = U.ID_ AND  T.END_DATE_>=@input_date
							INNER JOIN ADM_MST_RESTRICTIONS B ON B.ID_ = T.BATLN_ID
							INNER JOIN ADM_MST_RESTRICTIONS C ON C.ID_ = B.PRNT_ID
							INNER JOIN ADM_MST_ITEMS I ON U.ITEM_ID = I.ID_
							INNER JOIN ADM_MST_PLATFORMS P ON I.ID_ = P.ID_
							INNER JOIN ADM_MST_STATUS_CONDITIONS SC ON S.STSCND_ID = SC.ID_
							INNER JOIN ADM_MST_SIMPLE_REF SR ON SC.COND_ID = SR.ID_ 
							LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = T.UNIT_ID
							LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
					WHERE C.ID_ = @CommandId AND P.ID_ = @PlatformId AND (SR.ID_ = @FMC OR SR.ID_ = @PMCM OR SR.ID_ = @PMCS) AND T_VAR.ID_ IS NULL                                             

				END
				ELSE
				BEGIN
					SELECT @result = COUNT(*) 
					FROM MNT_TRN_AIRCRAFT_SERVS S 
							INNER JOIN ADM_MST_UNITS U ON S.UNIT_ID = U.ID_
							INNER JOIN ADM_MST_TAILS T ON T.UNIT_ID = U.ID_  AND  T.END_DATE_>=@input_date
							INNER JOIN ADM_MST_RESTRICTIONS B ON B.ID_ = T.BATLN_ID
							INNER JOIN ADM_MST_RESTRICTIONS C ON C.ID_ = B.PRNT_ID
							INNER JOIN ADM_MST_ITEMS I ON U.ITEM_ID = I.ID_
							INNER JOIN ADM_MST_PLATFORMS P ON I.ID_ = P.ID_
							INNER JOIN ADM_MST_STATUS_CONDITIONS SC ON S.STSCND_ID = SC.ID_
							INNER JOIN ADM_MST_SIMPLE_REF SR ON SC.COND_ID = SR.ID_ 
							LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = T.UNIT_ID
							LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
					WHERE C.ID_ = @CommandId AND P.ID_ = @PlatformId AND (SR.ID_ = @FMC OR SR.ID_ = @PMCM OR SR.ID_ = @PMCS) AND T_VAR.ID_ IS NOT NULL                                            

				END
			END
			ELSE
			BEGIN
				IF @PlatformVar IS NULL
				BEGIN
					SELECT @result = COUNT(*) 
					FROM MNT_TRN_AIRCRAFT_SERVS S 
							INNER JOIN ADM_MST_UNITS U ON S.UNIT_ID = U.ID_
							INNER JOIN ADM_MST_TAILS T ON T.UNIT_ID = U.ID_  AND  T.END_DATE_>=@input_date
							INNER JOIN ADM_MST_RESTRICTIONS B ON B.ID_ = T.BATLN_ID
							INNER JOIN ADM_MST_RESTRICTIONS C ON C.ID_ = B.PRNT_ID
							INNER JOIN ADM_MST_ITEMS I ON U.ITEM_ID = I.ID_
							INNER JOIN ADM_MST_PLATFORMS P ON I.ID_ = P.ID_
							INNER JOIN ADM_MST_STATUS_CONDITIONS SC ON S.STSCND_ID = SC.ID_
							INNER JOIN ADM_MST_SIMPLE_REF SR ON SC.COND_ID = SR.ID_ 
							LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = T.UNIT_ID
							LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
					WHERE C.ID_ = @CommandId AND P.ID_ = @PlatformId AND (SR.ID_ = @DEPOT OR SR.ID_ = @NMCM OR SR.ID_ = @NMCS) AND T_VAR.ID_ IS NULL
				END
				ELSE
				BEGIN
					SELECT @result = COUNT(*) 
					FROM MNT_TRN_AIRCRAFT_SERVS S 
							INNER JOIN ADM_MST_UNITS U ON S.UNIT_ID = U.ID_
							INNER JOIN ADM_MST_TAILS T ON T.UNIT_ID = U.ID_  AND  T.END_DATE_>=@input_date
							INNER JOIN ADM_MST_RESTRICTIONS B ON B.ID_ = T.BATLN_ID
							INNER JOIN ADM_MST_RESTRICTIONS C ON C.ID_ = B.PRNT_ID
							INNER JOIN ADM_MST_ITEMS I ON U.ITEM_ID = I.ID_
							INNER JOIN ADM_MST_PLATFORMS P ON I.ID_ = P.ID_
							INNER JOIN ADM_MST_STATUS_CONDITIONS SC ON S.STSCND_ID = SC.ID_
							INNER JOIN ADM_MST_SIMPLE_REF SR ON SC.COND_ID = SR.ID_ 
							LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = T.UNIT_ID
							LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
					WHERE C.ID_ = @CommandId AND P.ID_ = @PlatformId AND (SR.ID_ = @DEPOT OR SR.ID_ = @NMCM OR SR.ID_ = @NMCS) AND T_VAR.ID_ IS NOT NULL 
				END
			END
	  END
      ELSE
      BEGIN
            IF @McCount > 0
			BEGIN
				IF @PlatformVar IS NULL
				BEGIN
                    SELECT  @result =   COUNT(*) 
                    FROM MNT_HST_AIRCRAFT_SERVS AS S INNER JOIN
							MNT_TRN_AIRCRAFT_SERVS AS SERVICEA ON S.AIR_SRV_ID = SERVICEA.ID_ INNER JOIN
							ADM_MST_PLATFORMS AS P ON S.PLTF_ = P.CODE_ INNER JOIN
							ADM_MST_SIMPLE_REF AS SR ON S.COND_ = SR.CODE_ AND SR.GRP_ = 'MNT.CND' INNER JOIN
                            (SELECT tailnumber, MAX(createdDate) AS maxCreatedDate
                             FROM (SELECT TAIL_NUM_ AS tailnumber, CREATED_ON_ AS createdDate
								   FROM MNT_HST_AIRCRAFT_SERVS AS temp
								   WHERE (CREATED_ON_ > @input_date) AND (CREATED_ON_ < @input_date + 1)) AS Data
                             GROUP BY tailnumber) AS LastDate ON LastDate.maxCreatedDate = S.CREATED_ON_ AND LastDate.tailnumber = S.TAIL_NUM_ AND P.ID_ = @PlatformId AND 
                                                (SR.ID_ = @FMC OR  SR.ID_ = @PMCM OR SR.ID_ = @PMCS)
							LEFT JOIN ADM_MST_TAILS AS TAIL ON TAIL.T_NUM_ = S.TAIL_NUM_ AND  TAIL.END_DATE_>=@input_date
							LEFT JOIN ADM_MST_RESTRICTIONS B ON B.ID_ = TAIL.BATLN_ID
							LEFT JOIN ADM_MST_RESTRICTIONS C ON C.ID_ = B.PRNT_ID
							LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = TAIL.UNIT_ID
							LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
					WHERE C.ID_ = @CommandId AND T_VAR.ID_ IS NULL
				END
				ELSE
				BEGIN
                    SELECT  @result =   COUNT(*) 
                    FROM MNT_HST_AIRCRAFT_SERVS AS S INNER JOIN
							MNT_TRN_AIRCRAFT_SERVS AS SERVICEA ON S.AIR_SRV_ID = SERVICEA.ID_ INNER JOIN
							ADM_MST_PLATFORMS AS P ON S.PLTF_ = P.CODE_ INNER JOIN
							ADM_MST_SIMPLE_REF AS SR ON S.COND_ = SR.CODE_ AND SR.GRP_ = 'MNT.CND' INNER JOIN
                            (SELECT tailnumber, MAX(createdDate) AS maxCreatedDate
                             FROM (SELECT TAIL_NUM_ AS tailnumber, CREATED_ON_ AS createdDate
								   FROM MNT_HST_AIRCRAFT_SERVS AS temp
								   WHERE (CREATED_ON_ > @input_date) AND (CREATED_ON_ < @input_date + 1)) AS Data
                             GROUP BY tailnumber) AS LastDate ON LastDate.maxCreatedDate = S.CREATED_ON_ AND LastDate.tailnumber = S.TAIL_NUM_ AND P.ID_ = @PlatformId AND 
                                                    (SR.ID_ = @FMC OR  SR.ID_ = @PMCM OR SR.ID_ = @PMCS)
							LEFT JOIN ADM_MST_TAILS AS TAIL ON TAIL.T_NUM_ = S.TAIL_NUM_ AND  TAIL.END_DATE_>=@input_date
							LEFT JOIN ADM_MST_RESTRICTIONS B ON B.ID_ = TAIL.BATLN_ID
							LEFT JOIN ADM_MST_RESTRICTIONS C ON C.ID_ = B.PRNT_ID
							LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = TAIL.UNIT_ID
							LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
					WHERE C.ID_ = @CommandId AND T_VAR.ID_ IS NOT NULL
				END
			END
            ELSE
				IF @PlatformVar IS NULL
				BEGIN
                    SELECT   @result =  COUNT(*) 
                    FROM MNT_HST_AIRCRAFT_SERVS AS S INNER JOIN
							MNT_TRN_AIRCRAFT_SERVS AS SERVICEA ON S.AIR_SRV_ID = SERVICEA.ID_ INNER JOIN
							ADM_MST_PLATFORMS AS P ON S.PLTF_ = P.CODE_ INNER JOIN
							ADM_MST_SIMPLE_REF AS SR ON S.COND_ = SR.CODE_ AND SR.GRP_ = 'MNT.CND' INNER JOIN
							(SELECT tailnumber, MAX(createdDate) AS maxCreatedDate
								FROM (SELECT TAIL_NUM_ AS tailnumber, CREATED_ON_ AS createdDate
									FROM MNT_HST_AIRCRAFT_SERVS AS temp
									WHERE (CREATED_ON_ > @input_date) AND (CREATED_ON_ < @input_date + 1)) AS Data
								GROUP BY tailnumber) AS LastDate ON LastDate.maxCreatedDate = S.CREATED_ON_ AND LastDate.tailnumber = S.TAIL_NUM_ AND P.ID_ = @PlatformId AND 
												(SR.ID_ = @DEPOT OR SR.ID_ = @NMCM OR SR.ID_ = @NMCS)
							LEFT JOIN ADM_MST_TAILS AS TAIL ON TAIL.T_NUM_ = S.TAIL_NUM_ AND  TAIL.END_DATE_>=@input_date
							LEFT JOIN ADM_MST_RESTRICTIONS B ON B.ID_ = TAIL.BATLN_ID
							LEFT JOIN ADM_MST_RESTRICTIONS C ON C.ID_ = B.PRNT_ID
							LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = TAIL.UNIT_ID
							LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
					WHERE C.ID_ = @CommandId AND T_VAR.ID_ IS NULL

				END
				ELSE
                BEGIN
                    SELECT   @result =  COUNT(*) 
                    FROM MNT_HST_AIRCRAFT_SERVS AS S INNER JOIN
							MNT_TRN_AIRCRAFT_SERVS AS SERVICEA ON S.AIR_SRV_ID = SERVICEA.ID_ INNER JOIN
							ADM_MST_PLATFORMS AS P ON S.PLTF_ = P.CODE_ INNER JOIN
							ADM_MST_SIMPLE_REF AS SR ON S.COND_ = SR.CODE_ AND SR.GRP_ = 'MNT.CND' INNER JOIN
							(SELECT tailnumber, MAX(createdDate) AS maxCreatedDate
							 FROM (SELECT TAIL_NUM_ AS tailnumber, CREATED_ON_ AS createdDate
								   FROM MNT_HST_AIRCRAFT_SERVS AS temp
								   WHERE (CREATED_ON_ > @input_date) AND (CREATED_ON_ < @input_date + 1)) AS Data
							 GROUP BY tailnumber) AS LastDate ON LastDate.maxCreatedDate = S.CREATED_ON_ AND LastDate.tailnumber = S.TAIL_NUM_ AND P.ID_ = @PlatformId AND 
												(SR.ID_ = @DEPOT OR SR.ID_ = @NMCM OR SR.ID_ = @NMCS)
							LEFT JOIN ADM_MST_TAILS AS TAIL ON TAIL.T_NUM_ = S.TAIL_NUM_ AND  TAIL.END_DATE_>=@input_date
							LEFT JOIN ADM_MST_RESTRICTIONS B ON B.ID_ = TAIL.BATLN_ID
							LEFT JOIN ADM_MST_RESTRICTIONS C ON C.ID_ = B.PRNT_ID
							LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS T_VAR ON T_VAR.ID_ = TAIL.UNIT_ID
							LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS P_VAR ON P_VAR.ID_ = T_VAR.PLTF_VARIANT_ID
					WHERE C.ID_ = @CommandId AND T_VAR.ID_ IS NOT NULL
                END
                                         
            END
                    
            -- Return the result of the function
            RETURN @result
      END
go

