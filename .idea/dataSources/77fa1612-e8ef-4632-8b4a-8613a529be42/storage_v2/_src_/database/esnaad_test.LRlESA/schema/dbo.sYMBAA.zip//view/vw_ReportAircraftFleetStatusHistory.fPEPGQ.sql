/****** Object:  View [dbo].[vw_ReportAircraftFleetStatusHistory]    Script Date: 07/30/2013 09:43:01 ******/
CREATE VIEW [dbo].[vw_ReportAircraftFleetStatusHistory]
AS
SELECT     TOP (100) PERCENT T.ID_ AS TailId, H.TAIL_NUM_ AS TailNo, P.ID_ AS PlatformId, H.PLTF_ AS Platform, U.ID_ AS UnitId, R.PRNT_ID AS ParentId, 
                      RR.NAME_ AS Command, H.STAT_ AS Status, H.COND_ AS Condition, H.REMARKS_ AS Remarks, DS.DESC_ AS Deploy, R.ID_ AS BattalionID, H.BATT_ AS Battalion, 
                      US.ID_ AS ProfileID, H.CREATED_BY_ AS UserID, H.PERCENT_COMP_ AS Completed, H.START_DATE_ AS StartDate, H.EST_COMP_DATE_ AS EstCompDate, 
                      H.HRS_TO_INSP_ AS HrsInsp, H.CREATED_ON_ AS AsvcDate, P.ORDER_ AS PlatformOrder, UR.MODULE_ID AS ModuleID
FROM         dbo.MNT_HST_AIRCRAFT_SERVS AS H INNER JOIN
                      dbo.ADM_MST_TAILS AS T ON H.TAIL_NUM_ = T.T_NUM_ AND T.END_DATE_ = CONVERT(date, '31-DEC-9999') INNER JOIN
                      dbo.ADM_MST_UNITS AS U ON T.UNIT_ID = U.ID_ INNER JOIN
                      dbo.ADM_MST_PLATFORMS AS P ON H.PLTF_ = P.CODE_ INNER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS DS ON H.DEPL_ = DS.CODE_ AND DS.GRP_ = 'MNT.DPS' INNER JOIN
                      dbo.ADM_MST_RESTRICTIONS AS R ON H.BATT_ = R.CODE_ AND UPPER(R.TYPE_NAME_) = 'BATTALION' INNER JOIN
                      dbo.ADM_MST_RESTRICTIONS AS RR ON R.PRNT_ID = RR.ID_ INNER JOIN
                      dbo.ADM_TRN_USER_PROFILES AS US ON H.CREATED_BY_ = US.USER_ID_ INNER JOIN
                      dbo.ADM_TRN_USER_RESTRICTIONS AS UR ON US.ID_ = UR.USER_PROFILE_ID INNER JOIN
                      dbo.ADM_TRN_USER_PLATFORM_RESTRICION_DETAILS AS UPR ON P.ID_ = UPR.PLATFORM_ID AND UPR.USR_REST_ID = UR.ID_
ORDER BY PlatformOrder, TailNo, AsvcDate
go

