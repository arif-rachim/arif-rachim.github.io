-- create store procedure to update MedPlus data

-- =============================================
-- Author:		GAL22100
-- Create date: 27-11-2017
-- Description:	Update MedPlus Data from staging table
-- =============================================
CREATE PROCEDURE [dbo].[BIZ_UpdateMedPlusData] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	insert into BIZ_MEDPLUS_TRANSACTION
	select * from BIZ_MEDPLUS_TRANSACTION_STAGING
	where TRANSACTION_ID not in (select TRANSACTION_ID from BIZ_MEDPLUS_TRANSACTION)
	
	-- call sp to update medical fitness
	exec BIZ_UpdateFitnessData
	-- clean staging
	delete from BIZ_MEDPLUS_TRANSACTION_STAGING
END
go

