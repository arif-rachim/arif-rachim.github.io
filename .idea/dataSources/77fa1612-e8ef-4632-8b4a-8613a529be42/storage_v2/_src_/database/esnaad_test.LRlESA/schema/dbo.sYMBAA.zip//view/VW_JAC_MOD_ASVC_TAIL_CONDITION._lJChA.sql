
CREATE VIEW VW_JAC_MOD_ASVC_TAIL_CONDITION
AS (
	SELECT COUNT(ISNULL(tail.ID_, 0)) AS TailCount,  
		cond.ID_ AS ConditionId,
		cond.CODE_ AS Condition,
		cmd.CODE_ AS Command,
		cmd.PRNT_ID AS ForceId
	FROM ADM_MST_TAILS tail
	INNER JOIN ADM_MST_UNITS unit ON tail.UNIT_ID = unit.ID_ 		
	INNER JOIN ADM_MST_RESTRICTIONS battalion ON tail.BATLN_ID = battalion.ID_
	INNER JOIN ADM_MST_RESTRICTIONS cmd ON cmd.ID_ = battalion.PRNT_ID	
	LEFT JOIN MNT_TRN_AIRCRAFT_SERVS serviceability ON serviceability.UNIT_ID = unit.ID_ 
	LEFT JOIN ADM_MST_STATUS_CONDITIONS stcond ON serviceability.STSCND_ID = stcond.ID_
	LEFT JOIN ADM_MST_SIMPLE_REF cond ON stcond.COND_ID = cond.ID_
	WHERE tail.END_DATE_ = '9999-12-31'
	GROUP BY cond.ID_, cond.CODE_, cmd.CODE_, cmd.PRNT_ID
)
go

