CREATE VIEW dbo.VW_IMV_ASSEMBLY AS
select
    u.ID_          as UnitId
  , u.SERIAL_NO_   as SerialNo
  , i.ID_          as ItemId
  , i.PART_NO_     as PartNo
  , mfr.ID_        as MfrId
  , mfr.CAGE_CODE_ as MfrCode
  , cmd.ID_        as CommandId
  , cmd.CODE_      as CommandCode
  , l2.ID_         as L2Id
  , l2.CODE_       as L2Code
  , BU_ID_         as BusinessUnitId
  , bu.CODE_       as BusinessUnitCode
  , lg.ID_         as LocationGroupId
  , lg.NAME_       as LocationGroupName
  , loc.ID_        as LocationId
  , loc.NAME_      as LocationName
  , tc.ID_         as ConditionId
  , tc.CONDITION_  as Condition
  , imv.QTY_       as Qty
from ADM_TRN_IMV_ITEMS_IN_LOCATION imv
         join ADM_MST_UNITS u on u.ID_ = imv.UNIT_ID_
         join ADM_MST_ITEMS i on i.ID_ = u.ITEM_ID
         join ADM_MST_MANUFACTURES mfr on mfr.ID_ = i.MNF_ID
         join ADM_MST_RESTRICTIONS cmd on cmd.ID_ = imv.CMD_ID_
         join ADM_MST_BUSINESS_UNITS bu on bu.ID_ = imv.BU_ID_
         join ADM_TRN_ASSOC_GROUPS l2 on imv.OWNED_L2_ID_ = l2.ID_
         join ADM_MST_UNIT_LOCATION_GROUP lg on lg.ID_ = imv.LG_ID_
         join ADM_MST_UNIT_LOCATION loc on loc.ID_ = imv.LOC_ID_
         join ADM_MST_TAG_COLOR_CONDITION tc on tc.ID_ = imv.TC_ID_
union
select
    u.ID_           as UnitId
  , u.SERIAL_NO_    as SerialNo
  , i.ID_           as ItemId
  , i.PART_NO_      as PartNo
  , mfr.ID_         as MfrId
  , mfr.CAGE_CODE_  as MfrCode
  , null            as CommandId
  , null            as CommandCode
  , assy.ORG_L2_ID_ as L2Id
  , l2.CODE_        as L2Code
  , null            as BusinessUnitId
  , null            as BusinessUnitCode
  , null            as LocationGroupId
  , null            as LocationGroupName
  , null            as LocationId
  , '[INSTALLED]'   as LocationName
  , tc.ID_          as ConditionId
  , tc.CONDITION_   as Condition
  , 1               as Qty
from ADM_TRN_AUM_ASSY_UNIT assy
         join ADM_MST_UNITS u on u.ID_ = assy.UNIT_ID
         join ADM_MST_ITEMS i on i.ID_ = u.ITEM_ID
         join ADM_MST_MANUFACTURES mfr on mfr.ID_ = i.MNF_ID
         join ADM_TRN_ASSOC_GROUPS l2 on l2.ID_ = assy.ORG_L2_ID_
         join ADM_MST_TAG_COLOR_CONDITION tc on tc.ID_ = assy.ORG_TC_ID_
where assy.REM_DATE_ is null
go

