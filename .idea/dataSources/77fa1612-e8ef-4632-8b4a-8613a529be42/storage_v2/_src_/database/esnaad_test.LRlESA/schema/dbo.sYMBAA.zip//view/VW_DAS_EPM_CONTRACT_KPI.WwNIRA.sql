CREATE VIEW VW_DAS_EPM_CONTRACT_KPI AS
	SELECT VCON.ContractTypeId, VCON.ContractSubTypeId,  
				CASE WHEN VCON.ContractTypeId = 3 THEN 'FMS'
					 WHEN VCON.ContractTypeId = 4 THEN 'DCS'
				END AS ContractType,
				CASE WHEN (VCON.ContractSubTypeId = 2) THEN 'P&O'
					 WHEN (VCON.ContractSubTypeId = 3) THEN 'MOD'
					 WHEN (VCON.ContractSubTypeId = 4) THEN 'FOS'
					 WHEN (VCON.ContractSubTypeId = 5) THEN 'GEN'
					 WHEN (VCON.ContractSubTypeId = 6) THEN 'TRN'
					 ELSE ''
				END AS ContractSubType
				, VCON.NumberOfTask, VCON.NumberOfDeliverable, VCON.NumberOfMilestone
				, SUM(VTASK.DueIn) AS TaskDues, SUM(VDEL.DueIn) AS DeliverableDues, SUM(VMIL.DueIn) AS MilestoneDues
				, (100 * (SUM(VTASK.ContractTypeId) / VCON.NumberOfTask)) AS TaskDuesPercentage
				, (100 * (SUM(VDEL.ContractTypeId) / VCON.NumberOfDeliverable)) AS DeliverableDuesPercentage
				, (100 * (SUM(VMIL.ContractTypeId) / VCON.NumberOfMilestone)) AS MilestoneDuesPercentage
				, CASE WHEN (100 * (SUM(VTASK.ContractTypeId) / VCON.NumberOfTask)) > 10 THEN 3
					   WHEN (100 * (SUM(VTASK.ContractTypeId) / VCON.NumberOfTask)) = 0 THEN 1
					   WHEN SUM(VTASK.DueIn) IS NULL THEN '1'
					   ELSE 2
				  END AS TaskKpi
				, CASE WHEN (100 * (SUM(VDEL.ContractTypeId) / VCON.NumberOfDeliverable)) > 10 THEN '3'
					   WHEN (100 * (SUM(VDEL.ContractTypeId) / VCON.NumberOfDeliverable)) = 0 THEN '1'
					   WHEN SUM(VDEL.DueIn) IS NULL THEN 1
					   ELSE 2
				  END AS DeliverableKpi
				, CASE WHEN (100 * (SUM(VMIL.ContractTypeId) / VCON.NumberOfMilestone)) > 10 THEN '3'
					   WHEN (100 * (SUM(VMIL.ContractTypeId) / VCON.NumberOfMilestone)) = 0 THEN '1'
					   WHEN SUM(VMIL.DueIn) IS NULL THEN 1
					   ELSE 2
				  END AS MilestoneKpi
				
		FROM 		
			(SELECT CON.CONT_TYPE_ID AS ContractTypeId, CON.CONT_SUB_TYPE_ID AS ContractSubTypeId, 
					TYP.NAME_ AS ContractType, SUB.NAME_ AS ContractSubType
					, COUNT(TAS.ID_) AS NumberOfTask
					, COUNT(DEL.ID_) AS NumberOfDeliverable
					, COUNT(MIL.ID_) AS NumberOfMilestone
			FROM PMO_TRN_CONTRACT CON
				LEFT OUTER JOIN PMO_MST_CONTRACT_SUBTYPE SUB
					ON SUB.ID_ = CON.CONT_SUB_TYPE_ID
				LEFT OUTER JOIN PMO_MST_CONTRACT_TYPE TYP
					ON TYP.ID_ = CON.CONT_TYPE_ID
				LEFT OUTER JOIN PMO_TRN_TASK TAS
					ON TAS.CONTRACT_ID = CON.ID_
				LEFT OUTER JOIN PMO_TRN_DELIVERABLE DEL
					ON DEL.CONTRACT_ID = CON.ID_
				LEFT OUTER JOIN PMO_TRN_MILESTONE MIL
					ON MIL.CONTRACT_ID = CON.ID_
			GROUP BY TYP.NAME_, SUB.NAME_, CON.CONT_TYPE_ID, CON.CONT_SUB_TYPE_ID, TYP.ID_ , SUB.ID_
			) AS VCON
			
			LEFT OUTER JOIN
			
			(SELECT CON.CONT_TYPE_ID AS ContractTypeId, CON.CONT_SUB_TYPE_ID AS ContractSubTypeId
				, DATEDIFF(DAY, TAS.DUE_DATE_, GETDATE()) AS DueIn
				, TAS.COMPL_PERCENTAGE_ AS CompletionPercentage
				FROM PMO_TRN_CONTRACT CON 
					INNER JOIN PMO_TRN_TASK TAS
						ON TAS.CONTRACT_ID = CON.ID_
				WHERE TAS.COMPL_PERCENTAGE_ <> 100 AND DATEDIFF(DAY, TAS.DUE_DATE_, GETDATE()) >= 0
			) AS VTASK 
			
			ON VTASK.ContractTypeId = VCON.ContractTypeId AND VTASK.ContractSubTypeId = VCON.ContractSubTypeId
			
			LEFT OUTER JOIN
			
			(SELECT CON.CONT_TYPE_ID AS ContractTypeId, CON.CONT_SUB_TYPE_ID AS ContractSubTypeId
				, DATEDIFF(DAY, DEL.TARGET_DATE_, GETDATE()) AS DueIn
				, DEL.COMPL_PERCENTAGE_ AS CompletionPercentage
				FROM PMO_TRN_CONTRACT CON 
					INNER JOIN PMO_TRN_DELIVERABLE DEL
						ON DEL.CONTRACT_ID = CON.ID_
				WHERE DEL.COMPL_PERCENTAGE_ <> 100 AND DATEDIFF(DAY, DEL.TARGET_DATE_, GETDATE()) >= 0
			) AS VDEL 
			
			ON VDEL.ContractTypeId = VCON.ContractTypeId AND VDEL.ContractSubTypeId = VCON.ContractSubTypeId

			LEFT OUTER JOIN
			
			(SELECT CON.CONT_TYPE_ID AS ContractTypeId, CON.CONT_SUB_TYPE_ID AS ContractSubTypeId
				, DATEDIFF(DAY, MIL.TARGET_DATE_, GETDATE()) AS DueIn
				, MIL.COMPL_PERCENTAGE_ AS CompletionPercentage
				FROM PMO_TRN_CONTRACT CON 
					INNER JOIN PMO_TRN_MILESTONE MIL
						ON MIL.CONTRACT_ID = CON.ID_
				WHERE MIL.COMPL_PERCENTAGE_ <> 100 AND DATEDIFF(DAY, MIL.TARGET_DATE_, GETDATE()) >= 0
			) AS VMIL
			
			ON VMIL.ContractTypeId = VCON.ContractTypeId AND VMIL.ContractSubTypeId = VCON.ContractSubTypeId
		
		GROUP BY VCON.ContractType, VCON.ContractSubType, VCON.ContractTypeId, VCON.ContractSubTypeId
				, VCON.NumberOfTask, VCON.NumberOfDeliverable, VCON.NumberOfMilestone

go

