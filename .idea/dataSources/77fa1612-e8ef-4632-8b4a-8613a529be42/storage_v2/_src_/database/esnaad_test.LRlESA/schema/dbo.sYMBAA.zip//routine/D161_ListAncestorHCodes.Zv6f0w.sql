CREATE FUNCTION [dbo].[D161_ListAncestorHCodes](@hCode nvarchar(450))
RETURNS @ancestorHCodes TABLE (H_CODE_ nvarchar(450))
AS
BEGIN
	DECLARE @level int
	DECLARE @i int
	DECLARE @currHCode nvarchar(450)

	SELECT @level = COUNT(*) - 2 FROM dbo.SplitInts(@hCode,'.')
	SET @i = @level
	SET @currHCode = @hCode
	WHILE @i >= 0
	BEGIN
		SELECT @currHCode =  dbo.D161_GetParentHCode(@currHCode)
		
		INSERT @ancestorHCodes
		SELECT @currHCode

		SET @i = @i - 1
	END

	RETURN;
END
go

