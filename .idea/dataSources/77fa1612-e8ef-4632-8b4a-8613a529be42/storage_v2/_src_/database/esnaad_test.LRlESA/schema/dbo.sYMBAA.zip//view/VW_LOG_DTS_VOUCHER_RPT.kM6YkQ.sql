CREATE VIEW [dbo].[VW_LOG_DTS_VOUCHER_RPT]
AS
SELECT        ti.ID_ AS VOUCHER_ID, tr.TR_NO_ AS TRANSFER_DOCUMENT, ti.VOUCHER_NO_ AS TR_ISSUE_VOUCHER, rcm.CODE_ AS RECEIVING_CMD, 
                         fcm.CODE_ AS FULFILLING_CMD, rl2.CODE_ AS RECEIVING_L2, fl2.CODE_ AS FULFILLING_L2, RBU.CODE_ AS RECEIVING_BU, FBU.CODE_ AS FULFILLING_BU, 
                         tr.TR_DATE_ AS TRANSFER_DATE, UP.USER_ID_ AS TRANSFER_BY, UP.F_NAME_ + ' ' + UP.L_NAME_ AS TRANSFER_BY_FULL_NAME, 
                         ti.CREATED_ON_ AS TI_DATE, tr.REF_TYPE_
FROM            dbo.LOG_TRN_TRM_TRANSFER_INFO AS ti INNER JOIN
                         dbo.LOG_TRN_TRM_TRANSFER_REQUEST AS tr ON ti.TRF_REQ_ID_ = tr.ID_ AND tr.TR_TYPE_ = 'DirectTransfer' INNER JOIN
                         dbo.ADM_MST_RESTRICTIONS AS rcm ON tr.RI_CMD_ID_ = rcm.ID_ INNER JOIN
                         dbo.ADM_MST_RESTRICTIONS AS fcm ON tr.FI_CMD_ID_ = fcm.ID_ INNER JOIN
                         dbo.ADM_TRN_ASSOC_GROUPS AS rl2 ON tr.RI_L2_ID_ = rl2.ID_ INNER JOIN
                         dbo.ADM_TRN_ASSOC_GROUPS AS fl2 ON tr.FI_L2_ID_ = fl2.ID_ INNER JOIN
                         dbo.ADM_MST_BUSINESS_UNITS AS RBU ON tr.RI_BU_ID_ = RBU.ID_ INNER JOIN
                         dbo.ADM_MST_BUSINESS_UNITS AS FBU ON tr.FI_BU_ID_ = FBU.ID_ INNER JOIN
                         dbo.ADM_TRN_USER_PROFILES AS UP ON tr.CREATED_BY_ = UP.USER_ID_
go

