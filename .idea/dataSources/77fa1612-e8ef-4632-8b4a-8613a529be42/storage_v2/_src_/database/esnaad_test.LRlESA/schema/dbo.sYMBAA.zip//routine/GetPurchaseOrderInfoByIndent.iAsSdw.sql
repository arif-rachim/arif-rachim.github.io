CREATE FUNCTION [dbo].[GetPurchaseOrderInfoByIndent]
(	
	@IndentId uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
               select IndentItmId as IndentItmId, 
						SUM(OrderedQty) as OrderedQty, 
						SUM(OrderedQtyUop) as OrderedQtyUop,
						MIN(OrderedErd) as OrderedErd, COUNT(distinct PoCount) as PoCount
                        ,PoUom as PoUom, RfqUom as RfqUom ,PoStatus
						  ,FmsDocNo as FmsDocNo
						,sum(rcvQty) As rcvQty
						,sum(rcvQtyUop) As rcvQtyUop
						from (
  select prix.INDENT_ITEM_ID as IndentItmId, 
						poi.ORDERED_QTY_ * poi.UOM_CONVERSION_ as OrderedQty, 
						poi.ORDERED_QTY_ as OrderedQtyUop,
						poi.ERD_ as OrderedErd,  po.ID_ as PoCount
                        ,umpoi.CODE_ as PoUom, umpri.CODE_ as RfqUom
                        ,(select STRING_AGG(po.STATUS_ ,' ,') from LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi
						 join LOG_TRN_PRC_PURCHASE_ORDER po on po.ID_ = poi.PO_ID
                join LOG_TRN_PRC_PROCUREMENT_ITEM pri on pri.ID_ = poi.PROC_ITEM_ID   
                join LOG_XRF_PRC_PROCUREMENT_ITEM_INDENT_ITEM prix on prix.PROC_ITEM_ID = pri.ID_    
                join LOG_TRN_PRC_INDENT_ITEM pii on prix.INDENT_ITEM_ID = pii.ID_
						where pii.INDENT_ID=@IndentId
						) as PoStatus
                        ,mil.FMS_DOC_NO_ as FmsDocNo
						,dni.RCV_QTY_ As rcvQty
						,dni.RCV_QTY_UOP_ As rcvQtyUop
                from LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi
                join LOG_TRN_PRC_PURCHASE_ORDER po on po.ID_ = poi.PO_ID
                join LOG_TRN_PRC_PROCUREMENT_ITEM pri on pri.ID_ = poi.PROC_ITEM_ID   
                join LOG_XRF_PRC_PROCUREMENT_ITEM_INDENT_ITEM prix on prix.PROC_ITEM_ID = pri.ID_    
                join LOG_TRN_PRC_INDENT_ITEM pii on prix.INDENT_ITEM_ID = pii.ID_
                left join LOG_TRN_FMS_MILSTRIP mil on mil.INDENT_ID_ = pii.INDENT_ID and mil.PO_ITEM_ID_ = poi.ID_ 
                left join LOG_MST_UNIT_OF_MEASURE umpoi on umpoi.ID_ = poi.UOM_ID  
                left join LOG_MST_UNIT_OF_MEASURE umpri on umpri.ID_ = pri.Q_UOM_ID  
				left  join (

                            SELECT SUM(CASE WHEN itms.SERIALIZED_ = 1 AND idni.FOC_QTY_ > 0 THEN 0 ELSE idni.RCV_QTY_ END) as RCV_QTY_, 
									(SUM(CASE WHEN itms.SERIALIZED_ = 1 AND idni.FOC_QTY_ > 0 THEN 0 ELSE idni.RCV_QTY_ END) / ipoi.UOM_CONVERSION_) as RCV_QTY_UOP_,
									idni.PO_ITEM_ID_ AS PO_ITEM_ID_

                                    FROM 

                                            LOG_TRN_REC_DELIVERY_NOTE_ITEM idni INNER JOIN

											LOG_TRN_REC_DELIVERY_NOTE dn on dn.ID_ = idni.DN_ID INNER JOIN

                                            LOG_TRN_PRC_PURCHASE_ORDER_ITEM AS ipoi ON ipoi.ID_ = idni.PO_ITEM_ID_ 

                                                                           join LOG_TRN_PRC_PROCUREMENT_ITEM ipri on ipri.ID_ = ipoi.PROC_ITEM_ID   

                                                                           join LOG_XRF_PRC_PROCUREMENT_ITEM_INDENT_ITEM iprix on iprix.PROC_ITEM_ID = ipri.ID_    

                                                                           join LOG_TRN_PRC_INDENT_ITEM ipii on iprix.INDENT_ITEM_ID = ipii.ID_
																		   join ADM_MST_ITEMS itms on itms.ID_=ipii.ITEM_ID
                                                                           where ipii.INDENT_ID = @IndentId and dn.STATUS_ <> 'Created' and idni.IS_SDR_ = 0

                                    GROUP BY idni.PO_ITEM_ID_, ipoi.UOM_CONVERSION_

                ) dni on dni.PO_ITEM_ID_ = poi.ID_
				where pii.INDENT_ID = @IndentId and po.STATUS_ <> 'Canceled'
				) temp
                group by IndentItmId, PoUom, RfqUom,PoStatus,FmsDocNo 
)
go

