CREATE PROC [Generate_Repair_Order_Automatically] 
AS
BEGIN
select config.* into #LOG_MST_RPM_REORDER_CONFIG
from
(select bu.ID_ as  BU_ID  , buL2.L2_ID_ as  L2_ID,
iif(config.HAS_REORDER_POINT_PLATFORM_ALL=1, 1,0) as IS_BY_BU_,
iif(config.HAS_REORDER_POINT_PLATFORM_ALL=0,1,0) as IS_BY_PLATFORMS_
from LOG_MST_RPM_CANDIDATE_CONFIG config inner join
ADM_MST_BUSINESS_UNITS bu on config.STORE_ID=bu.ID_ inner join
ADM_MST_BUSINESS_UNITS_L2 buL2 on buL2.BU_ID_=bu.ID_
where config.HAS_AUTOMATIC_REORDER_POINT_CREATION_=1)config



;WITH CTE_REORDER AS (
		SELECT DISTINCT config.IS_BY_BU_ as ByBU,config.IS_BY_PLATFORMS_ as ByPltform,bu.CMD_ID_ as CommandId,
                                                    RO_LEVEL.ITEM_ID AS ItemId, ITEMS.PART_NO_ AS PartNo, ADM_MST_MANUFACTURES.CAGE_CODE_ AS CageCode,ITEMS.SERIALIZED_ as IsSerilzed, UOM.CODE_ AS Uom, ITEMS.NOMENCLATURE_ AS Nomenclature,                                                     
                                                    CASE WHEN LEN(ITEMS.NSN_) > 1 THEN SUBSTRING(ITEMS.NSN_,1,4) + '-' + SUBSTRING(ITEMS.NSN_,5,2) + '-' + SUBSTRING(ITEMS.NSN_,7,3) + '-' + SUBSTRING(ITEMS.NSN_,10,4) ELSE '' END AS Nsn,
                                                    ITEMS.PBL_ AS PblItemType, RO_LEVEL.L2_ID AS L2Id, RO_LEVEL.BU_ID AS BuId, ITEMS.CLS_ID_ AS ItemClassId, 
                                                    ITEMS.CAT_ID_ AS CategoryId, CAT.CODE_ AS Category, CLS.CODE_ AS ItemClass, CASE WHEN L2ATT.IS_FMS_ = 1 THEN 'YES' ELSE 'NO' END AS Fms, 
                                                    ISNULL(RO_LEVEL.MAX_LEVEL_, 0) - (CASE WHEN (RCC.HAS_PRIMARY_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.NEW_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_PRIMARY_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.NEW_DUES_IN_NOT_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_IN_LIEU_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.NEW_IN_LIEU_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_IN_LIEU_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_IN_LIEU_STOCK_ > 0) 
                                                    THEN (RO_LEVEL.IN_LIEU_STOCK_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_PRIMARY_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_PRIMARY_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_DUES_IN_NOT_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_IN_LIEU_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_IN_LIEU_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_IN_LIEU_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_) ELSE ' 0' END) AS Computed,
                                                        (SELECT        COUNT(LOG_TRN_RPM_REORDER_POINT_ITEM.ITEM_ID_) AS Expr1
                                                          FROM            LOG_TRN_RPM_REORDER_POINT_ITEM INNER JOIN
                                                                                    LOG_TRN_RPM_REORDER_POINT ON LOG_TRN_RPM_REORDER_POINT_ITEM.ROP_ID = LOG_TRN_RPM_REORDER_POINT.ID_
                                                          WHERE        (LOG_TRN_RPM_REORDER_POINT.STATUS_ <> N'Cancelled') AND (LOG_TRN_RPM_REORDER_POINT.STATUS_ <> N'Closed') AND 
                                                                                    (LOG_TRN_RPM_REORDER_POINT_ITEM.STATUS_ = N'Cancelled') AND (LOG_TRN_RPM_REORDER_POINT_ITEM.ITEM_ID_ = ITEMS.ID_) AND 
                                                                                    (LOG_TRN_RPM_REORDER_POINT.STORE_ID = 100795) AND (LOG_TRN_RPM_REORDER_POINT.L2_ID = 9)) AS LineColour, 
                                                    RO_LEVEL.STOCK_ - (CASE WHEN (RO_LEVEL.EXPIRED_STOCK <= RO_LEVEL.STOCK_) 
                                                    THEN RO_LEVEL.EXPIRED_STOCK ELSE 0 END) AS Qty, 
                                                    RO_LEVEL.IN_LIEU_STOCK_ - (CASE WHEN (RO_LEVEL.IN_LIEU_EXPIRED_STOCK <= RO_LEVEL.IN_LIEU_STOCK_) 
                                                    THEN RO_LEVEL.IN_LIEU_EXPIRED_STOCK ELSE 0 END) AS Inlieu, RO_LEVEL.SAFETY_LEVEL_ AS SafetyLevel, 
                                                    RO_LEVEL.NEW_DUES_IN_CONFIRMED_ + RO_LEVEL.NEW_IN_LIEU_DUES_IN_CONFIRMED_ AS DuesInConfirmed, 
                                                    RO_LEVEL.NEW_DUES_IN_NOT_CONFIRMED_ + RO_LEVEL.NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_ AS DuesInNotConfirmed, 
                                                    RO_LEVEL.EXPIRED_STOCK + RO_LEVEL.IN_LIEU_EXPIRED_STOCK AS ExpiredStock, 
                                                    RO_LEVEL.UNDER_STOCK_TAKING_ + RO_LEVEL.IN_LIEU_UNDER_STOCK_TAKING_ AS StockInStockTaking 
        
                FROM
				LOG_TRN_ITEM_REORDER_LEVELS RO_LEVEL inner join
                ADM_MST_ITEMS AS ITEMS ON RO_LEVEL.ITEM_ID = ITEMS.ID_ INNER JOIN
				ADM_TRN_ITEM_ASSOCS AGL2 on AGL2.L2_ID=RO_LEVEL.L2_ID and AGL2.ITEM_ID=RO_LEVEL.ITEM_ID inner join
				ADM_MST_BUSINESS_UNITS bu on bu.ID_=RO_LEVEL.BU_ID 	inner join
                ADM_MST_SIMPLE_REF AS CAT ON ITEMS.CAT_ID_ = CAT.ID_ LEFT OUTER JOIN
				ADM_MST_SIMPLE_REF AS CLS ON ITEMS.CLS_ID_ = CLS.ID_ LEFT OUTER JOIN
                ADM_MST_MANUFACTURES ON ITEMS.MNF_ID = ADM_MST_MANUFACTURES.ID_ LEFT OUTER JOIN
                LOG_MST_UNIT_OF_MEASURE AS UOM ON ITEMS.UOM_ID_ = UOM.ID_ INNER JOIN
                LOG_MST_RPM_CANDIDATE_CONFIG AS RCC ON RCC.STORE_ID = RO_LEVEL.BU_ID 
                LEFT JOIN LOG_TRN_ITEM_L2_ATTRIBUTES AS L2ATT  ON L2ATT.ITEM_ID =  RO_LEVEL.ITEM_ID AND L2ATT.L2_ID = RO_LEVEL.L2_ID  
                inner join #LOG_MST_RPM_REORDER_CONFIG config on config.BU_ID=RO_LEVEL.BU_ID and config.L2_ID=RO_LEVEL.L2_ID 

			
                WHERE  (CASE WHEN (L2ATT.IS_OBSOLETE_ = 1 AND  L2ATT.ITEM_OBSOLETE_DATE_ <= REPLACE(CONVERT(VARCHAR, GETDATE() , 106), ' ', '-'))  THEN 1 ELSE 0 END) = 0
                 AND (NOT EXISTS
                (SELECT 1
                FROM LOG_TRN_RPM_REORDER_POINT_ITEM AS ROI INNER JOIN
                LOG_TRN_RPM_REORDER_POINT AS RO ON 
                ROI.ROP_ID = RO.ID_
                WHERE (RO.STATUS_ <> N'Cancelled') AND (RO.STATUS_ <> N'Closed') AND  (ROI.STATUS_ <> N'Cancelled') AND (RO.STORE_ID = config.BU_ID) AND 
                (RO.L2_ID = config.L2_ID) AND ROI.ITEM_ID_ = AGL2.ITEM_ID)) AND (AGL2.PRIMARY_PART_ > 0) 
                AND  (ISNULL(RO_LEVEL.MAX_LEVEL_, 0) - (CASE WHEN (RCC.HAS_PRIMARY_DUES_IN_CONFIRMED_ > 0) THEN (RO_LEVEL.NEW_DUES_IN_CONFIRMED_) 
                                                    ELSE ' 0' END + CASE WHEN (RCC.HAS_PRIMARY_DUES_IN_NOT_CONFIRMED_ > 0) THEN (RO_LEVEL.NEW_DUES_IN_NOT_CONFIRMED_) 
                                                    ELSE ' 0' END + CASE WHEN (RCC.HAS_IN_LIEU_DUES_IN_CONFIRMED_ > 0) THEN (RO_LEVEL.NEW_IN_LIEU_DUES_IN_CONFIRMED_) 
                                                    ELSE ' 0' END + CASE WHEN (RCC.HAS_IN_LIEU_DUES_IN_NOT_CONFIRMED_ > 0) THEN (RO_LEVEL.NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_) 
                                                    ELSE ' 0' END + CASE WHEN (RCC.HAS_IN_LIEU_STOCK_ > 0) THEN (RO_LEVEL.IN_LIEU_STOCK_ + CASE WHEN (RCC.HAS_REPAIR_PRIMARY_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_PRIMARY_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_DUES_IN_NOT_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_IN_LIEU_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_IN_LIEU_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_IN_LIEU_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_) 
                                                    ELSE ' 0' END - (CASE WHEN (RO_LEVEL.IN_LIEU_EXPIRED_STOCK <= RO_LEVEL.IN_LIEU_STOCK_) 
                                                    THEN RO_LEVEL.IN_LIEU_EXPIRED_STOCK ELSE 0 END)) ELSE ' 0' END) > 0) 
													
													AND ((CASE WHEN (RCC.HAS_PRIMARY_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.NEW_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_PRIMARY_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.NEW_DUES_IN_NOT_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_IN_LIEU_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.NEW_IN_LIEU_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_IN_LIEU_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.NEW_IN_LIEU_DUES_IN_NOT_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_PRIMARY_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_PRIMARY_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_DUES_IN_NOT_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_IN_LIEU_DUES_IN_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_IN_LIEU_DUES_IN_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_REPAIR_IN_LIEU_DUES_IN_NOT_CONFIRMED_ > 0) 
                                                    THEN (RO_LEVEL.RPR_IN_LIEU_DUES_IN_NOT_CONFIRMED_) ELSE ' 0' END + CASE WHEN (RCC.HAS_IN_LIEU_STOCK_ > 0) 
                                                    THEN ((RO_LEVEL.IN_LIEU_STOCK_ - (CASE WHEN (RO_LEVEL.IN_LIEU_EXPIRED_STOCK <= RO_LEVEL.IN_LIEU_STOCK_) 
                                                    THEN RO_LEVEL.IN_LIEU_EXPIRED_STOCK ELSE 0 END))) ELSE ' 0' END) 
                                                    + (RO_LEVEL.STOCK_ - (CASE WHEN (RO_LEVEL.EXPIRED_STOCK <= RO_LEVEL.STOCK_) 
                                                    THEN RO_LEVEL.EXPIRED_STOCK ELSE 0 END)) <= RO_LEVEL.SAFETY_LEVEL_)
	) 
	select * into  #ALL_ITEMS from CTE_REORDER 








	-- Create Reorder point masters for items which  business unit and l2 combination does't exist
	begin tran
	             -- Get new pair count
				declare @newBuCount  bigint
				select @newBuCount=sum(cnt) from (select count(distinct AllItems.BuId + +'-'+AllItems.L2Id) as cnt from  #ALL_ITEMS AllItems
								outer apply (
							select ROID,[REORDER POINT NO] from(
							  SELECT   RO.ID_ ROID,RO.REORDER_POINT_NO_ as [REORDER POINT NO] ,ROW_NUMBER() over( partition by RO.STORE_ID,L2_ID  order by RO.CREATED_ON_ desc) Ranks
							  FROM  LOG_TRN_RPM_REORDER_POINT RO 
							where RO.STATUS_ in ('Created','PartiallyProcessed') and (RO.STORE_ID = AllItems.BuId) AND (RO.L2_ID = AllItems.L2Id)
							AND RO.JOB_REF_PLTFM_ID is NULL 
							)RO where RO.Ranks=1)ExistingRO
				where ExistingRO.ROID is  null and  ByBu=1
				group by AllItems.CommandId,AllItems.BuId,AllItems.L2Id)TotalRec

				---Create new reorder point for new BU and L2
				IF @newBuCount > 0 
				BEGIN

			        --Generate new reorder point number batch table 
					DECLARE @numberGeneratorParam esnaadm.Type_NumberGeneratorParam
					INSERT @numberGeneratorParam values(YEAR(GETDATE()),null,@newBuCount)

					DECLARE @generatedRPNos TABLE(YEAR_ int, MONTH_ int, FORMATTED_NO_ varchar(40))
					INSERT @generatedRPNos exec dbo.[GenerateSequenceNumbers] 'RP',@numberGeneratorParam

						SELECT FORMATTED_NO_, ROW_NUMBER() OVER(PARTITION BY YEAR_ ORDER BY FORMATTED_NO_) AS ROW_
						FROM @generatedRPNos

					

					insert  into LOG_TRN_RPM_REORDER_POINT 
					select (SELECT CAST(CAST(NEWID() AS BINARY(10)) + CAST(GETDATE() AS BINARY(6)) AS UNIQUEIDENTIFIER)),1,AllItem.CommandId, AllItem.BuId,AllItem.L2Id,'Created','SYSTEM','SYSTEM','SYSTEM',getdate(),null,null,null,null,null
					,RP.FORMATTED_NO_,null
					from
					(select AllItems.CommandId, AllItems.BuId,AllItems.L2Id, ROW_NUMBER() OVER( ORDER BY AllItems.BuId,AllItems.L2Id) AS ROW_
					from  #ALL_ITEMS AllItems
									outer apply (
								select ROID,[REORDER POINT NO] from(
								  SELECT   RO.ID_ ROID,RO.REORDER_POINT_NO_ as [REORDER POINT NO] ,ROW_NUMBER() over( partition by RO.STORE_ID,L2_ID  order by RO.CREATED_ON_ desc) Ranks
								  FROM  LOG_TRN_RPM_REORDER_POINT RO 
								where RO.STATUS_ in ('Created','PartiallyProcessed') and (RO.STORE_ID = AllItems.BuId) AND (RO.L2_ID = AllItems.L2Id)
								AND RO.JOB_REF_PLTFM_ID is NULL 
								)RO where RO.Ranks=1)ExistingRO
					where ExistingRO.ROID is  null and  ByBu=1
					group by AllItems.CommandId,AllItems.BuId,AllItems.L2Id
					)AllItem
					left join
					 (
		   				SELECT FORMATTED_NO_, ROW_NUMBER() OVER(PARTITION BY YEAR_ ORDER BY FORMATTED_NO_) AS ROW_
						FROM @generatedRPNos
					 ) RP ON RP.ROW_ = AllItem.ROW_
		
					select * from LOG_TRN_RPM_REORDER_POINT order by CREATED_ON_ desc
				end

			
			
				
				--- Create Reorder point detail entry for each item 
				insert  into LOG_TRN_RPM_REORDER_POINT_ITEM
				select (SELECT CAST(CAST(NEWID() AS BINARY(10)) + CAST(GETDATE() AS BINARY(6)) AS UNIQUEIDENTIFIER)),
				1,AllItems.ItemId,AllItems.PartNo,AllItems.CageCode,AllItems.Nomenclature,AllItems.IsSerilzed,null,'Created',ExistingRO.ROID,null,null  from  #ALL_ITEMS AllItems
				outer apply (
							select ROID,[REORDER POINT NO] from(
							  SELECT   RO.ID_ ROID,RO.REORDER_POINT_NO_ as [REORDER POINT NO] ,ROW_NUMBER() over( partition by RO.STORE_ID,L2_ID  order by RO.CREATED_ON_ desc) Ranks
							  FROM  LOG_TRN_RPM_REORDER_POINT RO 
							where RO.STATUS_ in ('Created','PartiallyProcessed') and (RO.STORE_ID = AllItems.BuId) AND (RO.L2_ID = AllItems.L2Id)
							AND RO.JOB_REF_PLTFM_ID is NULL 
							)RO where RO.Ranks=1)ExistingRO
				where ExistingRO.ROID is not  null and  ByBu=1
	commit

	-- Prepare data for each platform wise item


	--Neglect item which does'nt have platfrom configuration
	select AllItems.*,null as platformId into  #PLATFORM_ITEMS
	from  #ALL_ITEMS AllItems
	outer apply (
	 select distinct PL.ITEM_ID from  ADM_XRF_ITEM_PLATFORM_L2 PL 
      inner join ADM_MST_PLATFORM_L2 PLD on PLD.ID_=PL.PLATFORM_L2_ID  
	 where PL.ITEM_ID=AllItems.ItemId and PLD.L2_ID_=AllItems.L2Id and PLD.CMD_ID_=AllItems.CommandId
	 ) ITM_PL2 
	where ITM_PL2.ITEM_ID is not null and  ByPltform=1 

	------------------------------END-------------------------------
	 
	 --Update pltformid for item which has single platfrom configuration 
	 update A SET A.platformId=uniqPltform.PLTF_ID_ from #PLATFORM_ITEMS A 
	 inner join (
	 select  PLD.PLTF_ID_,	 AllItems.ItemId,AllItems.BuId,AllItems.L2Id
	 from #PLATFORM_ITEMS   AllItems
	 cross apply(
	 select  ITEM_ID,count(*) as countpltf from  ADM_XRF_ITEM_PLATFORM_L2 PL
	  inner join ADM_MST_PLATFORM_L2 PLD on PLD.ID_=PL.PLATFORM_L2_ID  and PLD.CMD_ID_=AllItems.CommandId and PL.ITEM_ID=AllItems.ItemId
	 group by PL.ITEM_ID
	 having count(*)=1  
	 )ITM_PL2  left join
	 ADM_XRF_ITEM_PLATFORM_L2 PL on PL.ITEM_ID=ITM_PL2.ITEM_ID left join
	 ADM_MST_PLATFORM_L2 PLD on PLD.ID_=PL.PLATFORM_L2_ID and PLD.CMD_ID_=AllItems.CommandId where  PLD.PLTF_ID_ is not null ) as uniqPltform on uniqPltform.ItemId=A.ItemId and uniqPltform.BuId=A.BuId and uniqPltform.L2Id=A.L2Id

	 --------------------------END --------------------------

	 -------------------Item with multiple platfrom configure, get it from maximum consumed platform-----------------
 declare @firstMonth date
declare @lastMonth date


select @lastMonth= dateadd(day,-1,convert(date,cast(year(getdate()) as varchar(4))+'-'+cast(Month(getdate()) as varchar(2))+'-'+'01'))
select @firstMonth= dateadd(month,-24, dateadd(day,-1,convert(date,cast(year(getdate()) as varchar(4))+'-'+cast(Month(getdate()) as varchar(2))+'-'+'01')))

 update A SET A.platformId=uniqPltform.PltfId from #PLATFORM_ITEMS A 
	 inner join (
	 select uniqPltform.PltfId, AllItems.* from #PLATFORM_ITEMS AllItems
	 cross APPLY (
select  ItemId,BuId,L2Id,PltfId,max(Issue) MaxIssue,ROW_NUMBER() OVER( PARTITION BY ItemID,BuId,L2Id  ORDER BY PltfId) AS RowNum from (
select  ITEM_ID as ItemId,BU_ID_ as BuId,L2_ID_ as L2Id,PLTF_ID_ as PltfId,sum(TOTAL_ISSUE_COUNT_) as Issue from LOG_TRN_ITEM_CONSUMPTION_HISTORY
where convert(date,cast(YEAR as varchar(4))+'-'+cast(MONTH_ as varchar(2))+'-01') between @firstMonth and @lastMonth
and ITEM_ID=AllItems.ItemId and BU_ID_=AllItems.BuId and L2_ID_=AllItems.L2Id
group by ITEM_ID,BU_ID_,L2_ID_,PLTF_ID_
having PLTF_ID_ is not null
) as temp
group by ItemId,BuId,L2Id,PltfId
) uniqPltform
where AllItems.platformId is  null and uniqPltform.RowNum=1 ) as uniqPltform on uniqPltform.ItemId=A.ItemId and uniqPltform.BuId=A.BuId and uniqPltform.L2Id=A.L2Id

--------------------------------------END----------------------------------------

----------------------------Take top most platfrom fro remaining item entry ----------------
update A SET A.platformId=uniqPltform.PltfId from #PLATFORM_ITEMS A 
	 inner join (
select allitem.BuId, allitem.L2Id, allitem.ItemId,allitem.PltfId from(
select  AllItems.BuId, AllItems.L2Id, AllItems.ItemId,PLD.PLTF_ID_ as PltfId,row_number() over(partition by AllItems.ItemId order by PLD.PLTF_ID_ ) rownum from #PLATFORM_ITEMS AllItems 
inner join  ADM_XRF_ITEM_PLATFORM_L2 PL on PL.ITEM_ID=AllItems.ItemId 
inner join ADM_MST_PLATFORM_L2 PLD on PLD.ID_=PL.PLATFORM_L2_ID and PLD.CMD_ID_=AllItems.CommandId
where AllItems.platformId is  null ) allitem where rownum=1) as uniqPltform on uniqPltform.ItemId=A.ItemId and uniqPltform.BuId=A.BuId and uniqPltform.L2Id=A.L2Id
--------------------------------END --------------------------------------


------------------------------------INSERT REORDER POINT FOR EACH PLTFORM-----------------------------------

              begin tran
                -- Get new BU,L2,PLTFROM PAIR COUNT
				declare @newRPPlatformCount  bigint
				select  @newRPPlatformCount=
				sum(cnt) from (select count(distinct AllItems.BuId +'-'+AllItems.L2Id+'-'+AllItems.platformId) cnt from  #PLATFORM_ITEMS AllItems
								outer apply (
							select ROID,[REORDER POINT NO] from(
							  SELECT   RO.ID_ ROID,RO.REORDER_POINT_NO_ as [REORDER POINT NO] ,ROW_NUMBER() over( partition by RO.STORE_ID,L2_ID  order by RO.CREATED_ON_ desc) Ranks
							  FROM  LOG_TRN_RPM_REORDER_POINT RO 
							where RO.STATUS_ in ('Created','PartiallyProcessed') and (RO.STORE_ID = AllItems.BuId) AND (RO.L2_ID = AllItems.L2Id)
							AND RO.JOB_REF_PLTFM_ID =isnull(AllItems.platformId,0)
							)RO where RO.Ranks=1)ExistingRO
				where ExistingRO.ROID is null and  ByPltform=1
				group by AllItems.CommandId,AllItems.BuId,AllItems.L2Id,AllItems.platformId)TotalRec

				select @newRPPlatformCount
				--Generate new reorder point number batch table 
				IF @newRPPlatformCount > 0 
				BEGIN
					DECLARE @numberGeneratorParam1 esnaadm.Type_NumberGeneratorParam
					INSERT @numberGeneratorParam1 values(YEAR(GETDATE()),null,@newRPPlatformCount)

					DECLARE @generatedRPpltNos TABLE(YEAR_ int, MONTH_ int, FORMATTED_NO_ varchar(40))
					INSERT @generatedRPpltNos exec dbo.[GenerateSequenceNumbers] 'RP',@numberGeneratorParam1

						SELECT FORMATTED_NO_, ROW_NUMBER() OVER(PARTITION BY YEAR_ ORDER BY FORMATTED_NO_) AS ROW_
						FROM @generatedRPpltNos


					insert  into LOG_TRN_RPM_REORDER_POINT 
					select (SELECT CAST(CAST(NEWID() AS BINARY(10)) + CAST(GETDATE() AS BINARY(6)) AS UNIQUEIDENTIFIER)),1,AllItem.CommandId, AllItem.BuId,AllItem.L2Id,'Created','SYSTEM','SYSTEM','SYSTEM',getdate(),null,null,null,null,null
					,RP.FORMATTED_NO_,AllItem.platformId
					from
					(select AllItems.CommandId, AllItems.BuId,AllItems.L2Id,AllItems.platformId, ROW_NUMBER() OVER( ORDER BY AllItems.BuId,AllItems.L2Id) AS ROW_
					from  #PLATFORM_ITEMS AllItems
									outer apply (
								select ROID,[REORDER POINT NO] from(
								  SELECT   RO.ID_ ROID,RO.REORDER_POINT_NO_ as [REORDER POINT NO] ,ROW_NUMBER() over( partition by RO.STORE_ID,L2_ID  order by RO.CREATED_ON_ desc) Ranks
								  FROM  LOG_TRN_RPM_REORDER_POINT RO 
								where RO.STATUS_ in ('Created','PartiallyProcessed') and (RO.STORE_ID = AllItems.BuId) AND (RO.L2_ID = AllItems.L2Id)
								AND RO.JOB_REF_PLTFM_ID =AllItems.platformId 
								)RO where RO.Ranks=1)ExistingRO
					where ExistingRO.ROID is  null and  ByPltform=1
					group by AllItems.CommandId,AllItems.BuId,AllItems.L2Id,AllItems.platformId
					)AllItem
					left join
					 (
		   				SELECT FORMATTED_NO_, ROW_NUMBER() OVER(PARTITION BY YEAR_ ORDER BY FORMATTED_NO_) AS ROW_
						FROM @generatedRPpltNos
					 ) RP ON RP.ROW_ = AllItem.ROW_
		
					--select * from LOG_TRN_RPM_REORDER_POINT order by CREATED_ON_ desc
				end

					--- Create Reorder point detail entry for each item 
				insert  into LOG_TRN_RPM_REORDER_POINT_ITEM
				select (SELECT CAST(CAST(NEWID() AS BINARY(10)) + CAST(GETDATE() AS BINARY(6)) AS UNIQUEIDENTIFIER)),
				1,AllItems.ItemId,AllItems.PartNo,AllItems.CageCode,AllItems.Nomenclature,AllItems.IsSerilzed,null,'Created',ExistingRO.ROID,null,null  from  #PLATFORM_ITEMS AllItems
				outer apply (
							select ROID from(
							  SELECT   RO.ID_ ROID,RO.REORDER_POINT_NO_ as [REORDER POINT NO] ,ROW_NUMBER() over( partition by RO.STORE_ID,L2_ID  order by RO.CREATED_ON_ desc) Ranks
							  FROM  LOG_TRN_RPM_REORDER_POINT RO 
							where RO.STATUS_ in ('Created','PartiallyProcessed') and (RO.STORE_ID = AllItems.BuId) AND (RO.L2_ID = AllItems.L2Id) 
							AND RO.JOB_REF_PLTFM_ID =AllItems.platformId  
							)RO where RO.Ranks=1)ExistingRO
				where ExistingRO.ROID is not  null and  ByPltform=1
             commit  


drop table #LOG_MST_RPM_REORDER_CONFIG
drop table #ALL_ITEMS
drop table #PLATFORM_ITEMS
END
go

