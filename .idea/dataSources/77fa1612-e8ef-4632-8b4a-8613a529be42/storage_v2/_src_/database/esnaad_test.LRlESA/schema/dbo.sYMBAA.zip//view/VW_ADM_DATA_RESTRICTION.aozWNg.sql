CREATE VIEW [dbo].[VW_ADM_DATA_RESTRICTION]
AS
SELECT     r1.ID_, r1.CODE_, r1.NAME_, r1.TYPE_NAME_, 
                      CASE r1.TYPE_NAME_ WHEN 'Force' THEN r1.ID_ WHEN 'Command' THEN r1.PRNT_ID WHEN 'Battalion' THEN r2.PRNT_ID WHEN 'Company' THEN r3.PRNT_ID END
                       AS FORCE_ID_, CASE r1.TYPE_NAME_ WHEN 'Command' THEN r1.ID_ WHEN 'Battalion' THEN r1.PRNT_ID WHEN 'Company' THEN r2.PRNT_ID END AS CMD_ID_, 
                      CASE r1.TYPE_NAME_ WHEN 'Battalion' THEN r1.ID_ WHEN 'Company' THEN r1.PRNT_ID END AS BTLN_ID_, 
                      CASE r1.TYPE_NAME_ WHEN 'Company' THEN r1.ID_ END AS COY_ID_, r1.CAN_ASSIGN_TAIL_FROM_OTHER_UNIT_
FROM         dbo.ADM_MST_RESTRICTIONS AS r1 LEFT OUTER JOIN
                      dbo.ADM_MST_RESTRICTIONS AS r2 ON r1.PRNT_ID = r2.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_RESTRICTIONS AS r3 ON r2.PRNT_ID = r3.ID_
go

