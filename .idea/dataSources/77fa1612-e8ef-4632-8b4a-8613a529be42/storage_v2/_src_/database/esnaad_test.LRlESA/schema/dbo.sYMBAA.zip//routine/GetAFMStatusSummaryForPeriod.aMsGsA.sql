create function dbo.GetAFMStatusSummaryForPeriod (@PlatformId bigint, @TailUnitId bigint, @FromDateTime datetime, @ToDateTime datetime)
returns @AFMSummary table (
	PlatformId bigint,
	TailUnitId bigint,
	StatusId int,
	SysId int,
	Mins bigint
)
as
begin

	declare @_PlatformId bigint;
	declare @_TailunitId bigint;
	declare @_FromDate datetime;
	declare @_ToDate datetime;

	set @_PlatformId = @PlatformId
	set @_TailunitId = @TailUnitId
	set @_FromDate = @FromDateTime
	set @_ToDate = @ToDateTime

    --split period between the input date as running sequence of minutes
	declare @TotalMinuteCount bigint;
	set @TotalMinuteCount = (select datediff_big(minute,@_FromDate,@_ToDate));

	declare @StatusByMinutes table (PlatformId bigint, TailUnitId bigint, MinuteSequence bigint, StatusId int, SysId int, Priority tinyint);
	
    --prepare a table for each tail, having @TotalMinuteCount number of records
	insert	into @StatusByMinutes (PlatformId, TailUnitId, MinuteSequence, StatusId, SysId, Priority)
	select	tails.PlatformId,
			tails.TailUnitId,
			ds.MinuteSequence,
			convert(int, null) StatusId,
			convert(int, null) SysId,
			convert(tinyint, null) [Priority]
	from	(
			select	top (@TotalMinuteCount) 
					row_number() over (order by (select null)) as MinuteSequence
			from	dbo.MNT_TRN_FAULT_UNITS t1 cross join dbo.MNT_TRN_FAULT_UNITS t2 
			--using a large table cross join just to get the total records upto the count. not using contents of the table
			) as ds
			join es_dataminer.VW_ALL_TAILS tails on tails.PlatformId = @_PlatformId and tails.TailUnitId = isnull(@_TailunitId, tails.TailUnitId);
	

	declare @CandidateFaults table (PlatformId bigint, TailUnitId bigint, FaultStatusId int, FaultSysId int, [Priority] tinyint, FaultInfoDate datetime, FaultCloseDate datetime, FromMinuteSeq bigint, ToMinuteSeq bigint);
	
    --fetch candidate faults within the period
    --code in the function is from NhAfmMonthlyReturnFinder.FindMonthlyReturnData
	insert	into @CandidateFaults (PlatformId, TailUnitId, FaultStatusId, FaultSysId, [Priority], FaultInfoDate, FaultCloseDate, FromMinuteSeq, ToMinuteSeq)
	select	ds.PlatformId, ds.TailUnitId, ds.FaultStatusId, ds.FaultSysId, ds.[Priority], ds.FaultInfoDate, ds.FaultCloseDate, ds.FromMinuteSeq, ds.ToMinuteSeq
	from	dbo.GetFaultDates(@_PlatformId, @_TailunitId, @_FromDate, @_ToDate) ds


    --for each fetched fault, convert fault begin date and end date into the minute sequence
	update	cf
	set		FromMinuteSeq =  DATEDIFF_BIG(minute, @_FromDate, cf.FaultInfoDate),
			ToMinuteSeq = DATEDIFF_BIG(minute, @_FromDate, cf.FaultCloseDate)
	from	@CandidateFaults cf;


    --for each priority of the candidate faults, beginning with biggest priority, update the @StatusByMinutes table 
    --this will update each minute in the period, the highest fault status id of that period
	declare	record_cursor cursor for
	select	distinct [Priority] from @CandidateFaults order by [Priority] desc;
	declare	@PriorityIterator tinyint;

	open	record_cursor
	fetch	next from record_cursor into @PriorityIterator;

	while	@@FETCH_STATUS = 0
	begin

		update	st
		set		StatusId = cf.FaultStatusId,
				SysId = cf.FaultSysId,
				[Priority] = cf.[Priority]
		from	@StatusByMinutes st
				join @CandidateFaults cf on  st.MinuteSequence between cf.FromMinuteSeq and cf.ToMinuteSeq and cf.PlatformId = st.PlatformId and cf.TailUnitId = st.TailUnitId
		where	cf.[Priority] = @PriorityIterator
				and st.StatusId is null
		
		fetch	next from record_cursor into @PriorityIterator;
	end

	close record_cursor
	deallocate record_cursor


	insert	into @AFMSummary (PlatformId, TailUnitId, StatusId, SysId, Mins)
	select	st.PlatformId, st.TailUnitId, st.StatusId, st.SysId, count(1) Mins
	from	@StatusByMinutes st
			join ADM_MST_SIMPLE_REF sref on st.StatusId = sref.ID_
	--group	by rollup (st.PlatformId, st.TailUnitId, sref.CODE_)
	group	by st.PlatformId, st.TailUnitId, st.StatusId, st.SysId

	return;
end
go

