CREATE FUNCTION [dbo].[GetActiveTailsCount] 
(
      @CommandId		int,
      @PlatformId       int,
	  @PlatformVar		varchar(3)
)
RETURNS int
AS
BEGIN
	DECLARE @result int

	IF @PlatformVar IS NULL
	BEGIN
        SELECT @result = COUNT(*) 
		FROM ADM_MST_TAILS as t
			JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
			JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
			JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
			LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
			LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
		WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NULL
	END
	ELSE
    BEGIN
        SELECT @result = COUNT(*) 
		FROM ADM_MST_TAILS as t
			JOIN ADM_MST_RESTRICTIONS as batt on batt.ID_ = t.BATLN_ID
			JOIN ADM_MST_UNITS as u on u.ID_ = t.UNIT_ID
			JOIN ADM_MST_PLATFORMS as p on p.ID_ = u.ITEM_ID
			LEFT JOIN dbo.ADM_MST_TAIL_VARIANT AS t_var ON t_var.ID_ = t.UNIT_ID
			LEFT JOIN dbo.ADM_MST_PLATFORM_VARIANT AS p_var ON p_var.ID_ = t_var.PLTF_VARIANT_ID 
		WHERE batt.PRNT_ID = @CommandId	and p.ID_ = @PlatformId and t.END_DATE_ = cast('12/31/9999' as date) AND t_var.ID_ IS NOT NULL
    END

	RETURN @result
END
go

