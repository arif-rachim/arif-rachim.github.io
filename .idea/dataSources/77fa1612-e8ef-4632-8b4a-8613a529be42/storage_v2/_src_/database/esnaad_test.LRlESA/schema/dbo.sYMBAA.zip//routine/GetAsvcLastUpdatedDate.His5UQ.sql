CREATE FUNCTION [dbo].[GetAsvcLastUpdatedDate]
(
	-- Add the parameters for the function here
	@ModifiedUserId		nvarchar(255),
	@Id					bigint
)
RETURNS nvarchar(255)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @result nvarchar(255)
   
    -- Add the T-SQL statements to compute the return value here
	IF @ModifiedUserId IS NOT NULL AND @ModifiedUserId <> ''
	BEGIN
		SELECT @result = CONVERT(VARCHAR,MOD_ON_,113) FROM MNT_TRN_AIRCRAFT_SERVS WHERE ID_ = @Id
	END
	ELSE
	BEGIN
		SELECT @result = CONVERT(VARCHAR,CREATED_ON_,113) FROM MNT_TRN_AIRCRAFT_SERVS WHERE ID_ = @Id
	END
	
	-- Return the result of the function
	RETURN @result
END
go

