CREATE   PROC dbo.adm_stockcard_saveinfo 
(
	@finalquoteid uniqueidentifier = null
)
AS
BEGIN
	declare @itemid bigint  
	declare @buid bigint 
	declare @agl2id bigint 

	select 
		@itemid = rpf.ITEM_ID, @buid = rpf.TFU_ID_, @agl2id = rpf.L2_ID_ 
	from 
		LOG_TRN_RFQ_REPAIR_FINAL_QUOTATION fqa join
		LOG_TRN_RPR_REPAIR_FILE rpf on rpf.ID_ = fqa.REPAIR_FILE_ID_
	where
		fqa.ID_ = @finalquoteid

	--delete
	delete from [LOG_TRN_FQA_STOCK_SNAPSHOPT] where RFQA_ID_ = @finalquoteid
	-- insert
	INSERT INTO [LOG_TRN_FQA_STOCK_SNAPSHOPT]
		SELECT        
			@finalquoteid, MainStore, AgL2, Uom, Stock, NonIssuableStock, ShippedOutside, DuesInConfirmed, DuesInNotConfirmed, DuesOutUser, DuesOutStore,  StockDate
		FROM            
			dbo.adm_getstockcardinfo(@itemid, @buid, @agl2id)
	
	RETURN 
END
go

