CREATE FUNCTION [dbo].[GetStockQtyTransferRequestItem]
(
	-- Add the parameters for the function here
	@StoreTransferId		uniqueidentifier,
	@FulfillingBuId			int,
	@TransferRequestItem    uniqueidentifier
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @result int
   
    -- Add the T-SQL statements to compute the return value here
	SELECT @result = ISNULL(SUM(S.QTY_),0) 
					 FROM LOG_TRN_TRM_TRANSFER_REQUEST_ITEM TRI
					 INNER JOIN ADM_MST_ITEMS I ON TRI.ITEM_ID_ = I.ID_
					 INNER JOIN ADM_MST_UNITS U ON U.ITEM_ID = I.ID_
					 INNER JOIN LOG_TRN_STOCK S ON S.UNIT_ID = U.ID_
					 INNER JOIN ADM_MST_UNIT_LOCATION L ON S.LOC_ID = L.ID_
					 INNER JOIN ADM_MST_UNIT_LOCATION_GROUP LG ON LG.ID_ = L.LG_ID		
					 WHERE TRI.TR_ID = @StoreTransferId AND LG.BU_ID = @FulfillingBuId
					 AND TRI.ID_ = @TransferRequestItem
	
	-- Return the result of the function
	RETURN @result
END
go

