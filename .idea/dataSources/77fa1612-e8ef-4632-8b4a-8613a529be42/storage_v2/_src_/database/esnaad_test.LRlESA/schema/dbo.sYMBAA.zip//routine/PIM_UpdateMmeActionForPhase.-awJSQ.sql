CREATE PROCEDURE [dbo].[PIM_UpdateMmeActionForPhase](
 @mmeRosterId bigint,
 @pUserProfileId bigInt,
 @pTerm nvarchar(max)
 )
As 
Begin



	DECLARE	@CreatedBy nvarchar(255), @Pid_Created_By nvarchar(255), @FullName_Created_By nvarchar(255);
	DECLARE @hostName VARCHAR(MAX) = HOST_NAME();
	SELECT @CreatedBy=USER_ID_,@Pid_Created_By=PID_,@FullName_Created_By=F_NAME_ + ' '+L_NAME_ FROM ADM_TRN_USER_PROFILES WHERE ID_=@pUserProfileId
	
	DECLARE @CREATED_ON DATETIME
    SET @CREATED_ON=GETDATE();

	select distinct PHASE_INSP_ID into #Inspections_phase 
	FROM MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS WHERE  MME_ROSTER_ID_=@mmeRosterId 

	ALTER TABLE #Inspections_phase 
	ADD mmeFirstIndex int,
	currentMmeCount int,
	indexToBeAdded int


	declare @mmeActionCount int
	select @mmeActionCount=COUNT(*) from MNT_MST_MME_ACTIONS where ROSTER_ID=@mmeRosterId

	Begin tran


		update CTE set CTE.mmeFirstIndex=mmeact.IDX_ from  #Inspections_phase CTE 
		cross apply
		(
		 select top 1 IDX_ from MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS act
		 where act.PHASE_INSP_ID=CTE.PHASE_INSP_ID 
		 and act.MME_ROSTER_ID_=@mmeRosterId 
		 order by act.IDX_
		) mmeact

		update CTE set CTE.currentMmeCount=mmeact.currentMmeCount from  #Inspections_phase CTE 
		cross apply
		(
		 select count(*) as currentMmeCount from MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS act
		 where act.PHASE_INSP_ID=CTE.PHASE_INSP_ID 
		 and act.MME_ROSTER_ID_=@mmeRosterId 
		
		) mmeact

		update CTE set CTE.indexToBeAdded=@mmeActionCount-CTE.currentMmeCount from  #Inspections_phase CTE 

		-- delete  mme roaster actions from all inspection
		delete act from MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS act join
		#Inspections_phase CTE  on CTE.PHASE_INSP_ID=act.PHASE_INSP_ID
		where  act.MME_ROSTER_ID_=@mmeRosterId;

		-- if  adhoc action exist , To update index for remaining adhoc action after removing mme records 
		update act set act.IDX_= iif(act.IDX_>CTE.mmeFirstIndex and CTE.indexToBeAdded>0,act.IDX_+CTE.indexToBeAdded,act.IDX_)
		from MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS act join
		#Inspections_phase CTE  on CTE.PHASE_INSP_ID=act.PHASE_INSP_ID

		--insert 
		insert into MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS (PHASE_INSP_ID,MME_ROSTER_ID_,STATUS_ID,ACTION_,IDX_,LEGACY_COLUMN__Phase_Area_InspActionSubstr)
		select CTE.PHASE_INSP_ID,mmeact.ROSTER_ID, STATUS_ID,upper(mmeact.RMA_),
		(CTE.mmeFirstIndex-1)+ (ROW_NUMBER() over (partition by  PHASE_INSP_ID order by mmeact.ORDER_)),null
		from MNT_MST_MME_ACTIONS mmeact
		join #Inspections_phase CTE  on 1=1
		where ROSTER_ID=@mmeRosterId
		order by PHASE_INSP_ID,mmeact.ORDER_

		update inspDetail
		set INSP_ACTIONS_COUNT_=(select count(*) from MNT_TRN_PIM_PHASE_INSPECTION_ACTIONS where PHASE_INSP_ID=inspDetail.ID_) 
		from MNT_TRN_PIM_PHASE_INSPECTION inspDetail inner join
		#Inspections_phase CTE on CTE.PHASE_INSP_ID=inspDetail.ID_


    commit

	  drop table if exists #Inspections_phase

end
go

