CREATE FUNCTION [dbo].[GetAircraftFlyHrsForAPeriodFromUnitUsageDetails] 
(
	@start_date datetime,
	@end_date datetime,
	@tail_id bigint
)
RETURNS decimal(9,2) -- fly hrs
AS
BEGIN
	-- Declare variables
	DECLARE @tamms_return_time decimal(9,2) 
	DECLARE @hourPart decimal(9,3) 
	DECLARE @minutePart decimal(9,3) 

	if(@start_date is not null)
	begin

		SELECT @tamms_return_time = 0
		
		
		SELECT @tamms_return_time = SUM(dbo.ReturnTAAMSTime(FLIGHT_MINS_))
		FROM ADM_TRN_UNIT_USAGE_DETAIL
		WHERE 
				DATE_ BETWEEN @start_date AND @end_date
			AND
				UNIT_ID_ = @tail_id
		

	end
	
	RETURN ISNULL(@tamms_return_time ,0)

END

go

