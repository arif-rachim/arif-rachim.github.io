CREATE FUNCTION [dbo].[GetTotalAchievedRequirementHoursByUnitAndPlatformAndRequirement]
(
	@unitId bigint,
	@platformId bigint,
	@year int,
	@requirementId uniqueidentifier
)
RETURNS bigint
AS
BEGIN
	DECLARE @result bigint
	SELECT @result = ISNULL(SUM(PR.HOURS_IN_MINS_),0)*60
					 FROM OPS_TRN_CREW_PERFORMED_REQUIREMENTS PR
						JOIN OPS_TRN_CTP_CREW_MONTHLY_PLAN_REQUIREMENT MPR ON MPR.ID_ = PR.RECORDED_PLANNED_REQ_ID AND MPR.MINUTES_>0 
						JOIN OPS_TRN_CTP_CREW_MONTHLY_PLAN CMP ON CMP.ID_ = MPR.CREW_MONTHLY_PLAN_ID
						JOIN OPS_TRN_CTP_MONTHLY_PLAN MP ON MP.ID_ = CMP.MONTHLY_PLAN_ID
					 WHERE PR.COY_ID = @unitId AND MP.PLTF_ID_ = @platformId AND MP.YEAR_ = @year AND MPR.REQUIREMENT_ID = @requirementId 
	RETURN @result 
END
go

