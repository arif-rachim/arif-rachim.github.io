CREATE FUNCTION [dbo].[SL_GetStockLevelDetails](@storeId int, @itemId int, @agl2Id int, @startDate date, @endDate datetime, @isIncludeInLieu bit, @isIncludeFromSubStore bit)
RETURNS TABLE AS 
RETURN (
	WITH D AS (
		    SELECT @endDate Date
			union all
			SELECT CONVERT(DATETIME, DATEFROMPARTS(YEAR(DATEADD(m,-1,Date)), MONTH(DATEADD(m,-1,Date)), 1))
			FROM D
			WHERE Date > DATEADD(m,-11,@endDate)
	),
	SL AS (
		SELECT IA.ITEM_ID, SL.MIN_, SL.MAX_, SL.SAFETY_, SL.WAR_RESERVE_, SL.VALID_FROM_, SL.VALID_TO_ 
		FROM LOG_TRN_STOCK_LEVEL2 FOR SYSTEM_TIME BETWEEN @startDate AND @endDate SL
		JOIN ADM_TRN_ITEM_ASSOCS IA ON IA.ID_ = SL.ITEM_ASSOC_ID_
		WHERE IA.ITEM_ID = @itemId AND IA.L2_ID = @agl2Id AND SL.STORE_ID = @storeId 
	),
	ST AS (
    	select  DATEADD(d,1,EOMONTH(CheckDate,-1)) as VALID_FROM_,DATEADD(d,-1, DATEADD(m,1,CheckDate))  as VALID_TO_,qty as QTY_ 
		from(
           select * from [dbo].[SL_GetLastDates](DATEADD(d,1,getDate())) as LastDate
		     outer apply
		     (
		       select * from [dbo].[SL_GetStockInfoMain](LastDate.CheckDate,@itemId,@isIncludeInLieu,@isIncludeFromSubStore,@storeId,@agl2Id)
		     )imv
		  ) Stock
	),
	ST2 AS (
		SELECT D.Date,ST.QTY_ QTY_ FROM ST
		JOIN D ON D.Date BETWEEN CAST(ST.VALID_FROM_ AS DATE) AND CAST(ST.VALID_TO_ AS DATE)
		--GROUP BY D.Date
	),
	SL2 AS (
		SELECT SL3.Date, SL3.MIN_, SL3.MAX_, SL3.SAFETY_, SL3.WAR_RESERVE_ FROM (
			SELECT D.Date, SL.MIN_, SL.MAX_, SL.SAFETY_, SL.WAR_RESERVE_, ROW_NUMBER() OVER(PARTITION BY D.DATE ORDER BY SL.VALID_TO_ DESC) ROW_
			FROM SL
			JOIN D ON D.Date BETWEEN CAST(SL.VALID_FROM_ AS DATE) AND CAST(SL.VALID_TO_ AS DATE)
		) SL3
		WHERE SL3.ROW_ = 1
	)
	SELECT D.Date,ISNULL(ST2.QTY_,0) Stocks , ISNULL(SL2.MIN_, 0) SlMin, ISNULL(SL2.MAX_,0) SlMax, ISNULL(SL2.SAFETY_,0) SlSafety, ISNULL(SL2.WAR_RESERVE_ , 0) SlWar
	FROM D
	LEFT JOIN ST2 ON ST2.Date = D.Date
	LEFT JOIN SL2 ON SL2.Date = D.Date
)
go

