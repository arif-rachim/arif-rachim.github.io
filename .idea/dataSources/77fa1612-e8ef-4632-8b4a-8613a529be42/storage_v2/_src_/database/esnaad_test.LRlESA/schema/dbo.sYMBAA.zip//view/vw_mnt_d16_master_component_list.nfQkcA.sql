CREATE VIEW [dbo].[vw_mnt_d16_master_component_list]
AS
SELECT     MST.ID_ AS Id, ci.ID_ AS ItemId, MST.L2_ID_ AS ItemAssocId, ci.PART_NO_ AS PartNo, ci.NSN_ AS Nsn, ci.NOMENCLATURE_ AS Nomenclature, 
                      FSC.CODE_ AS FscCode, COS.CODE_ AS CosCode, MST.REP_TYPE_ AS CatCode, MST.OVR_ACFT_HRS_ AS OverhaulHours, MST.OVR_LDGS_ AS OverhaulLandings, 
                      MST.OVR_CAL_VALUE_ AS OverhaulCalendarUnitValue, MST.OVR_CAL_UNIT_ AS OverhaulCalendarUnit, MST.REP_ACFT_HRS_ AS ReplaceHours, 
                      MST.REP_LDGS_ AS ReplaceLandings, MST.REP_CAL_VALUE_ AS ReplaceCalendarUnitValue, MST.REP_CAL_UNIT_ AS ReplaceCalendarUnit, ISNULL
                          ((SELECT     COUNT(ID_) AS Expr1
                              FROM          dbo.MNT_TRN_D16_ASSIGNED_COMPONENT
                              WHERE      (MST_COMP_ID_ = MST.ID_) AND (REM_DATE_ IS NULL)), 0) AS NumberOfAssigned, MST.CREATED_BY_ AS CreatedUserUser, 
                      MST.CREATED_ON_ AS CreatedOn, MST.PID_CREATED_BY_ AS CreatedPid, MST.FULL_NAME_CREATED_BY_ AS CreatedUserName, 
                      MST.MOD_BY_ AS LastModifiedUser, MST.MOD_ON_ AS LastModifiedOn, MST.PID_MOD_BY_ AS LastModifiedPid, 
                      MST.FULL_NAME_MOD_BY_ AS LastModifiedName, MST.CMD_ID_, MST.MAJOR_END_ITEM_ID_, 
                      case when MST.LINKED_FAULT_COUNT_ is null then 0 else MST.LINKED_FAULT_COUNT_ end as NumberOfActiveFault
FROM         dbo.MNT_MST_D16_MASTER_COMPONENT AS MST INNER JOIN
                      dbo.ADM_MST_ITEMS AS mei ON mei.ID_ = MST.MAJOR_END_ITEM_ID_ INNER JOIN
                      dbo.ADM_MST_ITEMS AS ci ON ci.ID_ = MST.COMP_ITEM_ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS FSC ON ci.FSC_ID = FSC.ID_ LEFT OUTER JOIN
                      dbo.ADM_MST_SIMPLE_REF AS COS ON ci.COS_ID = COS.ID_
go

