CREATE FUNCTION [dbo].[ConvertMinutesToHourMinSecString]
(
	@totalSeconds BIGINT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @hourPart BIGINT;
	DECLARE @minutesRem INT;
	DECLARE @minPart INT;
	DECLARE @secPart INT;
	
	-- Find Hr
	SET @hourPart = @totalSeconds / 3600
	SET @minutesRem = @totalSeconds % 3600;
	
	-- Find Min & Sec
	SET @minPart = @minutesRem / 60;
	SET @secPart = @minutesRem % 60;
	
	RETURN CONVERT(VARCHAR(MAX), @hourPart) + ' hr ' + CONVERT(VARCHAR(MAX), @minPart) + ' min ' + CONVERT(VARCHAR(MAX), @secPart) + ' sec';
END
go

