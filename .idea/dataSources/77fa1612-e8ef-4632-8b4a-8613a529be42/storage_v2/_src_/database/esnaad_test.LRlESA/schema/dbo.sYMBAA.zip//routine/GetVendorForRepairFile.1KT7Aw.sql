CREATE FUNCTION [dbo].[GetVendorForRepairFile] (
      @repairFileNo NVARCHAR(50),
      @repairFileStatus NVARCHAR(20))
RETURNS NVARCHAR(50)
AS
BEGIN

      DECLARE @venderCode NVARCHAR(50)
      DECLARE @repairStatus NVARCHAR(50)

      /* 
      RepairFileCreated,
    RFQCreated,
    RFQValidated,
    Quoted,
    RFQDeleted,
    BidAnalysisCreated,
    BidAnalysisEvaluated,
   BidAnalysisValidated,
    CaseCreated,
    CaseDeleted,
    ShipmentPrepared,
    Shipped,
    RepairOrderCreated,
    RepairOrderValidated,
    RepairOrderDeleted,
    RepairOrderClosed 
      */

      IF (@repairFileStatus = 'CaseCreated'
            OR @repairFileStatus = 'CaseDeleted')
            SET @repairStatus = 'Case'
      ELSE
      IF (@repairFileStatus = 'ShipmentPrepared'
            OR @repairFileStatus = 'ShipmentApproved'
            OR @repairFileStatus = 'Shipped')
            SET @repairStatus = 'Ship'
      ELSE
      IF (@repairFileStatus = 'RFQCreated'
            OR @repairFileStatus = 'RFQValidated'
            OR @repairFileStatus = 'Quoted'
            OR @repairFileStatus = 'RFQDeleted')
            SET @repairStatus = 'Rfq'
      ELSE
      IF (@repairFileStatus = 'BidAnalysisCreated'
            OR @repairFileStatus = 'BidAnalysisEvaluated'
            OR @repairFileStatus = 'BidAnalysisValidated')
            SET @repairStatus = 'Bid'
      ELSE
      IF (@repairFileStatus = 'RepairOrderCreated'
            OR @repairFileStatus = 'RepairOrderValidated'
            OR @repairFileStatus = 'RepairOrderCancelled'
            OR @repairFileStatus = 'RepairOrderDeleted'
            OR @repairFileStatus = 'FinalQuoteUpdated'
            OR @repairFileStatus = 'FinalQuoteAwaiting'
            OR @repairFileStatus = 'FinalQuoteAccepted'
            OR @repairFileStatus = 'FinalQuoteRejected'
            OR @repairFileStatus = 'RepairOrderClosed'
            OR @repairFileStatus = 'Closed'
            )
            SET @repairStatus = 'Repair'

      IF (@repairStatus = 'Case')
      BEGIN
            
			SELECT
                 @venderCode = sup.CODE_
            FROM LOG_TRN_RSM_SHIPMENT_CASE_ITEM
            INNER JOIN LOG_TRN_RSM_SHIPMENT_CASE
                  ON LOG_TRN_RSM_SHIPMENT_CASE_ITEM.SHIPMENT_CASE_ID_ = LOG_TRN_RSM_SHIPMENT_CASE.ID_
			INNER JOIN ADM_MST_SUPPLIER sup on LOG_TRN_RSM_SHIPMENT_CASE.SUP_ID = sup.ID_
            WHERE LOG_TRN_RSM_SHIPMENT_CASE_ITEM.REPAIR_FILE_NO_ = @repairFileNo
			
			/*SELECT
                  @venderCode = LOG_TRN_RSM_SHIPMENT_CASE.SUP_CODE_
            FROM LOG_TRN_RSM_SHIPMENT_CASE_ITEM
            INNER JOIN LOG_TRN_RSM_SHIPMENT_CASE
                  ON LOG_TRN_RSM_SHIPMENT_CASE_ITEM.SHIPMENT_CASE_ID_ = LOG_TRN_RSM_SHIPMENT_CASE.ID_
            WHERE LOG_TRN_RSM_SHIPMENT_CASE_ITEM.REPAIR_FILE_NO_ = @repairFileNo*/
      END
      ELSE
      IF (@repairStatus = 'Ship')
      BEGIN
            
			SELECT
                 @venderCode = sup.CODE_
            FROM LOG_TRN_RSM_SHIPMENT_ITEM
            INNER JOIN LOG_TRN_RSM_SHIPMENT
                  ON LOG_TRN_RSM_SHIPMENT_ITEM.SHIPMENT_ID_ = LOG_TRN_RSM_SHIPMENT.ID_
			INNER JOIN ADM_MST_SUPPLIER SUP on LOG_TRN_RSM_SHIPMENT.SUP_ID= sup.ID_
            WHERE LOG_TRN_RSM_SHIPMENT_ITEM.REPAIR_FILE_NO_ = @repairFileNo


			/*SELECT
                  @venderCode = LOG_TRN_RSM_SHIPMENT.SUP_CODE_
            FROM LOG_TRN_RSM_SHIPMENT_ITEM
            INNER JOIN LOG_TRN_RSM_SHIPMENT
                  ON LOG_TRN_RSM_SHIPMENT_ITEM.SHIPMENT_ID_ = LOG_TRN_RSM_SHIPMENT.ID_
            WHERE LOG_TRN_RSM_SHIPMENT_ITEM.REPAIR_FILE_NO_ = @repairFileNo*/
      END
      ELSE
      IF (@repairStatus = 'Rfq')
      BEGIN
            SET @venderCode = NULL
      END
      ELSE
      IF (@repairStatus = 'Bid')
      BEGIN
            SET @venderCode = NULL
            --SELECT   @venderCode=SUP_CODE_        FROM     LOG_TRN_BAM_REPAIR_SUPPLIER_RESP    WHERE    (SELECTED_ = 1) AND  REQ_REPAIR_FILE_NO_= @repairFileNo
      END
      ELSE
      IF (@repairStatus = 'Repair')
      BEGIN
            SELECT
                  @venderCode = S.CODE_
            FROM LOG_TRN_ROM_REPAIR_ORDER_ITEM item JOIN ADM_MST_SUPPLIER S ON S.ID_ = item.SUP_ID
            WHERE item.REPAIR_FILE_REF_ = @repairFileNo
      END


      RETURN @venderCode
END
go

