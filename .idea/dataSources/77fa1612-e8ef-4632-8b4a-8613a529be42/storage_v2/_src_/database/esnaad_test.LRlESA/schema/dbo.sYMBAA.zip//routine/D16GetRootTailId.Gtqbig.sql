CREATE FUNCTION [dbo].[D16GetRootTailId] (@AssignedComponentId uniqueidentifier)
RETURNS TABLE
AS RETURN
    WITH AssignedComponent AS
        (
            SELECT ac.ACFT_UNIT_ID_, ac.ID_, ac.PARENT_COMP_ID_,  mc.LEVEL_, ac.REM_P_HRS_
            FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
            JOIN MNT_MST_D16_MASTER_COMPONENT mc ON mc.ID_ = ac.MASTER_COMP_ID_
            WHERE ac.ID_ = @AssignedComponentId
            UNION ALL
            SELECT p_ac.ACFT_UNIT_ID_, p_ac.ID_, p_ac.PARENT_COMP_ID_, mc.LEVEL_, p_ac.REM_P_HRS_
            FROM MNT_TRN_D16_ASSIGNED_COMPONENT p_ac
            JOIN MNT_MST_D16_MASTER_COMPONENT mc ON mc.ID_ = p_ac.MASTER_COMP_ID_
            JOIN AssignedComponent ac ON ac.PARENT_COMP_ID_ = p_ac.COMP_ID_
            and (ac.REM_P_HRS_ >= p_ac.INST_C_HRS_ and (p_ac.REM_DATE_ is null or ac.REM_P_HRS_ <= p_ac.REM_C_HRS_))
        )
    SELECT top(1) t.ID_ FROM AssignedComponent ac
        join MNT_MST_D16_COMPONENT c on c.ID_ = ac.PARENT_COMP_ID_
       join ADM_MST_TAILS t on t.UNIT_ID = c.UNIT_ID_
      WHERE LEVEL_ = 0
go

