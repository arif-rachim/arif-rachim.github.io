CREATE FUNCTION [dbo].[GetRequestedItemEdd]
(@requested_item_id bigint, @cmd_id bigint, @l2_id bigint, @is_inlieu_acceptable bit = 0)

RETURNS datetime	
AS
BEGIN
	declare @output_edd datetime;
	DECLARE @MST_ITEMS_TO_CHECK_PO_EDD TABLE (ID_ BIGINT, SERIALIZED_ bit);


	IF @is_inlieu_acceptable > 0
	BEGIN
		INSERT 
			@MST_ITEMS_TO_CHECK_PO_EDD
		select 
			itm.ID_ as ID_ ,itm.SERIALIZED_ as SERIALIZED_
		from
	
			ADM_TRN_ITEM_ASSOCS ia join ADM_MST_ITEMS itm  on itm.ID_ = ia.ITEM_ID
		where 
			ia.ITEM_ID = @requested_item_id	and ia.L2_ID = @l2_id and ia.IN_LIEU_CODE_ is null
		union all
		select 
			itm.ID_ as ID_ ,itm.SERIALIZED_ as SERIALIZED_
		from
	
			ADM_TRN_ITEM_ASSOCS ia join ADM_TRN_ITEM_ASSOCS iail on ia.IN_LIEU_CODE_ = iail.IN_LIEU_CODE_ and ia.L2_ID = iail.L2_ID  join ADM_MST_ITEMS itm  on itm.ID_ = iail.ITEM_ID
		where 
			ia.ITEM_ID = @requested_item_id	and ia.L2_ID = @l2_id								 
	END
	ELSE
	BEGIN
		INSERT 
			@MST_ITEMS_TO_CHECK_PO_EDD
		select 
			itm.ID_ as ID_ ,itm.SERIALIZED_ as SERIALIZED_
		from
			ADM_MST_ITEMS itm  
		where 
			itm.ID_ = @requested_item_id	
		
	END
	
	SELECT
		@output_edd = MIN(EDD_)
	FROM
	(
		SELECT PROCITEM.ITEM_ID ITEM_ID_, STORE.CMD_ID_, PO.STORE_ID BU_ID_, PO.L2_ID L2_ID_, POITEM.ERD_ EDD_
		FROM            LOG_TRN_PRC_PURCHASE_ORDER PO JOIN
								 ADM_MST_BUSINESS_UNITS STORE ON PO.STORE_ID = STORE.ID_ JOIN
								 LOG_TRN_PRC_PURCHASE_ORDER_ITEM POITEM ON PO.ID_ = POITEM.PO_ID JOIN
								 LOG_TRN_PRC_PROCUREMENT_ITEM PROCITEM ON POITEM.PROC_ITEM_ID = PROCITEM.ID_ JOIN
								 @MST_ITEMS_TO_CHECK_PO_EDD ITM ON ITM.ID_ = PROCITEM.ITEM_ID LEFT OUTER JOIN
								 ADM_MST_ITEM_MEASUREMENT MEAS ON PROCITEM.ITEM_ID = MEAS.ITEM_ID AND POITEM.UOM_ID = MEAS.ALT_UOM_ID_ 
								 LEFT OUTER JOIN
									 (SELECT        DNITEM.PO_ITEM_ID_, SUM(DNITEM.RCV_QTY_) RCV_QTY_, SUM(ISNULL(DNITEM.FOC_QTY_, 0)) FOC_QTY_
									   FROM            LOG_TRN_REC_DELIVERY_NOTE_ITEM DNITEM INNER JOIN
																 LOG_TRN_REC_DELIVERY_NOTE DN ON DNITEM.DN_ID = DN.ID_
									   WHERE        DN.STATUS_ <> 'Created'
									   GROUP BY DNITEM.PO_ITEM_ID_) AS DN ON DN.PO_ITEM_ID_ = POITEM.ID_

		WHERE        
			(PO.STATUS_ <> 'Created' AND PO.STATUS_ <> 'Canceled') 
			AND POITEM.ORDERED_QTY_ > 0 
			AND ((IIF(POITEM.UOM_CONVERSION_ IS NULL
				, ISNULL(MEAS.VAL_, 1)
				,POITEM.UOM_CONVERSION_ * ISNULL(POITEM.TB_CONVERSION_, 1)) * POITEM.ORDERED_QTY_) - (ISNULL(DN.RCV_QTY_, 0) - (CASE WHEN ITM.SERIALIZED_ = 1 THEN ISNULL(DN.FOC_QTY_, 0) ELSE 0 END))) > 0 

	) AS src
	WHERE
		L2_ID_ = @l2_id and CMD_ID_ = @cmd_id
	GROUP BY
		ITEM_ID_, L2_ID_


	RETURN @output_edd
END
go

