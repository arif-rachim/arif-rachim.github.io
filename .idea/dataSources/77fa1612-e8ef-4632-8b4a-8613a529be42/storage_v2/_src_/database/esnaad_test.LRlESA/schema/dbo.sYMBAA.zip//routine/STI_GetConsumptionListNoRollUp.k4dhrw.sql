CREATE PROC [dbo].[STI_GetConsumptionListNoRollUp] (
	@agl2Id bigint,
	@buId bigint,
	@fromYear int,
	@commandId bigint,
	@actualYears int,
	@partNoId bigint
) AS
BEGIN
	SELECT 
		A.ItemId, A.PartNo, A.Nsn, A.Category, A.Uom, A.Nomenclature, A.PblItemType, A.CageCode, A.PrimaryPart, A.ItemClass, A.Maximum, A.Safety, A.WarReserve, 
		A.StockIncludeWaiting, A.ProDuesConfirm, A.ProDuesNotConfirm, A.RepDuesNotConfirm, A.RepDuesConfirm, A.StockExcludeWaiting, B.Yr1Issue, B.Yr2Issue, 
		B.Yr3Issue, B.Yr4Issue, B.Yr1Consumption, B.Yr2Consumption, B.Yr3Consumption, B.Yr4Consumption, B.Yr1TurnIn, B.Yr2TurnIn, B.Yr3TurnIn, B.Yr4TurnIn, 
		B.MaxConsumption, B.ActualYears, A.DuesOutUser, A.AvgPrice, A.LastAvgPrice, A.AvgTat, A.ItemClassId, A.UnderStockTaking
		, B.Yr1RegularizedQty, B.Yr2RegularizedQty, B.Yr3RegularizedQty, B.Yr4RegularizedQty
		, (
			CASE B.ActualYears
				WHEN 1 THEN B.Yr1Consumption
				WHEN 2 THEN B.Yr1Consumption + B.Yr2Consumption
				WHEN 3 THEN B.Yr1Consumption + B.Yr2Consumption + B.Yr3Consumption
				ELSE B.Yr1Consumption + B.Yr2Consumption + B.Yr3Consumption + B.Yr4Consumption
			END
		 ) AS TotalConsumption
	FROM (
			SELECT        
				MainItem.ID_ AS ItemId, MainItem.PART_NO_ AS PartNo, Uom.CODE_ AS Uom, MainItem.NSN_ AS Nsn, SREF.CODE_ + ' - ' + SREF.DESC_ AS Category, 
				MainItem.NOMENCLATURE_ AS Nomenclature, MainItem.PBL_ AS PblItemType, MainMfr.CAGE_CODE_ AS CageCode, 
				ITML2.PRIMARY_PART_ AS IsPrimaryPart, ITML2.IN_LIEU_CODE_ AS InLieuCode, MainRef.CODE_ AS ItemClass, ISNULL(MainStkLevel.MAX_, 0) 
				AS Maximum, ISNULL(MainStkLevel.SAFETY_, 0) AS Safety, ISNULL(MainStkLevel.WAR_RESERVE_, 0) AS WarReserve, 
				ISNULL(SUM(QtySnapShot.TOTAL_STOCK_), 0) AS StockIncludeWaiting, ISNULL(SUM(QtySnapShot.NEW_DUES_IN_CONF_), 0) AS ProDuesConfirm, 
				ISNULL(SUM(QtySnapShot.NEW_DUES_IN_NOT_CONF_), 0) AS ProDuesNotConfirm, ISNULL(SUM(QtySnapShot.RPR_DUES_IN_NOT_CONF_), 0) 
				AS RepDuesNotConfirm, ISNULL(SUM(QtySnapShot.RPR_DUES_IN_CONF_), 0) AS RepDuesConfirm, 
				ISNULL(SUM(QtySnapShot.TOTAL_STOCK_ - (QtySnapShot.STOCK_AWAITING_RECEPTION_ + QtySnapShot.STOCK_AWAITING_LOCATION_)), 0) 
				AS StockExcludeWaiting, MainRef.ID_ AS ItemClassId, ISNULL(SUM(QtySnapShot.USER_DUES_OUT_QTY), 0) AS DuesOutUser, 
				ISNULL(QtySnapShot1.AVG_PRICE, 0) AS AvgPrice, ISNULL(QtySnapShot1.LAST_PROC_PRICE, 0) AS LastAvgPrice, ISNULL(QtySnapShot1.AVG_TAT, 0) 
				AS AvgTat, ISNULL(SUM(QtySnapShot.UNDER_STOCK_TAKING_), 0) AS UnderStockTaking, 
				CASE WHEN ITML2.PRIMARY_PART_ = 1 THEN MainItem.PART_NO_ ELSE
				(
					SELECT I.PART_NO_
					FROM ADM_MST_ITEMS AS I 
					INNER JOIN ADM_TRN_ITEM_ASSOCS AS IA ON IA.ITEM_ID = I.ID_
					WHERE ITML2.IN_LIEU_CODE_ = IA.IN_LIEU_CODE_ AND IA.PRIMARY_PART_ = 1
				) END AS PrimaryPart
			FROM ADM_MST_ITEMS AS MainItem 
			LEFT JOIN ADM_MST_SIMPLE_REF AS SREF ON SREF.ID_ = MainItem.CAT_ID_ 
			INNER JOIN LOG_MST_UNIT_OF_MEASURE AS Uom ON Uom.ID_ = MainItem.UOM_ID_ 
			INNER JOIN ADM_TRN_ITEM_ASSOCS AS ITML2 ON MainItem.ID_ = ITML2.ITEM_ID 
			INNER JOIN ADM_MST_MANUFACTURES AS MainMfr ON MainItem.MNF_ID = MainMfr.ID_ 
			LEFT JOIN ADM_MST_SIMPLE_REF AS MainRef ON MainItem.CLS_ID_ = MainRef.ID_ 
			LEFT OUTER JOIN ADM_TRN_ITEM_ASSOCS AS ASS ON ASS.L2_ID = @agl2Id AND ASS.ITEM_ID = (
				SELECT IA.ITEM_ID                               
				FROM ADM_TRN_ITEM_ASSOCS AS IA                
				WHERE ITML2.IN_LIEU_CODE_ IS NOT NULL          
				AND ITML2.IN_LIEU_CODE_ = IA.IN_LIEU_CODE_   
				AND IA.PRIMARY_PART_ = 1                     
				AND IA.L2_ID = @agl2Id                           
				UNION ALL                                      
				SELECT MainItem.ID_                             
				WHERE ITML2.IN_LIEU_CODE_ IS NULL              
				AND ITML2.PRIMARY_PART_ = 1                  
			 ) 
			 LEFT OUTER JOIN LOG_TRN_STOCK_LEVEL2 AS MainStkLevel ON MainStkLevel.ITEM_ASSOC_ID_ = ASS.ID_ AND MainStkLevel.STORE_ID = @buId AND  ITML2.L2_ID = @agl2Id 
			 LEFT OUTER JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE AS QtySnapShot ON MainItem.ID_ = QtySnapShot.ITEM_ID_ AND QtySnapShot.CMD_ID_ = @commandId 
				AND QtySnapShot.L2_ID_ = @agl2Id 
				AND QtySnapShot.BU_ID_ IN 
				(					
					SELECT @buId AS Expr1
					UNION ALL
					SELECT TFU_ID
					FROM ADM_MST_STORE_TFU_BUSINESS_UNIT
					WHERE (STORE_ID = @buId)
				) 
			LEFT OUTER JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE AS QtySnapShot1 ON MainItem.ID_ = QtySnapShot1.ITEM_ID_ AND QtySnapShot1.CMD_ID_ = @commandId AND QtySnapShot1.L2_ID_ = @agl2Id AND QtySnapShot1.BU_ID_  = @buId
			WHERE (MainItem.GRP_TYPE_ = 'NonAircraft') AND (ITML2.L2_ID = @agl2Id)
			GROUP BY MainItem.ID_, MainItem.PART_NO_, MainItem.NSN_, MainItem.NOMENCLATURE_, MainItem.PBL_, MainMfr.CAGE_CODE_, SREF.CODE_, SREF.DESC_, 
			Uom.CODE_, ITML2.PRIMARY_PART_, ITML2.IN_LIEU_CODE_, MainRef.CODE_, MainStkLevel.MAX_, MainStkLevel.SAFETY_, 
			MainStkLevel.WAR_RESERVE_, MainRef.ID_, QtySnapShot1.AVG_PRICE, QtySnapShot1.LAST_PROC_PRICE, QtySnapShot1.AVG_TAT
	) AS A 
	LEFT OUTER JOIN (
		SELECT ItemId, Yr1Issue, Yr2Issue, Yr3Issue, Yr4Issue, Yr1RegularizedQty, Yr2RegularizedQty, Yr3RegularizedQty,  Yr4RegularizedQty,
		CASE WHEN Yr1Consumption < 0 THEN 0 ELSE Yr1Consumption END AS Yr1Consumption
		, CASE WHEN Yr2Consumption < 0 THEN 0 ELSE Yr2Consumption END AS Yr2Consumption
		, CASE WHEN Yr3Consumption < 0 THEN 0 ELSE Yr3Consumption END AS Yr3Consumption
		, CASE WHEN Yr4Consumption < 0 THEN 0 ELSE Yr4Consumption END AS Yr4Consumption
		, Yr1TurnIn, Yr2TurnIn, Yr3TurnIn, Yr4TurnIn
		, CASE WHEN 
				Yr1Consumption > Yr2Consumption AND Yr1Consumption > Yr3Consumption AND 
				Yr1Consumption > Yr4Consumption THEN Yr1Consumption WHEN Yr2Consumption > Yr1Consumption AND Yr2Consumption > Yr3Consumption AND 
				Yr2Consumption > Yr3Consumption THEN Yr2Consumption WHEN Yr3Consumption > Yr1Consumption AND Yr3Consumption > Yr2Consumption AND 
				Yr3Consumption > Yr4Consumption THEN Yr3Consumption WHEN Yr4Consumption > Yr1Consumption AND Yr4Consumption > Yr2Consumption AND 
				Yr4Consumption > Yr3Consumption THEN Yr4Consumption 
			END AS MaxConsumption
		, @actualYears AS ActualYears
		FROM (
			SELECT 
				  ISNULL(Consumption.ItemId, consumptionBase.ItemId) AS ItemId
				, ISNULL(Consumption.Yr1Issue, 0) + ISNULL(consumptionBase.Yr1Issue, 0) AS Yr1Issue
				, ISNULL(Consumption.Yr2Issue, 0) + ISNULL(consumptionBase.Yr2Issue, 0) AS Yr2Issue
				, ISNULL(Consumption.Yr3Issue, 0) + ISNULL(consumptionBase.Yr3Issue, 0) AS Yr3Issue
				, ISNULL(Consumption.Yr4Issue, 0) + ISNULL(consumptionBase.Yr4Issue, 0) AS Yr4Issue
				, ISNULL(Consumption.Yr1RegularizedQty, 0) + ISNULL(consumptionBase.Yr1RegularizedQty, 0) AS Yr1RegularizedQty
				, ISNULL(Consumption.Yr2RegularizedQty, 0) + ISNULL(consumptionBase.Yr2RegularizedQty, 0) AS Yr2RegularizedQty
				, ISNULL(Consumption.Yr3RegularizedQty, 0) + ISNULL(consumptionBase.Yr3RegularizedQty, 0) AS Yr3RegularizedQty
				, ISNULL(Consumption.Yr4RegularizedQty, 0) + ISNULL(consumptionBase.Yr4RegularizedQty, 0) AS Yr4RegularizedQty
				, ISNULL(Consumption.Yr1Consumption, 0) + ISNULL(consumptionBase.Yr1Consumption, 0) AS Yr1Consumption
				, ISNULL(Consumption.Yr2Consumption, 0) + ISNULL(consumptionBase.Yr2Consumption, 0) AS Yr2Consumption
				, ISNULL(Consumption.Yr3Consumption, 0) + ISNULL(consumptionBase.Yr3Consumption, 0) AS Yr3Consumption
				, ISNULL(Consumption.Yr4Consumption, 0) + ISNULL(consumptionBase.Yr4Consumption, 0) AS Yr4Consumption
				, ISNULL(Consumption.Yr1TurnIn, 0) + ISNULL(consumptionBase.Yr1TurnIn, 0) AS Yr1TurnIn
				, ISNULL(Consumption.Yr2TurnIn, 0) + ISNULL(consumptionBase.Yr2TurnIn, 0) AS Yr2TurnIn
				, ISNULL(Consumption.Yr3TurnIn, 0) + ISNULL(consumptionBase.Yr3TurnIn, 0) AS Yr3TurnIn
				, ISNULL(Consumption.Yr4TurnIn, 0) + ISNULL(consumptionBase.Yr4TurnIn, 0) AS Yr4TurnIn
			FROM (
				SELECT
					  CH.ITEM_ID AS ItemId
					, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr1Issue
					, SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr1RegularizedQty
					, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1TurnIn
					, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1Consumption				
					, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr2Issue
					, SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr2RegularizedQty
					, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2TurnIn
					, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear +1 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2Consumption
					, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr3Issue
					, SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr3RegularizedQty
					, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3TurnIn
					, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear +2 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3Consumption
					, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr4Issue
					, SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr4RegularizedQty
					, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4TurnIn
					, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear +3 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4Consumption
				FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY CH 
				INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId)
				WHERE (BU.BU_TYPE_ = 'Store') AND (CH.L2_ID_ = @agl2Id)
				GROUP BY CH.ITEM_ID
			) AS Consumption 
			FULL OUTER JOIN (
				SELECT 
					  CHB.ITEM_ID AS ItemId
					, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr1Issue
					, SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr1RegularizedQty
					, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1TurnIn
					, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1Consumption
					, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr2Issue
					, SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr2RegularizedQty
					, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2TurnIn
					, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2Consumption
					, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr3Issue
					, SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr3RegularizedQty
					, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3TurnIn
					, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3Consumption
					, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr4Issue
					, SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr4RegularizedQty
					, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4TurnIn
					, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4Consumption
				FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE AS CHB 
				INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CHB.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId)
				WHERE (BU.BU_TYPE_ = 'Store') AND (CHB.L2_ID_ = @agl2Id)   
				GROUP BY CHB.ITEM_ID
			) AS consumptionBase ON Consumption.ItemId = consumptionBase.ItemId
	) AS totalConsumption) AS B ON A.ItemId = B.ItemId
	WHERE A.ItemId = @partNoId

END
go

