CREATE FUNCTION [dbo].[Tmde_Delinquency]
(
      @StartDate     date,
      @EndDate       date,
      @Stores nvarchar(max)
)

RETURNS @values Table ([Value] decimal(8,2))
AS
begin

       WITH CTEBASE AS (
       SELECT RN = ROW_NUMBER() OVER (PARTITION BY HTC.UNIT_ID ORDER BY HTC.UNIT_ID, HTC.LST_CAL_DATE_), HTC.UNIT_ID as UnitId, HTC.LST_CAL_DATE_ as LastCalDate, HTC.CAL_DUE_DATE_ as CalDueDate, HTC.ACT_STATUS as ActiveStatus
       FROM LOG_HST_TOM_TOOLS_CALIBRATION HTC 
       LEFT JOIN LOG_TRN_TOM_TOOLS_REGISTER TREG ON TREG.UNIT_ID = HTC.UNIT_ID
       LEFT OUTER JOIN ADM_TRN_CAL_UNIT_CALIBRATION AS UCL ON HTC.UNIT_ID = UCL.UNIT_ID
        WHERE HTC.LST_CAL_DATE_ IS NOT NULL AND HTC.CAL_DUE_DATE_ IS NOT NULL AND HTC.BU_ID IN (SELECT Item from dbo.SplitInts(@Stores, ',')) AND (TREG.STATUS_ <> 'InCalibration' AND UCL.IN_CALIBRATION_ <> 1)
       ),
       CTE AS
       (
              SELECT * FROM LOG_HST_TOM_TOOLS_CALIBRATION HTC WHERE  HTC.DATE_ <= @EndDate AND HTC.BU_ID IN (SELECT Item from dbo.SplitInts(@Stores, ','))
       ) 

       INSERT INTO @values
       SELECT (CASE WHEN  
                     ( ( SELECT COUNT(DISTINCT CTE.UNIT_ID)  FROM CTE )  -   (SELECT COUNT(*)  FROM CTE  WHERE CTE.INTERVAL_ID IN (555, 556))  ) <= 0 THEN 0
               ELSE  
                 CAST(CAST((count(*) * 100) AS decimal(8,2))
       /  
        (
                    SELECT
                     (
                           ( 
                                  SELECT COUNT(DISTINCT CTE.UNIT_ID)  FROM CTE
                           ) 
                     -       
                                  (SELECT COUNT(*)  FROM CTE  WHERE CTE.INTERVAL_ID IN (555, 556)) 
                           
              )
       )
as decimal(8,2)) 
               END ) As Value


       from CTEBASE
       LEFT JOIN CTEBASE AS NEX  ON CTEBASE.RN = NEX.RN - 1 AND CTEBASE.UnitId = NEX.UnitId
       WHERE 
       (CTEBASE.CalDueDate Between @StartDate AND @EndDate AND (NEX.LastCalDate IS NULL OR NEX.LastCalDate > @EndDate))
       OR
       (CTEBASE.CalDueDate < @StartDate AND CTEBASE.RN = 1 )
       RETURN;
end
go

