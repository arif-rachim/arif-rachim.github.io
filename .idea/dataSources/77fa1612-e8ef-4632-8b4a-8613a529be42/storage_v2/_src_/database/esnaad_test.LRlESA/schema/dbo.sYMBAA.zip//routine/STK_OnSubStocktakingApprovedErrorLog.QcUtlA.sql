CREATE PROC [dbo].[STK_OnSubStocktakingApprovedErrorLog](
        @subStocktakingId uniqueidentifier
) AS
BEGIN
        SET XACT_ABORT ON
		DECLARE @logId uniqueidentifier = dbo.GenerateTimebasedGuid()
		DECLARE @generatedOn DATETIME = GETDATE()

		DELETE FROM LOG_TRN_STM_SUB_STOCKTAKING2_ADJ_ERROR_LOG WHERE SST_ID_ = @subStocktakingId;

		INSERT INTO LOG_TRN_STM_SUB_STOCKTAKING2_ADJ_ERROR_LOG(SST_ID_, LOCATION_, PART_NO_, MFR_CODE_, SERIAL_BATCH_NO_, CAUSE_, GENERATED_ON)
		SELECT @subStocktakingId, E.Location, E.PartNo, E.MfrCode, E.SerialBatchNo, E.CauseOfFailure, @generatedOn
		FROM dbo.STK_GetStockAdjustmentErrorLog(@subStocktakingId) E
        
END
go

