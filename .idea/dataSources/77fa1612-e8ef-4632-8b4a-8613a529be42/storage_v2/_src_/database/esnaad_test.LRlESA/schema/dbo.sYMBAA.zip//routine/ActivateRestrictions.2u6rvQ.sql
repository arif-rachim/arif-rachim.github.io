CREATE PROCEDURE [dbo].[ActivateRestrictions]
	@role_id uniqueidentifier,
	@activate bit
AS 
BEGIN

--	begin tran t1;
	-- prepare temp tables
	create table #ROLE_IDS (ID_ uniqueidentifier);
	create table #MODULE_IDS (ID_ varchar(40)  COLLATE Arabic_CI_AS );
	create table #USER_PRF_IDS (ID_ bigint);
	create table #USER_RESTRICTION_ID (ID_ UNIQUEIDENTIFIER);

	-- prepare modules id and user_prf_ids
	if (@activate = 0) -- deactivate
	begin
		-- active role ids which are assigned to user id from the role tobe deactivated except the deactivated role id
		insert into #ROLE_IDS
		select distinct rol.ID_
		from ADM_TRN_SEC_ROLE rol
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg2 on asg.USR_PRF_ID = asg2.USR_PRF_ID and asg2.ROLE_ID = @role_id
		where rol.ID_ <> @role_id
		and rol.IS_ACTIVE_ = 1
		
		-- modules id which User Restriction will be removed
		
		insert into #MODULE_IDS 
		select distinct MDL_ID
		from (
			select distinct MDL_ID from ADM_TRN_SEC_ROLE_ACL acl
			inner join #ROLE_IDS ri on ri.ID_ = acl.ROLE_ID
			union all
			select MDL_ID from ADM_TRN_SEC_ROLE_ACL where ROLE_ID = @role_id
		) mids
		
		-- user ids which User Restriction will be removed
		insert into #USER_PRF_IDS 
		select distinct USR_PRF_ID
		from (
			select distinct USR_PRF_ID from ADM_TRN_SEC_ROLE_ASSIGNMENT where ROLE_ID in (select ID_ from #ROLE_IDS)
			union all
			select USR_PRF_ID from ADM_TRN_SEC_ROLE_ASSIGNMENT where ROLE_ID = @role_id
		) uids
	end
	else
	begin
		insert into #MODULE_IDS select distinct(MDL_ID) from ADM_TRN_SEC_ROLE_ACL where ROLE_ID  = @role_id;
		insert into #USER_PRF_IDS select distinct(USR_PRF_ID) from ADM_TRN_SEC_ROLE_ASSIGNMENT where ROLE_ID = @role_id;		
		insert into #ROLE_IDS 
		select distinct rol.ID_ from ADM_TRN_SEC_ROLE rol
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ROLE_ID = rol.ID_
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join #MODULE_IDS mids on mids.ID_ = acl.MDL_ID
		inner join #USER_PRF_IDS uids on uids.ID_ = asg.USR_PRF_ID		
		where rol.IS_ACTIVE_ = 1		
	end
		
	-- prepare user restrictions to clear ( all user restrictions containing module and user asigned in selected role)
	if (@activate = 0) -- deactivate
	begin
	insert into #USER_RESTRICTION_ID
		select ur.ID_
		from ADM_TRN_USER_RESTRICTIONS ur
		inner join #MODULE_IDS mdl on mdl.ID_ = ur.MODULE_ID
		inner join #USER_PRF_IDS up on up.ID_ = ur.USER_PROFILE_ID
	end
	else
	begin
		insert into #USER_RESTRICTION_ID
		select ur.ID_
			from ADM_TRN_SEC_ROLE rol
			inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ROLE_ID = rol.ID_
			inner join dbo.ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
			inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID	
			inner join #ROLE_IDS roid on rol.ID_ = roid.ID_	
	end		
			
		
	-- delete restriction details
	delete urd FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_AIRBASE_RESTRICION_DETAILS urd on urd.USR_REST_ID = ids.ID_
	delete urd FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_BUSINESS_UNIT_RESTRICION_DETAILS urd on urd.USR_REST_ID = ids.ID_ 
	delete urd FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_CURRENCY_TYPE_RESTRICTION_DETAILS urd on urd.USR_REST_ID = ids.ID_ 
	delete urd FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_DEPARTMENT_RESTRICION_DETAILS urd on urd.USR_REST_ID = ids.ID_ 
	delete urd FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_LEVEL2_ASSOCIATION_RESTRICION_DETAILS urd on urd.USR_REST_ID = ids.ID_ 
	delete urd FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_PLATFORM_RESTRICION_DETAILS urd on urd.USR_REST_ID = ids.ID_ 
	delete urd FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_QUALIFICATION_CAT_DETAILS urd on urd.USR_REST_ID = ids.ID_ 
	delete urd FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_SITE_RESTRICION_DETAILS urd on urd.USR_REST_ID = ids.ID_ 
	delete urd FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_RESTRICION_DETAILS urd on urd.USR_REST_ID = ids.ID_ 

	-- delete user restrictions
	delete ur FROM #USER_RESTRICTION_ID ids join ADM_TRN_USER_RESTRICTIONS ur on ur.ID_ = ids.ID_ 

	if (@activate = 0) -- deactivate
	begin
		insert into ADM_TRN_USER_RESTRICTIONS (ID_, VERSION_, MODULE_ID, USER_PROFILE_ID, CREATED_BY_, CREATED_ON_)
		select newid(), 1, acl.MDL_ID, asg.USR_PRF_ID, 'SYSTEM', getdate()
		from ADM_TRN_SEC_ROLE_ACL acl
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join #ROLE_IDS rrol on rrol.ID_ = asg.ROLE_ID
		group by acl.MDL_ID, asg.USR_PRF_ID
	end
	else
	begin
		insert into ADM_TRN_USER_RESTRICTIONS (ID_, VERSION_, MODULE_ID, USER_PROFILE_ID, CREATED_BY_, CREATED_ON_)
		select newid(), 1, acl.MDL_ID, asg.USR_PRF_ID, 'SYSTEM', getdate()
		from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
		inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
		inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
		inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
		where rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id
		group by asg.USR_PRF_ID, acl.MDL_ID;
	end
	
	-- populate military unit restriction details, ignore existing
	insert into ADM_TRN_USER_RESTRICION_DETAILS
	select newid(), 1, res.TYPE_NAME_, ur.ID_, acld.TYPE_ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
	from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
	inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
	inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
	inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
	inner join ADM_MST_RESTRICTIONS res on res.ID_ = acld.TYPE_ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
	inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
	where acld.TYPE_ = 'MilitaryUnit'
	and (rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id)
	group by acld.TYPE_ID_, res.TYPE_NAME_, ur.ID_


	-- populate platform restriction details, ignore existing
	insert into ADM_TRN_USER_PLATFORM_RESTRICION_DETAILS
	select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
	from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
	inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
	inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
	inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
	inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
	where acld.TYPE_ = 'Platform'	
	and (rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id)
	group by acld.TYPE_ID_, ur.ID_	

	-- populate QualificationCategory restriction details, ignore existing

	insert into ADM_TRN_USER_QUALIFICATION_CAT_DETAILS
	select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
	from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
	inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
	inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
	inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
	inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
	where acld.TYPE_ = 'QualificationCategory'	
	and (rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id)
	group by acld.TYPE_ID_, ur.ID_	

	-- CURRENCY --
	
	-- populate Currency Restriction details, ignore existing

	insert into ADM_TRN_USER_CURRENCY_TYPE_RESTRICTION_DETAILS
	select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by acld.TYPE_ID_ )) - 1
	from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
	inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
	inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
	inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
	inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
	where acld.TYPE_ = 'Currency'	
	and (rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id)
	group by acld.TYPE_ID_, ur.ID_	
		
		
	---=========================	

	-- populate Air Base Restriction details

	insert into ADM_TRN_USER_AIRBASE_RESTRICION_DETAILS
	select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
	from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
	inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
	inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
	inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
	inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
	where acld.TYPE_ = 'AirBase'	
	and (rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id)
	group by acld.TYPE_ID_, ur.ID_	

	-- populate Business Unit Restriction details

	insert into ADM_TRN_USER_BUSINESS_UNIT_RESTRICION_DETAILS
	select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
	from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
	inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
	inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
	inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
	inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
	where acld.TYPE_ = 'BusinessUnit'
	--and rol.ID_ in (select ID_ from #ROLE_IDS)
	and (rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id)
	group by acld.TYPE_ID_, ur.ID_	

	-- populate Department Restriction details

	insert into ADM_TRN_USER_DEPARTMENT_RESTRICION_DETAILS
	select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
	from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
	inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
	inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
	inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
	inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
	where acld.TYPE_ = 'UnitStructure'
	--and rol.ID_ in (select ID_ from #ROLE_IDS)
	and (rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id)
	group by acld.TYPE_ID_, ur.ID_	


	-- populate Association Group Restriction details

	insert into ADM_TRN_USER_LEVEL2_ASSOCIATION_RESTRICION_DETAILS
	select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as int))) - 1
	from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
	inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
	inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
	inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
	inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
	where acld.TYPE_ = 'AssociationGroup'
	--and rol.ID_ in (select ID_ from #ROLE_IDS)
	and (rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id)
	group by acld.TYPE_ID_, ur.ID_	

	-- populate Site Restriction details

	insert into ADM_TRN_USER_SITE_RESTRICION_DETAILS
	select newid(), 1, acld.TYPE_ID_, ur.ID_, (row_number() over (partition by ur.ID_ order by cast(acld.TYPE_ID_ as uniqueidentifier))) - 1
	from ADM_TRN_SEC_ROLE_ACL_DETAIL acld
	inner join ADM_TRN_SEC_ROLE_ACL acl on acl.ID_ = acld.ROLE_ACL_ID
	inner join ADM_TRN_SEC_ROLE rol on rol.ID_ = acl.ROLE_ID
	inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = rol.ID_
	inner join ADM_TRN_USER_RESTRICTIONS ur on ur.MODULE_ID = acl.MDL_ID and ur.USER_PROFILE_ID = asg.USR_PRF_ID
	inner join #ROLE_IDS rids on rids.ID_ = rol.ID_
	where acld.TYPE_ = 'Site'
	--and rol.ID_ in (select ID_ from #ROLE_IDS)
	and (rol.IS_ACTIVE_ = 1 or rol.ID_ = @role_id)
	group by acld.TYPE_ID_, ur.ID_	

	-- add/remove facl 
	if (@activate = 0) -- deactivate
	begin
		-- delete groups users
		delete ADM_XRF_USER_PROFILE_GROUPS where GROUP_ID in (select ID_ from ADM_TRN_GROUPS where ROLE_ID=@role_id);	
	end
	else -- activate
	begin
		-- add group users
		insert into ADM_XRF_USER_PROFILE_GROUPS
		select grp.ID_, asg.USR_PRF_ID from ADM_TRN_GROUPS grp 
		inner join ADM_TRN_SEC_ROLE_ASSIGNMENT asg on asg.ROLE_ID = grp.ROLE_ID
		where grp.ROLE_ID = @role_id		
	end
	--- drop temporary table

	drop table #ROLE_IDS;
	drop table #MODULE_IDS;
	drop table #USER_PRF_IDS;
	drop table #USER_RESTRICTION_ID
		
	--
--	commit tran t1;

END
go

