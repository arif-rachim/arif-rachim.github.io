CREATE FUNCTION [dbo].[GetWorkOrderDefectReportRepairFile] (@unitId AS BIGINT, @commandId AS BIGINT)
RETURNS TABLE
AS RETURN
	WITH WorkOrderDefectReportRepairFile AS
        (
            Select  UnitId,  DocReferenceId, DocReferenceNo, DocStatus, DocCommandId, DocDate  From (SELECT        U.ID_ AS UnitId,

					IIF(RF.REPAIR_FILE_NO_ IS NOT NULL AND RF.STATUS_ <>'Closed', RF.ID_, 
					IIF(WFINST.WF_STATE_ NOT IN ( 'Closed', 'Cancelled', 'Rejected'), DFR.ID_, 
					IIF(((WO.WO_CONDITION_ IN ('ACTIVE') OR WO.WO_STS_CODE_  = 'NR1')   OR   ((WO.WO_CONDITION_ IN ('ACTIVE')) AND WO.WO_STS_CODE_ IN ('IM', 'IMC'))) , WO.ID_, NULL))) AS DocReferenceId,

					IIF(RF.REPAIR_FILE_NO_ IS NOT NULL AND RF.STATUS_ <>'Closed', RF.REPAIR_FILE_NO_, 
					IIF(WFINST.WF_STATE_ NOT IN ( 'Closed', 'Cancelled', 'Rejected'), DFR.DEFECT_NO_, 
					IIF(((WO.WO_CONDITION_ IN ('ACTIVE') OR WO.WO_STS_CODE_  = 'NR1')   OR   ((WO.WO_CONDITION_ IN ('ACTIVE')) AND WO.WO_STS_CODE_ IN ('IM', 'IMC'))) , WO.WO_NO_, NULL))) AS DocReferenceNo, 

					IIF(RF.REPAIR_FILE_NO_  IS NOT NULL AND RF.STATUS_ <>'Closed', 
					(CASE RF.STATUS_ 
                        WHEN 'RepairFileCreated' THEN 'REPAIR FILE CREATED' 
                        WHEN 'RFQCreated' THEN 'RFQ CREATED' 
                        WHEN 'RFQValidated' THEN 'RFQ VALIDATED' 
                        WHEN 'RFQDeleted' THEN 'RFQ DELETED' 
                        WHEN 'BidAnalysisCreated' THEN 'BID ANALYSIS CREATED' 
                        WHEN 'BidAnalysisAwaitingEvaluation' THEN 'BID ANALYSIS AWAITING EVALUATION' 
                        WHEN 'BidAnalysisEvaluated' THEN 'BID ANALYSIS EVALUATED' 
                        WHEN 'BidAnalysisValidated' THEN 'BID ANALYSIS VALIDATED' 
                        WHEN 'BidAnalysisDeleted' THEN 'BID ANALYSIS DELETED' 
                        WHEN 'BidAnalysisSignCancelled' THEN 'CANCEL BID ANALYSIS SIGN' 
                        WHEN 'BidAnalysisEvaluateCancelled' THEN 'CANCEL BID ANALYSIS EVALUATION' 
                        WHEN 'BidAnalysisValidateCancelled' THEN 'CANCEL BID ANALYSIS VALIDATION' 
                        WHEN 'BidAnalysisExcluded' THEN 'EXCLUDED FROM BID ANALYSIS' 
                        WHEN 'ShipmentRequestApproved' THEN 'SHIPMENT REQUEST APPROVED' 
                        WHEN 'BER' THEN 'MARKED AS BEYOND ECONOMICAL REPAIR' 
                        WHEN 'CaseCreated' THEN 'CASE CREATED' 
                        WHEN 'CaseDeleted' THEN 'CASE DELETED' 
                        WHEN 'ShipmentPrepared' THEN 'SHIPMENT PREPARED' 
                        WHEN 'ShipmentApproved' THEN 'SHIPMENT APPROVED' 
                        WHEN 'FinalQuoteUpdated' THEN 'FINAL QUOTE UPDATED' 
                        WHEN 'FinalQuoteRejected' THEN 'FINAL QUOTE REJECTED' 
                        WHEN 'FinalQuoteAwaiting' THEN 'FINAL QUOTE AWAITING' 
                        WHEN 'FinalQuoteAccepted' THEN 'FINAL QUOTE APPROVED' 
                        WHEN 'RepairLetterReferenceCreated' THEN 'REPAIR LETTER REFERENCE CREATED' 
                        WHEN 'RepairLetterReferenceDeleted' THEN 'REPAIR LETTER REFERENCE DELETED' 
                        WHEN 'RepairLetterReferenceCanceled' THEN 'REPAIR LETTER REFERENCE CANCELED' 
                        WHEN 'RepairOrderCreated' THEN 'REPAIR ORDER CREATED' 
                        WHEN 'RepairOrderValidated' THEN 'REPAIR ORDER VALIDATED' 
                        WHEN 'RepairOrderDeleted' THEN 'REPAIR ORDER DELETED' 
                        WHEN 'RepairOrderCancelled' THEN 'REPAIR ORDER CANCELED' 
                        WHEN 'RepairOrderClosed' THEN 'REPAIR ORDER CLOSED' 
                        WHEN 'FMSDocumentCreated' THEN 'FMS DOCUMENT CREATED' 
                        WHEN 'FMSDocumentRequested' THEN 'FMS DOCUMENT REQUESTED' 
                        WHEN 'FMSDocumentReleased' THEN 'FMS DOCUMENT RELEASED' 
                        WHEN 'ScrapRequestCreated' THEN 'SCRAP REQUEST CREATED' 
                        ELSE UPPER(RF.STATUS_) END   ) ,
					IIF(WFINST.WF_STATE_ NOT IN ( 'Closed', 'Cancelled', 'Rejected'), 
												(CASE WHEN (WFINST.WF_STATE_ ='NeedCorrection' ) 
															THEN  
																CASE 
																	WHEN DFR.PREVIOUS_STATE_ = 'Approved' then 'NEED CORRECTION BY APPROVER' 
																	WHEN DFR.PREVIOUS_STATE_ = 'Validated' then 'NEED CORRECTION BY VALIDATOR' 
																	WHEN DFR.PREVIOUS_STATE_ = 'Submitted' then 'NEED CORRECTION BY SUBMITTER' 								
																END								
															ELSE WFINST.WF_STATE_ END), 
					IIF(((WO.WO_CONDITION_ IN ('ACTIVE') OR WO.WO_STS_CODE_  = 'NR1')   OR   ((WO.WO_CONDITION_ IN ('ACTIVE')) AND WO.WO_STS_CODE_ IN ('IM', 'IMC'))) ,  
										(CASE 
										WHEN  WO.WO_STS_CODE_ IN ('IM', 'IMC') THEN 'AWAITING ITEM MOVEMENT'
										WHEN  WO.WO_STS_CODE_ IN ('NR1') THEN 'AWAITING NRTS VALIDATION'
										ELSE 'OPEN' END)
					, NULL))) AS DocStatus,

					IIF(RF.REPAIR_FILE_NO_ IS NOT NULL AND RF.STATUS_ <>'Closed',TFU.CMD_ID_, 
					IIF(WFINST.WF_STATE_ NOT IN ( 'Closed', 'Cancelled', 'Rejected'), DFRBU.CMD_ID_, 
					IIF( ((WO.WO_CONDITION_ IN ('ACTIVE') OR WO.WO_STS_CODE_  = 'NR1')   OR   ((WO.WO_CONDITION_ IN ('ACTIVE')) AND WO.WO_STS_CODE_ IN ('IM', 'IMC'))), WO_BU.CMD_ID_, NULL))) AS DocCommandId,

					IIF(RF.REPAIR_FILE_NO_  IS NOT NULL AND RF.STATUS_ <>'Closed', RF.CREATED_ON_, 
					IIF(WFINST.WF_STATE_ NOT IN ( 'Closed', 'Cancelled', 'Rejected' ), DFR.CREATED_ON_, 
					IIF( ((WO.WO_CONDITION_ IN ('ACTIVE') OR WO.WO_STS_CODE_  = 'NR1')   OR   ((WO.WO_CONDITION_ IN ('ACTIVE')) AND WO.WO_STS_CODE_ IN ('IM', 'IMC'))) , WO.CREATED_ON_, NULL))) AS DocDate

	FROM            ADM_MST_UNITS AS U LEFT OUTER JOIN
							 LOG_TRN_RPR_REPAIR_FILE AS RF ON U.ID_ = RF.UNIT_ID LEFT OUTER JOIN
							 ADM_MST_BUSINESS_UNITS AS TFU ON TFU.ID_ = RF.TFU_ID_ LEFT OUTER JOIN
							 MNT_TRN_WOTS_WORK_ORDER AS WO ON WO.EI_UNIT_ID_ = U.ID_ LEFT OUTER JOIN
							 ADM_MST_BUSINESS_UNITS AS WO_BU ON WO_BU.ID_ = WO.WS_BU_ID_ LEFT OUTER JOIN
							 MNT_TRN_DFR_DEFECT_REPORT AS DFR ON DFR.UNIT_ID_ = U.ID_ LEFT OUTER JOIN
							 ADM_MST_BUSINESS_UNITS AS DFRBU ON DFR.ORG_BU_ID_ = DFRBU.ID_ LEFT OUTER JOIN
							 WF_TRN_INSTANCE AS WFINST ON DFR.WF_ID = WFINST.ID_ AND WFINST.WF_DEF_ID_ = 'DefectReportWorkflow' LEFT OUTER JOIN
							 WF_TRN_INSTANCE AS WF ON WO.WF_ID = WF.ID_ AND WF.WF_DEF_ID_='WOWorkflow' 

	WHERE        (RF.REPAIR_FILE_NO_ IS NOT NULL AND RF.STATUS_ <>'Closed') OR
							 (WFINST.WF_STATE_ NOT IN ( 'Closed', 'Cancelled', 'Rejected')) OR
							 ((WO.WO_CONDITION_ IN ('ACTIVE') OR WO.WO_STS_CODE_  = 'NR1')   OR   ((WO.WO_CONDITION_ IN ('ACTIVE')) AND WO.WO_STS_CODE_ IN ('IM', 'IMC')))						 
			) AS SRC 
			where UnitId = @unitId and DocCommandId= @commandId
 
        )
    SELECT UnitId,  DocReferenceId, DocReferenceNo, DocStatus, DocCommandId, DocDate FROM WorkOrderDefectReportRepairFile
go

