CREATE FUNCTION [dbo].[GetDateOccurrence](@startDate datetime, @endDate datetime, @dateUnit varchar(10), @dateUnitVal int)
    RETURNS int
AS
BEGIN

    DECLARE @count as INT;
    DECLARE @nextDate as DATETIME;

	IF @startDate IS NULL OR @endDate  IS NULL OR @dateUnit  IS NULL OR @dateUnitVal  IS NULL
	BEGIN
		RETURN NULL
	END

    SET @count = 0
	SET @nextDate = @startDate

    WHILE (@nextDate >= @startDate AND @nextDate <= @endDate)
    BEGIN
        SELECT @count = @count + 1;

		SET @nextDate = CASE @dateUnit 
						WHEN 'Days' THEN DATEADD(DAY , @dateUnitVal, @nextDate) 
						WHEN 'Months' THEN DATEADD(MONTH , @dateUnitVal, @nextDate) 
						WHEN 'Years' THEN DATEADD(YEAR , @dateUnitVal, @nextDate)
						ELSE NULL END
	END

	RETURN @count
END
go

