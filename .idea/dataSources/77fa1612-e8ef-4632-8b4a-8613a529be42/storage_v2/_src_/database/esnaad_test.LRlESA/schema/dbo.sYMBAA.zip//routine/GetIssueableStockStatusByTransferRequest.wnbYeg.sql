CREATE FUNCTION [dbo].[GetIssueableStockStatusByTransferRequest]
(
	@transferRequestId			uniqueidentifier
)
RETURNS int
AS
BEGIN
	-- return value
	DECLARE @result int

	select  

	@result =
	case 
		when sum(partialyavailable) > 0 then 2
		when sum(nostock) > 0 and sum(availablestock) > 0 then 2
		when sum(availablestock) > 0 then 1
		when sum(nostock) > 0 then 3
	end

		from (
		select 

		stockchcek.ITEM_ID as itemid,
		case 
			when ISNULL(stockchcek.AvailableStock,0) = 0 then 1
			else 0 end nostock 
		,
		case 
			when ISNULL(stockchcek.AvailableStock,0) >= ((stockchcek.REQ_QTY_ - stockchcek.CANCELED_QTY_) - isnull(stockchcek.ISSUED_QTY_,0)) then 1
			else 0 end availablestock 
		,
		case 
			when ISNULL(stockchcek.AvailableStock,0) > 0 AND ISNULL(stockchcek.AvailableStock,0) < ((stockchcek.REQ_QTY_ - stockchcek.CANCELED_QTY_) - isnull(stockchcek.ISSUED_QTY_,0)) then 1
			else 0 end partialyavailable


		from
			(
				SELECT        reqitem.ITEM_ID, reqitem.REQ_QTY_, reqitem.ISSUED_QTY_, ISNULL(reqitem.CANCELED_QTY_, 0) AS CANCELED_QTY_
									, dbo.GetAvailableStock(reqitem.ITEM_ID, tranReq.FI_L2_ID_, tranReq.FI_BU_ID_, reqitem.IN_LIEU_, 0, tranReq.FI_CMD_ID_) AS AvailableStock
				FROM            LOG_TRN_TRM_TRANSFER_REQUEST AS tranReq INNER JOIN
										 LOG_TRN_TRM_TRANSFER_REQUEST_ITEM AS reqitem ON tranReq.ID_ = reqitem.TR_ID_
				WHERE        (tranReq.ID_ = @transferRequestId) AND (reqitem.FF_STATUS_ IN ('NotFulfilled', 'PartiallyFulfilled'))
			) as stockchcek
		) as tmp

	RETURN @result
END
go

