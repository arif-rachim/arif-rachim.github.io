CREATE FUNCTION ReturnDisplyStringForSimpleRef(@SimpleRefId int, @whatToDisplay varchar(10) = 'code') RETURNS varchar(100)
BEGIN
	DECLARE @retValue varchar(100)
	IF(UPPER(@whatToDisplay) = 'CODE') BEGIN
		SELECT @retValue = CODE_ FROM dbo.ADM_MST_SIMPLE_REF WHERE 	ID_ =  @SimpleRefId
	END	
	ELSE BEGIN
		SELECT @retValue = DESC_ FROM dbo.ADM_MST_SIMPLE_REF WHERE 	ID_ =  @SimpleRefId
	END		
	RETURN @retValue
END
go

