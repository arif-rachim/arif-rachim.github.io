CREATE PROCEDURE [dbo].[GetAircraftInventoryNrtReport]   
  
 @month int = 0,   
 @year int = 0,  
 @user_profile_id bigint = 0,  
 @selected_tail_ids nvarchar(max) = ''  
   
AS  
BEGIN  
  
 SET NOCOUNT ON;  
 IF (@month = 0)  
  SET @month = Month(getdate())  
 IF (@year = 0)  
  SET @year = Year(getdate())  
    
 DECLARE @FMC int = 220  
 DECLARE @PMCM int = 221  
 DECLARE @PMCS int = 222  
 DECLARE @NMCS_1st int = 223  
 DECLARE @NMCM_1st int = 224  
 DECLARE @DEPOT int = 225  
 DECLARE @NMCS_2nd int = 226  
 DECLARE @NMCM_2nd int = 227  
 DECLARE @TOTAL int = 228  
 DECLARE @FLT_HRS int = 229  
 DECLARE @LNDGS int = 230  
 DECLARE @AUTOS int = 231  
 DECLARE @PMCS_CODE int = 232   
 DECLARE @PMCM_CODE int = 233
 DECLARE @NRT int = 234
 

 DECLARE @start_date  SMALLDATETIME  
 SET @start_date = convert(smalldatetime,(SELECT dateadd(mm, (@year - 1900) * 12 + @month - 1 , 1 - 1)),100)  
   
 DECLARE @end_date       SMALLDATETIME  
    SET @end_date = DATEADD(DD, -1, DATEADD(M, 1, @start_date))   
    IF @end_date > getdate()  
  SET @end_date = cast(convert(varchar,DATEADD(DD,-1,getdate()),101) as smalldatetime)  
    
 DECLARE @end_day       int  
 SET @end_day = DATEPART(day, @end_date)  
  
 SELECT       
  dbo.MNT_TRN_AIRCRAFT_INVENTORIES.AIRCRAFT_ID              AIRCRAFT_ID,	--TESTING   
  dbo.ADM_MST_TAILS.ID_										TAIL_ID,		--TESTING   
  dbo.ADM_MST_TAILS.T_NUM_									TAIL_NUMBER,	--TESTING   
  @start_date												START_DATE,		--TESTING   
  @end_date													END_DATE,		--TESTING   
  @end_day													END_DAY,		--TESTING   
  dbo.ADM_MST_PLATFORMS.CODE_								SERIES,			--TESTING  
  dbo.ADM_MST_TAILS.T_NUM_									SERIAL_NUM,		--TESTING    
  'AGA'														ASSG_FUNC_CODE,    
  sum(dbo.MNT_TRN_AIRCRAFT_INVENTORIES.HOURS_)              TOTAL_AC_INV_HRS,  
  ((case when @end_date > getdate() then (@end_day - 1) else @end_day end) * 24) TOTAL_HRS_ONHAND,  

  ((case when @end_date > getdate() then (@end_day - 1) else @end_day end) * 24) -  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @NRT)) HRS_ONHAND,  

  /*((case when @end_date > getdate() then (@end_day - 1) else @end_day end) * 24) -  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @DEPOT)) -
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @NMCS_1st)) -
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @NMCS_2nd))	HRS_ONHAND,*/  
    
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, 0))			AC_TOTAL_HRS,  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @FMC))			FMC_HRS,  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @PMCM))		PMCM_HRS,  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @PMCS))		PMCS_HRS,  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @NMCS_1st))	NMCS1_HRS,  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @NMCS_2nd))	NMCS2_HRS,  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @DEPOT))		DEPOT,  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @NMCM_1st))	NMCM1_HRS,  
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @NMCM_2nd))	NMCM2_HRS,  
  isnull((select dbo.GetAircraftFlyHrsForAPeriod(@start_date, @end_date, ADM_MST_TAILS.UNIT_ID, @user_profile_id)), 0) HRS_FLAWN,  
  isnull((select dbo.GetAircraftLandingsForAPeriod(@start_date, @end_date, ADM_MST_TAILS.UNIT_ID, @user_profile_id)), 0) NUM_LANDINGS,  
  isnull((select dbo.GetAircraftAutoLandingsForAPeriod(@start_date, @end_date, ADM_MST_TAILS.UNIT_ID, @user_profile_id)), 0) AUTO_ROATIONS,
  (select dbo.GetAircraftInvReportHrsForAperiod(@start_date, @end_date, AIRCRAFT_ID, @NRT)) NRT_HRS,
  (select dbo.GetAircraftInvReportCodeForAperiod(@start_date, @end_date, AIRCRAFT_ID, @PMCM_CODE,@PMCM))  PMCM_CODE,
  (select dbo.GetAircraftInvReportCodeForAperiod(@start_date, @end_date, AIRCRAFT_ID, @PMCS_CODE,@PMCS))  PMCS_CODE


 FROM         dbo.ADM_MST_TAILS INNER JOIN  
                      dbo.ADM_MST_UNITS ON dbo.ADM_MST_TAILS.UNIT_ID = dbo.ADM_MST_UNITS.ID_ INNER JOIN 
                      ADM_MST_ITEMS ON ADM_MST_ITEMS.ID_ =  ADM_MST_UNITS.ITEM_ID INNER JOIN 
                      dbo.ADM_MST_PLATFORMS ON dbo.ADM_MST_ITEMS.ID_ = dbo.ADM_MST_PLATFORMS.ID_ LEFT OUTER JOIN  
                      dbo.MNT_TRN_AIRCRAFT_INVENTORIES ON dbo.ADM_MST_UNITS.ID_ = dbo.MNT_TRN_AIRCRAFT_INVENTORIES.AIRCRAFT_ID  
 WHERE  
  dbo.ADM_MST_TAILS.ID_ IN  (SELECT * FROM dbo.[CSVToTable](@selected_tail_ids))  
 GROUP BY   
  dbo.MNT_TRN_AIRCRAFT_INVENTORIES.AIRCRAFT_ID   ,  
  dbo.ADM_MST_PLATFORMS.CODE_  ,  
  dbo.ADM_MST_TAILS.ID_ ,  
  dbo.ADM_MST_TAILS.T_NUM_,
  dbo.ADM_MST_TAILS.UNIT_ID
                      
    
END
go

