CREATE FUNCTION [dbo].[AM_GetAutogenerateCandidates]
(
	@field				nvarchar(255),
	@offset				int,
	@type				nvarchar(10))
RETURNS @data TABLE (
	ID_			bigint,
	CMD_ID_		bigint,
	REF_		nvarchar(255),
	SECTION_ID_	bigint
) AS
BEGIN

	DECLARE @dateString nvarchar(50) = CONVERT(NVARCHAR(50), DATEADD(d, @offset, getdate()) , 5)

	INSERT @data
	SELECT NCR.ID_ AS ID_, AP.CMD_ID AS CMD_ID_, AP.AUDIT_PLAN_NO_ + '/NCR' + RIGHT('0000' + CAST(NCR.SEQ_NO_ AS VARCHAR(4)), 4) AS REF_, AP.AUDIT_SECTION AS SECTION_ID_
	FROM ADM_TRN_AUDIT_NCR NCR
	INNER JOIN ADM_TRN_AUDIT_REPORT AR ON AR.ID_ = NCR.AUDIT_REPORT_ID
	INNER JOIN ADM_TRN_AUDIT_PLAN AP ON AP.ID_ = AR.AUDIT_PLAN_ID
	WHERE @type = 'Ncr' AND (
		1 = (CASE WHEN @field = 'NcrCreationDate' AND CONVERT(NVARCHAR(50), NCR.NCR_DATE_ , 5) = @dateString AND NCR.STATUS_ NOT IN ('Drafted','Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'NcrDueDate' AND CONVERT(NVARCHAR(50), NCR.DUE_DATE_ , 5) = @dateString AND NCR.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'NcrContainmentActionPlannedCompletionDate' AND CONVERT(NVARCHAR(50), NCR.CORR_PLN_CMPL_DATE_ , 5) = @dateString AND NCR.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'NcrCorrectiveActionPlannedCompletionDate' AND CONVERT(NVARCHAR(50), NCR.CORR_ACT_CMPL_DATE_ , 5) = @dateString AND NCR.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'NcrAuditorAcceptanceDate' AND CONVERT(NVARCHAR(50), NCR.NCR_PLAN_ACCEPTED_DATE , 5) = @dateString AND NCR.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'NcrExtensionRequestDate' AND CONVERT(NVARCHAR(50), NCR.NCR_EXTN_REQ_DATE , 5) = @dateString AND NCR.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'NcrClosureDate' AND CONVERT(NVARCHAR(50), NCR.NCR_CLOS_AUDITOR_DATE_ , 5) = @dateString AND NCR.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
	)
	
	UNION ALL
	
	SELECT AP.ID_ AS ID_, AP.CMD_ID AS CMD_ID_, AP.AUDIT_PLAN_NO_ AS REF_, AP.AUDIT_SECTION AS SECTION_ID_
	FROM ADM_TRN_AUDIT_PLAN AP
	LEFT JOIN ADM_TRN_AUDIT_REPORT AR ON AP.ID_ = AR.AUDIT_PLAN_ID
	WHERE @type = 'Audit' AND (
		1 = (CASE WHEN @field = 'AuditPlanCreationDate' AND CONVERT(NVARCHAR(50), AP.SUBMITD_DATE_ , 5) = @dateString AND AP.STATUS_ NOT IN ('Drafted', 'NeedCorrection') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'AuditPlanApprovalDate' AND CONVERT(NVARCHAR(50), AP.APPROVD_DATE_ , 5) = @dateString AND AP.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'AuditPlanStartDate' AND CONVERT(NVARCHAR(50), AP.START_DATE_ , 5) = @dateString AND AP.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'AuditPlanEndDate' AND CONVERT(NVARCHAR(50), AP.END_DATE_ , 5) = @dateString AND AP.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'AuditReportCreationDate' AND CONVERT(NVARCHAR(50), AR.SUBMITD_DATE_ , 5) = @dateString AND AR.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
		OR
		1 = (CASE WHEN @field = 'AuditReportApprovalDate' AND CONVERT(NVARCHAR(50), AR.APPROVD_DATE_ , 5) = @dateString AND AR.STATUS_ NOT IN ('Closed') THEN 1 ELSE 0 END)
	)

RETURN;
END
go

