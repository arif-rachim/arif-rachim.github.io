CREATE PROCEDURE [dbo].[PIM_UpdateMmeActionForPhaseExecution](
 @mmeRosterId bigint,
 @pUserProfileId bigInt,
 @pTerm nvarchar(max)
 )
As 
Begin



	DECLARE	@CreatedBy nvarchar(255), @Pid_Created_By nvarchar(255), @FullName_Created_By nvarchar(255);
	DECLARE @hostName VARCHAR(MAX) = HOST_NAME();
	SELECT @CreatedBy=USER_ID_,@Pid_Created_By=PID_,@FullName_Created_By=F_NAME_ + ' '+L_NAME_ FROM ADM_TRN_USER_PROFILES WHERE ID_=@pUserProfileId
	
	DECLARE @CREATED_ON DATETIME
    SET @CREATED_ON=GETDATE();

	select distinct PHASE_EXEC_DET_ID into #InspectionsphaseExec 
	from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS execAction
	join MNT_TRN_PIM_PHASE_EXECUTION_DETAIL execDetail on execDetail.ID_ = execAction.PHASE_EXEC_DET_ID
	where MME_ROSTER_ID_ =@mmeRosterId and execDetail.STATUS_ in ('NotCompleted','PendingAction')
	group by PHASE_EXEC_DET_ID
 	having max(execAction.MOD_ON_) is null

	ALTER TABLE #InspectionsphaseExec 
	ADD mmeFirstIndex int,
	currentMmeCount int,
	indexToBeAdded int


	declare @mmeActionCount int
	select @mmeActionCount=COUNT(*) from MNT_MST_MME_ACTIONS where ROSTER_ID=@mmeRosterId

	begin tran


		update CTE set CTE.mmeFirstIndex=mmeact.IDX_ from  #InspectionsphaseExec CTE 
		cross apply
		(
		 select top 1 IDX_ from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS act
		 where act.PHASE_EXEC_DET_ID=CTE.PHASE_EXEC_DET_ID 
		 and act.MME_ROSTER_ID_=@mmeRosterId 
		 order by act.IDX_
		) mmeact

		update CTE set CTE.currentMmeCount=mmeact.currentMmeCount from  #InspectionsphaseExec CTE 
		cross apply
		(
		 select count(*) as currentMmeCount from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS act
		 where act.PHASE_EXEC_DET_ID=CTE.PHASE_EXEC_DET_ID 
		 and act.MME_ROSTER_ID_=@mmeRosterId 
		
		) mmeact

		update CTE set CTE.indexToBeAdded=@mmeActionCount-CTE.currentMmeCount from  #InspectionsphaseExec CTE 

		-- delete  mme actions from all inspection
		delete act from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS act join
		#InspectionsphaseExec CTE  on CTE.PHASE_EXEC_DET_ID=act.PHASE_EXEC_DET_ID
		where  act.MME_ROSTER_ID_=@mmeRosterId;

		-- if  adhoc action exist , To update index for remaining adhoc action after removing mme records 
		update act set act.IDX_= iif(act.IDX_>CTE.mmeFirstIndex and CTE.indexToBeAdded>0,act.IDX_+CTE.indexToBeAdded,act.IDX_)
		from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS act join
		#InspectionsphaseExec CTE  on CTE.PHASE_EXEC_DET_ID=act.PHASE_EXEC_DET_ID

		--insert 
		insert into MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS(ID_,VERSION_,PHASE_EXEC_DET_ID,MME_ROSTER_ID_,STATUS_ID,ACTION_,
		PERFORMED_BY_ID,PERFORMED_ON_,PERFORMED_MMH_,PERFORMED_ACTION_,TI_VALIDATION_BY_ID,CREATED_BY_,PID_CREATED_BY_,FULL_NAME_CREATED_BY_,
		CREATED_ON_,MOD_BY_,PID_MOD_BY_,FULL_NAME_MOD_BY_,MOD_ON_,TERM_,IDX_,TI_MMH_,REMARKS_
		) 
		select NEWID(),1,CTE.PHASE_EXEC_DET_ID,mmeact.ROSTER_ID, STATUS_ID,upper(mmeact.RMA_),
		null,null,null,null,null,
		@CreatedBy, @Pid_Created_By,@FullName_Created_By,@CREATED_ON,
		null,null,null,null,
		@pTerm,(CTE.mmeFirstIndex-1)+ (ROW_NUMBER() over (partition by  PHASE_EXEC_DET_ID order by mmeact.ORDER_)),
		null,null
		from MNT_MST_MME_ACTIONS mmeact
		join #InspectionsphaseExec CTE  on 1=1
		where ROSTER_ID=@mmeRosterId
		order by PHASE_EXEC_DET_ID,mmeact.ORDER_

		update execDetail
		set INSP_ACTIONS_COUNT_=(select count(*) from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL_ACTIONS where PHASE_EXEC_DET_ID=execDetail.ID_) 
		from MNT_TRN_PIM_PHASE_EXECUTION_DETAIL execDetail inner join
		#InspectionsphaseExec CTE on CTE.PHASE_EXEC_DET_ID=execDetail.ID_

		commit

		 drop table if exists #InspectionsphaseExec
	

end
go

