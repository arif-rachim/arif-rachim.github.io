CREATE FUNCTION [dbo].[D16_GetAssignmentCount]
(
    @masterComponentId uniqueidentifier
    )
    RETURNS int
AS
BEGIN
    DECLARE @result int = 0;

    SELECT @result = count(ac.ID_)
    FROM MNT_TRN_D16_ASSIGNED_COMPONENT ac
    WHERE IS_ACTIVE_ = 1
      AND REM_DATE_ IS NULL
      AND MASTER_COMP_ID_ = @masterComponentId

    RETURN @result
END
go

