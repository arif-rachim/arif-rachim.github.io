CREATE FUNCTION [GetStockTrendData]
(
	 @cmdId bigint, @agl2Id bigint, @itemId bigint, @start date, @end date
)
RETURNS TABLE
AS
RETURN
(
	WITH dates AS (
	select @start as DateOn
	union all
	select dateadd(d, 1, DateOn) as date
	from dates
	where dateon < getdate()
	), 
	ST AS (
		SELECT U.ITEM_ID, imv.VALID_FROM_, imv.VALID_TO_, SUM(imv.QTY_ ) AS QTY_
		FROM ADM_TRN_IMV_ITEMS_IN_LOCATION FOR SYSTEM_TIME BETWEEN @start and @end IMV
		JOIN ADM_MST_UNITS FOR SYSTEM_TIME BETWEEN @start and @end U on U.ID_ = IMV.UNIT_ID_
		JOIN ADM_MST_UNIT_LOCATION L ON L.ID_ = IMV.LOC_ID_
		JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = IMV.BU_ID_
		WHERE BU.BU_TYPE_ = 'Store' AND BU.CMD_ID_ = @cmdId AND IMV.OWNED_L2_ID_ =  IIF(@agl2Id =0 , IMV.OWNED_L2_ID_ , @agl2Id) AND U.ITEM_ID = @itemId
		AND (L.LOC_TYPE_='Regular' OR L.LOC_TYPE_='Receiving') AND IMV.TC_ID_ = 1 AND (U.EXP_DATE_ is null or U.EXP_DATE_ >= GETDATE())
		group by U.ITEM_ID, imv.VALID_FROM_, imv.VALID_TO_
	),
	ST2 AS (
		SELECT D.DateOn, SUM(ST.QTY_) QTY_
		FROM ST
		JOIN dates D ON D.DateOn BETWEEN ST.VALID_FROM_ AND ST.VALID_TO_
		GROUP BY D.DateOn
	),
	PO AS (
		SELECT CAST(PO.PO_DATE_ AS DATE) PO_DATE_, PO.PRIORITY_, SUM(POQTY.UOM_QTY_) QTY_
		FROM LOG_TRN_PRC_PURCHASE_ORDER_ITEM POI
		JOIN LOG_TRN_PRC_PURCHASE_ORDER PO ON PO.ID_ = POI.PO_ID
		JOIN VW_LOG_TRN_PO_QTY POQTY ON POQTY.PO_ITM_ID_ = POI.ID_
		JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = PO.STORE_ID
		WHERE PO.PO_DATE_ >= @start and PO.STATUS_ in ('Closed', 'PartiallyDelivered', 'Validated')
		AND BU.CMD_ID_ = @cmdId AND PO.L2_ID = IIF(@agl2Id =0 , PO.L2_ID , @agl2Id)
		AND ISNULL(POQTY.INLIEU_ITEM_ID, POQTY.ITEM_ID) = @itemId 
		GROUP BY PO.PO_DATE_, PO.PRIORITY_
	) ,
	REQ  AS
	(
	SELECT 
		CAST(Req.TR_DATE_ as Date) as REQ_DATE, Req.TR_NO_ ,Req.PRIORITY_ , SUM(ReqItem.REQ_QTY_- ISNULL(ReqItem.CANCELED_QTY_,0)) as Qty
	FROM
		LOG_TRN_TRM_TRANSFER_REQUEST_ITEM ReqItem	INNER JOIN LOG_TRN_TRM_TRANSFER_REQUEST Req ON Req.ID_ = ReqItem.TR_ID_
													INNER JOIN ADM_MST_BUSINESS_UNITS BU ON BU.ID_ = Req.FI_BU_ID_
													INNER JOIN WF_TRN_INSTANCE AS wfinst ON req.WF_ID = wfinst.ID_  --AND wfinst.WF_DEF_ID_ = 'RequisitionWorkflow'
 
	WHERE
			Req.TR_DATE_ >= '2023-10-14'  
		AND (
					(wfinst.WF_STATE_  = 'Validated' AND req.IS_APPROVAL_REQUIRED_ = 0)
				OR	wfinst.WF_STATE_  = 'Approved'
				OR	wfinst.WF_STATE_  = 'PartiallyFulfilled'
				OR	wfinst.WF_STATE_  = 'Completed'
			)
		AND BU.CMD_ID_ = @cmdId 
		AND ReqItem.ITEM_ID = @itemId 
		AND Req.RI_L2_ID_ = IIF(@agl2Id =0 , Req.RI_L2_ID_  , @agl2Id)
	GROUP BY  Req.TR_DATE_, Req.TR_NO_, Req.PRIORITY_ 
	)
			SELECT 
			d.DateOn, ISNULL(ST2.QTY_, 0) AS Stock, isnull(aog.QTY_, 0) AS Aog, isnull(ior.QTY_, 0) AS Ior, isnull(nor.QTY_, 0) AS Nor ,
			ISNULL(r_aog.Qty, 0) as ReqAog, ISNULL(r_ior.Qty, 0) as ReqIor, ISNULL(r_nor.Qty, 0) as ReqNor
		from 
			dates d		left join ST2 on ST2.DateOn = d.DateOn  
						left join po aog on aog.PO_DATE_ = d.DateOn and aog.PRIORITY_ = 'AOG'  
						left join po ior on ior.PO_DATE_ = d.DateOn and ior.PRIORITY_ = 'IOR'  
						left join po nor on nor.PO_DATE_ = d.DateOn and nor.PRIORITY_ = 'NOR'
						left join REQ r_aog on r_aog.REQ_DATE = d.DateOn and r_aog.PRIORITY_ = 'AOG'
						left join REQ r_ior on r_ior.REQ_DATE = d.DateOn and r_ior.PRIORITY_ = 'IOR'
						left join REQ r_nor on r_nor.REQ_DATE = d.DateOn and r_nor.PRIORITY_ = 'NOR'
	--option(maxrecursion 0)
)
go

