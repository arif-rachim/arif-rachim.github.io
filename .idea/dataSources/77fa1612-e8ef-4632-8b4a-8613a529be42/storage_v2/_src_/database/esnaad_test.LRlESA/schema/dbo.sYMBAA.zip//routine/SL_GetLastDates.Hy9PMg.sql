Create FUNCTION [dbo].[SL_GetLastDates](

 @given_date datetime
 )

RETURNS TABLE AS 
RETURN (
with monthoffsets as (
       select top 11 ROW_NUMBER() over (order by (select null)) as monthoffset
       from master.dbo.spt_values
)
select @given_date CheckDate
union all
select dateadd(month, -monthoffset, datefromparts(year(@given_date), month(@given_date), 1)) as CheckDate
from monthoffsets mno

 )
go

