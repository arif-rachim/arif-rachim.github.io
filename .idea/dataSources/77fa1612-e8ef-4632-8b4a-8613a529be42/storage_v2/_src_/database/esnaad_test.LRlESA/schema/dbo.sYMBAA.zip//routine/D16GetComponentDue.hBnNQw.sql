CREATE FUNCTION [dbo].[D16GetComponentDue]
(
  @compId AS UNIQUEIDENTIFIER
)
  RETURNS @componentDue TABLE
                        (
                          _hours    REAL,
                          _landings INT,
                          _date     DATETIME
                        )
AS
BEGIN
  DECLARE
    @due_hours NUMERIC(10, 2),
    @due_landings INT,
    @due_date DATETIME

  SELECT @due_hours = CASE
                        WHEN r_due._hours IS NULL THEN o_due._hours
                        WHEN o_due._hours IS NULL THEN r_due._hours
                        WHEN r_due._hours < o_due._hours THEN r_due._hours
                        ELSE o_due._hours END
       ,
      @due_landings = CASE
                        WHEN r_due._landings IS NULL THEN o_due._landings
                        WHEN o_due._landings IS NULL THEN r_due._landings
                        WHEN r_due._landings < o_due._landings THEN r_due._landings
                        ELSE o_due._landings END
       ,
      @due_date = (CASE
                     WHEN r_due._date IS NULL THEN o_due._date
                     WHEN o_due._date IS NULL THEN r_due._date
                     WHEN r_due._date < o_due._date THEN r_due._date
                     ELSE o_due._date END)
  FROM MNT_MST_D16_COMPONENT c
         CROSS APPLY dbo.D16_GetReplaceDue(c.ID_) r_due
         CROSS APPLY dbo.D16_GetOverhaulDue(c.ID_) o_due
  WHERE c.ID_ = @compId

  INSERT @componentDue
  SELECT @due_hours
       , @due_landings
       , @due_date;
  RETURN;
END;
go

