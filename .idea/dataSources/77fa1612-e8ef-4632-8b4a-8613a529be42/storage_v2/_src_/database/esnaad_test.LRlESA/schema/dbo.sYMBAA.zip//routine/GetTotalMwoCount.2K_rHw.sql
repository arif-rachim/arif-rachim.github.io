CREATE FUNCTION [dbo].[GetTotalMwoCount](@compID uniqueidentifier) RETURNS int
AS
BEGIN
	DECLARE @mwoCount int
	set @mwoCount = 0

	SELECT @mwoCount = COUNT(MWO.MWO_NO_)  
					                            FROM MNT_TRN_D5_1_COMPONENT AS D51COMP
					                            INNER JOIN MNT_TRN_D5_1_ASSIGNMENT AS ASSIGN ON ASSIGN.D15_COM_ID = D51COMP.ID_
					                            INNER JOIN MNT_TRN_D5_1_MWO_MASTER AS MWO ON MWO.ID_ = ASSIGN.MWO_ID					                         
                            WHERE D51COMP.ID_ = @compID
	
	RETURN @mwoCount
END
go

