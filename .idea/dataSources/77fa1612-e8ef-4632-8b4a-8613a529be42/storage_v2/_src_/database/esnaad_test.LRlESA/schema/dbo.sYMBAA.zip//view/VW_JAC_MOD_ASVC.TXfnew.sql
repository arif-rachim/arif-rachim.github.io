
CREATE VIEW VW_JAC_MOD_ASVC AS
	WITH 	
	
	-- Formula CTE
	cte_formula AS (
		select 'Daily = (FMC + PMC ) / (Number Of Tails - (DEPOT + NMCS)), Availability = (FMC + PMC) / Number Of Tails' as Formula
	),

	cte_jac_ghq_asvc AS (
		SELECT
			asvc.TailCount AS TailCount,
			asvc.ConditionId as ConditionId,
			asvc.Command AS Command,
			frc.CODE_ AS [Force]
		FROM VW_JAC_MOD_ASVC_TAIL_CONDITION asvc
		INNER JOIN ADM_MST_RESTRICTIONS frc on frc.ID_ = asvc.ForceId
		INNER JOIN VW_JAC_MOD_ASVC_FORCE_CONFIG cfg ON cfg.ForceId = asvc.ForceId
		WHERE cfg.IsActive = 1 AND frc.IS_ACTIVE_ = 1
	),

	-- Force list based on interface configuration
	cte_force AS (
		select ForceId, frc.CODE_ as [Force]
		from ADM_MST_RESTRICTIONS frc 
		INNER JOIN VW_JAC_MOD_ASVC_FORCE_CONFIG cfg on cfg.ForceId = frc.ID_
		where cfg.IsActive = 1 AND frc.IS_ACTIVE_ = 1
	),

	--  Total tail number segregated by command and force
	cte_totalTail AS (
		SELECT
			SUM(ISNULL(TailCount, 0)) AS TailCount,
			Command AS Command,
			[Force] AS [Force]
		FROM cte_jac_ghq_asvc
		GROUP by [Force], Command
	),


	-- Total command tails having FMC, PMCM, and PMCS condition
	cte_command_fpmc AS (
		select CAST(SUM(TailCount) AS FLOAT) TailCount, Command, [Force] FROM cte_jac_ghq_asvc WHERE ConditionId IN (32, 36, 37) group by Command, [Force]
	),

	-- Total command tails having DEPOT condition
	cte_command_depot AS (
		SELECT SUM(TailCount) AS TailCount, Command, [Force] FROM cte_jac_ghq_asvc WHERE ConditionId = 33  group by Command, [Force]
	),

	-- Total command tails having NMCS condition
	cte_command_nmcs AS (
		SELECT SUM(TailCount) AS TailCount, Command, [Force] FROM cte_jac_ghq_asvc WHERE ConditionId = 35  group by Command, [Force]
	),

	-- Total tails having FMC, PMCM, and PMCS condition
	cte_total_fpmc AS (
		select CAST(SUM(TailCount) AS FLOAT) TailCount, [Force] FROM cte_command_fpmc GROUP BY [Force]
	),

	-- Total tails having DEPOT condition
	cte_total_depot AS (
		SELECT SUM(TailCount) AS TailCount, [Force] FROM cte_command_depot GROUP BY [Force]
	),

	-- Total tails having NMCS condition
	cte_total_nmcs AS (
		SELECT SUM(TailCount) AS TailCount, [Force] FROM cte_command_nmcs group by [Force]
	)

	SELECT 
		(SELECT
		ROUND(
			(
				ISNULL((SELECT TailCount from cte_total_fpmc where cte_total_fpmc.[Force] = cf.[Force]), 0)
				/
				(
					ISNULL((SELECT CAST(SUM(TailCount) AS FLOAT) FROM cte_totalTail where cte_totalTail.[Force] = cf.[Force]), 0)
					-
					ISNULL((SELECT TailCount FROM cte_total_depot where cte_total_depot.[Force] = cf.[Force]) + (SELECT TailCount FROM cte_total_nmcs where cte_total_nmcs.[force] = cf.[Force]), 0)
				)
			) * 100
			, 0
		)) AS Daily,
		(SELECT
		ROUND(	
			(
				(SELECT TailCount FROM cte_total_fpmc WHERE cte_total_fpmc.[Force] = cf.[Force])
				/
				(SELECT CAST(SUM(TailCount) AS FLOAT) FROM cte_totalTail WHERE cte_totalTail.[Force] = cf.[Force])
			) * 100
			, 0
		)) as Availability,
		1 AS UnitType,
		NULL AS Command,
		cf.[Force],
		ISNULL((SELECT TailCount from cte_total_fpmc where cte_total_fpmc.[Force] = cf.[Force]), 0) AS TotalTail,
		(SELECT Formula from cte_formula) as Formula
	FROM cte_force cf

	union all

	SELECT 
		ROUND(
			(
				ISNULL((SELECT CAST(TailCount AS FLOAT) FROM cte_command_fpmc WHERE Command = totalTail.Command), 0)
				/
				(
					ISNULL((SELECT CAST(SUM(TailCount) AS FLOAT) FROM cte_totalTail WHERE cte_totalTail.Command = totalTail.Command), 0)
					-
					(
						ISNULL((SELECT TailCount FROM cte_command_depot WHERE Command = totalTail.Command), 0)
						+
						ISNULL((SELECT TailCount FROM cte_command_nmcs WHERE Command = totalTail.Command), 0)
					)
		
				)
			) * 100
			, 0
		) AS Daily,
		ROUND(	
			(
				ISNULL((SELECT CAST(TailCount AS FLOAT) FROM cte_command_fpmc WHERE Command = totalTail.Command), 0)
				/
				ISNULL((SELECT CAST(SUM(TailCount) AS FLOAT) FROM cte_totalTail WHERE cte_totalTail.Command = totalTail.Command), 0)
			) * 100
			, 0
		) AS Availability,
		2 AS UnitType,
		totalTail.Command AS Command,
		totalTail.[Force] AS [Force],
		ISNULL((SELECT CAST(TailCount AS FLOAT) FROM cte_command_fpmc WHERE Command = totalTail.Command), 0) AS TotalTail,
		(SELECT Formula from cte_formula) as Formula
	FROM cte_totalTail totalTail
go

