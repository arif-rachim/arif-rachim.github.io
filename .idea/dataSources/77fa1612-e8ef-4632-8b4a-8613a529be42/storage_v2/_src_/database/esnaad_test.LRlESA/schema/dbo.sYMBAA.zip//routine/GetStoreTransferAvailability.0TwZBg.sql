CREATE FUNCTION [dbo].[GetStoreTransferAvailability]
(
	-- Add the parameters for the function here
	@StoreTransferId		uniqueidentifier,
	@FulfillingBuId			int
)
RETURNS varchar(255)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @result varchar(255)
	
	DECLARE @RequestQty int;
	DECLARE @StockQty int;
	--loop start
		DECLARE @itemRequestId uniqueidentifier;
		DECLARE @itemStatus varchar(255)
		SET @itemStatus = '';
		
		DECLARE itemCursor CURSOR FOR
		SELECT TRI.ID_ from LOG_TRN_TRM_TRANSFER_REQUEST_ITEM as TRI
        join LOG_TRN_TRM_TRANSFER_REQUEST as TR on TRI.TR_ID = TR.ID_
        join WF_TRN_INSTANCE as WF on TR.WF_ID = WF.ID_
		where TR_ID = @StoreTransferId and WF.WF_STATE_ <> 'Fulfilled'
				
		OPEN itemCursor;
		FETCH NEXT FROM itemCursor	INTO @itemRequestId
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
		
			SELECT @RequestQty = dbo.GetStoreTransferRemainingQtyRequestItem (@StoreTransferId, @itemRequestId)
			SELECT @StockQty = dbo.GetStockQtyTransferRequestItem(@StoreTransferId, @FulfillingBuId, @itemRequestId)
			
			IF (@StockQty > 0 AND @StockQty < @RequestQty)
			BEGIN
				SELECT @itemStatus = 'PARTIALLY FULFILLABLE'
				break;
			END
			
			IF (@StockQty = 0)
			BEGIN
				-- current status 'NOT FULFILLABLE'
				IF (@itemStatus = 'FULFILLABLE')
				BEGIN
					SELECT @itemStatus = 'PARTIALLY FULFILLABLE'
					break
				END
				ELSE
				BEGIN
					SELECT @itemStatus = 'NOT FULFILLABLE'
				END
			END
			ELSE IF (@StockQty >= @RequestQty)
			BEGIN
				SELECT @itemStatus = 'FULFILLABLE'
			END
    
			FETCH NEXT FROM itemCursor	INTO @itemRequestId
		END
		
		CLOSE itemCursor;
		DEALLOCATE itemCursor;
	
	SET @result = @itemStatus;
	RETURN @result
END
go

