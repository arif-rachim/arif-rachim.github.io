CREATE PROC [STI_GetConsumptionListRollUp] (
	@agl2Id bigint,
	@buId bigint,
	@fromYear int,
	@commandId bigint,
	@actualYears int,
	@partNoId bigint
) AS
BEGIN
	SELECT @partNoId = ISNULL(IAP.ITEM_ID, @partNoId)
	FROM ADM_TRN_ITEM_ASSOCS IA
	LEFT JOIN ADM_TRN_ITEM_ASSOCS IAP ON IAP.L2_ID = IA.L2_ID AND IAP.IN_LIEU_CODE_ = IA.IN_LIEU_CODE_ AND IAP.PRIMARY_PART_ = 1
	WHERE IA.L2_ID = @agl2Id AND IA.ITEM_ID = @partNoId

	SELECT 
		  ItemId, Yr1Issue, Yr2Issue, Yr3Issue, Yr4Issue, Yr1TurnIn, Yr2TurnIn, Yr3TurnIn, Yr4TurnIn, Yr1Consumption, Yr2Consumption, Yr3Consumption
		, Yr4Consumption, MaxConsumption, Safety, WarReserve, Maximum, PartNo, PblItemType, Nomenclature, CageCode, ItemClassId, ActualYears, ItemClass, ProDuesConfirm
		, ProDuesNotConfirm, RepDuesConfirm, RepDuesNotConfirm, StockExcludeWaiting, StockIncludeWaiting, DuesOutUser, AvgPrice, LastAvgPrice, AvgTat
		, Nsn, Category, Uom, UnderStockTaking, Yr1RegularizedQty, Yr2RegularizedQty, Yr3RegularizedQty, Yr4RegularizedQty
		, CASE ActualYears 
			WHEN 1 THEN Yr1Consumption 
			WHEN 2 THEN Yr1Consumption + Yr2Consumption 
			WHEN 3 THEN Yr1Consumption + Yr2Consumption + Yr3Consumption 
			ELSE Yr1Consumption + Yr2Consumption + Yr3Consumption + Yr4Consumption 
		  END AS TotalConsumption	
	FROM (
		SELECT 
			  T1.ItemId, 0 AS Yr1Issue, 0 AS Yr2Issue, 0 AS Yr3Issue, 0 AS Yr4Issue, 
			  0 AS Yr1RegularizedQty, 0 AS Yr2RegularizedQty, 0 AS Yr3RegularizedQty, 0 AS Yr4RegularizedQty, 
			  0 AS Yr1TurnIn, 0 AS Yr2TurnIn, 0 AS Yr3TurnIn, 0 AS Yr4TurnIn
			, 0 AS Yr1Consumption, 0 AS Yr2Consumption, 0 AS Yr3Consumption, 0 AS Yr4Consumption, 0 AS MaxConsumption,  T1.Safety, T1.WarReserve
			, T1.Maximum, T1.PartNo, T1.PblItemType, T1.Nomenclature, T1.CageCode, T1.ItemClassId, @actualYears AS ActualYears, T1.ItemClass,  T2.ProDuesConfirm, T2.ProDuesNotConfirm
			, T2.RepDuesConfirm, T2.RepDuesNotConfirm, T2.StockExcludeWaiting, T2.StockIncludeWaiting, T2.DuesOutUser, T2.AvgPrice, T2.LastAvgPrice, T2.AvgTat, T1.Nsn, T1.Category, T1.Uom, T2.UnderStockTaking
		FROM ( --T1
			SELECT 
				  FirstPart.ItemId, LOG_TRN_STOCK_LEVEL2.SAFETY_ AS Safety, LOG_TRN_STOCK_LEVEL2.WAR_RESERVE_ AS WarReserve
				, LOG_TRN_STOCK_LEVEL2.MAX_ AS Maximum, ITMM.PART_NO_ AS PartNo, ITMM.PBL_ AS PblItemType, ITMM.NSN_ AS Nsn
				, SREF.CODE_ + ' - ' + SREF.DESC_ AS Category, Uom.CODE_ AS Uom, ITMM.NOMENCLATURE_ AS Nomenclature
				, ADM_MST_MANUFACTURES.CAGE_CODE_ AS CageCode, ADM_MST_SIMPLE_REF.ID_ AS ItemClassId, ADM_MST_SIMPLE_REF.CODE_ AS ItemClass
			FROM (
				SELECT ItemId, InLieuCode
				FROM (
					SELECT (
						SELECT TOP (1) ADM_MST_ITEMS.ID_ 
						FROM ADM_MST_ITEMS
						INNER JOIN ADM_TRN_ITEM_ASSOCS AS IT21 ON IT21.ITEM_ID = ADM_MST_ITEMS.ID_ AND IT21.L2_ID = @agl2Id
						WHERE (IT21.PRIMARY_PART_ = 1) AND (IT21.IN_LIEU_CODE_ = _source.IN_LIEU_CODE_) AND (IT21.PRIMARY_PART_ = 1)
					) AS ItemId, _source.IN_LIEU_CODE_ AS InLieuCode
					FROM (
						SELECT ITM.ID_ AS ItemId, IT22.IN_LIEU_CODE_ 
						FROM ADM_MST_ITEMS AS ITM 
						INNER JOIN ADM_TRN_ITEM_ASSOCS AS ITML2 ON ITM.ID_ = ITML2.ITEM_ID  AND ITML2.L2_ID = @agl2Id
						INNER JOIN ADM_MST_ITEMS AS ADM_MST_ITEMS_2 ON ITM.ID_ = ADM_MST_ITEMS_2.ID_
						INNER JOIN ADM_TRN_ITEM_ASSOCS AS IT22 ON IT22.ITEM_ID = ADM_MST_ITEMS_2.ID_ AND IT22.L2_ID = @agl2Id
						WHERE (ITM.GRP_TYPE_ = 'NonAircraft') AND (ITML2.L2_ID = @agl2Id) 
					) AS _source 
					INNER JOIN ADM_TRN_ITEM_ASSOCS AS IT23 ON IT23.IN_LIEU_CODE_ = _source.IN_LIEU_CODE_ AND IT23.L2_ID = @agl2Id
					WHERE (_source.IN_LIEU_CODE_ IS NOT NULL)
					GROUP BY _source.IN_LIEU_CODE_) AS Tem4
					WHERE (
						NOT EXISTS (
							SELECT 1 AS Expr1 FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY AS CH 
							INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId) 
									AND BU.BU_TYPE_ = 'Store' 
							WHERE (CH.ITEM_ID = Tem4.ItemId) AND (CH.L2_ID_ = @agl2Id)
						)
					) AND (
						NOT EXISTS (
							SELECT 1 AS Expr1 
							FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY AS CH
							INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId) AND BU.BU_TYPE_ = 'Store' 
							INNER JOIN ADM_MST_ITEMS AS PP ON CH.ITEM_ID = PP.ID_
							INNER JOIN ADM_TRN_ITEM_ASSOCS AS IT24 ON PP.ID_ = IT24.ITEM_ID AND IT24.L2_ID = @agl2Id
							WHERE (CH.L2_ID_ = @agl2Id) 
							AND (IT24.IN_LIEU_CODE_ = Tem4.InLieuCode)
						)
					  ) 
					  AND (
						NOT EXISTS (
							SELECT 1 AS Expr1 FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE AS CH 
							INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId) AND BU.BU_TYPE_ = 'Store' 
							INNER JOIN ADM_MST_ITEMS AS PP ON CH.ITEM_ID = PP.ID_
							INNER JOIN ADM_TRN_ITEM_ASSOCS AS IT25 ON PP.ID_ = IT25.ITEM_ID AND IT25.L2_ID = @agl2Id
							WHERE (CH.L2_ID_ = @agl2Id) AND (IT25.IN_LIEU_CODE_ = Tem4.InLieuCode)
						)
					  ) 
	  				 AND (
						NOT EXISTS (
								SELECT 1 AS Expr1 FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE AS CH 
								INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId)
								AND BU.BU_TYPE_ = 'Store'
								WHERE (CH.ITEM_ID = Tem4.ItemId) AND (CH.L2_ID_ = @agl2Id)
						 )
					 )
			) AS FirstPart 
			INNER JOIN ADM_MST_ITEMS AS ITMM ON ITMM.ID_ = FirstPart.ItemId
			LEFT JOIN  ADM_MST_SIMPLE_REF AS SREF ON SREF.ID_ = ITMM.CAT_ID_ 
			INNER JOIN LOG_MST_UNIT_OF_MEASURE AS Uom ON Uom.ID_ = ITMM.UOM_ID_
			INNER JOIN ADM_MST_MANUFACTURES ON ITMM.MNF_ID = ADM_MST_MANUFACTURES.ID_
			LEFT JOIN ADM_MST_SIMPLE_REF ON ITMM.CLS_ID_ = ADM_MST_SIMPLE_REF.ID_ 
			LEFT OUTER JOIN ADM_TRN_ITEM_ASSOCS as ITMA1 ON ITMA1.ITEM_ID = ITMM.ID_ AND ITMA1.L2_ID = @agl2Id 
			LEFT OUTER JOIN LOG_TRN_STOCK_LEVEL2 ON ITMA1.ID_ = LOG_TRN_STOCK_LEVEL2.ITEM_ASSOC_ID_ AND LOG_TRN_STOCK_LEVEL2.STORE_ID = @buId
		) AS T1
		LEFT OUTER JOIN (
			SELECT 
				  A.PRIMARY_PART_ITEM_ID_ AS ItemId, SUM(A.NEW_DUES_IN_CONF_) AS ProDuesConfirm, SUM(A.NEW_DUES_IN_NOT_CONF_) AS ProDuesNotConfirm
				, SUM(A.RPR_DUES_IN_CONF_) AS RepDuesConfirm, SUM(A.RPR_DUES_IN_NOT_CONF_) AS RepDuesNotConfirm
				, SUM(A.TOTAL_STOCK_) - (SUM(a.STOCK_AWAITING_RECEPTION_) + SUM(a.STOCK_AWAITING_LOCATION_)) AS StockExcludeWaiting
				, SUM(A.TOTAL_STOCK_) AS StockIncludeWaiting, SUM(A.USER_DUES_OUT_QTY) AS DuesOutUser, AVG(A.AVG_PRICE) AS AvgPrice
				, MAX(B.LAST_PROC_PRICE)  AS LastAvgPrice, AVG(A.AVG_TAT) AS AvgTat, ISNULL(SUM(A.UNDER_STOCK_TAKING_), 0) AS UnderStockTaking
			FROM LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE A 
			LEFT JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE B on  B.ITEM_ID_ = A.PRIMARY_PART_ITEM_ID_ and B.L2_ID_=A.L2_ID_ and B.BU_ID_=A.BU_ID_
			WHERE (A.L2_ID_ = @agl2Id) AND (A.CMD_ID_ = @commandId) 
			AND (
				A.BU_ID_ IN (
					SELECT ID_ FROM ADM_MST_BUSINESS_UNITS 
					WHERE ID_ = @buId
					UNION ALL
					SELECT TFU_ID FROM ADM_MST_STORE_TFU_BUSINESS_UNIT 
					WHERE (STORE_ID = @buId)
				)
			)
			GROUP BY A.PRIMARY_PART_ITEM_ID_
		) AS T2 ON T1.ItemId = T2.ItemId
		UNION ALL
		SELECT 
			T1.ItemId, T1.Yr1Issue, T1.Yr2Issue, T1.Yr3Issue, T1.Yr4Issue, T1.Yr1RegularizedQty,T1.Yr2RegularizedQty,T1.Yr3RegularizedQty,T1.Yr4RegularizedQty, 
			T1.Yr1TurnIn, T1.Yr2TurnIn, T1.Yr3TurnIn, T1.Yr4TurnIn
		, CASE WHEN T1.Yr1Consumption < 0 THEN 0 ELSE T1.Yr1Consumption END AS Yr1Consumption
		, CASE WHEN T1.Yr2Consumption < 0 THEN 0 ELSE T1.Yr2Consumption END AS Yr2Consumption
		, CASE WHEN T1.Yr3Consumption < 0 THEN 0 ELSE T1.Yr3Consumption END AS Yr3Consumption
		, CASE WHEN T1.Yr4Consumption < 0 THEN 0 ELSE T1.Yr4Consumption END AS Yr4Consumption
		, T1.MaxConsumption, T1.Safety, T1.WarReserve, T1.Maximum, T1.PartNo, T1.PblItemType, T1.Nomenclature, T1.CageCode, T1.ItemClassId
		, T1.ActualYears, T1.ItemClass, T2.ProDuesConfirm, T2.ProDuesNotConfirm, T2.RepDuesConfirm, T2.RepDuesNotConfirm, T2.StockExcludeWaiting
		, T2.StockIncludeWaiting, T2.DuesOutUser, T2.AvgPrice, T2.LastAvgPrice, T2.AvgTat, T1.Nsn, T1.Category, T1.Uom, T2.UnderStockTaking
		FROM (--T1
			SELECT 
				  ItemId, Yr1Issue, Yr2Issue, Yr3Issue, Yr4Issue, Yr1RegularizedQty,Yr2RegularizedQty,Yr3RegularizedQty,Yr4RegularizedQty, 
				  Yr1TurnIn, Yr2TurnIn, Yr3TurnIn, Yr4TurnIn, Yr1Consumption, Yr2Consumption
				, Yr3Consumption, Yr4Consumption, MaxConsumption, Safety, WarReserve, Maximum, PartNo, PblItemType, Nomenclature, CageCode
				, ItemClassId, @actualYears AS ActualYears, ItemClass, Nsn, Category, Uom
			FROM ( --RollupUnion
				SELECT 
					  FirstPart.ItemId, FirstPart.Yr1Issue, FirstPart.Yr2Issue, FirstPart.Yr3Issue, FirstPart.Yr4Issue, 
					  FirstPart.Yr1RegularizedQty, FirstPart.Yr2RegularizedQty, FirstPart.Yr3RegularizedQty, FirstPart.Yr4RegularizedQty,
					  FirstPart.Yr1TurnIn
					, FirstPart.Yr2TurnIn, FirstPart.Yr3TurnIn, FirstPart.Yr4TurnIn, FirstPart.Yr1Consumption, FirstPart.Yr2Consumption
					, FirstPart.Yr3Consumption, FirstPart.Yr4Consumption, FirstPart.MaxConsumption, LOG_TRN_STOCK_LEVEL2.SAFETY_ AS Safety
					, LOG_TRN_STOCK_LEVEL2.WAR_RESERVE_ AS WarReserve, LOG_TRN_STOCK_LEVEL2.MAX_ AS Maximum, ITMM.PART_NO_ AS PartNo
					, ITMM.PBL_ AS PblItemType, ITMM.NSN_ AS Nsn, SREF.CODE_ + ' - ' + SREF.DESC_ AS Category
					, Uom.CODE_ AS Uom, ITMM.NOMENCLATURE_ AS Nomenclature, ADM_MST_MANUFACTURES.CAGE_CODE_ AS CageCode
					, ADM_MST_SIMPLE_REF.ID_ AS ItemClassId, ADM_MST_SIMPLE_REF.CODE_ AS ItemClass
				FROM (
					SELECT 
						  SUM(_source.Yr1Issue) AS Yr1Issue, SUM(_source.Yr2Issue) AS Yr2Issue, SUM(_source.Yr3Issue) AS Yr3Issue, SUM(_source.Yr4Issue) AS Yr4Issue
						, SUM(_source.Yr1RegularizedQty) AS Yr1RegularizedQty, SUM(_source.Yr2RegularizedQty) AS Yr2RegularizedQty, SUM(_source.Yr3RegularizedQty) AS Yr3RegularizedQty, SUM(_source.Yr4RegularizedQty) AS Yr4RegularizedQty
						, SUM(_source.Yr1TurnIn) AS Yr1TurnIn, SUM(_source.Yr2TurnIn) AS Yr2TurnIn
						, SUM(_source.Yr3TurnIn) AS Yr3TurnIn, SUM(_source.Yr4TurnIn) AS Yr4TurnIn, SUM(_source.Yr1Consumption) AS Yr1Consumption
						, SUM(_source.Yr2Consumption) AS Yr2Consumption, SUM(_source.Yr3Consumption) AS Yr3Consumption, SUM(_source.Yr4Consumption) AS Yr4Consumption
						, CASE 
							WHEN SUM(_source.Yr1Consumption) > SUM(_source.Yr2Consumption) AND SUM(_source.Yr1Consumption) > SUM(_source.Yr3Consumption) 
								 AND SUM(_source.Yr1Consumption) > SUM(_source.Yr4Consumption) THEN SUM(_source.Yr1Consumption) 
							WHEN SUM(_source.Yr2Consumption) > SUM(_source.Yr1Consumption) AND SUM(_source.Yr2Consumption) > SUM(_source.Yr3Consumption)
								 AND SUM(_source.Yr2Consumption) > SUM(_source.Yr4Consumption) THEN SUM(_source.Yr2Consumption) 
							WHEN SUM(_source.Yr3Consumption) > SUM(_source.Yr1Consumption) AND SUM(_source.Yr3Consumption) > SUM(_source.Yr2Consumption)
								 AND SUM(_source.Yr3Consumption) > SUM(_source.Yr4Consumption) THEN SUM(_source.Yr3Consumption) 
							WHEN SUM(_source.Yr4Consumption) > SUM(_source.Yr1Consumption) AND SUM(_source.Yr4Consumption) > SUM(_source.Yr2Consumption) 
								 AND SUM(_source.Yr4Consumption) > SUM(_source.Yr3Consumption) THEN SUM(_source.Yr4Consumption) 
						  END AS MaxConsumption
						, (
							SELECT TOP (1) ADM_MST_ITEMS.ID_ 
							FROM  ADM_MST_ITEMS
							INNER JOIN ADM_TRN_ITEM_ASSOCS AS IA12 ON IA12.ITEM_ID = ADM_MST_ITEMS.ID_ AND IA12.L2_ID = @agl2Id
							INNER JOIN ADM_TRN_ITEM_ASSOCS AS IA13 ON IA13.IN_LIEU_CODE_ = IA12.IN_LIEU_CODE_ AND IA13.L2_ID = @agl2Id
							WHERE (IA12.PRIMARY_PART_ = 1) AND (IA12.IN_LIEU_CODE_ = _source.IN_LIEU_CODE_) AND (IA12.PRIMARY_PART_ = 1)
						  ) AS ItemId
					FROM (
						SELECT 
							  totalConsumption.ItemId, totalConsumption.Yr1Issue, totalConsumption.Yr2Issue, totalConsumption.Yr3Issue
							, totalConsumption.Yr4Issue,  totalConsumption.Yr1RegularizedQty,  totalConsumption.Yr2RegularizedQty,  totalConsumption.Yr3RegularizedQty,  totalConsumption.Yr4RegularizedQty
							, totalConsumption.Yr1TurnIn, totalConsumption.Yr2TurnIn, totalConsumption.Yr3TurnIn
							, totalConsumption.Yr4TurnIn, totalConsumption.Yr1Consumption, totalConsumption.Yr2Consumption
							, totalConsumption.Yr3Consumption, totalConsumption.Yr4Consumption,IT13.IN_LIEU_CODE_
						FROM (
							SELECT 
								  ISNULL(Consumption.ItemId, consumptionBase.ItemId) AS ItemId
								, ISNULL(Consumption.Yr1Issue, 0) + ISNULL(consumptionBase.Yr1Issue, 0) AS Yr1Issue
								, ISNULL(Consumption.Yr2Issue, 0) + ISNULL(consumptionBase.Yr2Issue, 0) AS Yr2Issue
								, ISNULL(Consumption.Yr3Issue, 0) + ISNULL(consumptionBase.Yr3Issue, 0) AS Yr3Issue
								, ISNULL(Consumption.Yr4Issue, 0) + ISNULL(consumptionBase.Yr4Issue, 0) AS Yr4Issue
								, ISNULL(Consumption.Yr1RegularizedQty, 0) + ISNULL(consumptionBase.Yr1RegularizedQty, 0) AS Yr1RegularizedQty
								, ISNULL(Consumption.Yr2RegularizedQty, 0) + ISNULL(consumptionBase.Yr2RegularizedQty, 0) AS Yr2RegularizedQty
								, ISNULL(Consumption.Yr3RegularizedQty, 0) + ISNULL(consumptionBase.Yr3RegularizedQty, 0) AS Yr3RegularizedQty
								, ISNULL(Consumption.Yr4RegularizedQty, 0) + ISNULL(consumptionBase.Yr4RegularizedQty, 0) AS Yr4RegularizedQty
								, ISNULL(Consumption.Yr1TurnIn, 0) + ISNULL(consumptionBase.Yr1TurnIn, 0) AS Yr1TurnIn
								, ISNULL(Consumption.Yr2TurnIn, 0) + ISNULL(consumptionBase.Yr2TurnIn, 0) AS Yr2TurnIn
								, ISNULL(Consumption.Yr3TurnIn, 0) + ISNULL(consumptionBase.Yr3TurnIn, 0) AS Yr3TurnIn
								, ISNULL(Consumption.Yr4TurnIn, 0) + ISNULL(consumptionBase.Yr4TurnIn, 0) AS Yr4TurnIn
								, ISNULL(Consumption.Yr1Consumption, 0) + ISNULL(consumptionBase.Yr1Consumption, 0) AS Yr1Consumption
								, ISNULL(Consumption.Yr2Consumption, 0) + ISNULL(consumptionBase.Yr2Consumption, 0) AS Yr2Consumption
								, ISNULL(Consumption.Yr3Consumption, 0) + ISNULL(consumptionBase.Yr3Consumption, 0) AS Yr3Consumption
								, ISNULL(Consumption.Yr4Consumption, 0) + ISNULL(consumptionBase.Yr4Consumption, 0) AS Yr4Consumption
							FROM (
								SELECT 
									  CH.ITEM_ID AS ItemId
									, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr1Issue
									, SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr1RegularizedQty
									, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1TurnIn
									, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1Consumption
									, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr2Issue
									, SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr2RegularizedQty
									, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2TurnIn
									, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2Consumption
									, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr3Issue
									, SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr3RegularizedQty
									, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3TurnIn
									, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3Consumption
									, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr4Issue
									, SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr4RegularizedQty
									, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4TurnIn
									, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4Consumption
								FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY AS CH
								INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId)
								WHERE (CH.L2_ID_ = @agl2Id) AND (BU.BU_TYPE_ = 'Store') 
								GROUP BY CH.ITEM_ID
							) AS Consumption
							FULL OUTER JOIN (
								SELECT 
									  CHB.ITEM_ID AS ItemId
									, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr1Issue
									, SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr1RegularizedQty
									, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1TurnIn
									, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1Consumption
									, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr2Issue
									, SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr2RegularizedQty
									, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2TurnIn
									, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2Consumption
									, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr3Issue
									, SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr3RegularizedQty
									, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3TurnIn
									, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3Consumption
									, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr4Issue
									, SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr4RegularizedQty
									, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4TurnIn
									, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4Consumption
							   FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE AS CHB 
							   INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CHB.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId)
							   WHERE (CHB.L2_ID_ = @agl2Id) AND (BU.BU_TYPE_ = 'Store') 
							   GROUP BY CHB.ITEM_ID) AS consumptionBase ON Consumption.ItemId = consumptionBase.ItemId
							) AS totalConsumption
							INNER JOIN ADM_MST_ITEMS AS ADM_MST_ITEMS_2 ON totalConsumption.ItemId = ADM_MST_ITEMS_2.ID_
							INNER JOIN ADM_TRN_ITEM_ASSOCS AS IT13 ON IT13.ITEM_ID = totalConsumption.ItemId AND IT13.L2_ID = @agl2Id) AS _source
							INNER JOIN ADM_TRN_ITEM_ASSOCS AS IT14 ON IT14.ITEM_ID = _source.ItemId AND _source.IN_LIEU_CODE_ = IT14.IN_LIEU_CODE_ AND IT14.L2_ID = @agl2Id
							WHERE (_source.IN_LIEU_CODE_ IS NOT NULL)
							GROUP BY _source.IN_LIEU_CODE_) AS FirstPart
							INNER JOIN ADM_MST_ITEMS AS ITMM ON ITMM.ID_ = FirstPart.ItemId
							LEFT JOIN ADM_MST_SIMPLE_REF AS SREF ON SREF.ID_ = ITMM.CAT_ID_ 
							INNER JOIN LOG_MST_UNIT_OF_MEASURE AS Uom ON Uom.ID_ = ITMM.UOM_ID_
							INNER JOIN ADM_MST_MANUFACTURES ON ITMM.MNF_ID = ADM_MST_MANUFACTURES.ID_
							LEFT JOIN ADM_MST_SIMPLE_REF ON ITMM.CLS_ID_ = ADM_MST_SIMPLE_REF.ID_
							LEFT OUTER JOIN ADM_TRN_ITEM_ASSOCS AS ITMA2 ON ITMA2.ITEM_ID = ITMM.ID_ AND ITMA2.L2_ID = @agl2Id
							LEFT OUTER JOIN LOG_TRN_STOCK_LEVEL2 ON ITMA2.ID_ = LOG_TRN_STOCK_LEVEL2.ITEM_ASSOC_ID_ AND LOG_TRN_STOCK_LEVEL2.STORE_ID = @buId
							UNION ALL
							SELECT 
								  item.ID_ AS ItemId, SUM(totalConsumption.Yr1Issue) AS Yr1Issue, SUM(totalConsumption.Yr2Issue) AS Yr2Issue
								, SUM(totalConsumption.Yr3Issue) AS Yr3Issue, SUM(totalConsumption.Yr4Issue) AS Yr4Issue
								, SUM(totalConsumption.Yr1RegularizedQty) AS Yr1RegularizedQty, SUM(totalConsumption.Yr2RegularizedQty) AS Yr2RegularizedQty
								, SUM(totalConsumption.Yr3RegularizedQty) AS Yr3RegularizedQty, SUM(totalConsumption.Yr4RegularizedQty) AS Yr4RegularizedQty
								, SUM(totalConsumption.Yr1TurnIn) AS Yr1TurnIn, SUM(totalConsumption.Yr2TurnIn) AS Yr2TurnIn
								, SUM(totalConsumption.Yr3TurnIn) AS Yr3TurnIn, SUM(totalConsumption.Yr4TurnIn) AS Yr4TurnIn
								, SUM(totalConsumption.Yr1Consumption) AS Yr1Consumption, SUM(totalConsumption.Yr2Consumption) AS Yr2Consumption
								, SUM(totalConsumption.Yr3Consumption) AS Yr3Consumption, SUM(totalConsumption.Yr4Consumption) AS Yr4Consumption
								, CASE 
									WHEN SUM(totalConsumption.Yr1Consumption) > SUM(totalConsumption.Yr2Consumption) AND SUM(totalConsumption.Yr1Consumption) > SUM(totalConsumption.Yr3Consumption) 
										AND SUM(totalConsumption.Yr1Consumption) > SUM(totalConsumption.Yr4Consumption) THEN SUM(totalConsumption.Yr1Consumption) 
									WHEN SUM(totalConsumption.Yr2Consumption) > SUM(totalConsumption.Yr1Consumption) AND SUM(totalConsumption.Yr2Consumption) > SUM(totalConsumption.Yr3Consumption) 
										AND SUM(totalConsumption.Yr2Consumption) > SUM(totalConsumption.Yr4Consumption) THEN SUM(totalConsumption.Yr2Consumption) 
									WHEN SUM(totalConsumption.Yr3Consumption) > SUM(totalConsumption.Yr1Consumption) AND SUM(totalConsumption.Yr3Consumption) > SUM(totalConsumption.Yr2Consumption) 
										AND SUM(totalConsumption.Yr3Consumption) > SUM(totalConsumption.Yr4Consumption) THEN SUM(totalConsumption.Yr3Consumption) 
									WHEN SUM(totalConsumption.Yr4Consumption) > SUM(totalConsumption.Yr1Consumption) AND SUM(totalConsumption.Yr4Consumption) > SUM(totalConsumption.Yr2Consumption) 
										AND SUM(totalConsumption.Yr4Consumption) > SUM(totalConsumption.Yr3Consumption) THEN SUM(totalConsumption.Yr4Consumption) 
								  END AS MaxConsumption
								, LOG_TRN_STOCK_LEVEL2.SAFETY_ AS Safety, LOG_TRN_STOCK_LEVEL2.WAR_RESERVE_ AS WarReserve
								, LOG_TRN_STOCK_LEVEL2.MAX_ AS Maximum, item.PART_NO_ AS PartNo, item.PBL_ AS PblItemType, item.NSN_ AS Nsn
								, SREF.CODE_ + ' - ' + SREF.DESC_ AS Category, Uom.CODE_ AS Uom,item.NOMENCLATURE_ AS Nomenclature
								, ADM_MST_MANUFACTURES.CAGE_CODE_ AS CageCode, ADM_MST_SIMPLE_REF.ID_ AS ItemClassId
								, ADM_MST_SIMPLE_REF.CODE_ AS ItemClass
							FROM ( --totalConsumption
								SELECT 
									  ISNULL(Consumption.ItemId, consumptionBase.ItemId) AS ItemId
									, ISNULL(Consumption.Yr1Issue, 0)+ ISNULL(consumptionBase.Yr1Issue, 0) AS Yr1Issue
									, ISNULL(Consumption.Yr2Issue, 0) + ISNULL(consumptionBase.Yr2Issue, 0) AS Yr2Issue
									, ISNULL(Consumption.Yr3Issue, 0) + ISNULL(consumptionBase.Yr3Issue, 0) AS Yr3Issue
									, ISNULL(Consumption.Yr4Issue, 0) + ISNULL(consumptionBase.Yr4Issue, 0) AS Yr4Issue
									, ISNULL(Consumption.Yr1RegularizedQty, 0)+ ISNULL(consumptionBase.Yr1RegularizedQty, 0) AS Yr1RegularizedQty
									, ISNULL(Consumption.Yr2RegularizedQty, 0)+ ISNULL(consumptionBase.Yr2RegularizedQty, 0) AS Yr2RegularizedQty
									, ISNULL(Consumption.Yr3RegularizedQty, 0)+ ISNULL(consumptionBase.Yr3RegularizedQty, 0) AS Yr3RegularizedQty
									, ISNULL(Consumption.Yr4RegularizedQty, 0)+ ISNULL(consumptionBase.Yr4RegularizedQty, 0) AS Yr4RegularizedQty
									, ISNULL(Consumption.Yr1TurnIn, 0) + ISNULL(consumptionBase.Yr1TurnIn, 0) AS Yr1TurnIn
									, ISNULL(Consumption.Yr2TurnIn, 0) + ISNULL(consumptionBase.Yr2TurnIn, 0) AS Yr2TurnIn
									, ISNULL(Consumption.Yr3TurnIn, 0) + ISNULL(consumptionBase.Yr3TurnIn, 0) AS Yr3TurnIn
									, ISNULL(Consumption.Yr4TurnIn, 0) + ISNULL(consumptionBase.Yr4TurnIn, 0) AS Yr4TurnIn
									, ISNULL(Consumption.Yr1Consumption, 0) + ISNULL(consumptionBase.Yr1Consumption, 0) AS Yr1Consumption
									, ISNULL(Consumption.Yr2Consumption, 0) + ISNULL(consumptionBase.Yr2Consumption, 0) AS Yr2Consumption
									, ISNULL(Consumption.Yr3Consumption, 0) + ISNULL(consumptionBase.Yr3Consumption, 0) AS Yr3Consumption
									, ISNULL(Consumption.Yr4Consumption, 0) + ISNULL(consumptionBase.Yr4Consumption, 0) AS Yr4Consumption
								FROM (
									SELECT 
										  CH.ITEM_ID AS ItemId
										, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr1Issue
										, SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr1RegularizedQty
										, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1TurnIn
										, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1Consumption
										, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr2Issue
										, SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr2RegularizedQty
										, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2TurnIn
										, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2Consumption
										, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr3Issue
										, SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr3RegularizedQty
										, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3TurnIn
										, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3Consumption
										, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr4Issue
										, SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr4RegularizedQty
										, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4TurnIn
										, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4Consumption
									FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY AS CH
									INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CH.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId)
									WHERE (CH.L2_ID_ = @agl2Id) AND (BU.BU_TYPE_ = 'Store') 
									GROUP BY CH.ITEM_ID
								) AS Consumption
								FULL OUTER JOIN (
									SELECT 
										CHB.ITEM_ID AS ItemId, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr1Issue
										, SUM(CASE WHEN YEAR = @fromYear THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr1RegularizedQty
										, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1TurnIn
										, SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr1Consumption
										, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr2Issue
										, SUM(CASE WHEN YEAR = @fromYear + 1 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr2RegularizedQty
										, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2TurnIn
										, SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 1 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr2Consumption
										, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr3Issue
										, SUM(CASE WHEN YEAR = @fromYear + 2 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr3RegularizedQty
										, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3TurnIn
										, SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 2 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr3Consumption
										, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) AS Yr4Issue
										, SUM(CASE WHEN YEAR = @fromYear + 3 THEN REGULARIZED_QTY_ ELSE 0 END) AS Yr4RegularizedQty
										, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4TurnIn
										, SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_ISSUE_ ELSE 0 END) - SUM(CASE WHEN YEAR = @fromYear + 3 THEN TOTAL_TURN_IN_ ELSE 0 END) AS Yr4Consumption
									FROM LOG_TRN_ITEM_CONSUMPTION_HISTORY_BASELINE AS CHB
									INNER JOIN ADM_MST_BUSINESS_UNITS AS BU ON CHB.BU_ID_ = BU.ID_ AND BU.CMD_ID_ = @commandId AND (BU.ID_ = @buId)
									WHERE (CHB.L2_ID_ = @agl2Id) AND (BU.BU_TYPE_ = 'Store') 
									GROUP BY CHB.ITEM_ID
								) AS consumptionBase ON Consumption.ItemId = consumptionBase.ItemId
							) totalConsumption
							INNER JOIN ADM_MST_ITEMS AS item ON totalConsumption.ItemId = item.ID_
							LEFT JOIN ADM_MST_SIMPLE_REF AS SREF ON SREF.ID_ = item.CAT_ID_ 
							INNER JOIN LOG_MST_UNIT_OF_MEASURE AS Uom ON Uom.ID_ = item.UOM_ID_
							INNER JOIN ADM_MST_MANUFACTURES ON item.MNF_ID = ADM_MST_MANUFACTURES.ID_
							LEFT JOIN ADM_MST_SIMPLE_REF ON item.CLS_ID_ = ADM_MST_SIMPLE_REF.ID_
							LEFT OUTER JOIN ADM_TRN_ITEM_ASSOCS AS ITMA3 ON ITMA3.ITEM_ID = item.ID_ AND ITMA3.L2_ID = @agl2Id
							LEFT OUTER JOIN LOG_TRN_STOCK_LEVEL2 ON ITMA3.ID_ = LOG_TRN_STOCK_LEVEL2.ITEM_ASSOC_ID_ AND LOG_TRN_STOCK_LEVEL2.STORE_ID = @buId
							LEFT OUTER JOIN ADM_TRN_ITEM_ASSOCS ON ITMA3.IN_LIEU_CODE_ = ADM_TRN_ITEM_ASSOCS.IN_LIEU_CODE_ AND ITMA3.L2_ID = ADM_TRN_ITEM_ASSOCS.L2_ID
							WHERE (ITMA3.IN_LIEU_CODE_ IS NULL) AND (ITMA3.PRIMARY_PART_ = 1)
							GROUP BY  item.ID_, item.PART_NO_, item.PBL_, item.NOMENCLATURE_, ADM_MST_MANUFACTURES.CAGE_CODE_
									, item.NSN_,LOG_TRN_STOCK_LEVEL2.SAFETY_, LOG_TRN_STOCK_LEVEL2.WAR_RESERVE_, LOG_TRN_STOCK_LEVEL2.MAX_
									, LOG_TRN_STOCK_LEVEL2.STORE_ID, ITMA3.L2_ID, ADM_MST_SIMPLE_REF.ID_, ADM_MST_SIMPLE_REF.CODE_, SREF.CODE_, SREF.DESC_ ,Uom.CODE_
			) AS RollupUnion
		) AS T1 
		LEFT OUTER JOIN
		(
			SELECT 
				A.PRIMARY_PART_ITEM_ID_ AS ItemId, SUM(A.NEW_DUES_IN_CONF_) AS ProDuesConfirm, SUM(A.NEW_DUES_IN_NOT_CONF_) AS ProDuesNotConfirm
				, SUM(A.TOTAL_STOCK_) - (SUM(A.STOCK_AWAITING_RECEPTION_) + SUM(A.STOCK_AWAITING_LOCATION_)) AS StockExcludeWaiting
				, SUM(A.TOTAL_STOCK_) AS StockIncludeWaiting, SUM(A.RPR_DUES_IN_CONF_) AS RepDuesConfirm, SUM(A.RPR_DUES_IN_NOT_CONF_) AS RepDuesNotConfirm
				, SUM(A.USER_DUES_OUT_QTY) AS DuesOutUser, AVG(A.AVG_PRICE) AS AvgPrice, AVG(B.LAST_PROC_PRICE) AS LastAvgPrice, AVG(A.AVG_TAT) AS AvgTat
				, ISNULL(SUM(A.UNDER_STOCK_TAKING_), 0) AS UnderStockTaking
			FROM LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE A
			LEFT JOIN LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE B on  B.ITEM_ID_ = A.PRIMARY_PART_ITEM_ID_ and B.L2_ID_=A.L2_ID_ and B.BU_ID_=A.BU_ID_
			WHERE (A.L2_ID_ = @agl2Id) AND (A.CMD_ID_ = @commandId) AND (
				A.BU_ID_ IN (
					SELECT ID_ 
					FROM ADM_MST_BUSINESS_UNITS WHERE ID_ = @buId
					UNION ALL
					SELECT TFU_ID FROM ADM_MST_STORE_TFU_BUSINESS_UNIT WHERE (STORE_ID = @buId)
				)
			)
			GROUP BY A.PRIMARY_PART_ITEM_ID_
		) AS T2 ON T1.ItemId = T2.ItemId
	) AS FinalRollup
	WHERE (1 = 1 AND @partNoId = 0) OR (ItemId = @partNoId)

END
go

