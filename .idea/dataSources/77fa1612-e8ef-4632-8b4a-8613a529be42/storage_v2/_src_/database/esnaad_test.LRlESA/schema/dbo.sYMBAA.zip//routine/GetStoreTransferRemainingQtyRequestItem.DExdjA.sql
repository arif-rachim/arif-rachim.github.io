CREATE FUNCTION [dbo].[GetStoreTransferRemainingQtyRequestItem]
(
	-- Add the parameters for the function here
	@StoreTransferIds		uniqueidentifier,
	@TransferRequestItemId  uniqueidentifier
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @result int
   
    -- Add the T-SQL statements to compute the return value here
SELECT @result = ISNULL(SUM(TRI.REQ_QTY_),0) - ISNULL(SUM(TRI.TOT_ISSUED_QTY_),0)
					 FROM LOG_TRN_TRM_TRANSFER_REQUEST_ITEM TRI
					 INNER JOIN ADM_MST_ITEMS I ON TRI.ITEM_ID_ = I.ID_
					 WHERE TRI.TR_ID = @StoreTransferIds
					 AND TRI.ID_ = @TransferRequestItemId
	
	-- Return the result of the function
	RETURN @result
END
go

