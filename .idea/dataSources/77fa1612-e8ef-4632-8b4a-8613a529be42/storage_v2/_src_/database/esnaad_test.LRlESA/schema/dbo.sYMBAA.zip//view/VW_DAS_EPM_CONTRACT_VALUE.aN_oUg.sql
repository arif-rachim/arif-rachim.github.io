CREATE VIEW VW_DAS_EPM_CONTRACT_VALUE AS
SELECT     VCON.ContractTypeId, VCON.ContractSubTypeId, VCON.NumberOfContract, VFIN.ContractValue, 'AED' AS Currency, 
                      CASE WHEN VCON.ContractTypeId = 3 THEN 'FMS' WHEN VCON.ContractTypeId = 4 THEN 'DCS' END AS ContractType, CASE WHEN (VCON.ContractSubTypeId = 2) 
                      THEN 'P&O' WHEN (VCON.ContractSubTypeId = 3) THEN 'MOD' WHEN (VCON.ContractSubTypeId = 4) THEN 'FOS' WHEN (VCON.ContractSubTypeId = 5) 
                      THEN 'GEN' WHEN (VCON.ContractSubTypeId = 6) THEN 'TRN' ELSE '' END AS ContractSubType
FROM         (SELECT     CON.CONT_TYPE_ID AS ContractTypeId, CON.CONT_SUB_TYPE_ID AS ContractSubTypeId, COUNT(*) AS NumberOfContract, TYP.NAME_ AS ContractType, 
                                              SUB.NAME_ AS ContractSubType
                        FROM         dbo.PMO_TRN_CONTRACT AS CON LEFT OUTER JOIN
                                              dbo.PMO_MST_CONTRACT_SUBTYPE AS SUB ON SUB.ID_ = CON.CONT_SUB_TYPE_ID LEFT OUTER JOIN
                                              dbo.PMO_MST_CONTRACT_TYPE AS TYP ON TYP.ID_ = CON.CONT_TYPE_ID
                        GROUP BY TYP.NAME_, SUB.NAME_, CON.CONT_TYPE_ID, CON.CONT_SUB_TYPE_ID, TYP.ID_, SUB.ID_) AS VCON LEFT OUTER JOIN
                          (SELECT     CON.CONT_TYPE_ID AS ContractTypeId, CON.CONT_SUB_TYPE_ID AS ContractSubTypeId, SUM(CONVERT(decimal(18, 2), CONVERT(decimal(18, 2), 
                                                   FIN.CONT_VAL_CURR_VAL_) * CONVERT(decimal(18, 2), FIN.RATE_CURR_VAL_))) AS ContractValue, 'AED' AS Currency
                             FROM         dbo.PMO_TRN_CONTRACT AS CON INNER JOIN
                                                   dbo.PMO_TRN_CONTRACT_FINANCIAL_INFO AS FIN ON FIN.CONTRACT_ID = CON.ID_ INNER JOIN
                                                   dbo.ADM_MST_MONEY_CURRENCY AS CUR ON CUR.ID_ = FIN.CONT_VAL_CURR_ID
                             GROUP BY CON.CONT_TYPE_ID, CON.CONT_SUB_TYPE_ID) AS VFIN ON VCON.ContractTypeId = VFIN.ContractTypeId AND ISNULL(VCON.ContractSubTypeId, 0) 
                      = ISNULL(VFIN.ContractSubTypeId, 0)
GROUP BY VCON.ContractType, VCON.ContractSubType, VCON.ContractTypeId, VCON.ContractSubTypeId, VCON.NumberOfContract, VCON.NumberOfContract, 
                      VFIN.ContractValue, VFIN.Currency
go

