CREATE FUNCTION [dbo].[ConvertSecondsToTamms]
(
	@totalSeconds BIGINT
)
RETURNS decimal(9,1)
AS
BEGIN
	DECLARE @hourPart BIGINT;
	DECLARE @minutesRem INT;
	DECLARE @minPart INT;	
	
	DECLARE @return_taams_time decimal(9,1);	
	DECLARE @minutePart decimal(9,3); 
	
	-- Find Hr
	SET @hourPart = @totalSeconds / 3600
	SET @minutesRem = @totalSeconds % 3600;
	-- Find Min
	SET @minPart = @minutesRem / 60;

	if(@hourPart is not null OR @minPart is not null)
	BEGIN
		SELECT @return_taams_time = 0
		SET @hourPart = @hourPart
		SET @minutePart = @minPart
		SET @return_taams_time =  @hourPart + ceiling(@minutePart/6) /10
	END
	RETURN @return_taams_time
END
go

