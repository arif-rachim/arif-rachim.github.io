CREATE FUNCTION [dbo].[GetAveragePrice](
    @itemId bigint
)
    RETURNS decimal(18, 2)
AS
BEGIN
    DECLARE @result decimal(18, 2);

    with cte as (
        select
            po.PO_DATE_                                             as PoDate
          , cast(POI.UNIT_PRICE_VAL_ / CUR.RATE_ as decimal(18, 2)) as Price
        FROM LOG_TRN_PRC_PURCHASE_ORDER po
                 JOIN LOG_TRN_PRC_PURCHASE_ORDER_ITEM poi ON poi.PO_ID = po.ID_
                 JOIN LOG_TRN_PRC_PROCUREMENT_ITEM pri ON poi.PROC_ITEM_ID = pri.ID_
                 JOIN ADM_MST_MONEY_CURRENCY cur ON cur.ID_ = poi.UNIT_PRICE_CUR_ID
        WHERE PO.STATUS_ IN ('Validated', 'PartiallyDelivered', 'Closed')
          and PO.PRIORITY_ in ('NOR', 'IOR')
          AND POI.UNIT_PRICE_VAL_ > 0
          AND ISNULL(POI.INLIEU_ITEM_ID, PRI.ITEM_ID) = @itemId
          and po.PO_DATE_ >= dateadd(year, -5, getdate()))
    select
            @result =
            case
                when (select count(cte.PoDate) from cte where cte.PoDate >= dateadd(year, -3, getdate())) > 0 then
                    (select cast(sum(cte.Price) / count(cte.Price) as decimal(18, 2))
                     from cte
                     where cte.PoDate >= dateadd(year, -3, getdate()))
                else
                    (select cast(sum(cte.Price) / count(cte.Price) as decimal(18, 2))
                     from cte
                     where cte.PoDate >= dateadd(year, -5, getdate()))
                end

    RETURN @result
END
go

