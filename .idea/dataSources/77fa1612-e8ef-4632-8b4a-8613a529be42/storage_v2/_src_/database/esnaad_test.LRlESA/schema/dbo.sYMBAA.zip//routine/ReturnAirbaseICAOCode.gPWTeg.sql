CREATE FUNCTION ReturnAirbaseICAOCode(@airbaseId int) RETURNS varchar(100)
BEGIN
	DECLARE @retValue varchar(100)
	SELECT @retValue = ICAO_ FROM ADM_MST_AIR_BASES WHERE ID_ = @airbaseId
	RETURN @retValue
END
go

