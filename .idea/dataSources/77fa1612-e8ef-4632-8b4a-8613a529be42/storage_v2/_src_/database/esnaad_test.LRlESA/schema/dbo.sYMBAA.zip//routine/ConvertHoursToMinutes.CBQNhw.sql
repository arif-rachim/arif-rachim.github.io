CREATE FUNCTION [dbo].[ConvertHoursToMinutes]
(
	@hours FLOAT
)
RETURNS FLOAT --FLOAT
AS
BEGIN
	DECLARE @minutes FLOAT;
	DECLARE @minutePart FLOAT;
	DECLARE @hourPart bigint;
	SET @hourPart = FLOOR(@hours);	
	SET @minutePart = @hours - @hourPart;
	SET @minutes = (@hourPart * 60) + (@minutePart * 100);
	RETURN @minutes;
END
go

