CREATE FUNCTION ReturnFlightSymbol(@Id int) RETURNS varchar(100)
BEGIN
	DECLARE @retValue varchar(100)
	SELECT 	@retValue = CODE_ FROM  OPS_MST_FLIGHT_SYMBOL WHERE ID_ = @Id
	RETURN @retValue
END
go

