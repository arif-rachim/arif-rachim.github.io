CREATE PROCEDURE [dbo].[OPS_CREW_FLYING_RECORD]  
 -- ===============================================
 -- Updates:
 -- 2020-08-05 : us #53929-Enhancement_in_Displaying_Cross_Midnight_Flights_in_Flight_Activities 
 --				 introduce isGmt parameter
 -- ===============================================
 @crewId BIGINT,  
 @fromDate VARCHAR(50),  
 @toDate VARCHAR(50),  
 @platformFilter VARCHAR(50) = '',  
   
 -- =============================================  
 -- GRID FILTER  
 -- =============================================  
 @missionDateFilter VARCHAR(50) = NULL,  
 @companyFilter VARCHAR(50) = NULL,  
 @platformGridFilter VARCHAR(50) = NULL,  
 @tailFilter VARCHAR(50) = NULL,  
 @dutySymbolFilter VARCHAR(50) = NULL,  
 @dayHoursFilter VARCHAR(50) = NULL,  
 @nightHoursFilter VARCHAR(50) = NULL,  
 @nvgFilter VARCHAR(50) = NULL,  
 @nvsFilter VARCHAR(50) = NULL,  
 @totalFilter VARCHAR(50) = NULL,  
 @ifrActualFilter VARCHAR(50) = NULL,  
 @ifrSimulatedFilter VARCHAR(50) = NULL,  
 @missionTypeFilter VARCHAR(500) = NULL,  
 @missionSubTypeFilter VARCHAR(500) = NULL,
 @isGmt bit = 0 
  
AS  
BEGIN  
  
 SET NOCOUNT ON;  
  
   PRINT '|' + @missionDateFilter + '|';  
   print 'LIKE %' + @missionDateFilter + '%'  
     
  SELECT MissionDate, Company, Platform, Tail, DutySymbol, FlightRecordId, 
	 D, DS,	 DayHours,
	 NightHours, N, Nvg, Nvs, 
	 Total, TotalHours,
	 CASE WHEN RankId <> 1 THEN '0:00' ELSE IfrActual END AS IfrActual, 
	 CASE WHEN RankId <> 1 THEN '0:00' ELSE IfrSimulated END AS IfrSimulated, 
	 Seat, MissionType, MissionSubType
	 FROM 
 (SELECT   
  UPPER(case @isGmt when 0 then MissionDate else MissionDateGmt end) as MissionDate, Company, Platform, Tail, DutySymbol, FlightRecordId, 
  ROW_NUMBER() OVER (PARTITION BY FlightRecordId ORDER BY FlightRecordId) AS RankId, 
  dbo.ConvertMinutesToHHMM(D*60) AS D,
  dbo.ConvertMinutesToHHMM(DS*60) AS DS, 
  dbo.ConvertMinutesToHHMM(DayHours*60) AS DayHours, 
  dbo.ConvertMinutesToHHMM(NightHours*60) AS NightHours, 
  dbo.ConvertMinutesToHHMM(N*60) AS N,   
  dbo.ConvertMinutesToHHMM(Nvg*60) AS Nvg, 
  dbo.ConvertMinutesToHHMM(Nvs*60) AS Nvs, 
  dbo.ConvertMinutesToHHMM(Total*60) AS Total, 
  dbo.ConvertMinutesToHHMM(Total*60) AS TotalHours,   
  dbo.ConvertMinutesToHHMM(IfrActual*60) AS IfrActual, 
  dbo.ConvertMinutesToHHMM(IfrSimulated*60) AS IfrSimulated,  
  MissionType, MissionSubType ,Seat  
 FROM  
  VW_OPS_CREW_FLYING_RECORD_LIST  
 WHERE  
  CrewId = @crewId  
  AND ((@isGmt = 1 and CAST(MissionDateGmt AS DATE) >= @fromDate) or (@isGmt = 0 and CAST(MissionDate AS DATE) >= @fromDate))
  AND ((@isGmt =1 and CAST(MissionDateGmt AS DATE) <= @toDate) or (@isGmt = 0 and CAST(MissionDate AS DATE) <= @toDate))
  AND   
  (   
   ( (@platformFilter IS NOT NULL) AND (@platformFilter <> '') AND [Platform] = @platformFilter)  
   OR  
   ( (@platformFilter IS NULL) OR (@platformFilter = '') )  
  )   
  AND  
  (  
   ( (@MissionDateFilter IS NOT NULL) AND (@MissionDateFilter <> '') AND (MissionDate LIKE '%' + @missionDateFilter + '%') )  
   OR  
   ( (@MissionDateFilter IS NULL) OR (@MissionDateFilter = '') )  
  )  
  AND  
  (  
   ( (@companyFilter IS NOT NULL) AND (@companyFilter <> '') AND (Company LIKE '%' + @companyFilter + '%') )  
   OR  
   ( (@companyFilter IS NULL) OR (@companyFilter = '') )  
  )  
  AND  
  (  
   ( (@platformGridFilter IS NOT NULL) AND (@platformGridFilter <> '') AND ([Platform] LIKE '%' + @platformGridFilter + '%') )  
   OR  
   ( (@platformGridFilter IS NULL) OR (@platformGridFilter = '') )  
  )  
  AND  
  (  
   ( (@tailFilter IS NOT NULL) AND (@tailFilter <> '') AND (Tail LIKE '%' + @tailFilter + '%') )  
   OR  
   ( (@tailFilter IS NULL) OR (@tailFilter = '') )  
  )  
  AND  
  (  
   ( (@dutySymbolFilter IS NOT NULL) AND (@dutySymbolFilter <> '') AND (DutySymbol LIKE '%' + @dutySymbolFilter + '%') )  
   OR  
   ( (@dutySymbolFilter IS NULL) OR (@dutySymbolFilter = '') )  
  )  
  AND  
  (  
   ( (@dayHoursFilter IS NOT NULL) AND (@dayHoursFilter <> '') AND (dbo.ConvertMinutesToHHMM(DayHours*60) LIKE '%' + @dayHoursFilter + '%') )  
   OR  
   ( (@dayHoursFilter IS NULL) OR (@dayHoursFilter = '') )  
  )  
  AND  
  (  
   ( (@nightHoursFilter IS NOT NULL) AND (@nightHoursFilter <> '') AND (dbo.ConvertMinutesToHHMM(NightHours*60) LIKE '%' + @nightHoursFilter + '%') )  
   OR  
   ( (@nightHoursFilter IS NULL) OR (@nightHoursFilter = '') )  
  )  
  AND  
  (  
   ( (@nvgFilter IS NOT NULL) AND (@nvgFilter <> '') AND (dbo.ConvertMinutesToHHMM(Nvg*60) LIKE '%' + @nvgFilter + '%') )  
   OR  
   ( (@nvgFilter IS NULL) OR (@nvgFilter = '') )  
  )  
  AND  
  (  
   ( (@nvsFilter IS NOT NULL) AND (@nvsFilter <> '') AND (dbo.ConvertMinutesToHHMM(Nvs*60) LIKE '%' + @nvsFilter + '%') )  
   OR  
   ( (@nvsFilter IS NULL) OR (@nvsFilter = '') )  
  )  
  AND  
  (  
   ( (@totalFilter IS NOT NULL) AND (@totalFilter <> '') AND (dbo.ConvertMinutesToHHMM(Total*60) LIKE '%' + @totalFilter + '%') )  
   OR  
   ( (@totalFilter IS NULL) OR (@totalFilter = '') )  
  )  
  AND  
  (  
   ( (@missionTypeFilter IS NOT NULL) AND (@missionTypeFilter <> '') AND (MissionType LIKE '%' + @missionTypeFilter + '%') )  
   OR  
   ( (@missionTypeFilter IS NULL) OR (@missionTypeFilter = '') )  
  )  
  AND  
  (  
   ( (@missionSubTypeFilter IS NOT NULL) AND (@missionSubTypeFilter <> '') AND (MissionSubType LIKE '%' + @missionSubTypeFilter + '%') )  
   OR  
   ( (@missionSubTypeFilter IS NULL) OR (@missionSubTypeFilter = '') )  
  ) ) _table 
        
 ORDER BY CAST(MissionDate AS DATE) DESC, Company ASC, FlightRecordId ASC  
  
  
  
 SELECT  
  dbo.ConvertMinutesToHHMM(SUM(DayHours)*60) AS TotalDayHours,   
  dbo.ConvertMinutesToHHMM(SUM(NightHours)*60) AS TotalNightHours, 
  dbo.ConvertMinutesToHHMM(SUM(D)*60) AS TotalD,   
  dbo.ConvertMinutesToHHMM(SUM(DS)*60) AS TotalDS,   
  dbo.ConvertMinutesToHHMM(SUM(N)*60) AS TotalN,  
  dbo.ConvertMinutesToHHMM(SUM(Nvg)*60) AS TotalNvg,   
  dbo.ConvertMinutesToHHMM(SUM(Nvs)*60) AS TotalNvs,  
  dbo.ConvertMinutesToHHMM(SUM(Total)*60) AS GrandTotal
 FROM VW_OPS_CREW_FLYING_RECORD_LIST  
 WHERE   
  CrewId = @crewId  
  AND ((@isGmt = 1 and CAST(MissionDateGmt AS DATE) >= @fromDate) or (@isGmt = 0 and CAST(MissionDate AS DATE) >= @fromDate))
  AND ((@isGmt =1 and CAST(MissionDateGmt AS DATE) <= @toDate) or (@isGmt = 0 and CAST(MissionDate AS DATE) <= @toDate))
  AND   
  (   
   ( (@platformFilter IS NOT NULL) AND (@platformFilter <> '') AND [Platform] = @platformFilter)  
   OR  
   ( (@platformFilter IS NULL) OR (@platformFilter = '') )  
  )   
  AND  
  (  
   ( (@MissionDateFilter IS NOT NULL) AND (@MissionDateFilter <> '') AND (MissionDate LIKE '%' + @missionDateFilter + '%') )  
   OR  
   ( (@MissionDateFilter IS NULL) OR (@MissionDateFilter = '') )  
  )  
  AND  
  (  
   ( (@companyFilter IS NOT NULL) AND (@companyFilter <> '') AND (Company LIKE '%' + @companyFilter + '%') )  
   OR  
   ( (@companyFilter IS NULL) OR (@companyFilter = '') )  
  )  
  AND  
  (  
   ( (@platformGridFilter IS NOT NULL) AND (@platformGridFilter <> '') AND ([Platform] LIKE '%' + @platformGridFilter + '%') )  
   OR  
   ( (@platformGridFilter IS NULL) OR (@platformGridFilter = '') )  
  )  
  AND  
  (  
   ( (@tailFilter IS NOT NULL) AND (@tailFilter <> '') AND (Tail LIKE '%' + @tailFilter + '%') )  
   OR  
   ( (@tailFilter IS NULL) OR (@tailFilter = '') )  
  )  
  AND  
  (  
   ( (@dutySymbolFilter IS NOT NULL) AND (@dutySymbolFilter <> '') AND (DutySymbol LIKE '%' + @dutySymbolFilter + '%') )  
   OR  
   ( (@dutySymbolFilter IS NULL) OR (@dutySymbolFilter = '') )  
  )  
  AND  
  (  
   ( (@dayHoursFilter IS NOT NULL) AND (@dayHoursFilter <> '') AND (dbo.ConvertMinutesToHHMM(DayHours*60) LIKE '%' + @dayHoursFilter + '%') )  
   OR  
   ( (@dayHoursFilter IS NULL) OR (@dayHoursFilter = '') )  
  )  
  AND  
  (  
   ( (@nightHoursFilter IS NOT NULL) AND (@nightHoursFilter <> '') AND (dbo.ConvertMinutesToHHMM(NightHours*60) LIKE '%' + @nightHoursFilter + '%') )  
   OR  
   ( (@nightHoursFilter IS NULL) OR (@nightHoursFilter = '') )  
  )  
  AND  
  (  
   ( (@nvgFilter IS NOT NULL) AND (@nvgFilter <> '') AND (dbo.ConvertMinutesToHHMM(Nvg*60) LIKE '%' + @nvgFilter + '%') )  
   OR  
   ( (@nvgFilter IS NULL) OR (@nvgFilter = '') )  
  )  
  AND  
  (  
   ( (@nvsFilter IS NOT NULL) AND (@nvsFilter <> '') AND (dbo.ConvertMinutesToHHMM(Nvs*60) LIKE '%' + @nvsFilter + '%') )  
   OR  
   ( (@nvsFilter IS NULL) OR (@nvsFilter = '') )  
  )  
  AND  
  (  
   ( (@totalFilter IS NOT NULL) AND (@totalFilter <> '') AND (dbo.ConvertMinutesToHHMM(Total*60) LIKE '%' + @totalFilter + '%') )  
   OR  
   ( (@totalFilter IS NULL) OR (@totalFilter = '') )  
  )  
  AND  
  (  
   ( (@missionTypeFilter IS NOT NULL) AND (@missionTypeFilter <> '') AND (MissionType LIKE '%' + @missionTypeFilter + '%') )  
   OR  
   ( (@missionTypeFilter IS NULL) OR (@missionTypeFilter = '') )  
  )  
  AND  
  (  
   ( (@missionSubTypeFilter IS NOT NULL) AND (@missionSubTypeFilter <> '') AND (MissionSubType LIKE '%' + @missionSubTypeFilter + '%') )  
   OR  
   ( (@missionSubTypeFilter IS NULL) OR (@missionSubTypeFilter = '') )  
  )  
    
  
 SELECT   
  dbo.ConvertMinutesToHHMM(SUM(DERIVED.IfrActual) * 60) AS TotalIfrActual,   
  dbo.ConvertMinutesToHHMM(SUM(DERIVED.IfrSimulated) * 60) AS TotalIfrSimulated   
  FROM   
   (SELECT DISTINCT  
     MissionDate, FlightRecordId, IfrActual, IfrSimulated    
     FROM VW_OPS_CREW_FLYING_RECORD_LIST   
     where   
     CrewId = @crewId  
     AND CAST(MissionDate AS DATE) >= @fromDate  
     AND CAST(MissionDate AS DATE) <= @toDate  
     AND   
     (   
      ( (@platformFilter IS NOT NULL) AND (@platformFilter <> '') AND [Platform] = @platformFilter)  
      OR  
      ( (@platformFilter IS NULL) OR (@platformFilter = '') )  
     ) ) AS DERIVED    
   
 SELECT       
  FLTCREW.ID_ AS CrewId, USRPROF.USER_ID_ AS Pid, SREF.CODE_ AS Rank, 
  UPPER(ISNULL(USRPROF.F_NAME_, '') + CASE WHEN USRPROF.M_NAME_ IS NOT NULL THEN ' ' + USRPROF.M_NAME_ ELSE '' END + CASE WHEN USRPROF.L_NAME_ IS NOT NULL THEN ' ' + USRPROF.L_NAME_ ELSE '' END) AS FullName,   
  FLTCREW.BRF_NAME_ AS BriefName, COUNTRY.NAME_ AS Country, PROFQUALI.NAME_ AS ProfessionalQualification,   
  cmd.CODE_ AS Command,   
  (CASE WHEN FLTCREW.CREW_COMPANY_TYPE_ = 'Sponsor' THEN MSTRST.CODE_ + ' (s)' ELSE MSTRST.CODE_ END) AS FlyingUnitOrCompany,   
  PLATFORMS.CODE_ AS PrimaryPlatform  
 FROM OPS_MST_FLIGHT_CREWS AS FLTCREW  
  INNER JOIN ADM_TRN_USER_PROFILES AS USRPROF ON FLTCREW.PERSON_ID = USRPROF.ID_  
  INNER JOIN ADM_MST_SIMPLE_REF AS SREF ON USRPROF.RANK_ID = SREF.ID_ AND SREF.GRP_ = 'RNK'   
  LEFT JOIN ADM_MST_COUNTRIES AS COUNTRY ON USRPROF.COUNTRY_ID = COUNTRY.ID_   
  INNER JOIN ADM_MST_PROF_QUALIFICATIONS AS PROFQUALI ON FLTCREW.QUALF_ID = PROFQUALI.ID_   
  INNER JOIN ADM_MST_QUALFCN_CATS AS QUALICAT ON PROFQUALI.CAT_ID = QUALICAT.ID_  
  INNER JOIN ADM_MST_RESTRICTIONS AS MSTRST ON FLTCREW.COMPANY_ID = MSTRST.ID_  
  LEFT JOIN ADM_MST_PLATFORMS AS PLATFORMS ON FLTCREW.PRI_PLTF_ID_ = PLATFORMS.ID_  
  LEFT JOIN ADM_MST_RESTRICTIONS btn on btn.ID_ = MSTRST.PRNT_ID and btn.TYPE_NAME_ = 'Battalion'
  LEFT JOIN ADM_MST_RESTRICTIONS cmd on cmd.ID_ = btn.PRNT_ID and cmd.TYPE_NAME_ = 'Command'
 WHERE  
  (FLTCREW.ID_ = @crewId)  
END
go

