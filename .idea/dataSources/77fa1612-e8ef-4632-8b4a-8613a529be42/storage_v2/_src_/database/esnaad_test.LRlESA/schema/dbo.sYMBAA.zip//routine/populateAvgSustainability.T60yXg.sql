CREATE proc [dbo].[populateAvgSustainability] 
as
begin
-------------------------------------------
-- tbo and sustainability parts analysis --
---------- author: gal24913 ---------------
------- data preparation scripts ----------
-------------------------------------------

declare @startDate date = concat('1-JAN-',year(getdate())-5), @endDate date = concat('1-JAN-',year(getdate()))

--candidate parts bsed on item catalog association and prior requisitions
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='_PlatformItems')
DROP TABLE es_temp._PlatformItems;

with PlatformItems (ItemId, CommandId, PlatformId) as
(
select  distinct ch.ITEM_ID, ch.CMD_ID, ch.PLTF_ID_
from  LOG_TRN_ITEM_CONSUMPTION_HISTORY ch
where ch.PLTF_ID_ is not null
    and ch.YEAR between DATEPART(YEAR,getdate())-5 and DATEPART(YEAR,getdate())-1
union
select  distinct items.ID_, pl2.CMD_ID_, pl2.PLTF_ID_
from  ADM_MST_ITEMS items
    join ADM_XRF_ITEM_PLATFORM_L2 ipl2 on items.id_ = ipl2.item_id
    join ADM_MST_PLATFORM_L2 pl2 on ipl2.PLATFORM_L2_ID = pl2.ID_
union
select  distinct mc.COMP_ITEM_ID_, mc.CMD_ID_, mc.PLTF_ID
from  MNT_MST_D16_MASTER_COMPONENT mc
)
select  pli.*
into  es_temp._PlatformItems
from  PlatformItems pli



-- add primary item id
-- all calculations are to be rolled up to primary item id
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='PlatformItems')
drop table es_temp.PlatformItems

select  distinct ds.CommandId, ds.PlatformId, isnull(ds.PrimaryItemId, ds.ItemId) PrimaryItemId, ds.ItemId
into  es_temp.PlatformItems
from  (
    select  pfh.*,
        (
        select  top(1) r.ROLLUP_ITEM_ID_
        from  dbo.VW_ITEM_ROLLUPS r
        where r.ITEM_ID = pfh.ItemId
            and r.L2_ID = pl2.L2_ID_
        ) PrimaryItemId
    from  es_temp._PlatformItems pfh
        join ADM_MST_PLATFORM_L2 pl2 on pfh.PlatformId = pl2.PLTF_ID_ and pfh.CommandId = pl2.CMD_ID_
    ) as ds



-- find platform level and command level flight hours for the primary part
-- required to distribute quantities
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='_PrimaryItemsFlightHours')
drop table es_temp._PrimaryItemsFlightHours;

-- platform flight hours
with PlatformFlightHours (CommandId, PlatformId, FlightHours, FlightMinutes) as
(
select  cmd.id_, pl.ID_, sum(1.0*tf.FlightMinutes)/60 FlightHours, sum(tf.FlightMinutes) FlightMinutes
from  es_dataminer.VW_TAIL_DAILY_FLIGHT_HOURS tf
    join ADM_MST_RESTRICTIONS cmd on tf.Command = cmd.CODE_ and cmd.TYPE_NAME_ = 'Command'
    join ADM_MST_PLATFORMS pl on tf.Platform = pl.CODE_
where tf.Departure >= @startDate and tf.Departure < @endDate
group by cmd.id_, pl.ID_
)
select  pli.*, pfh.FlightHours
into  es_temp._PrimaryItemsFlightHours
from  (select p.CommandId, p.PlatformId, p.PrimaryItemId from es_temp.PlatformItems p group by p.CommandId, p.PlatformId, p.PrimaryItemId) pli
    join PlatformFlightHours pfh on pli.CommandId = pfh.CommandId and pli.PlatformId = pfh.PlatformId


-- platform and command flight hours
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='PrimaryItemsFlightHours')
drop table es_temp.PrimaryItemsFlightHours

select  pif.CommandId, pif.PlatformId, pif.PrimaryItemId, pif.FlightHours PlatformFlightHours,
    (select sum(p.FlightHours) from es_temp._PrimaryItemsFlightHours p where p.CommandId = pif.CommandId and p.PrimaryItemId = pif.PrimaryItemId) CommandFlightHours
into  es_temp.PrimaryItemsFlightHours
from  es_temp._PrimaryItemsFlightHours pif
order by pif.PrimaryItemId, pif.CommandId




--scrap quantity
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='_CommandItemsScrapQty')
drop table es_temp._CommandItemsScrapQty

select  bu.CMD_ID_ CommandId, units.ITEM_ID ItemId, sum(scri.SCRAP_QTY_) ScrapQty
into  es_temp._CommandItemsScrapQty
from  LOG_TRN_SCR_SCRAP_REQUEST scr
    join ADM_MST_BUSINESS_UNITS bu on scr.BU_ID = bu.ID_
    join LOG_TRN_SCR_SCRAP_REQUEST_ITEM scri on scr.id_ = scri.SR_ID
    join ADM_MST_UNITS units on scri.UNIT_ID = units.ID_
where scr.STATUS_ = 'Validated'
    and scr.REQ_DATE_ >= @startDate and scr.REQ_DATE_ < @endDate 
    and exists (select 1 from es_temp.PlatformItems pfi where pfi.ItemId = units.ITEM_ID and pfi.CommandId = bu.CMD_ID_)
group by bu.CMD_ID_, units.ITEM_ID


-- scrap doesn't have platform associated with
-- distribute the scrap quantity to different platforms by multiplying the quantity
-- with platform hours / total command hours
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='CommandPlatformPrimaryItemsScrapQty')
drop table es_temp.CommandPlatformPrimaryItemsScrapQty

select  pifh.CommandId, pifh.PlatformId, pifh.PrimaryItemId, 
    convert(decimal(10,2),sum(scr.ScrapQty))*(convert(decimal(10,2),pifh.PlatformFlightHours)/pifh.CommandFlightHours) ScrapQty
into  es_temp.CommandPlatformPrimaryItemsScrapQty
from  (
    select  scr.CommandId, scr.ScrapQty,
        (select top(1) pli.PrimaryItemId from es_temp.PlatformItems pli where pli.CommandId = scr.CommandId and pli.ItemId = scr.ItemId) PrimaryItemId
    from  es_temp._CommandItemsScrapQty scr
    ) as scr
    join es_temp.PrimaryItemsFlightHours pifh on scr.CommandId = pifh.CommandId and scr.PrimaryItemId = pifh.PrimaryItemId
group by pifh.CommandId, pifh.PlatformId, pifh.PrimaryItemId, pifh.PlatformFlightHours, pifh.CommandFlightHours
order by PrimaryItemId, pifh.CommandId



--repair quantity
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='_CommandPlatformItemRepairOutQty')
drop table es_temp._CommandPlatformItemRepairOutQty

select  bu.CMD_ID_ CommandId, isnull(drpl.ID_, tfu.PLATFORM_ID) PlatformId, rf.ITEM_ID ItemId, sum(dr.QTY_) RepairOutQty
into  es_temp._CommandPlatformItemRepairOutQty
from  LOG_TRN_RSM_SHIPMENT sh
    join LOG_TRN_RSM_SHIPMENT_ITEM shi on sh.id_ = shi.SHIPMENT_ID_
    join LOG_TRN_RPR_REPAIR_FILE rf on rf.REPAIR_FILE_NO_ = shi.REPAIR_FILE_NO_
    left outer join LOG_TRN_TFR_TFU_RECEIVING tfu on rf.REPAIR_FILE_NO_ = tfu.REPAIR_FILE_NO_
    join MNT_TRN_DFR_DEFECT_REPORT dr on rf.DEFECT_REPORT_NO_ = dr.DEFECT_NO_
    left outer join ADM_MST_PLATFORMS drpl on dr.PLTF_CODE_ = drpl.CODE_
    join ADM_MST_BUSINESS_UNITS bu on dr.ORG_BU_ID_ = bu.ID_
where sh.DISPATCH_DATE_ >= @startDate and sh.DISPATCH_DATE_ < @endDate
    --and isnull(drpl.ID_, tfu.PLATFORM_ID) is not null
    and exists (select 1 from es_temp.PlatformItems pfi where pfi.ItemId = rf.ITEM_ID and pfi.CommandId = bu.CMD_ID_)
group by bu.CMD_ID_, isnull(drpl.ID_, tfu.PLATFORM_ID), rf.ITEM_ID


IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='CommandPlatformPrimaryItemsRepairQty')
drop table es_temp.CommandPlatformPrimaryItemsRepairQty

-- repairs data come with and without platform
-- with platform repairs are counted against respective platforms
-- without platform repairs are distributed to different platforms by 
-- multiplying the quantity with platform hours / total command hours
select  ds.CommandId, ds.PlatformId, ds.PrimaryItemId, sum(ds.RepairOutQty) RepairOutQty
into  es_temp.CommandPlatformPrimaryItemsRepairQty
from  (
    select  ro.CommandId CommandId, 
        ro.PlatformId PlatformId, 
        --ro.ItemId ItemId, 
        (select top(1) pli.PrimaryItemId from es_temp.PlatformItems pli where pli.CommandId = ro.CommandId and pli.ItemId = ro.ItemId) PrimaryItemId,
        ro.RepairOutQty RepairOutQty
    from  es_temp._CommandPlatformItemRepairOutQty ro
    where ro.PlatformId is not null
    union all
    select  pifh.CommandId, pifh.PlatformId, pifh.PrimaryItemId, sum(convert(decimal(10,2),rp.RepairOutQty)*(convert(decimal(10,2),pifh.PlatformFlightHours)/pifh.CommandFlightHours)) RepairQty
    from  (
          select  ro.CommandId CommandId, 
              --ro.ItemId ItemId, 
              (select top(1) pli.PrimaryItemId from es_temp.PlatformItems pli where pli.CommandId = ro.CommandId and pli.ItemId = ro.ItemId) PrimaryItemId,
              ro.RepairOutQty RepairOutQty
          from  es_temp._CommandPlatformItemRepairOutQty ro
          where ro.PlatformId is null
        ) rp 
        join es_temp.PrimaryItemsFlightHours pifh on rp.CommandId = pifh.CommandId and rp.PrimaryItemId = pifh.PrimaryItemId
    group by pifh.CommandId, pifh.PlatformId, pifh.PrimaryItemId, pifh.PlatformFlightHours, pifh.CommandFlightHours
) as ds group by ds.CommandId, ds.PlatformId, ds.PrimaryItemId






---------------------------------------------------------
-- #1. Remaining Hours by Item for Installed Component --
------------- author gal9147@jac.mil.ae -----------------
---------------------------------------------------------
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='InstalledComponentRemainingHours')
drop table es_temp.InstalledComponentRemainingHours

select PrimaryItemId, CommandId, PlatformId, case when sum(Remaining) < 0 then 0 else sum(Remaining) end as RemainingHours
into   es_temp.InstalledComponentRemainingHours
from (
         select
             PrimaryItemId
           , CommandId
           , PlatformId
           , case
                 when RemainingOverhaulAircraftHour is not null and RemainingReplaceAircraftHour is not null and RemainingOverhaulAircraftHour <= RemainingReplaceAircraftHour
                     then RemainingOverhaulAircraftHour
                 when RemainingOverhaulAircraftHour is not null and RemainingReplaceAircraftHour is not null and RemainingOverhaulAircraftHour > RemainingReplaceAircraftHour
                     then RemainingReplaceAircraftHour
                 else coalesce(RemainingOverhaulAircraftHour, RemainingReplaceAircraftHour) end as Remaining
         from (
                  select
                      ix.PrimaryItemId                                                     as PrimaryItemId
                    , ix.CommandId                                                         as CommandId
                    , ix.PlatformId                                                        as PlatformId
                    , CONVERT(DECIMAL(10, 1), c_o_due._hours - uu.TOT_FLIGHT_MINS_ / 60.0) as RemainingOverhaulAircraftHour
                    , CONVERT(DECIMAL(10, 1), c_r_due._hours - uu.TOT_FLIGHT_MINS_ / 60.0) AS RemainingReplaceAircraftHour
                  from MNT_MST_D16_COMPONENT c
                           join ADM_MST_UNITS u on u.ID_ = c.UNIT_ID_
                           join ADM_MST_ITEMS i on i.ID_ = u.ITEM_ID
                           join ADM_MST_MANUFACTURES mfr on mfr.ID_ = i.MNF_ID
                           join MNT_TRN_D16_ASSIGNED_COMPONENT ac on ac.COMP_ID_ = c.ID_
                           join MNT_MST_D16_MASTER_COMPONENT mc on mc.ID_ = ac.MASTER_COMP_ID_
                           join es_temp.PlatformItems ix on ix.ItemId = i.ID_ and ix.CommandId = mc.CMD_ID_ and ix.PlatformId = mc.PLTF_ID
                           LEFT JOIN ADM_TRN_UNIT_USAGE uu ON uu.UNIT_ID_ = ac.ROOT_ACFT_UNIT_ID_
                           CROSS APPLY dbo.D16_GetComponentUsage(c.ID_) c_usage
                           CROSS APPLY dbo.D16_GetReplaceDue(c.ID_) c_r_due
                           CROSS APPLY dbo.D16_GetOverhaulDue(c.ID_) c_o_due
                  where ac.IS_ACTIVE_ = 1
                    and ac.REM_DATE_ is null
                    and ac.ROOT_ACFT_UNIT_ID_ > 0
                    and ac.ACFT_UNIT_ID_ > 0
                    and mc.PART_TYPE_ <> 'CC'
                    and (mc.REP_HRS_ > 0 or mc.OVR_HRS_ > 0)
              ) as x
         where (RemainingOverhaulAircraftHour is not null or RemainingReplaceAircraftHour is not null)
     ) as y
group by PrimaryItemId, CommandId, PlatformId










--------------------------------------------------------
-- #2. Remaining Hours by Item for Detached Component --
------------- author gal9147@jac.mil.ae ----------------
--------------------------------------------------------
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='DetachedComponentRemainingHours')
drop table es_temp.DetachedComponentRemainingHours

select PrimaryItemId, CommandId, PlatformId, round(case when sum(Remaining) < 0 then 0 else sum(Remaining) end, 2) as RemainingHours
into   es_temp.DetachedComponentRemainingHours
from (
         select
             PrimaryItemId                                                        as PrimaryItemId
           , CommandId                                                            as CommandId
           , PlatformId                                                           as PlatformId
           , case
                 when RemainingOverhaulHours is not null and RemainingReplaceHours is not null and RemainingOverhaulHours <= RemainingReplaceHours
                     then RemainingOverhaulHours
                 when RemainingOverhaulHours is not null and RemainingReplaceHours is not null and RemainingOverhaulHours > RemainingReplaceHours
                     then RemainingReplaceHours
                 else coalesce(RemainingOverhaulHours, RemainingReplaceHours) end as Remaining
         from (
                  select
                      ix.PrimaryItemId                                                                                      as PrimaryItemId
                    , ix.CommandId                                                                                          as CommandId
                    , ix.PlatformId                                                                                         as PlatformId
                    , CASE WHEN mc.REP_HRS_ > 0 THEN mc.REP_HRS_ - c_usage.Hours else null end                              as RemainingReplaceHours
                    , CASE WHEN mc.OVR_HRS_ > 0 THEN mc.OVR_HRS_ - (c_usage.Hours - isnull(ac.L_OVR_HRS_, 0)) else null end as RemainingOverhaulHours
                  from MNT_MST_D16_COMPONENT c
                           join ADM_MST_UNITS u on u.ID_ = c.UNIT_ID_
                           join ADM_MST_ITEMS i on i.ID_ = u.ITEM_ID
                           join MNT_TRN_D16_ASSIGNED_COMPONENT ac on ac.COMP_ID_ = c.ID_
                           join MNT_MST_D16_MASTER_COMPONENT mc on mc.ID_ = ac.MASTER_COMP_ID_
                           join es_temp.PlatformItems ix on ix.ItemId = i.ID_ and ix.CommandId = mc.CMD_ID_ and ix.PlatformId = mc.PLTF_ID
                           join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.UNIT_ID_ = u.ID_ and imv.TC_ID_ in (1, 14) and imv.CMD_ID_ = mc.CMD_ID_
                           LEFT JOIN ADM_TRN_UNIT_USAGE uu ON uu.UNIT_ID_ = ac.ROOT_ACFT_UNIT_ID_
                           CROSS APPLY dbo.D16_GetComponentUsage(c.ID_) c_usage
                           CROSS APPLY dbo.D16_GetReplaceDue(c.ID_) c_r_due
                           CROSS APPLY dbo.D16_GetOverhaulDue(c.ID_) c_o_due
                  where ac.IS_ACTIVE_ = 1
                    and ac.REM_DATE_ is not null
                    and mc.PART_TYPE_ <> 'CC'
                    and (mc.REP_HRS_ > 0 or mc.OVR_HRS_ > 0)
                    and c_usage.Hours is not null
              ) as x
         where (RemainingOverhaulHours is not null or RemainingReplaceHours is not null)
     ) as y
group by PrimaryItemId, CommandId, PlatformId




-------------------------------------------------------------------
-- #3. Remaining Hours by Item for New Component (No Assignment) --
------------------ author gal9147@jac.mil.ae ----------------------
-------------------------------------------------------------------
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='NeverInstalledComponentRemainingHours')
drop table es_temp.NeverInstalledComponentRemainingHours

select PrimaryItemId, CommandId, PlatformId, round(sum(Remaining * Qty), 2) as RemainingHours
into   es_temp.NeverInstalledComponentRemainingHours
from (
    SELECT * FROM (
      select *
      , ROW_NUMBER() OVER(PARTITION BY PrimaryItemId, CommandId,PlatformId,  UnitId ORDER BY PrimaryItemId, CommandId,PlatformId,Remaining) AS ROW_ from (
        select
          PrimaryItemId
        , CommandId
        , PlatformId
        , Qty
        , case
            when RemainingOverhaulHours is not null and RemainingReplaceHours is not null and RemainingOverhaulHours <= RemainingReplaceHours
              then RemainingOverhaulHours
            when RemainingOverhaulHours is not null and RemainingReplaceHours is not null and RemainingOverhaulHours > RemainingReplaceHours
              then RemainingReplaceHours
            else coalesce(RemainingOverhaulHours, RemainingReplaceHours) end as Remaining
        , UnitId
        , MasterComponentId
        from (
            select
              ix.PrimaryItemId                                             as PrimaryItemId
            , ix.CommandId                                                 as CommandId
            , ix.PlatformId                                                as PlatformId
            , CASE WHEN mc.REP_HRS_ > 0 THEN mc.REP_HRS_ - 0 else null end as RemainingReplaceHours
            , CASE WHEN mc.OVR_HRS_ > 0 THEN mc.OVR_HRS_ - 0 else null end as RemainingOverhaulHours
            , imv.QTY_                                                     as Qty
            , imv.UNIT_ID_ as UnitId          
            , mc.ID_ as MasterComponentId
            from es_temp.PlatformItems ix
                join ADM_MST_ITEMS i on i.ID_ = ix.ItemId
                join ADM_MST_UNITS u on u.ITEM_ID = i.ID_
                join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.UNIT_ID_ = u.ID_ AND imv.CMD_ID_ = ix.CommandId
                join MNT_MST_D16_MASTER_COMPONENT mc on mc.COMP_ITEM_ID_ = i.ID_ and mc.PART_TYPE_ <> 'CC' and ix.CommandId = mc.CMD_ID_ and ix.PlatformId = mc.PLTF_ID
                join ADM_MST_PLATFORM_L2 pl2 on pl2.PLTF_ID_ = ix.PlatformId and pl2.L2_ID_ = imv.OWNED_L2_ID_
            where u.ID_ not in (select c.UNIT_ID_ from MNT_MST_D16_COMPONENT c)
            and (mc.REP_HRS_ > 0 or mc.OVR_HRS_ > 0)
          ) as x
        where (RemainingOverhaulHours is not null or RemainingReplaceHours is not null)
      ) as y
    ) z
    where ROW_ = 1
     ) as y
group by PrimaryItemId, CommandId, PlatformId
order by sum(Remaining) asc


-------------------------------------------------------
-- #1. Remaining Day by Item for Installed Component --
------------- author gal9147@jac.mil.ae ---------------
-------------------------------------------------------
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='InstalledComponentRemainingDays')
drop table es_temp.InstalledComponentRemainingDays

select PrimaryItemId, CommandId, PlatformId, case when sum(Remaining) < 0 then 0.0 else sum(Remaining) end as RemainingDays
into   es_temp.InstalledComponentRemainingDays
from (
         select
             PrimaryItemId
           , CommandId
           , PlatformId
           , case
                 when RemainingOverhaul is not null and RemainingReplace is not null and RemainingOverhaul <= RemainingReplace
                     then RemainingOverhaul
                 when RemainingOverhaul is not null and RemainingReplace is not null and RemainingOverhaul > RemainingReplace
                     then RemainingReplace
                 else coalesce(RemainingOverhaul, RemainingReplace) end as Remaining
         from (
                  select
                      ix.PrimaryItemId                        as PrimaryItemId
                    , ix.CommandId                            as CommandId
                    , ix.PlatformId                           as PlatformId
                    , DATEDIFF(DAY, GETDATE(), c_o_due._date) as RemainingOverhaul
                    , DATEDIFF(DAY, GETDATE(), c_r_due._date) AS RemainingReplace
                  from MNT_MST_D16_COMPONENT c
                           join ADM_MST_UNITS u on u.ID_ = c.UNIT_ID_
                           join ADM_MST_ITEMS i on i.ID_ = u.ITEM_ID
                           join ADM_MST_MANUFACTURES mfr on mfr.ID_ = i.MNF_ID
                           join MNT_TRN_D16_ASSIGNED_COMPONENT ac on ac.COMP_ID_ = c.ID_
                           join MNT_MST_D16_MASTER_COMPONENT mc on mc.ID_ = ac.MASTER_COMP_ID_
                           join es_temp.PlatformItems ix on ix.ItemId = i.ID_ and ix.CommandId = mc.CMD_ID_ and ix.PlatformId = mc.PLTF_ID
                           LEFT JOIN ADM_TRN_UNIT_USAGE uu ON uu.UNIT_ID_ = ac.ROOT_ACFT_UNIT_ID_
                           CROSS APPLY dbo.D16_GetComponentUsage(c.ID_) c_usage
                           CROSS APPLY dbo.D16_GetReplaceDue(c.ID_) c_r_due
                           CROSS APPLY dbo.D16_GetOverhaulDue(c.ID_) c_o_due
                  where ac.IS_ACTIVE_ = 1
                    and ac.REM_DATE_ is null
                    and ac.ROOT_ACFT_UNIT_ID_ > 0
                    and ac.ACFT_UNIT_ID_ > 0
                    and mc.PART_TYPE_ <> 'CC'
                    and (mc.REP_CAL_VALUE_ > 0 or mc.OVR_CAL_VALUE_ > 0 or mc.TSI_VALUE_ > 0)
              ) as x
         where (RemainingOverhaul is not null or RemainingReplace is not null)
     ) as y
group by PrimaryItemId, CommandId, PlatformId





-------------------------------------------------------
-- #2. Remaining Days by Item for Detached Component --
------------ author gal9147@jac.mil.ae ----------------
-------------------------------------------------------
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='DetachedComponentRemainingDays')
drop table es_temp.DetachedComponentRemainingDays

select PrimaryItemId, CommandId, PlatformId, case when sum(Remaining) < 0 then 0.0 else sum(Remaining) end as RemainingDays
into   es_temp.DetachedComponentRemainingDays
from (
         select
             PrimaryItemId                                              as PrimaryItemId
           , CommandId                                                  as CommandId
           , PlatformId                                                 as PlatformId
           , case
                 when RemainingOverhaul is not null and RemainingReplace is not null and RemainingOverhaul <= RemainingReplace
                     then RemainingOverhaul
                 when RemainingOverhaul is not null and RemainingReplace is not null and RemainingOverhaul > RemainingReplace
                     then RemainingReplace
                 else coalesce(RemainingOverhaul, RemainingReplace) end as Remaining
         from (
                  select
                      ix.PrimaryItemId                                                                                                                    as PrimaryItemId
                    , ix.CommandId                                                                                                                        as CommandId
                    , ix.PlatformId                                                                                                                       as PlatformId
                    , DATEDIFF(DAY, GETDATE(),
                               (CASE
                                    WHEN (mc.OVR_CAL_VALUE_ > 0 and ac.L_OVR_DATE_ is not null) THEN CASE
                                                                                                         WHEN (mc.OVR_CAL_UNIT_ = 'Months') then dateadd(month, mc.OVR_CAL_VALUE_, ac.L_OVR_DATE_)
                                                                                                         ELSE dateadd(year, mc.OVR_CAL_VALUE_, ac.L_OVR_DATE_) END
                                    ELSE null END))                                                                                                       as RemainingOverhaul
                    , DATEDIFF(DAY, GETDATE(),
                               dbo.GetD16ComponentDueDate(mc.REP_CAL_VALUE_, mc.REP_CAL_UNIT_, mc.TSI_VALUE_, mc.TSI_UNIT_, ac.INST_DATE_, u.MANF_DATE_)) as RemainingReplace
                  from MNT_MST_D16_COMPONENT c
                           join ADM_MST_UNITS u on u.ID_ = c.UNIT_ID_
                           join ADM_MST_ITEMS i on i.ID_ = u.ITEM_ID
                           join MNT_TRN_D16_ASSIGNED_COMPONENT ac on ac.COMP_ID_ = c.ID_
                           join MNT_MST_D16_MASTER_COMPONENT mc on mc.ID_ = ac.MASTER_COMP_ID_
                           join es_temp.PlatformItems ix on ix.ItemId = i.ID_ and ix.CommandId = mc.CMD_ID_ and ix.PlatformId = mc.PLTF_ID
                           join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.UNIT_ID_ = u.ID_ and imv.TC_ID_ in (1, 14) and imv.CMD_ID_ = mc.CMD_ID_
                  where ac.IS_ACTIVE_ = 1
                    and ac.REM_DATE_ is not null
                    and mc.PART_TYPE_ <> 'CC'
                    and (mc.REP_CAL_VALUE_ > 0 or mc.OVR_CAL_VALUE_ > 0 or mc.TSI_VALUE_ > 0)
              ) as x
         where (RemainingOverhaul is not null or RemainingReplace is not null)
     ) as y
group by PrimaryItemId, CommandId, PlatformId




-------------------------------------------------------------------
-- #3. Remaining Days by Item for New Component (No Assignment) --
------------------ author gal9147@jac.mil.ae ----------------------
-------------------------------------------------------------------
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='NeverInstalledComponentRemainingDays')
drop table es_temp.NeverInstalledComponentRemainingDays

select PrimaryItemId, CommandId, PlatformId, case when sum(Remaining * Qty) < 0 then 0.0 else sum(Remaining * Qty) end as RemainingDays
into es_temp.NeverInstalledComponentRemainingDays
from (
  SELECT *, ROW_NUMBER() OVER(PARTITION BY PrimaryItemId, CommandId,PlatformId,  UnitId ORDER BY PrimaryItemId, CommandId,PlatformId,Remaining) AS ROW_
  FROM (
       select
         PrimaryItemId    as PrimaryItemId
         , CommandId        as CommandId
         , PlatformId       as PlatformId
         , Qty              as Qty
         , RemainingReplace as Remaining
         , UnitId
         , MasterComponentId
       from (
            select
              ix.PrimaryItemId                                                                                                                   as PrimaryItemId
            , ix.CommandId                                                                                                                       as CommandId
            , ix.PlatformId                                                                                                                      as PlatformId
            , DATEDIFF(DAY, GETDATE(),
                   dbo.GetD16ComponentDueDate(mc.REP_CAL_VALUE_, mc.REP_CAL_UNIT_, mc.TSI_VALUE_, mc.TSI_UNIT_, u.MANF_DATE_, u.MANF_DATE_)) as RemainingReplace
            , imv.QTY_                                                                                                                           as Qty
            , imv.UNIT_ID_ as UnitId          
            , mc.ID_ as MasterComponentId
            from es_temp.PlatformItems ix
                 join ADM_MST_ITEMS i on i.ID_ = ix.ItemId
                 join ADM_MST_UNITS u on u.ITEM_ID = i.ID_
                 join ADM_TRN_IMV_ITEMS_IN_LOCATION imv on imv.UNIT_ID_ = u.ID_ AND imv.CMD_ID_ = ix.CommandId
                 join MNT_MST_D16_MASTER_COMPONENT mc on mc.COMP_ITEM_ID_ = i.ID_ and mc.PART_TYPE_ <> 'CC' and ix.CommandId = mc.CMD_ID_ and ix.PlatformId = mc.PLTF_ID
                 join ADM_MST_PLATFORM_L2 pl2 on pl2.PLTF_ID_ = ix.PlatformId and pl2.L2_ID_ = imv.OWNED_L2_ID_
            where u.ID_ not in (select c.UNIT_ID_ from MNT_MST_D16_COMPONENT c)
            and (mc.REP_CAL_VALUE_ > 0 and u.MANF_DATE_ is not null)
          ) as x
       where RemainingReplace is not null
     ) as y
) z
where ROW_ = 1
group by PrimaryItemId, CommandId, PlatformId




IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='es_temp' and t.name='RollupLegacyPrice')
drop table es_temp.RollupLegacyPrice

-- legacy price in case procurement price not in esnaad
select  * 
into es_temp.RollupLegacyPrice
from
(
      select  lp.PRICE_*cur.RATE_ Price, ir.ROLLUP_ITEM_ID_, ROW_NUMBER() over(partition by ir.rollup_item_id_ order by lp.ref_date_ desc) rnk
      from  VW_LOG_TRN_ITEM_LEGACY_PRICE lp
          join ADM_MST_SEC_L2_COMMAND l2cmd on lp.CMD_ID_ = l2cmd.CMD_ID
          join dbo.VW_ITEM_ROLLUPS ir on lp.ITEM_ID_ = ir.ITEM_ID and l2cmd.L2_ID = ir.L2_ID
          join ADM_MST_MONEY_CURRENCY cur on lp.CURRENCY_ = cur.CODE_
      where lp.REF_TYPE_ = 'PURCHASE ORDER'
          and lp.PRICE_ <> 0
) as ds where ds.rnk = 1

create index IdxRollupItemId on es_temp.RollupLegacyPrice(ROLLUP_ITEM_ID_) include (Price)


-- summary for hours
IF EXISTS(SELECT 1 FROM sys.tables t join sys.schemas s on t.schema_id = s.schema_id where s.name='dw' and t.name='TboHrs')
drop table dw.TboHrs

select  ds.*,
    ((ds.MaxiMin/ds.PlatformFlightHrs)*60) EquivMonths,
    iif(((ds.MaxiMin/ds.PlatformFlightHrs)*60)<=1.0,1,0) OneMonth,
    iif(((ds.MaxiMin/ds.PlatformFlightHrs)*60) > 1.0 and ((ds.MaxiMin/ds.PlatformFlightHrs)*60) <= 3.0,1,0) OneThreeMonth,
    iif(((ds.MaxiMin/ds.PlatformFlightHrs)*60) > 3.0 ,1,0) ThreeMonth
into  dw.TboHrs
from  (
  select  ds.*,
      isnull(ds.TotalStock,0)*isnull(ds.TotalRate,0) AvailableHours,
      iif(ds.TboBn < (isnull(ds.TotalStock,0)*isnull(ds.TotalRate,0)), ds.TboBn, (isnull(ds.TotalStock,0)*isnull(ds.TotalRate,0))) MaxiMin
  from  (
    select  ds.PartNumber, ds.Nomenclature, ds.MFR, ds.Class, ds.Command, ds.Platform, ds.PlatformFlightHrs, ds.ItemAllPlatformFlightHrs,
        (ds.CurentlyInstalledRemHrs) CurentlyInstalledRemHrs, 
        (ds.DetachedRemHrs) DetachedRemHrs, 
        (ds.NeverInstalledRemHrs) NeverInstalledRemHrs,
        (ds.ScrapQty) ScrapQty,
        (ds.RepairOutQty) RepairOutQty,
        (ds.StockInCommandStore) StockInCommandStore,
        (ds.StockInASCStore) StockInASCStore,
        isnull((ds.LastProcPrice), (ds.LastLegacyProcPrice)) LastProcPrice,
        isnull(ds.StockInCommandStore,0) + isnull(ds.StockInASCStore,0) TotalStock,
        case when ds.CurentlyInstalledRemHrs is null and ds.DetachedRemHrs is null and ds.NeverInstalledRemHrs is null then 99999 
          else (isnull(ds.CurentlyInstalledRemHrs,0)+isnull(ds.DetachedRemHrs,0)+isnull(ds.NeverInstalledRemHrs,0)) end TboBn,
        case when ds.ScrapQty is null and ds.RepairOutQty is null then 99999
          else (ds.ItemAllPlatformFlightHrs/(isnull(ds.ScrapQty,0)+isnull(ds.RepairOutQty,0))) end TotalRate
    from  (
        select  pch.PrimaryItemId,
            replace(replace(replace(replace(primaryitems.PART_NO_, char(9), ''), char(13), ''), char(10), ''), char(34),'') PartNumber,
            replace(replace(replace(replace(primaryitems.NOMENCLATURE_, char(9), ''), char(13), ''), char(10), ''), char(34),'') Nomenclature,
            cage.CAGE_CODE_ MFR,
            itemclass.CODE_ Class,
            cmd.CODE_ Command,
            pl.ID_ PlatformId,
            pl.CODE_ [Platform],
            pch.PlatformFlightHours PlatformFlightHrs,
            pch.CommandFlightHours ItemAllPlatformFlightHrs, 
            case when icrh.RemainingHours < 0 then 0 else icrh.RemainingHours end CurentlyInstalledRemHrs,
            case when dcrh.RemainingHours < 0 then 0 else dcrh.RemainingHours end DetachedRemHrs,
            case when ncrh.RemainingHours < 0 then 0 else ncrh.RemainingHours end NeverInstalledRemHrs,
            csr.ScrapQty ScrapQty,
            ro.RepairOutQty RepairOutQty,
            ( select  sum(stock.QTY_) Qty 
              from  dbo.VW_ITEM_STOCK stock 
              where stock.COMMAND_ID_ = pch.CommandId and stock.L2_ID_ = pl2.L2_ID_ and stock.ROLLUP_ITEM_ID_ = pch.PrimaryItemId
            ) as StockInCommandStore,
            ( select  sum(stock.QTY_) Qty 
              from  dbo.VW_ITEM_STOCK stock 
              where stock.COMMAND_ = 'ASC'
                  and stock.L2_ID_ = pl2.L2_ID_ and stock.ROLLUP_ITEM_ID_ = pch.PrimaryItemId
            ) as StockInASCStore,
            ( select  max(convert(decimal(18,2),snap.LAST_PROC_PRICE))
              from  LOG_TRN_ITEM_QUANTITY_SNAPSHOT_ALL_STORE snap
              where snap.PRIMARY_PART_ITEM_ID_ = primaryitems.ID_
                  and snap.LAST_PROC_PRICE is not null
            ) as LastProcPrice,
            ( select  convert(decimal(18,2),lp.Price,2)
              from  es_temp.RollupLegacyPrice lp
              where lp.ROLLUP_ITEM_ID_ = primaryitems.ID_
            ) as LastLegacyProcPrice
        from  es_temp.PrimaryItemsFlightHours pch
            join ADM_MST_ITEMS primaryitems on pch.PrimaryItemId = primaryitems.ID_
            join ADM_MST_MANUFACTURES cage on primaryitems.MNF_ID = cage.ID_
            join ADM_MST_PLATFORMS pl on pch.PlatformId = pl.ID_
            join ADM_MST_RESTRICTIONS cmd on pch.CommandId = cmd.ID_
            join ADM_MST_PLATFORM_L2 pl2 on pch.CommandId = pl2.CMD_ID_ and pch.PlatformId = pl2.PLTF_ID_
            left outer join es_temp.CommandPlatformPrimaryItemsScrapQty csr on pch.CommandId = csr.CommandId and pch.PlatformId = csr.PlatformId and pch.PrimaryItemId = csr.PrimaryItemId
            left outer join es_temp.CommandPlatformPrimaryItemsRepairQty ro on pch.CommandId = ro.CommandId and pch.PlatformId = ro.PlatformId and pch.PrimaryItemId = ro.PrimaryItemId
            left outer join ADM_MST_SIMPLE_REF itemclass on primaryitems.CLS_ID_ = itemclass.ID_
            left outer join es_temp.InstalledComponentRemainingHours icrh on icrh.CommandId = pch.CommandId and icrh.PlatformId = pch.PlatformId and icrh.PrimaryItemId = pch.PrimaryItemId
            left outer join es_temp.DetachedComponentRemainingHours dcrh on dcrh.CommandId = pch.CommandId and dcrh.PlatformId = pch.PlatformId and dcrh.PrimaryItemId = pch.PrimaryItemId
            left outer join es_temp.NeverInstalledComponentRemainingHours ncrh on ncrh.CommandId = pch.CommandId and ncrh.PlatformId = pch.PlatformId and ncrh.PrimaryItemId = pch.PrimaryItemId
        ) as ds
    where ds.CurentlyInstalledRemHrs is not null or 
        ds.DetachedRemHrs is not null or 
        ds.NeverInstalledRemHrs is not null or
        ds.ScrapQty is not null or 
        ds.RepairOutQty is not null or 
        ds.StockInCommandStore is not null or 
        ds.StockInASCStore is not null or
        exists (
          select  1 
          from  LOG_TRN_ITEM_CONSUMPTION_HISTORY_ROLLUP ch 
          where ch.ITEM_ID = ds.PrimaryItemId and ch.PLTF_ID_ = ds.PlatformId and ch.YEAR between DATEPART(YEAR,getdate())-5 and DATEPART(YEAR,getdate())-1
          )
    ) as ds
  ) as ds
order by ds.PartNumber, ds.Command, ds.Platform

end
go

