CREATE view [dbo].[VW_D16_AssignedComponent]
as select ac.ID_ as Id
,t.T_NUM_ [Attached to Tail/ACFT_UNIT_ID]
,(select T_NUM_ from ADM_MST_TAILS where UNIT_ID =  ac.ROOT_ACFT_UNIT_ID_) as [Attached to Tail/ROOT_ACFT_UNIT_ID]
,(select T_NUM_ from ADM_MST_TAILS where UNIT_ID =  dbo.D16_GetRootAcftUnitId(ac.ID_)) as [Computed Attached to Tail/ROOT_ACFT_UNIT_ID]
,parent_item.PART_NO_ as [Parent Part Number]
,parent_mfr.CAGE_CODE_ as [Parent Manufacture Code]
, parent_unit.SERIAL_NO_ as [Parent Serial No]
, parent_wuc.CODE_ as [Parent WUC]
,child_item.PART_NO_ as [Child Part Number]
,child_mfr.CAGE_CODE_ as [Child Manufacture Code]
, child_wuc.CODE_ as [Child WUC]
, child_unit.SERIAL_NO_ as [Child Serial No]
, mc.LEVEL_ as [Level]
from MNT_TRN_D16_ASSIGNED_COMPONENT ac
join MNT_MST_D16_MASTER_COMPONENT mc on ac.MASTER_COMP_ID_ = mc.ID_
join MNT_MST_D16_COMPONENT parent_comp on parent_comp.ID_ = ac.PARENT_COMP_ID_
join MNT_MST_D16_COMPONENT child_comp on child_comp.ID_ = ac.COMP_ID_
join ADM_MST_UNITS parent_unit on parent_unit.ID_ = parent_comp.UNIT_ID_
join ADM_MST_UNITS child_unit on child_unit.ID_ = child_comp.UNIT_ID_
join ADM_MST_ITEMS parent_item on parent_item.ID_ = parent_unit.ITEM_ID
join ADM_MST_ITEMS child_item on child_item.ID_ = child_unit.ITEM_ID
left join ADM_MST_MANUFACTURES parent_mfr on parent_mfr.ID_ = parent_item.MNF_ID
left join ADM_MST_MANUFACTURES child_mfr on child_mfr.ID_ = child_item.MNF_ID
left join MNT_MST_D16_WORK_UNIT_CODE parent_wuc on mc.PRNT_WUC_ID_ = parent_wuc.ID_
left join MNT_MST_D16_WORK_UNIT_CODE child_wuc on mc.WUC_ID_ = child_wuc.ID_
left join ADM_MST_TAILS t on t.UNIT_ID = ac.ACFT_UNIT_ID_
go

