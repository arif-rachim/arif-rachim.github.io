CREATE FUNCTION [dbo].[GetStoreStockAvailableQty]
(
	-- Add the parameters for the function here
	@ItemId		int,
	@FulfillingAgl2		int,
	@FulfillingCommand int = 0,
	@StoreType varchar(10)
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @result int
    
    -- Add the T-SQL statements to compute the return value here
    
    
    SELECT     @result = case when SUM(S.QTY_) is null then 0 else  SUM(S.QTY_) end
               FROM   LOG_TRN_STOCK AS S INNER JOIN
                      ADM_MST_UNIT_LOCATION AS UL ON S.LOC_ID = UL.ID_ INNER JOIN
                      ADM_MST_UNIT_LOCATION_GROUP AS ULG ON UL.LG_ID = ULG.ID_ INNER JOIN
                      ADM_MST_BUSINESS_UNITS AS BU ON ULG.BU_ID = BU.ID_ INNER JOIN
                      ADM_MST_UNITS AS U ON S.UNIT_ID = U.ID_ INNER JOIN
                      ADM_XRF_ADM_MST_BUSINESS_GROUP_ADM_TRN_ASSOC_GROUPS ON 
                      BU.BUG_ID = ADM_XRF_ADM_MST_BUSINESS_GROUP_ADM_TRN_ASSOC_GROUPS.BUG_ID INNER JOIN
                      ADM_MST_BUSINESS_GROUP ON 
                      ADM_XRF_ADM_MST_BUSINESS_GROUP_ADM_TRN_ASSOC_GROUPS.BUG_ID = ADM_MST_BUSINESS_GROUP.ID_ INNER JOIN
                      ADM_MST_ITEMS AS I ON U.ITEM_ID = I.ID_ 
                      AND I.ID_ = @ItemId AND ADM_XRF_ADM_MST_BUSINESS_GROUP_ADM_TRN_ASSOC_GROUPS.AG_ID = @FulfillingAgl2
                      AND ADM_MST_BUSINESS_GROUP.CMD_ID = @FulfillingCommand
                      AND STORE_TYPE_=@StoreType
   
	-- Return the result of the function
	RETURN @result
END
go

