CREATE FUNCTION [dbo].[GetIndentItemAlcStatus]
(
	@indentItemId uniqueidentifier
)
RETURNS nvarchar(255)
AS
BEGIN
	DECLARE @result nvarchar(10)
	DECLARE @maxRequestId bigint
	DECLARE @indentItemLineNo int

	SELECT @maxRequestId = MAX(IXTB.TB_REQUEST_ID), @indentItemLineNo = MAX(IDNTI.LINE_NO_)
		FROM LOG_XRF_INDENT_TADBEER_REQUEST IXTB
		INNER JOIN LOG_TRN_PRC_INDENT_ITEM IDNTI ON IDNTI.INDENT_ID = IXTB.INDENT_ID
		WHERE IDNTI.ID_ = @indentItemId

	SELECT @result = (CASE WHEN TBR.STATUS_ = 'E' THEN 'Failed' ELSE 'Success' END)
	FROM ADM_TRN_INT_ESNAAD_TADBEER_RESPONSE TBR
	WHERE TBR.REQ_ID_ = @maxRequestId AND (CAST(TBR.EXT_ID2_ AS INT) / 10) = @indentItemLineNo

	RETURN @result
END
go

