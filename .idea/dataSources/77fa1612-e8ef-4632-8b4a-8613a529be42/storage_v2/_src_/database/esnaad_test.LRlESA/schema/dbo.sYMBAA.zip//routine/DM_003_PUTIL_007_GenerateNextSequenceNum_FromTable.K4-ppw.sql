
-- ==========================================================================================
-- Author:		GAL2723
-- Create date: 19-Mar-2014
-- Description:	Generate next sequence number from string
-- Ex: EXEC DM_003_PUTIL_007_GenerateNextSequenceNum_FromTable @sequenceCode = 'SI'
/*
Ex: 	
declare @newSeqNumStr VARCHAR(MAX)
EXEC DM_003_PUTIL_007_GenerateNextSequenceNum_FromTable @sequenceCode = 'SI', @newSeqNumStr_OUT = @newSeqNumStr OUTPUT;
print @newSeqNumStr
*/
-- ==========================================================================================

CREATE PROCEDURE DM_003_PUTIL_007_GenerateNextSequenceNum_FromTable
	 @sequenceCode VARCHAR(MAX)
	,@newSeqNumStr_OUT VARCHAR(1024) OUTPUT
AS
BEGIN

	SET NOCOUNT ON;

	SET @sequenceCode = RTRIM(LTRIM(@sequenceCode));
	IF (@sequenceCode IS NULL) OR (@sequenceCode = '')
	BEGIN
		-- Invalid call, STOP
		RETURN
	END

--declare	@sequenceCode VARCHAR(MAX) = 'SI';

--	DECLARE @newSeqNumStr_OUT VARCHAR(1024);
	
	DECLARE @currentYear INT;
	DECLARE @newSeqNum INT;
	DECLARE @padFormat VARCHAR(MAX);
	DECLARE @padLength INT;
	
	-- ########################### Get padding from last entered year's rec ########################### _START
	SET @padFormat = NULL;
	
	SELECT TOP(1) @padFormat = PAD_FORMAT_
	FROM ADM_MST_SEQ_ANNUAL_SEQUENCE
	WHERE CODE_ = @sequenceCode
	ORDER BY YEAR_ DESC
	
	IF @padFormat IS NULL
	BEGIN
		SET @padFormat = 
			CASE @sequenceCode
				WHEN 'CLT' THEN 'D3'
				WHEN 'AF' THEN 'D6'
				WHEN 'SI' THEN 'D6'
				WHEN 'DR' THEN 'D6'
				WHEN 'RQ' THEN 'D6'
				WHEN 'IDNT' THEN 'D6'
				WHEN 'RFQ' THEN 'D6'
				WHEN 'BA' THEN 'D6'
				WHEN 'RBA' THEN 'D6'
				WHEN 'TI' THEN 'D5'
				WHEN 'TR' THEN 'D6'
				WHEN 'TRF' THEN 'D6'
				WHEN 'TV' THEN 'D6'
				WHEN 'GV' THEN 'D6'
				WHEN 'RRFQ' THEN 'D6'
			END
	END
	
	SET @padLength = SUBSTRING(@padFormat, 2, LEN(@padFormat))
	-- ########################### Get padding from last entered year's rec ########################### _END
	
	SET @currentYear = YEAR(GETDATE());
	SET @newSeqNum = NULL;
	
	SELECT @newSeqNum = LAST_SEQ_ + 1
	FROM ADM_MST_SEQ_ANNUAL_SEQUENCE
	WHERE
		CODE_ = @sequenceCode
		AND YEAR_ = @currentYear
		
	IF @newSeqNum IS NULL
	BEGIN
		
		SET @newSeqNum = 1
		
		INSERT INTO ADM_MST_SEQ_ANNUAL_SEQUENCE
		(
			VERSION_
			,YEAR_
			,CODE_
			,LAST_SEQ_
			,PAD_FORMAT_
			,SEQ_TYPE_
			,CMD_CODE_
		)
		VALUES
		(
			1
			,@currentYear
			,@sequenceCode
			,@newSeqNum
			,@padFormat
			,'Normal'
			,NULL
		)
	END
	
	ELSE
	BEGIN
		UPDATE ADM_MST_SEQ_ANNUAL_SEQUENCE
		SET
			VERSION_ = VERSION_ + 1
			 ,LAST_SEQ_ = @newSeqNum
		WHERE
			CODE_ = @sequenceCode 
			AND YEAR_ = @currentYear
	END
	
	SET @newSeqNumStr_OUT = @sequenceCode + CAST(@currentYear AS VARCHAR) + RIGHT('00000000000' + RTRIM(CAST(@newSeqNum AS VARCHAR)), @padLength);
END

/*

EXEC DM_003_PUTIL_007_GenerateNextSequenceNum_FromTable @sequenceCode = 'SI'
	
*/
go

