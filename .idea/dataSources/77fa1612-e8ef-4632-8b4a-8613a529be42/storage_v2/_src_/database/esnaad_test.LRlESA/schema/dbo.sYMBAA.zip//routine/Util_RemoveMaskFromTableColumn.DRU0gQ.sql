
-- =============================================
-- Date			: 20-May-2021
-- Description	: Remove mask from a table column
-- @schemaName	: Schema of table to remove mask from
-- @tableName	: Table to remove mask from
-- @columnName	: Column to remove mask from
-- Example		: EXEC Util_RemoveMaskFromTableColumn @schemaName = 'dbo', @tableName = 'sensitive_table1', @columnName = 'sensitive_column1';
-- =============================================

CREATE   PROCEDURE Util_RemoveMaskFromTableColumn
	@schemaName VARCHAR(MAX),
	@tableName	VARCHAR(MAX),
	@columnName	VARCHAR(MAX),
	@maskType	VARCHAR(MAX) = 'DEFAULT'
AS
BEGIN
	IF EXISTS
	(
		SELECT 1
		FROM sys.masked_columns c
		JOIN sys.tables t ON c.object_id = t.object_id
		JOIN sys.schemas s ON t.schema_id = s.schema_id
		WHERE s.name = @schemaName
		AND t.name = @tableName
		AND c.name = @columnName
	)
	BEGIN
		DECLARE @sqlTxt NVARCHAR(MAX) = '
		ALTER TABLE ' + @schemaName + '.' + @tableName
		+ ' ALTER COLUMN ' + @columnName
		+ ' DROP MASKED'
		;

		EXEC sp_executesql @sqlTxt;
	END
	ELSE
	BEGIN
		PRINT 'Column does not have a mask attached to it (' + @schemaName + '.' + @tableName + '.' + @columnName + ')';
	END
END
go

