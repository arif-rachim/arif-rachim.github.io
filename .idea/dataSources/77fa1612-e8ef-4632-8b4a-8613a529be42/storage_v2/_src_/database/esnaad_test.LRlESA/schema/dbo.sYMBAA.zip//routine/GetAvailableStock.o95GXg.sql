CREATE FUNCTION [dbo].[GetAvailableStock]
(
      @itemId					bigint,
      @agl2Id					int,
      @buId						int, 
	  @includeInlieuItemStock	bit = 0,
	  @includeAllStoreStock		bit = 0,
	  @cmdId					int
)
RETURNS int
AS
BEGIN
      
	DECLARE @stockInBu int
	DECLARE @stockInSubStore int = 0
	DECLARE @stockInParentStore int = 0
	DECLARE @stockInAllRelatedStore int = 0
	DECLARE @TagcolorConditionId tinyint = 1 --seviceable 

	DECLARE @IsParentStore bit = 1 --
	DECLARE @ParentStoreId bigint = 1  

    DECLARE @ItemIds TABLE (ITEM_ID BIGINT);

	--DECLARE @cmdIdAsc int

	--select top(1) @cmdIdAsc = ID_ from ADM_MST_RESTRICTIONS where SHARED_SERVICES_ = 1 and IS_ACTIVE_=1

	select @ParentStoreId = bu.PARENT_STORE_ID_  from ADM_MST_BUSINESS_UNITS bu where ID_ = @buId;


    INSERT @ItemIds
    --if in lieu stock is requested, include all the in lieu item ids
    SELECT il.ITEM_ID
      FROM ADM_TRN_ITEM_ASSOCS ia
           JOIN ADM_TRN_ITEM_ASSOCS il ON ia.IN_LIEU_CODE_ = il.IN_LIEU_CODE_
     WHERE ia.ITEM_ID = @itemId
       AND ia.L2_ID = @agl2Id
       AND ia.IN_LIEU_CODE_ IS NOT NULL 
       AND @includeInlieuItemStock = 1
     UNION 
    --always include the input item id so that even if the above section returns null
    --the @ItemIds will have input item id
    --union makes sure the input item id is not duplicated
    SELECT @itemId;

	--select stock for the @buid
	SELECT    
		@stockInBu= SUM(stk.QTY_) 
		--'select stock for the @buid', stk.STORE_ID,  stk.OWNED_BY_L2_ID_, stk.TAG_COLOR_COND_ID_, SUM(stk.QTY_) 
	FROM  
					@ItemIds AS il
		INNER JOIN  ADM_MST_UNITS AS un ON il.ITEM_ID = un.ITEM_ID 
		INNER JOIN  LOG_TRN_STOCK AS stk ON un.ID_ = stk.UNIT_ID AND  (stk.TAG_COLOR_COND_ID_ =	1) 
		INNER JOIN  ADM_MST_UNIT_LOCATION AS ul ON stk.LOC_ID = ul.ID_ AND ul.LOC_TYPE_ IN ('Regular','Receiving')

	WHERE 
			 --( stk.OWNED_BY_L2_ID_ = CASE WHEN @cmdIdAsc <> @cmdId THEN @agl2Id ELSE stk.OWNED_BY_L2_ID_ END )
		--AND  
		(stk.STORE_ID					=	@buId) 
		AND  (stk.TAG_COLOR_COND_ID_		=	@TagcolorConditionId) 
		AND NOT EXISTS (SELECT 1 FROM LOG_TRN_SII_INSTORE_UNIT_INSPECTION AS UN_INSP WHERE (IS_ACTIVE_ = 1) AND (WO_NO_ IS NOT NULL) AND UN_INSP.UNIT_ID = stk.UNIT_ID)
		AND dateadd(d, datediff(d,0,ISNULL(un.EXP_DATE_, getdate() +1)),0) >= dateadd(d, datediff(d,0,getdate()),0)
        OPTION (FORCE ORDER);
    
	--print '@stockInBu ' + cast(@stockInBu as nvarchar(10))
	if(@includeAllStoreStock = 1)
	BEGIN

		if(@ParentStoreId is null)
		begin
			--select stock for the substores of @buid 
			SELECT    
				@stockInAllRelatedStore= SUM(stk.QTY_) 
				--'select stock for the substores of @buid',  stk.OWNED_BY_L2_ID_, stk.TAG_COLOR_COND_ID_, SUM(stk.QTY_) --,stk.STORE_ID 
			 FROM  
							@ItemIds AS il 
				INNER JOIN  ADM_MST_UNITS AS un ON il.ITEM_ID = un.ITEM_ID
				INNER JOIN  LOG_TRN_STOCK AS stk ON un.ID_ = stk.UNIT_ID AND  (stk.TAG_COLOR_COND_ID_ =	1) 
				INNER JOIN  ADM_MST_UNIT_LOCATION AS ul ON stk.LOC_ID = ul.ID_ AND ul.LOC_TYPE_ IN ('Regular','Receiving')
				INNER JOIN	ADM_MST_BUSINESS_UNITS sst ON stk.STORE_ID = sst.ID_

			 WHERE 
					 --( stk.OWNED_BY_L2_ID_ = CASE WHEN @cmdIdAsc <> @cmdId THEN @agl2Id ELSE stk.OWNED_BY_L2_ID_ END )
				--AND  
				(sst.PARENT_STORE_ID_				=	@buId) 
				AND  (stk.TAG_COLOR_COND_ID_			=	@TagcolorConditionId) 
				AND NOT EXISTS (SELECT 1 FROM LOG_TRN_SII_INSTORE_UNIT_INSPECTION AS UN_INSP WHERE (IS_ACTIVE_ = 1) AND (WO_NO_ IS NOT NULL) AND UN_INSP.UNIT_ID = stk.UNIT_ID)
				AND dateadd(d, datediff(d,0,ISNULL(un.EXP_DATE_, getdate() +1)),0) >= dateadd(d, datediff(d,0,getdate()),0)
                OPTION (FORCE ORDER);


		end
		else
		begin
			--select stock for the related substores of @buid , @ParentStoreId of @buid
			SELECT    
					@stockInSubStore= SUM(stk.QTY_) 
					--'select stock for the related substores of @buid',  stk.OWNED_BY_L2_ID_, stk.TAG_COLOR_COND_ID_, SUM(stk.QTY_)  --,stk.STORE_ID
			FROM  
							@ItemIds AS il
				INNER JOIN  ADM_MST_UNITS AS un ON il.ITEM_ID = un.ITEM_ID
				INNER JOIN  LOG_TRN_STOCK AS stk ON un.ID_ = stk.UNIT_ID AND  (stk.TAG_COLOR_COND_ID_		=	1) 
				INNER JOIN  ADM_MST_UNIT_LOCATION AS ul ON stk.LOC_ID = ul.ID_ AND ul.LOC_TYPE_ IN ('Regular','Receiving')
				INNER JOIN	ADM_MST_BUSINESS_UNITS sst ON stk.STORE_ID = sst.ID_

			WHERE 
	 				 --( stk.OWNED_BY_L2_ID_ = CASE WHEN @cmdIdAsc <> @cmdId THEN @agl2Id ELSE stk.OWNED_BY_L2_ID_ END )
				--AND  
				(sst.PARENT_STORE_ID_				=	@ParentStoreId) 
				AND  (stk.TAG_COLOR_COND_ID_			=	@TagcolorConditionId) 
				AND  sst.ID_							<>	@buId 
				AND NOT EXISTS (SELECT 1 FROM LOG_TRN_SII_INSTORE_UNIT_INSPECTION AS UN_INSP WHERE (IS_ACTIVE_ = 1) AND (WO_NO_ IS NOT NULL) AND UN_INSP.UNIT_ID = stk.UNIT_ID)
				AND dateadd(d, datediff(d,0,ISNULL(un.EXP_DATE_, getdate() +1)),0) >= dateadd(d, datediff(d,0,getdate()),0)
                OPTION (FORCE ORDER);
			

			--select stock for the parent store @buid , @ParentStoreId of @buid
			SELECT    
				@stockInParentStore = SUM(stk.QTY_)
				--'select stock for the parent store of @buid', stk.STORE_ID,  stk.OWNED_BY_L2_ID_, stk.TAG_COLOR_COND_ID_, SUM(stk.QTY_)  
			FROM  
							@ItemIds AS il
				INNER JOIN  ADM_MST_UNITS AS un ON il.ITEM_ID = un.ITEM_ID
				INNER JOIN  LOG_TRN_STOCK AS stk ON un.ID_ = stk.UNIT_ID AND  (stk.TAG_COLOR_COND_ID_		=	1) 
				INNER JOIN  ADM_MST_UNIT_LOCATION AS ul ON stk.LOC_ID = ul.ID_ AND ul.LOC_TYPE_ IN ('Regular','Receiving')

			WHERE 
					 --( stk.OWNED_BY_L2_ID_ = CASE WHEN @cmdIdAsc <> @cmdId THEN @agl2Id ELSE stk.OWNED_BY_L2_ID_ END )
				--AND  
				(stk.STORE_ID							=	@ParentStoreId) 
				AND  (stk.TAG_COLOR_COND_ID_			=	@TagcolorConditionId) 
				AND  stk.STORE_ID							<>	@buId 
				AND NOT EXISTS (SELECT 1 FROM LOG_TRN_SII_INSTORE_UNIT_INSPECTION AS UN_INSP WHERE (IS_ACTIVE_ = 1) AND (WO_NO_ IS NOT NULL) AND UN_INSP.UNIT_ID = stk.UNIT_ID)
				AND dateadd(d, datediff(d,0,ISNULL(un.EXP_DATE_, getdate() +1)),0) >= dateadd(d, datediff(d,0,getdate()),0)
                OPTION (FORCE ORDER);


			SET @stockInAllRelatedStore = ISNULL(@stockInSubStore,0) + ISNULL(@stockInParentStore,0)				
		end
		SET @stockInBu = ISNULL(@stockInBu,0) + ISNULL(@stockInAllRelatedStore,0)
	END
	RETURN ISNULL(@stockInBu,0)
END
go

