CREATE FUNCTION [dbo].[GetAllDaysInAMonth]
(
	@year bigint,
	@month bigint
)
RETURNS TABLE
AS
RETURN
(
WITH numbers
as
(
Select 1 as value
UNION ALL
Select value+1 from numbers WHERE  value+1 <= Day(EOMONTH(datefromparts(@year, @month, 1)))
)
Select DATEFROMPARTS(@year, @month, numbers.value) dateum from numbers
)
go

