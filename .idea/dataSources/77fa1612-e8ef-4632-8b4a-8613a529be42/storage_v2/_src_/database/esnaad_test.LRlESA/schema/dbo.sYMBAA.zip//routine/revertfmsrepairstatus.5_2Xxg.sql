
CREATE Procedure revertfmsrepairstatus 
--@repairfile varchar(100) 
AS
Begin

create table #repairfiles
(
repairfile varchar(100) COLLATE DATABASE_DEFAULT
);
insert into #repairfiles (repairfile) values 
('AH-64D/2020/000352'),
('AH-64D/2020/000360'),
('AH-64D/2019/001704'),
('AH-64D/2019/001651'),
('AH-64D/2019/001563'),
('AH-64D/2019/001320'),
('AH-64D/2019/001287'),
('AH-64D/2019/001286'),
('AH-64D/2019/000926'),
('AH-64D/2019/000686'),
('AH-64D/2019/000252')

delete  from LOG_TRN_ROM_REPAIR_ORDER_ITEM where REPAIR_FILE_REF_ in 
(
	select repairfile from #repairfiles
)

delete  from LOG_TRN_RPR_FMS_DOCUMENT where REPAIR_FILE_ID in 
(
	select ID_ from LOG_TRN_RPR_REPAIR_FILE where REPAIR_FILE_NO_ in 
	(
		select repairfile from #repairfiles
	)
);

delete from LOG_HST_RPR_REPAIR_FILE where REPAIR_FILE_NO_ in 
(
	select repairfile from #repairfiles
)
and STATUS_ <> 'RepairFileCreated';

delete from LOG_TRN_RPR_REPAIR_FILE_TADBEER_INTEGRATION where id_ in 
(
	select ID_  from LOG_TRN_RPR_REPAIR_FILE where REPAIR_FILE_NO_ in 
	(
		select repairfile from #repairfiles
	)
);

update LOG_TRN_RPR_REPAIR_FILE set status_='RepairFileCreated' where REPAIR_FILE_NO_ in 
(
	select repairfile from #repairfiles
)
and status_='FMSDocumentRequested';

drop table #repairfiles

End
exec revertfmsrepairstatus


go

